package com.ailk.emcc.action.cdrServ;

import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.annotation.ParamType;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.xdr.CdrDis;
import jef.http.server.actions.ServletExchange;
import jef.codegen.support.NotModified;
@NotModified
public interface CdrServAction{

	public Map<String,List> qryCdrByWechatId(@Param("wechatId") String wechatId,@Param("startDate") String startDate,@Param("endDate") String endDate,@Param("combineFlag") Boolean combineFlag);
	public List<CdrDis> qryCdrByAct(@Param("acctId") Long acctId,@Param("startDate") String startDate,@Param("endDate") String endDate,@Param("combineFlag") Boolean combineFlag);
	public void getPic(@Param("picKey") String picKey,ServletExchange exchange);

}