package com.ailk.emcc.action.userServ;

import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.annotation.ParamType;
import com.ailk.emcc.busi.user.UserInfo;
import java.util.List;
import jef.codegen.support.NotModified;
@NotModified
public interface UserServAction{

	public UserInfo getMyProfile(@Param("wechatId") String wechatId);
	public Boolean bindWechat(@Param("openId") String openId,@Param("acctId") Long acctId);
	public List<UserInfo> getActList(@Param("mobile") String mobile,@Param("code") String code);

}