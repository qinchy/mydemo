package com.ailk.emcc.action.billServ;

import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.annotation.ParamType;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.bill.BillDis;
import jef.codegen.support.NotModified;
@NotModified
public interface BillServAction{

	public Map<String,List> qryBillByWechatId(@Param("startMonth") String startMonth,@Param("endMonth") String endMonth,@Param("wechatId") String wechatId);
	public Map<String,List> qryBillHisByWechatId(@Param("wechatId") String wechatId,@Param("startMonth") String startMonth,@Param("endMonth") String endMonth);
	public List<BillDis> qryBillByAct(@Param("startMonth") String startMonth,@Param("endMonth") String endMonth,@Param("acctId") Long acctId);

}