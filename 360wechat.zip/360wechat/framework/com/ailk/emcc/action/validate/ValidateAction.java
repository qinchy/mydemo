package com.ailk.emcc.action.validate;

import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.annotation.ParamType;
import jef.codegen.support.NotModified;
@NotModified
public interface ValidateAction{

	public String getValidateCode(@Param("mobile") String mobile,@Param("wechatId") String wechatId);
	public Boolean validateCode(@Param("code") String code,@Param("mobile") String mobile);
	public String getOpenIdByCode(@Param("wechatCode") String wechatCode);

}