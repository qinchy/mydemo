package com.ailk.emcc.service.cdrServ;

import jef.codegen.support.NotModified;
@NotModified
public abstract class CdrServServiceSkeleton implements CdrServService{


}