package com.ailk.emcc.service.cdrServ;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.WebServiceProvider;
import javax.jws.WebParam;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.xdr.CdrDis;
import jef.codegen.support.NotModified;
@NotModified
@WebService
@WebServiceProvider(portName="CdrServService")
public interface CdrServServiceWs{

	@WebMethod
	public Map<String,List> qryCdrByWechatId(@WebParam(name = "wechatId") String wechatId,@WebParam(name = "startDate") String startDate,@WebParam(name = "endDate") String endDate,@WebParam(name = "combineFlag") Boolean combineFlag);
	@WebMethod
	public List<CdrDis> qryCdrByAct(@WebParam(name = "acctId") Long acctId,@WebParam(name = "startDate") String startDate,@WebParam(name = "endDate") String endDate,@WebParam(name = "combineFlag") Boolean combineFlag);

}