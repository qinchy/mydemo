package com.ailk.emcc.service.cdrServ;

import com.ailk.easyframe.web.common.dal.IService;
import org.springframework.transaction.annotation.Transactional;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.xdr.CdrDis;
import jef.codegen.support.NotModified;
@NotModified
@Transactional
public interface CdrServService extends IService{

	/**
	 * 
	 * @param wechatId  
	 * @param startDate  
	 * @param endDate  
	 * @param combineFlag  
	 * @return 
	 */
	public Map<String,List> qryCdrByWechatId(String wechatId,String startDate,String endDate,Boolean combineFlag);
	/**
	 * 
	 * @param acctId  
	 * @param startDate  
	 * @param endDate  
	 * @param combineFlag  
	 * @return 
	 */
	public List<CdrDis> qryCdrByAct(Long acctId,String startDate,String endDate,Boolean combineFlag);

}