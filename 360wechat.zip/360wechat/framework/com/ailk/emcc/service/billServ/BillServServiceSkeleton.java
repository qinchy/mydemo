package com.ailk.emcc.service.billServ;

import jef.codegen.support.NotModified;
@NotModified
public abstract class BillServServiceSkeleton implements BillServService{


}