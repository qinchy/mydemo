package com.ailk.emcc.service.billServ;

import com.ailk.easyframe.web.common.dal.IService;
import org.springframework.transaction.annotation.Transactional;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.bill.BillDis;
import jef.codegen.support.NotModified;
@NotModified
@Transactional
public interface BillServService extends IService{

	/**
	 * 
	 * @param startMonth  
	 * @param endMonth  
	 * @param wechatId  
	 * @return 
	 */
	public Map<String,List> qryBillByWechatId(String startMonth,String endMonth,String wechatId);
	/**
	 * 
	 * @param wechatId  
	 * @param startMonth  
	 * @param endMonth  
	 * @return 
	 */
	public Map<String,List> qryBillHisByWechatId(String wechatId,String startMonth,String endMonth);
	/**
	 * 
	 * @param startMonth  
	 * @param endMonth  
	 * @param acctId  
	 * @return 
	 */
	public List<BillDis> qryBillByAct(String startMonth,String endMonth,Long acctId);

}