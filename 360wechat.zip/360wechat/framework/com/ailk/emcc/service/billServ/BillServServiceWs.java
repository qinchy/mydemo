package com.ailk.emcc.service.billServ;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.WebServiceProvider;
import javax.jws.WebParam;
import java.util.Map;
import java.util.List;
import com.ailk.emcc.busi.bill.BillDis;
import jef.codegen.support.NotModified;
@NotModified
@WebService
@WebServiceProvider(portName="BillServService")
public interface BillServServiceWs{

	@WebMethod
	public Map<String,List> qryBillByWechatId(@WebParam(name = "startMonth") String startMonth,@WebParam(name = "endMonth") String endMonth,@WebParam(name = "wechatId") String wechatId);
	@WebMethod
	public Map<String,List> qryBillHisByWechatId(@WebParam(name = "wechatId") String wechatId,@WebParam(name = "startMonth") String startMonth,@WebParam(name = "endMonth") String endMonth);
	@WebMethod
	public List<BillDis> qryBillByAct(@WebParam(name = "startMonth") String startMonth,@WebParam(name = "endMonth") String endMonth,@WebParam(name = "acctId") Long acctId);

}