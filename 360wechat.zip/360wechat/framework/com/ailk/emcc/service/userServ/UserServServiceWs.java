package com.ailk.emcc.service.userServ;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.WebServiceProvider;
import javax.jws.WebParam;
import com.ailk.emcc.busi.user.UserInfo;
import java.util.List;
import jef.codegen.support.NotModified;
@NotModified
@WebService
@WebServiceProvider(portName="UserServService")
public interface UserServServiceWs{

	@WebMethod
	public UserInfo getMyProfile(@WebParam(name = "wechatId") String wechatId);
	@WebMethod
	public Boolean bindWechat(@WebParam(name = "openId") String openId,@WebParam(name = "acctId") Long acctId);
	@WebMethod
	public List<UserInfo> getActList(@WebParam(name = "mobile") String mobile,@WebParam(name = "code") String code);

}