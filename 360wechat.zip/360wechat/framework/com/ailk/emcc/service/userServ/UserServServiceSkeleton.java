package com.ailk.emcc.service.userServ;

import jef.codegen.support.NotModified;
@NotModified
public abstract class UserServServiceSkeleton implements UserServService{


}