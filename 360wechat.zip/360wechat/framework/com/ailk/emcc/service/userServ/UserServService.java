package com.ailk.emcc.service.userServ;

import com.ailk.easyframe.web.common.dal.IService;
import org.springframework.transaction.annotation.Transactional;
import com.ailk.emcc.busi.user.UserInfo;
import java.util.List;
import jef.codegen.support.NotModified;
@NotModified
@Transactional
public interface UserServService extends IService{

	/**
	 * 
	 * @param wechatId  
	 * @return 
	 */
	public UserInfo getMyProfile(String wechatId);
	/**
	 * 
	 * @param openId  
	 * @param acctId  
	 * @return 
	 */
	public Boolean bindWechat(String openId,Long acctId);
	/**
	 * 
	 * @param mobile  
	 * @param code  
	 * @return 
	 */
	public List<UserInfo> getActList(String mobile,String code);

}