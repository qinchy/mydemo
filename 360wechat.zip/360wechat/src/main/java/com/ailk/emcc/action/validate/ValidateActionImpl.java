package com.ailk.emcc.action.validate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ailk.easyframe.web.action.BaseAction;
import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.service.user.BaseUserService;
import com.ailk.emcc.util.common.Config;
import com.ailk.emcc.util.validate.Auth;
import com.ailk.emcc.util.validate.Generate;
import com.alibaba.fastjson.JSONObject;
import com.ailk.easyframe.web.common.annotation.ParamType;
public class ValidateActionImpl extends BaseAction implements ValidateAction{


	@Autowired
	private BaseUserService user_baseUserService;

	Log log = LogFactory.getLog(ValidateActionImpl.class);

	public BaseUserService getUser_baseUserService() {
		return user_baseUserService;
	}

	public void setUser_baseUserService(BaseUserService user_baseUserService) {
		this.user_baseUserService = user_baseUserService;
	}

	/*public String getValidateCode(@Param("acctId") String acctId,
			@Param("wechatId") String wechatId) {
		HttpServletRequest request = ContextHolder.getRequestContext()
				.getRequest();
		HttpSession session = request.getSession();
		session.setMaxInactiveInterval(300);
		Validate vd = new Validate();
		vd.setOpenId(wechatId);
		vd.setCode(Generate.generateCode());
		// TODO send code
		session.setAttribute(acctId, vd);
		return wechatId;
	}*/

	
	
	/*public Boolean validateCode(@Param("code") String code,
			@Param("acctId") String acctId) {
		HttpServletRequest request = ContextHolder.getRequestContext()
				.getRequest();
		HttpSession session = request.getSession();
		Validate vd = (Validate) session.getAttribute(acctId);
		if (vd == null) {
			return false;
		}
		if (vd.getCode().equals(code)) {
			return true;
		} else {
			return false;
		}
	}*/

	public String getOpenIdByCode(@Param("wechatCode") String wechatCode) {
		if (StringUtils.isNotEmpty(wechatCode) && !"null".equals(wechatCode)) {
			return Auth.getOpenIdByCode(wechatCode);
		} else {
			log.info("-------------没有获得code从配置文件读openId--------------");
			return 	Config.getValue("test_openId");
		}
	}

	public String getValidateCode(@Param("mobile") String mobile,@Param("wechatId") String wechatId){
		ContextHolder.setTenantId(22L);
		Boolean existAcct = user_baseUserService.qryContactByMobile(mobile, wechatId);
		if(!existAcct){
			return "-1";
		}
		HttpServletRequest request = ContextHolder.getRequestContext()
				.getRequest();
		HttpSession session = request.getSession();
		session.setMaxInactiveInterval(300);
		Validate vd = new Validate();
		vd.setOpenId(wechatId);
		vd.setCode(Generate.generateCode());
		// TODO send code
		session.setAttribute(mobile, vd);
		return wechatId;
	}

	public Boolean validateCode(@Param("code") String code,@Param("mobile") String mobile){
		HttpServletRequest request = ContextHolder.getRequestContext()
				.getRequest();
		HttpSession session = request.getSession();
		Validate vd = (Validate) session.getAttribute(mobile);
		if (vd == null) {
			return false;
		}
		if (vd.getCode().equals(code)) {
			return true;
		} else {
			return false;
		}
	}


	class Validate {
		String openId;
		String code;
		Long acctId;

		public String getOpenId() {
			return openId;
		}

		public void setOpenId(String openId) {
			this.openId = openId;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public Long getAcctId() {
			return acctId;
		}

		public void setAcctId(Long acctId) {
			this.acctId = acctId;
		}

	}

}