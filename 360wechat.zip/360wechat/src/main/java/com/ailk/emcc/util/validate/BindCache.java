package com.ailk.emcc.util.validate;


public interface BindCache {
	public void put(String key,BindEntity bind);
	public BindEntity get(String key);
	public void remove(String key);
}
