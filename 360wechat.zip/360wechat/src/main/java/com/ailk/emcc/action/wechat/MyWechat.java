package com.ailk.emcc.action.wechat;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoader;
import org.sword.wechat4j.WechatSupport;
import org.sword.wechat4j.message.CustomerMsg;
import org.sword.wechat4j.request.WechatRequest;

import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.busi.bill.BillBusi;
import com.ailk.emcc.service.bill.BaseBillService;
import com.ailk.emcc.service.qryBill.QryBillService;
import com.ailk.emcc.service.user.BaseUserService;
import com.ailk.emcc.service.userServ.UserServService;
import com.ailk.emcc.util.common.Config;
import com.ailk.emcc.util.validate.BindCache;
import com.ailk.emcc.util.validate.BindEntity;
import com.ailk.emcc.util.validate.Generate;

/**
 * 微信服务桩
 * 
 * @author ChengNing
 * @date 2015年1月7日
 */
public class MyWechat extends WechatSupport {
	private static Logger logger = Logger.getLogger(MyWechat.class);
	Log log = LogFactory.getLog(MyWechat.class);
	@Autowired
	public MyWechat(HttpServletRequest request) {
		super(request);
	}

	/**
	 * 文本消息
	 */
	@Override
	protected void onText() {
	/*	if (wechatRequest != null
				&& StringUtils.isNotEmpty(wechatRequest.getContent())) {
			String content = wechatRequest.getContent().trim();
			if (StringUtils.isNotEmpty(content)
					&& (content.indexOf("账户") > -1
							|| content.indexOf("账号") > -1 || (content
							.indexOf("帐户") > -1 || content.indexOf("帐号") > -1))) {
				responseText("请在收到短信验证码后填写验证码");
			} else if (content.contains("账单")) {
				responseText("请稍候，您的账单马上送上");
			} else if(StringUtils.isNotEmpty(content)&&content.length()==6&&content.matches("^[0-9]{6}$")){
				responseText("校验中...请稍后");
			} else {
				responseText("很抱歉，微信还没开通这个服务呢");
			}

		}*/
	}


	/**
	 * 图片消息
	 */
	@Override
	protected void onImage() {
		/*
		 * String picUrl = wechatRequest.getPicUrl(); String MediaId =
		 * wechatRequest.getMediaId(); String MsgId = wechatRequest.getMsgId();
		 * 
		 * String result = "图片消息picUrl:" + picUrl + ", MediaId:" + MediaId +
		 * ", MsgId:" + MsgId; logger.info(result); responseText(result); //
		 * responseImage(mediaId);
		 */}

	/**
	 * 语音消息
	 */
	@Override
	protected void onVoice() {
		/*
		 * String Format = wechatRequest.getFormat(); String MediaId =
		 * wechatRequest.getMediaId();// 视频消息媒体id，可以调用多媒体文件下载接口拉取数据 String MsgId
		 * = wechatRequest.getMsgId();
		 * 
		 * String result = "语音消息Format:" + Format + ", MediaId:" + MediaId +
		 * ", MsgId:" + MsgId; logger.info(result); responseText(result); //
		 * responseVoice(mediaId);
		 * 
		 * // 回复音乐消息 // MusicResponse music = new MusicResponse(); //
		 * music.setTitle(title); // music.setDescription(description); //
		 * music.setMusicURL(musicURL); // music.setHQMusicUrl(hQMusicUrl); //
		 * music.setThumbMediaId(thumbMediaId); // responseMusic(music); // //
		 * responseMusic(title, description, musicURL, hQMusicUrl, //
		 * thumbMediaId);
		 */}

	/**
	 * 视频消息
	 */
	@Override
	protected void onVideo() {
		/*
		 * String ThumbMediaId = wechatRequest.getThumbMediaId(); String MediaId
		 * = wechatRequest.getMediaId();// 语音消息媒体id，可以调用多媒体文件下载接口拉取数据 String
		 * MsgId = wechatRequest.getMsgId();
		 * 
		 * String result = "视频消息ThumbMediaId:" + ThumbMediaId + ", MediaId:" +
		 * MediaId + ", MsgId:" + MsgId; logger.info(result);
		 * responseText(result);
		 * 
		 * // 回复视频消息 // VideoResponse video = new VideoResponse(); //
		 * video.setTitle(title); // video.setDescription(description); //
		 * video.setMediaId(mediaId); // responseVideo(video); // //
		 * responseVideo(mediaId, title, description);
		 */}

	/**
	 * 地理位置消息
	 */
	@Override
	protected void onLocation() {
		/*
		 * String Location_X = wechatRequest.getLocation_X(); String Location_Y
		 * = wechatRequest.getLocation_Y(); String Scale =
		 * wechatRequest.getScale(); String Label = wechatRequest.getLabel();
		 * String MsgId = wechatRequest.getMsgId();
		 * 
		 * String result = "地理位置消息Location_X:" + Location_X + ", Location_Y:" +
		 * Location_Y + ", Scale:" + Scale + ", Label:" + Label + ", MsgId:" +
		 * MsgId; logger.info(result); responseText(result);
		 */
	}

	/**
	 * 链接消息
	 */
	@Override
	protected void onLink() {
		/*
		 * String Title = wechatRequest.getTitle(); String Description =
		 * wechatRequest.getDescription(); String Url = wechatRequest.getUrl();
		 * String MsgId = wechatRequest.getMsgId();
		 * 
		 * String result = "链接消息Title:" + Title + ", Description:" + Description
		 * + ", Url:" + Url + ", MsgId:" + MsgId; logger.info(result);
		 * responseText(result);
		 */
	}

	/**
	 * 未知消息类型，错误处理
	 */
	@Override
	protected void onUnknown() {
		/*
		 * String msgType = wechatRequest.getMsgType();
		 * 
		 * String result = "未知消息msgType:" + msgType; logger.info(result);
		 * responseText(result);
		 */

	}

	/**
	 * 扫描二维码事件
	 */
	@Override
	protected void scan() {
		/*
		 * String FromUserName = wechatRequest.getFromUserName(); String Ticket
		 * = wechatRequest.getTicket();
		 * 
		 * String result = "扫描二维码事件FromUserName:" + FromUserName + ", Ticket:" +
		 * Ticket; logger.info(result); responseText(result);
		 */
	}

	/**
	 * 订阅事件
	 */
	@Override
	protected void subscribe() {
		// String result = "欢迎加入新奥燃气，为了方便使用，请您输入“账户 xxx”，完成绑定";
		String result = Config.getValue("wechat_welcome");
		log.info("-----------get wechat_welcome from config-------------- "+result);
		responseText(result);
	}

	/**
	 * 取消订阅事件
	 */
	@Override
	protected void unSubscribe() {
		/*
		 * String FromUserName = wechatRequest.getFromUserName(); String result
		 * = "取消订阅事件FromUserName:" + FromUserName; logger.info(result);
		 * responseText(result);
		 */
	}

	/**
	 * 点击菜单跳转链接时的事件推送
	 */
	@Override
	protected void view() {
		/*
		 * String link = super.wechatRequest.getEventKey();
		 * logger.info("点击菜单跳转链接时的事件推送link:" + link);
		 * responseText("点击菜单跳转链接时的事件推送link:" + link);
		 */
	}

	/**
	 * 自定义菜单事件
	 */
	@Override
	protected void click() {
		ContextHolder.requestInit();
		if(ContextHolder.getTenantId()==0||ContextHolder.getTenantId()==-1){
			ContextHolder.setTenantId(22L);
		}
		String key = super.wechatRequest.getEventKey();
		String fromOpen = wechatRequest.getFromUserName();
		if (key.equals("V1001_MY_PROFILE")) {
			ApplicationContext act = ContextLoader
					.getCurrentWebApplicationContext();
			UserServService userServ_userServService = (UserServService) act
					.getBean("userServ_userServService");
			//TODO 
			responseText("");
		}
	}

	/**
	 * 上报地理位置事件
	 */
	@Override
	protected void location() {
		/*
		 * String Latitude = wechatRequest.getLatitude(); String Longitude =
		 * wechatRequest.getLongitude(); String Precision =
		 * wechatRequest.getPrecision(); String result = "上报地理位置事件Latitude:" +
		 * Latitude + ", Longitude:" + Longitude + ", Precision:" + Precision;
		 * logger.info(result); responseText(result);
		 */
	}

	/**
	 * 模板消息发送成功推送事件
	 */
	@Override
	protected void templateMsgCallback() {
		/*
		 * String MsgID = wechatRequest.getMsgId(); String Status =
		 * wechatRequest.getStatus(); String result = "模板消息发送成功推送事件MsgID:" +
		 * MsgID + ", Status:" + Status; logger.info(result);
		 */
	}

	/**
	 * 弹出地理位置选择器的事件
	 */
	@Override
	protected void locationSelect() {
		/*
		 * String Location_X =
		 * wechatRequest.getSendLocationInfo().getLocation_X(); String
		 * Location_Y = wechatRequest.getSendLocationInfo().getLocation_Y();
		 * String Scale = wechatRequest.getSendLocationInfo().getScale(); String
		 * Label = wechatRequest.getSendLocationInfo().getLabel(); String
		 * Poiname = wechatRequest.getSendLocationInfo().getPoiname(); String
		 * result = "弹出地理位置选择器的事件Location_X:" + Location_X + ", Location_Y:" +
		 * Location_Y + ", Scale:" + Scale + ", Label:" + Label + ", Poiname:" +
		 * Poiname; logger.info(result); responseText(result);
		 */
	}

	/**
	 * 弹出拍照或者相册发图的事件
	 */
	@Override
	protected void picPhotoOrAlbum() {
		/*
		 * String Count = wechatRequest.getSendPicsInfo().getCount(); String
		 * PicMd5Sum = ""; if (StringUtils.isNotBlank(Count) &&
		 * !Count.equals("0")) { PicMd5Sum =
		 * wechatRequest.getSendPicsInfo().getItem().get(0) .getPicMd5Sum(); }
		 * String result = "弹出系统拍照发图的事件Count:" + Count + ", PicMd5Sum:" +
		 * PicMd5Sum; logger.info(result); responseText(result);
		 */
	}

	/**
	 * 弹出系统拍照发图的事件
	 */
	@Override
	protected void picSysPhoto() {
		/*
		 * String Count = wechatRequest.getSendPicsInfo().getCount(); String
		 * result = "弹出系统拍照发图的事件Count:" + Count; logger.info(result);
		 * responseText(result);
		 */
	}

	/**
	 * 弹出微信相册发图器的事件推送
	 */
	@Override
	protected void picWeixin() {
		/*
		 * String Count = wechatRequest.getSendPicsInfo().getCount(); String
		 * result = "弹出系统拍照发图的事件Count:" + Count; logger.info(result);
		 * responseText(result);
		 */
	}

	/**
	 * 扫码推事件
	 * 
	 */
	@Override
	protected void scanCodePush() {
		/*
		 * String ScanType = wechatRequest.getScanCodeInfo().getScanType();
		 * String ScanResult = wechatRequest.getScanCodeInfo().getScanResult();
		 * String result = "扫码推事件ScanType:" + ScanType + ", ScanResult:" +
		 * ScanResult; logger.info(result); responseText(result);
		 */
	}

	/**
	 * 扫码推事件且弹出“消息接收中”提示框的事件
	 */
	@Override
	protected void scanCodeWaitMsg() {
		/*
		 * String ScanType = wechatRequest.getScanCodeInfo().getScanType();
		 * String ScanResult = wechatRequest.getScanCodeInfo().getScanResult();
		 * String result = "扫码推事件ScanType:" + ScanType + ", ScanResult:" +
		 * ScanResult; logger.info(result); responseText(result);
		 */
	}
}
