package com.ailk.emcc.util.validate;

import java.net.URI;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Protocol;

public class MyJedisPool extends JedisPool {
	private String host = "unknow";
	private int port = 0;
	
	public String getHost() {
		return host;
	}

	public int getPort() {
		return port;
	}

	public MyJedisPool() {
		super();
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host, int port, int timeout, String password,
			int database, String clientName) {
		super(poolConfig, host, port, timeout, password, database, clientName);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host, int port, int timeout, String password,
			int database) {
		super(poolConfig, host, port, timeout, password, database);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host, int port, int timeout, String password) {
		super(poolConfig, host, port, timeout, password);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host, int port, int timeout) {
		super(poolConfig, host, port, timeout);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host, int port) {
		super(poolConfig, host, port);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, String host) {
		super(poolConfig, host);
		this.host = host;
		this.port = Protocol.DEFAULT_PORT;
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, URI uri, int timeout) {
		super(poolConfig, uri, timeout);
	}

	public MyJedisPool(GenericObjectPoolConfig poolConfig, URI uri) {
		super(poolConfig, uri);
	}

	public MyJedisPool(String host, int port) {
		super(host, port);
		this.host = host;
		this.port = port;
	}

	public MyJedisPool(String host) {
		super(host);
		this.host = host;
		this.port = Protocol.DEFAULT_PORT;
	}

	public MyJedisPool(URI uri, int timeout) {
		super(uri, timeout);
	}

	public MyJedisPool(URI uri) {
		super(uri);
	}
}
