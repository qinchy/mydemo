/**
 * 
 */
package com.ailk.emcc.action.wechat;

import org.sword.wechat4j.token.Token;
import org.sword.wechat4j.token.server.CustomerServer;

/**
 * @author repo_user
 * @date   2015年1月12日
 */
public class CustomerAccessTokenServer extends CustomerServer {
	private static Token token;
	/* (non-Javadoc)
	 * @see org.sword.wechat4j.token.DbAccessTokenServer#find()
	 */
	@Override
	public String find() {
		return token.getToken();
	}

	/* (non-Javadoc)
	 * @see org.sword.wechat4j.token.DbAccessTokenServer#save()
	 */
	@Override
	public boolean save(Token accessToken) {
		token =accessToken;
		return true;
	}
}
