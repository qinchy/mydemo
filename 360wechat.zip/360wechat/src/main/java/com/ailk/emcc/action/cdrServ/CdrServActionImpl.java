package com.ailk.emcc.action.cdrServ;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ailk.easyframe.web.action.BaseAction;
import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.emcc.busi.xdr.CdrDis;
import com.ailk.emcc.service.cdrServ.CdrServService;
import com.taobao.common.tfs.TfsManager;
import com.ailk.easyframe.web.common.annotation.ParamType;

import jef.http.server.actions.ServletExchange;
public class CdrServActionImpl extends BaseAction implements CdrServAction{


	Log log = LogFactory.getLog(CdrServActionImpl.class);

	@Autowired
	TfsManager tfsManager;

	@Autowired
	protected CdrServService cdrServ_cdrServService;

	public void setCdrServ_cdrServService(CdrServService obj){
		this.cdrServ_cdrServService = obj;
	}

	public CdrServService getCdrServ_cdrServService(){
		return cdrServ_cdrServService;
	}

	protected CdrServService getCrudService(){
		return cdrServ_cdrServService;
	}

	public TfsManager getTfsManager() {
		return tfsManager;
	}

	public void setTfsManager(TfsManager tfsManager) {
		this.tfsManager = tfsManager;
	}

	public Map<String,List> qryCdrByWechatId(@Param("wechatId") String wechatId,@Param("startDate") String startDate,@Param("endDate") String endDate,@Param("combineFlag") Boolean combineFlag){
		return  cdrServ_cdrServService.qryCdrByWechatId(wechatId,startDate,endDate,combineFlag);
	}

	public List<CdrDis> qryCdrByAct(@Param("acctId") Long acctId,@Param("startDate") String startDate,@Param("endDate") String endDate,@Param("combineFlag") Boolean combineFlag){
		return cdrServ_cdrServService.qryCdrByAct(acctId,startDate,endDate,combineFlag);
	}

	public void getPic(@Param("picKey") String picKey,ServletExchange exchange){
		try {
			exchange.getResponse().setContentType("image/jpg");
			tfsManager.fetchFile(picKey, null, exchange.getResponse().getOutputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}