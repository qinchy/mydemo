package com.ailk.emcc.action.userServ;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ailk.easyframe.web.action.BaseAction;
import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.busi.user.UserInfo;
import com.ailk.emcc.service.userServ.UserServService;
public class UserServActionImpl extends BaseAction implements UserServAction{


	@Autowired
	protected UserServService userServ_userServService;

	public void setUserServ_userServService(UserServService obj){
		this.userServ_userServService = obj;
	}

	public UserServService getUserServ_userServService(){
		return userServ_userServService;
	}

	protected UserServService getCrudService(){
		return userServ_userServService;
	}

	public UserInfo getMyProfile(@Param("wechatId") String wechatId){
		ContextHolder.setTenantId(22L);
		return userServ_userServService.getMyProfile(wechatId);
	}

	public Boolean bindWechat(@Param("openId") String openId,@Param("acctId") Long acctId){
		ContextHolder.setTenantId(22L);
		return userServ_userServService.bindWechat(openId,acctId);
	}

	public List<UserInfo> getActList(@Param("mobile") String mobile,@Param("code") String code){
		return userServ_userServService.getActList(mobile,code);
	}

}