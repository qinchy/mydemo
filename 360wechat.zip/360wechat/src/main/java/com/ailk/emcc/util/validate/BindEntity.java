package com.ailk.emcc.util.validate;

import java.io.Serializable;

public class BindEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2996566424064761162L;
	private long custId;
	private long acctId;
	private String code;
	private long createTime = System.currentTimeMillis();
	private long expireTime;
	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		this.custId = custId;
	}
	public long getAcctId() {
		return acctId;
	}
	public void setAcctId(long acctId) {
		this.acctId = acctId;
	}
	public long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}
	public long getExpireTime() {
		return expireTime;
	}
	public void setExpireTime(long expireTime) {
		this.expireTime = expireTime;
	}
	public BindEntity(long custId, long acctId, String code, long createTime,
			long expireTime) {
		super();
		this.custId = custId;
		this.acctId = acctId;
		this.code = code;
		this.createTime = createTime;
		this.expireTime = expireTime;
	}
	public BindEntity(long acctId, String code) {
		super();
		this.acctId = acctId;
		this.code = code;
		this.createTime = System.currentTimeMillis();
		//code validate in 5 min
		this.expireTime = createTime+5*60*1000;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
