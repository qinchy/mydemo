package com.ailk.emcc.action.wechat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.sword.lang.JaxbParser;
import org.sword.lang.StreamUtils;
import org.sword.wechat4j.common.Config;
import org.sword.wechat4j.common.ValidateSignature;
import org.sword.wechat4j.param.SignatureParam;
import org.sword.wechat4j.request.WechatRequest;

import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.service.userServ.UserServService;

/**
 * Servlet implementation class WechatServlet
 */
public class WeChatServlet extends HttpServlet{
	Log log = LogFactory.getLog(WeChatServlet.class);
	private static List<WechatRequest>  requested= new ArrayList<WechatRequest>();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public WeChatServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		log.info("-------------------------------request from wechat---------------");
		SignatureParam param = new SignatureParam(request);
	//	log.info(JSON.toJSONString(request));
		String signature = param.getSignature();
		String timestamp = param.getTimestamp();
		String nonce = param.getNonce();
		String echostr = param.getEchostr();
		String token = Config.instance().getToken();

		ValidateSignature validateSignature = new ValidateSignature(signature,
				timestamp, nonce, token);
		String result = "";
		if (!(validateSignature.check())) {
			result = "error";
		}
		if (StringUtils.isNotBlank(echostr)) {
			result = echostr;
		}
		response.reset();
		response.getWriter().write(result);
		response.flushBuffer();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		JaxbParser jaxbParser = new JaxbParser(WechatRequest.class);
		ContextHolder.requestInit();
		if(ContextHolder.getTenantId()==0||ContextHolder.getTenantId()==-1){
			ContextHolder.setTenantId(22L);
		}
		WechatRequest wq = ((WechatRequest)jaxbParser.toObj(StreamUtils.streamToString(request.getInputStream())));
		if(processFlag(wq)){
			MyWechat myWechat = new MyWechat(request);
			String res = myWechat.execute();
			response.getOutputStream().write(res.getBytes());
			response.getOutputStream().close();
			/*if(wq.getMsgType().equals("text")){
				myWechat.dealText(wq);
			}*/
		}
	
	}
	private boolean processFlag(WechatRequest wechatRequest){
		boolean flag = true;
		for(WechatRequest req:requested){
			if((req.getMsgId()!=null &&req.getMsgId().equals(wechatRequest.getMsgId()))||
					req.getCreateTime().equals(wechatRequest.getCreateTime())
					&&req.getFromUserName().equals(wechatRequest.getFromUserName())){
				flag = false;
			}
		}
		requested.add(wechatRequest);
		return flag;
	}

}
