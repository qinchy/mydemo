package com.ailk.emcc.service.userServ;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ailk.emcc.busi.user.UserInfo;
import com.ailk.emcc.persistence.user.entity.CaAccountMapping;
import com.ailk.emcc.service.user.BaseUserService;
import com.ailk.emcc.service.user.CaAccountMappingService;
import java.util.List;
@Transactional
public class UserServServiceImpl extends UserServServiceSkeleton{


	@Autowired
	private BaseUserService user_baseUserService;

	@Autowired
	private CaAccountMappingService user_caAccountMappingService;

	public BaseUserService getUser_baseUserService() {
		return user_baseUserService;
	}

	public void setUser_baseUserService(BaseUserService user_baseUserService) {
		this.user_baseUserService = user_baseUserService;
	}

	public CaAccountMappingService getUser_caAccountMappingService() {
		return user_caAccountMappingService;
	}

	public void setUser_caAccountMappingService(CaAccountMappingService user_caAccountMappingService) {
		this.user_caAccountMappingService = user_caAccountMappingService;
	}

	/**
	 * 
	 * @param wechatId  
	 * @return 
	 */
	public UserInfo getMyProfile(String wechatId){
		UserInfo userInfo = user_baseUserService.qryUserInfoByOpenId(wechatId);
		Map<Long,Long> actMapping = new HashMap<Long,Long>();
		userInfo.setAcctMapping(actMapping);
		Set<Long> accts = userInfo.getUsers().keySet();
		for(Long act:accts){
			CaAccountMapping map = user_caAccountMappingService.qryForignId(act);
			if(map!=null){
				actMapping.put(act, map.getForeignUserId());	
			}
		}
		return userInfo;
	}

	/**
	 * 
	 * @param openId  
	 * @param acctId  
	 */
	public Boolean bindWechat(String openId,Long acctId){
		return user_baseUserService.bindWechat(acctId, openId);
	}

	/**
	 * 
	 * @param mobile  
	 * @return 
	 */
	public List<UserInfo> getActList(String mobile){
		return user_baseUserService.qryActListByMobile(mobile);
	}

	/**
	 * 
	 * @param mobile  
	 * @param code  
	 * @return 
	 */
	public List<UserInfo> getActList(String mobile,String code){
		//TODO please implement this method for you business.
		return null;
	}


}