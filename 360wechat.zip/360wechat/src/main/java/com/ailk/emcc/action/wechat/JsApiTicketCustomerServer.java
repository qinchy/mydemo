package com.ailk.emcc.action.wechat;

import org.sword.wechat4j.token.Token;
import org.sword.wechat4j.token.server.CustomerServer;

public class JsApiTicketCustomerServer extends CustomerServer{
	private static Token token;
	public String find() {
		return token.getToken();
	}

	/* (non-Javadoc)
	 * @see org.sword.wechat4j.token.DbAccessTokenServer#save()
	 */
	@Override
	public boolean save(Token jsApiTicket) {
		token=jsApiTicket;
		return true;
	}

}
