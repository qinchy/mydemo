package com.ailk.emcc.service.cdrServ;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ailk.emcc.busi.xdr.CdrDis;
import com.ailk.emcc.service.qryCdr.QryCdrService;
@Transactional
public class CdrServServiceImpl extends CdrServServiceSkeleton{


	@Autowired
	private QryCdrService qryCdr_qryCdrService ;

	public QryCdrService getQryCdr_qryCdrService() {
		return qryCdr_qryCdrService;
	}

	public void setQryCdr_qryCdrService(QryCdrService qryCdr_qryCdrService) {
		this.qryCdr_qryCdrService = qryCdr_qryCdrService;
	}

	/**
	 * 
	 * @param wechatId  
	 * @param startDate  
	 * @param endDate  
	 * @param combineFlag  
	 * @return 
	 */
	public Map<String,List>  qryCdrByWechatId(String wechatId,String startDate,String endDate,Boolean combineFlag){
		List<CdrDis> list = qryCdr_qryCdrService.qryXdrByWechat(wechatId, startDate, endDate, combineFlag);
		Map<String,List> res = new HashMap<String, List>();
		for(CdrDis cdr:list){
			String act = cdr.getAcctId()+"";
			if(res.containsKey(act)){
				res.get(act).add(cdr);
			}else{
				List cdrs = new ArrayList();
				cdrs.add(cdr);
				res.put(act, cdrs);
			}
		}
		return res;
	}

	/**
	 * 
	 * @param acctId  
	 * @param startDate  
	 * @param endDate  
	 * @param combineFlag  
	 * @return 
	 */
	public List<CdrDis> qryCdrByAct(Long acctId,String startDate,String endDate,Boolean combineFlag){
		return qryCdr_qryCdrService.qryXdrByAct(startDate, endDate, acctId, combineFlag);
	}


}