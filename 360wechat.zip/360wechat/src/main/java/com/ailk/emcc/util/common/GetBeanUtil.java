package com.ailk.emcc.util.common;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


public class GetBeanUtil implements ApplicationContextAware {
	private static ApplicationContext act;

	public static ApplicationContext getContext() {
		return act;
	}

	@SuppressWarnings("unchecked")
	public static <X> X getBean(String beanName) {
		return (X) getContext().getBean(beanName);
	}

	@SuppressWarnings("static-access")
	public void setApplicationContext(ApplicationContext act)
			throws BeansException {
		updateAct(act);
	}
	
	private static void updateAct(ApplicationContext act){
		GetBeanUtil.act = act;
	}
}
