package com.ailk.emcc.service.billServ;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.busi.bill.BillBusi;
import com.ailk.emcc.busi.bill.BillDis;
import com.ailk.emcc.busi.user.UserInfo;
import com.ailk.emcc.persistence.bill.entity.BillCond;
import com.ailk.emcc.persistence.bill.entity.CaBill;
import com.ailk.emcc.persistence.bill.entity.CaBillUsage;
import com.ailk.emcc.persistence.bill.entity.CaCycleRun;
import com.ailk.emcc.service.bill.BaseBillService;
import com.ailk.emcc.service.qryBill.QryBillService;
import com.ailk.emcc.service.user.BaseUserService;
import com.ailk.emcc.util.date.DateUtil;
@Transactional
public class BillServServiceImpl extends BillServServiceSkeleton{


	@Autowired
	private QryBillService qryBill_qryBillService;

	@Autowired
	private BaseUserService user_baseUserService;

	@Autowired
	private BaseBillService bill_baseBillService;

	@Autowired
	private BillBusi qryBill_billBusi;

	/**
	 * 
	 * @param startMonth  
	 * @param endMonth  
	 * @param wechatId  
	 * @return 
	 */
	public Map<String,List> qryBillByWechatId(String startMonth,String endMonth,String wechatId){
		initTenant();
		UserInfo userInfo =  this.user_baseUserService.qryUserInfoByOpenId(wechatId);
		if(userInfo==null||userInfo.getUsers()==null||userInfo.getUsers().keySet()==null){
			return null;
		}
		Long acctId = null;
		Set<Long> actsUsers = userInfo.getUsers().keySet();
		for(Long act:actsUsers){
			if(acctId==null){
				acctId= act;
			}else{
				break;
			}
		}
		if(StringUtils.isEmpty(startMonth)&&StringUtils.isEmpty(endMonth)){
			CaCycleRun cycles = this.bill_baseBillService.qryLastBillCycle(acctId);
			if(cycles!=null){
				 int nextBill = cycles.getBillMonth();
				 if(nextBill>0){
					 endMonth=DateUtil.getPreMonth(nextBill+"");
					 startMonth = endMonth;
				 }
			}
		}
		
		BillCond billCond = preDate(startMonth, endMonth);
		BillCond prebillCond = this.preDateBefore(startMonth, endMonth);
		List<CaBill>  caBills =this.qryBill_qryBillService.qryOriBill(prebillCond, userInfo.getUsers().keySet());
		List<CaBillUsage> usages =qryBill_qryBillService.qryOriBillUsg(billCond, userInfo.getUsers().keySet());
		List<BillDis> diss = qryBill_billBusi.bill2Dis(caBills, usages, userInfo,Integer.parseInt(prebillCond.getStartDate()));
		Map<String,List> res= new HashMap<String, List>();
		for(BillDis bill:diss){
			String act = bill.getAccoutId()+"";
			if(res.containsKey(act)){
				res.get(act).add(bill);
			}else{
				List<BillDis> list = new ArrayList<BillDis>();
				list.add(bill);
				res.put(act, list );
			}
		}
		return res;
	}

	/**
	 * 
	 * @param wechatId  
	 * @param startMonth  
	 * @param endMonth  
	 * @return 
	 */
	public Map<String,List> qryBillHisByWechatId(String wechatId,String startMonth,String endMonth){
		initTenant();
		UserInfo userInfo =  this.user_baseUserService.qryUserInfoByOpenId(wechatId);
		if(userInfo==null||userInfo.getUsers()==null||userInfo.getUsers().keySet()==null){
			return null;
		}
		Long acctId = null;
		Set<Long> actsUsers = userInfo.getUsers().keySet();
		for(Long act:actsUsers){
			if(acctId==null){
				acctId= act;
			}else{
				break;
			}
		}
		if(StringUtils.isEmpty(startMonth)&&StringUtils.isEmpty(endMonth)){
			CaCycleRun cycles = this.bill_baseBillService.qryLastBillCycle(acctId);
			if(cycles!=null){
				 int nextBill = cycles.getBillMonth();
				 if(nextBill>0){
					 endMonth=DateUtil.getDifMonth(nextBill+"", -2);
					 startMonth = DateUtil.getDifMonth(endMonth, -5);
				 }
			}
		}
		
		BillCond billCond = preDate(startMonth, endMonth);
		BillCond prebillCond = this.preDateBefore(startMonth, endMonth);
		List<CaBill>  caBills =this.qryBill_qryBillService.qryOriBill(prebillCond, userInfo.getUsers().keySet());
		List<CaBillUsage> usages =qryBill_qryBillService.qryOriBillUsg(billCond, userInfo.getUsers().keySet());
		List<BillDis> diss = qryBill_billBusi.bill2Dis(caBills, usages, userInfo,Integer.parseInt(prebillCond.getStartDate()));
		Map<String,List> res = new HashMap<String, List>();
		for(BillDis b:diss){
			String act = b.getAccoutId()+"";
			if(res.containsKey(act)){
				res.get(act).add(b);
			}else{
				List value = new ArrayList();
				value.add(b);
				res.put(act, value);
			}
		}
		return res;
	}

	/**
	 * 
	 * @param startMonth  
	 * @param endMonth  
	 * @param acctId  
	 * @return 
	 */
	public List<BillDis> qryBillByAct(String startMonth,String endMonth,Long acctId){
		initTenant();
		UserInfo userInfo = this.user_baseUserService.qryUserInfoByAct(acctId);
		BillCond billCond = preDate(startMonth, endMonth);
		BillCond prebillCond = this.preDateBefore(startMonth, endMonth);
		List<CaBill>  caBills =this.qryBill_qryBillService.qryOriBill(prebillCond, userInfo.getUsers().keySet());
		List<CaBillUsage> usages =qryBill_qryBillService.qryOriBillUsg(billCond, userInfo.getUsers().keySet());
		return qryBill_billBusi.bill2Dis(caBills, usages, userInfo,Integer.parseInt(prebillCond.getStartDate()));
	}

	public BillBusi getQryBill_billBusi() {
		return qryBill_billBusi;
	}

	public void setQryBill_billBusi(BillBusi qryBill_billBusi) {
		this.qryBill_billBusi = qryBill_billBusi;
	}

	public QryBillService getQryBill_qryBillService() {
		return qryBill_qryBillService;
	}

	public void setQryBill_qryBillService(QryBillService qryBill_qryBillService) {
		this.qryBill_qryBillService = qryBill_qryBillService;
	}

	public BaseUserService getUser_baseUserService() {
		return user_baseUserService;
	}

	public void setUser_baseUserService(BaseUserService user_baseUserService) {
		this.user_baseUserService = user_baseUserService;
	}

	public BaseBillService getBill_baseBillService() {
		return bill_baseBillService;
	}

	public void setBill_baseBillService(BaseBillService bill_baseBillService) {
		this.bill_baseBillService = bill_baseBillService;
	}

	/**
	 * 
	 * @param startMonth
	 * @param endMonth
	 * @return
	 */
	private BillCond preDate(String startMonth, String endMonth) {
		// log.info(JsonUtil.serialize(userInfo));
		BillCond billCond = new BillCond();
		if (StringUtils.isNotEmpty(startMonth)
				&& StringUtils.isNotEmpty(endMonth)) {
			billCond.setStartDate(startMonth);
			billCond.setEndDate(endMonth);
		} else if (StringUtils.isNotEmpty(endMonth)) {
			billCond.setStartDate(endMonth);
			billCond.setEndDate(endMonth);
		} else if (StringUtils.isNotEmpty(startMonth)) {
			billCond.setStartDate(startMonth);
			billCond.setEndDate(startMonth);
		} else {
			return null;
		}
		return billCond;
	}

	private BillCond preDateBefore(String startMonth, String endMonth) {
		// log.info(JsonUtil.serialize(userInfo));
		BillCond billCond = new BillCond();
		if (StringUtils.isNotEmpty(startMonth)
				&& StringUtils.isNotEmpty(endMonth)) {
			billCond.setStartDate(DateUtil.getPreMonth(startMonth));
			billCond.setEndDate(endMonth);
		} else if (StringUtils.isNotEmpty(endMonth)) {
			billCond.setStartDate(DateUtil.getPreMonth(endMonth));
			billCond.setEndDate(endMonth);
		} else if (StringUtils.isNotEmpty(startMonth)) {
			billCond.setStartDate(DateUtil.getPreMonth(startMonth));
			billCond.setEndDate(startMonth);
		} else {
			return null;
		}
		return billCond;
	}

	private void initTenant() {
		if (ContextHolder.getTenantId() == 0
				|| ContextHolder.getTenantId() == -1) {
			ContextHolder.setTenantId(22L);
		}
	}


}