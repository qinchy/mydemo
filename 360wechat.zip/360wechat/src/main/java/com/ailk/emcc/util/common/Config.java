/**
 * $Id: DBMConfig.java 355660 2013-08-16 09:49:08Z dongjf3 $
 */

package com.ailk.emcc.util.common;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import jef.jre5support.Properties;
import jef.tools.IOUtils;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ResourceUtils;

import com.ailk.easyframe.web.common.session.ContextHolder;

/**
 * @version 2.0
 */
public final class Config {
	@Autowired
	private static org.sword.wechat4j.common.Config wechat_config;
	
	public static org.sword.wechat4j.common.Config getWechat_config() {
		return wechat_config;
	}

	public static void setWechat_config(
			org.sword.wechat4j.common.Config wechat_config) {
		Config.wechat_config = wechat_config;
	}

	private static Logger log = LoggerFactory.getLogger(Config.class);

	// 所有配置常量名都定义在这里
	public static final String DB_DRIVERCLASSNAME = "db.driverClassName";
	public static final String DB_URL = "db.url";
	public static final String DB_USERNAME = "db.username";
	public static final String DB_PASSWORD = "db.password";
	public static final String DB_SCHEMA_MAPPING = "db.schema.mapping";
	public static final String DB_TYPE = "db.type";

	// 单点登录配置
	public static final String SSO_LOGIN_TYPE = "sso.login.type";
	// 权限数据配置
	public static final String PRIV_DATA_TYPE1 = "priv.data.type";
	public static final String SSO_AICAS_PRE = "sso.client.";
	// crm web服务地址
	public static final String CRM_WEBSERVICE = "crm.webservice";
	// 客户端应用ID,将根据此ID获取配置ID的菜单、权限数据
	public static final String SYSTEM_ID = "systemId";
	public static final String USE_CRM_STYLE = "use_crm_style";

	// 用户、系统菜单、系统权限列表、用户权限操作信息
	public static final String USER_DETAIL = "USER_DETAIL";
	public static final String SYSTEM_MENU = "SYSTEM_MENU";// 系统菜单框架用com.ailk.easyframe.web.common.auth.entity.SysMenu
	public static final String USER_MENU = "USER_MENU";// 用户有权菜单框架用com.ailk.easyframe.web.common.auth.entity.SysMenu
	public static final String PAGE_MENU = "PAGE_MENU";// 页面展示的菜单系管用com.ailk.sysmgnt.persistence.menu.entity.SysMenu
	public static final String PAGE_ALLMENU = "PAGE_ALLMENU";// 包括所有语言
	public static final String SYSTEM_PRIVS = "SYSTEM_PRIVS";
	public static final String USER_PRIV_TYPE = "USER_PRIV_TYPE";
	public static final String USER_PRIVSTRATEGY_TYPE = "USER_PRIVSTRATEGY_TYPE";
	public static final String USER_PRIV_ACTION = "USER_PRIV_ACTION";
	public static final String TFS_MAXWAITTHREAD = "tfs.maxWaitThread";
	public static final String TFS_TIMEOUT = "tfs.timeout";
	public static final String TFS_NSIP = "tfs.nsip";
	public static final String TFS_TFSCLUSTERINDEX = "tfs.tfsClusterIndex";
	public static final String TFS_MAXCACHEITEMCOUNT = "tfs.maxCacheItemCount";
	public static final String TFS_MAXCACHETIME = "tfs.maxCacheTime";

	// 多数据源情况下，默认的读取参数配置的数据库
	public static String DATASOURCE_ID = "";

	// 保存系统属性的地方
	private static Properties CONFIG_PROPERTIES = null;

	public static boolean containsKey(String key) {
		return CONFIG_PROPERTIES.containsKey(key);
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 */
	public static void setValue(String key, String value) {
		CONFIG_PROPERTIES.setProperty(key, value);
	}

	public static String getValue(String key) {
		return StringUtils.defaultString(getProperties().getProperty(key), "");
	}

	public static String getValue(String key, String defaultVal) {
		return StringUtils.defaultString(getProperties().getProperty(key),
				defaultVal);
	}

	private static Properties getProperties() {
		if (null == CONFIG_PROPERTIES) {
			CONFIG_PROPERTIES = new Properties();
			initProperties();
		}
		return CONFIG_PROPERTIES;
	}

	public static void initProperties() {
		// 加载本地配置
		loadProperties1("/AppConfig.properties");

		// 加载服务器环境变量中配置：AppConfig
		String configPath = System.getenv("AppConfig");
		log.info("env AppConfig path is:" + configPath);
		if (StringUtils.isNotEmpty(configPath)) {
			try {
				File pFile = ResourceUtils.getFile(configPath);
				if (pFile.exists()) {
					loadProperties(configPath);
				}
			} catch (Exception e) {
				log.error(
						"read file error,please check the file:" + configPath,
						e);
			}
		}
		if(!StringUtils.isEmpty(getValue("wechat.appid"))){
			log.info("------------get wechat.appid from system Appconfig------------");
			wechat_config.instance().setAppid(getValue("wechat.appid"));
		}
		if(!StringUtils.isEmpty(getValue("wechat.appsecret"))){
			log.info("------------get wechat.appsecret from system Appconfig------------");
			wechat_config.instance().setAppSecret(getValue("wechat.appsecret"));
		}
		if(!StringUtils.isEmpty(getValue("wechat.url"))){
			log.info("------------get wechat.url from system Appconfig------------");
			wechat_config.instance().setUrl(getValue("wechat.url"));
		}
		if(!StringUtils.isEmpty(getValue("wechat.token"))){
			log.info("------------get wechat.token from system Appconfig------------");
			wechat_config.instance().setToken(getValue("wechat.token"));
		}
		
	}

	private static void loadProperties1(String fileName) {
		URL configUrl = null;
		try {
			configUrl = Config.class.getResource(fileName);
			File pFile = IOUtils.urlToFile(configUrl);
			CONFIG_PROPERTIES.load(IOUtils.getReader(pFile, "UTF-8"));
			log.info("read properties from file:" + configUrl + pFile);
		} catch (Exception e) {
			log.error("read properties error,please check file:" + configUrl);
		}
	}

	private static void loadProperties(String path) {
		try {
			File pFile = ResourceUtils.getFile(path);
			CONFIG_PROPERTIES.load(IOUtils.getReader(pFile, "UTF-8"));
			log.info("read properties from file:" + path);
		} catch (Exception e) {
			log.error("read properties error,please check file:" + path, e);
		}
	}

	public static void logProperties() {
		log.info("appconfig.properties values...");
		try {
			for (Object key : CONFIG_PROPERTIES.keySet()) {
				if (!key.toString().contains("_db.")) {
					log.info(key + "="
							+ CONFIG_PROPERTIES.getProperty((String) key));
				}
			}
		} catch (Exception ex) {
			log.error("read properties error", ex);
		}
	}
}
