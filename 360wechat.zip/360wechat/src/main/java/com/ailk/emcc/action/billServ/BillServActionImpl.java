package com.ailk.emcc.action.billServ;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ailk.easyframe.web.action.BaseAction;
import com.ailk.easyframe.web.common.annotation.Param;
import com.ailk.emcc.busi.bill.BillDis;
import com.ailk.emcc.service.billServ.BillServService;
import com.ailk.emcc.util.common.Config;
public class BillServActionImpl extends BaseAction implements BillServAction{


	Log log = LogFactory.getLog(BillServActionImpl.class);

	@Autowired
	private BillServService billServ_billServService;

	public Map<String,List> qryBillByWechatId(@Param("startMonth") String startMonth,@Param("endMonth") String endMonth,@Param("wechatId") String wechatId){
			return billServ_billServService.qryBillByWechatId(startMonth, endMonth, wechatId);
	}

	public Map<String,List> qryBillHisByWechatId(@Param("wechatId") String wechatId,@Param("startMonth") String startMonth,@Param("endMonth") String endMonth){
		if(StringUtils.isEmpty(wechatId)){
			wechatId = Config.getValue("test_openId");
		}
		return billServ_billServService.qryBillHisByWechatId(wechatId, startMonth, endMonth);	
	}

	public List<BillDis> qryBillByAct(@Param("startMonth") String startMonth,@Param("endMonth") String endMonth,@Param("acctId") Long acctId){
		return billServ_billServService.qryBillByAct(startMonth, endMonth, acctId);
	}

	public BillServService getBillServ_billServService() {
		return billServ_billServService;
	}

	public void setBillServ_billServService(BillServService billServ_billServService) {
		this.billServ_billServService = billServ_billServService;
	}

	protected BillServService getCrudService(){
		return billServ_billServService;
	}


}