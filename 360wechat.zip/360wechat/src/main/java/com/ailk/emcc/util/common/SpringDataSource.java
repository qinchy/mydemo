/**
  * $Id: SpringDataSource.java 239975 2012-11-14 06:27:52Z wangyl9 $
  */

package com.ailk.emcc.util.common;


import java.io.IOException;
import java.sql.SQLException;

import jef.database.DbUtils;
import jef.tools.JefConfiguration;
import jef.tools.JefConfiguration.Item;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.ailk.easyframe.web.common.exception.BusinessException;

public class SpringDataSource extends DriverManagerDataSource{
	
	private Logger log = LoggerFactory.getLogger(SpringDataSource.class);
	
	/**
	 * 1.系统启动加载该bean时就会读取配置文件获取数据库配置信息 
	 * 有待优化
	 * @throws SQLException 
	 * @throws Exception 
	 **/
	public SpringDataSource(String sid) throws IOException, SQLException{
		String sidTemp = sid;
		if( StringUtils.isEmpty( sidTemp ) ){
			sidTemp = "";
		}
		else{
			sidTemp = sidTemp + "_";
		}
		
		log.info("sid is:" + sidTemp);
		String driverClassName = Config.getValue( sidTemp + Config.DB_DRIVERCLASSNAME, "" );
		if( StringUtils.isEmpty( driverClassName ) ){
			driverClassName = Config.getValue( Config.DB_DRIVERCLASSNAME );
		}
		
		String url = Config.getValue( sidTemp + Config.DB_URL, "" );
		if( StringUtils.isEmpty( url ) ){
			url = Config.getValue( Config.DB_URL );
		}
		
		String userName = Config.getValue( sidTemp + Config.DB_USERNAME, "" );	
		if( StringUtils.isEmpty( userName ) ){
			userName = Config.getValue( Config.DB_USERNAME );	
		}
		
		String passWord = Config.getValue( sidTemp + Config.DB_PASSWORD, "" );
		if( StringUtils.isEmpty( passWord ) ){
			passWord = Config.getValue( Config.DB_PASSWORD );	
		}
		
		//数据库密码加密处理, 则说明没有加密
		if( JefConfiguration.getBoolean(JefConfiguration.Item.DB_PASSWORD_ENCRYPTED, false) ){	
			//系统需要加密，但是没有配置加密，则dbm再处理一下，支持测试、开发阶段
			if( passWord.equalsIgnoreCase( userName ) ){	
				//不加密，则如果
				passWord = DbUtils.ecrypt(passWord);
			}
		}
				
		//检查
		log.info("Database config detail: \n\tdriverClassName={}; \n\turl={}; \n\tuserName={}; \n\tpassWord=***", new Object[]{driverClassName, url, userName} );
		log.info("dbInfotyty:"+url+","+userName+","+passWord);
		this.setDriverClassName( driverClassName );
		this.setUrl( url );
		this.setUsername( userName );
		this.setPassword( passWord );
		
		updateFrameScheme(sidTemp);
	}	
	
	//更新框架数据库scheme
	private void updateFrameScheme(String sid){
		String schema_mapping = Config.getValue( sid+Config.DB_SCHEMA_MAPPING, "" );
		if( StringUtils.isEmpty( schema_mapping ) ){
			schema_mapping = Config.getValue( Config.DB_SCHEMA_MAPPING, "" );	
		}				
		try {
			// 数据库scheme影射db.schema.mapping
			if ( !StringUtils.isEmpty( schema_mapping ) ) {
				// 需要初始化一下JefConfiguration里面file
				String k = JefConfiguration.Item.SCHEMA_MAPPING.toString();				
				String key = StringUtils.replaceChars(k, "_$", ".-").toLowerCase();
				System.setProperty(key, schema_mapping);
			}
		} catch (Exception e) {
			log.warn("JefConfiguration.update failure: " + schema_mapping, e);
		};	
		
		//数据库类型jdbc:mysql
		String db_url = Config.getValue( sid+Config.DB_URL, "" );
		String k = JefConfiguration.Item.DB_TYPE.toString();	
		String key = StringUtils.replaceChars(k, "_$", ".-").toLowerCase();
		String dbType = "";
		if( db_url.startsWith("jdbc:mysql") ){
			dbType =  "mysql";
		}
		else if( db_url.startsWith("jdbc:oracle") ){
			dbType =  "oracle";
		}
		else{
			throw new BusinessException( "Unsupported database type for current version. db.url=" + db_url );
		}
		if( ! (JefConfiguration.get( Item.DB_TYPE ).equalsIgnoreCase( dbType ) ) ){	
			log.warn("The value :" + JefConfiguration.get( Item.DB_TYPE ) +" of db.type in jef.properties is not match the value:" + db_url +" of db.url in AppConfig.properties.");
			System.setProperty(key, dbType);
		}
		Config.setValue(Config.DB_TYPE, dbType);		
	}
}

