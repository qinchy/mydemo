package com.ailk.emcc.util.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.persistence.user.dao.CmContactDao;
import com.ailk.emcc.persistence.user.entity.CmContact;
import com.ailk.emcc.util.common.GetBeanUtil;
import com.ailk.emcc.util.validate.Auth;

public class BindFilter implements Filter {
	public static final String BIND_HTML="/bind.jsp";
	public static final String MEDIA_PAGE="tobind.html";

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String code = req.getParameter("code");
		String openId = req.getParameter("openId");
		if (StringUtils.isEmpty(code) && StringUtils.isEmpty(openId)) {
			res.sendRedirect(MEDIA_PAGE);
		}
		if(!StringUtils.isEmpty(code)){
			openId = Auth.getOpenIdByCode(code);
			if(StringUtils.isEmpty(openId)){
				res.sendRedirect(MEDIA_PAGE);
			}
		}
		if(!StringUtils.isEmpty(openId)){
			CmContactDao cnct= GetBeanUtil.getBean("user_cmContactDao");
			CmContact contact =new CmContact();
			contact.setWechatId(openId);
			contact.setContactType(1);
			ContextHolder.requestInit();
			ContextHolder.setTenantId(22L);
			List<CmContact> result = cnct.qryContact(contact );
			if(result!=null&&result.size()>0){
				req.setAttribute("openId", openId);
			}else{
				String lastUrl = req.getServletPath();
				if(!StringUtils.isEmpty(lastUrl)){
					lastUrl = lastUrl.substring(1, lastUrl.length());
				}
				res.sendRedirect(MEDIA_PAGE+"?openId="+openId+"&lastUrl="+lastUrl);
			}
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
