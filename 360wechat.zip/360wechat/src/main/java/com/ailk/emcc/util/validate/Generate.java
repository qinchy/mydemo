package com.ailk.emcc.util.validate;

import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Generate {
	Log log = LogFactory.getLog(Generate.class);
	public static String generateCode(){
		/*StringBuffer stb =new StringBuffer();
		for(int i=0;i<6;i++){
			stb.append((int)(Math.random()*10)%10);
		}
		return stb.toString();*/
		return "123456";
	}
	public static void main(String[] args) {
		Generate g =new Generate();
		System.out.print(g.generateCode());
	}
}
