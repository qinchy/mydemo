package com.ailk.emcc.util.validate;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import org.sword.wechat4j.common.Config;

import com.ailk.emcc.util.http.HttpKit;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class Auth {
	//https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code 
	private static final String ACCESS_TOKEN_URL="https://api.weixin.qq.com/sns/oauth2/access_token?";
	 public static String getOpenIdByCode(String code) {
		 String appid = Config.instance().getAppid();
		  String appsecret = Config.instance().getAppSecret();
		    String url =ACCESS_TOKEN_URL+"appid="+appid+"&secret="+appsecret+"&code="+code+"&grant_type=authorization_code";
		    String jsonStr;
			try {
				jsonStr = HttpKit.get(url);
				JSONObject json = JSON.parseObject(jsonStr);  
				return json == null ? "" : json.getString("openid");
			} catch (KeyManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchProviderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   return null;
	 }
	
}
