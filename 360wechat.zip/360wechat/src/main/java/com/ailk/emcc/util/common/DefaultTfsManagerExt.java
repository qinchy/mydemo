/**
 * 
 */
package com.ailk.emcc.util.common;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.taobao.common.tfs.DefaultTfsManager;

/**
 * @author zhangxl16
 *
 */
public class DefaultTfsManagerExt extends DefaultTfsManager {
	Log log = LogFactory.getLog(DefaultTfsManagerExt.class);
	public void init(){
		super.init();
		doRefresh();
	}

	private void doRefresh() {
		log.info("---------------init tfs server config-------------");
		log.info("---------------tfs ip config is"+Config.getValue(Config.TFS_NSIP)+"-------------");
		this.setMaxWaitThread(Integer.parseInt(Config.getValue(Config.TFS_MAXWAITTHREAD, "100")));
		this.setMaxCacheTime(Integer.parseInt(Config.getValue(Config.TFS_MAXCACHETIME, "100")));
		this.setMaxCacheItemCount(Integer.parseInt(Config.getValue(Config.TFS_MAXCACHEITEMCOUNT, "100")));
		this.setNsip(Config.getValue(Config.TFS_NSIP, "10.10.21.130:8100"));
		this.setTfsClusterIndex(Config.getValue(Config.TFS_MAXWAITTHREAD, "1").toCharArray()[0]);
		this.setTimeout(Integer.parseInt(Config.getValue(Config.TFS_TIMEOUT, "2000")));
		
	}
}
