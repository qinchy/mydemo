package com.ailk.emcc.util.validate;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import redis.clients.jedis.Jedis;

public class BindCacheImpl implements BindCache {
	Log log = LogFactory.getLog(BindCacheImpl.class);
	private MyJedisPool jedisPool;
	private int seconds = 6*60;

	public MyJedisPool getJedisPool() {
		return jedisPool;
	}

	public void setJedisPool(MyJedisPool jedisPool) {
		this.jedisPool = jedisPool;
	}

	@Override
	public void put(String key, BindEntity bind) {
		Jedis jedis = jedisPool.getResource();
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(bind);
			byte[] byteArray = bos.toByteArray();
			oos.close();
			bos.close();
			jedis .set(key.getBytes(), byteArray);
			jedis.expire(key, seconds);
			jedis.disconnect();
		} catch (IOException e) {
			log.error("put bind object in cache faild,wechatId is " + key);
			e.printStackTrace();
		}finally{
			jedis.close();
		}

	}

	@Override
	public BindEntity get(String key) {
		Jedis jedis = jedisPool.getResource();
		byte[] bs = jedis.get(key.getBytes());
		jedis.expire(key, seconds);
		ByteArrayInputStream bis = new ByteArrayInputStream(bs);
		try {
			ObjectInputStream inputStream = new ObjectInputStream(bis);
			BindEntity readObject = (BindEntity) inputStream.readObject();
			inputStream.close();
			bis.close();
			jedis.disconnect();
			return readObject;
		} catch (IOException e) {
			log.error("get bind object in cache faild,wechatId is " + key);
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			log.error("get bind object in cache faild,wechatId is " + key);
			e.printStackTrace();
		}finally{
			jedis.close();
		}
		return null;

	}

	@Override
	public void remove(String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.del(key);
		jedis.close();
	}

	public int getSeconds() {
		return seconds;
	}

	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}

}
