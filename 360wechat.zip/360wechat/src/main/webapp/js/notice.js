function delorcreat() 
{
	var has=2;
  if (has==1){
	  strdiv='<li><i class="ui-icon-add"></i></li>' 
  }
  else if (has==2){
	  
	  strdiv='<li><i class="ui-icon-delete"></i></li>'
  }
  else {
	  strdiv='error'
  }
  $("#del_create").html(strdiv);
} 

