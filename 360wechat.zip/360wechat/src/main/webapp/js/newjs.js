function fillBill(bill){
	 $(".txtTable tr td:nth-child(2)").text("");
	 $(".txtTable tr:nth-child(1) td:nth-child(2)").text(bill.foreignAcctId);
	 $(".txtTable tr:nth-child(2) td:nth-child(2)").text(bill.custName);
	 $(".txtTable tr:nth-child(3) td:nth-child(2)").html("<span>"+bill.amount/1000+"m³</span> （"+bill.lastRatingVal+"-"+bill.ratingVal+"）");
	 $(".txtTable tr:nth-child(4) td:nth-child(2)").html("<span>￥"+bill.billFee/1000+"<span/>");
	 $(".txtTable tr:nth-child(5) td:nth-child(2)").text(bill.status);
	 if(bill.status=="未缴费"){
		 $(".txtTable tr:nth-child(5) td:nth-child(2)").append("（￥"+bill.unpayFee/1000+"）");
	 }
	 $(".txtTable tr:nth-child(6) td:nth-child(2)").text(bill.payStartTime+"-"+bill.payEndTime);
	 $(".txtTable tr:nth-child(7) td:nth-child(2)").text(bill.cycleStartDate+"-"+bill.cycleEndDate);
	 $(".txtTable tr:nth-child(8) td:nth-child(2)").text(bill.adress);
}

function initTabBill(actBills){
	var i=0;
	var firstAct=0;
	for(var act in actBills){
		if(act=="success"){
			continue;
		}
		if(i>1){
			return firstAct;
		}else if(i==0){
			firstAct= act;
		}
		$("#tabs .pre-actLogo:eq("+i+") span ").text(act);
		if(i>0){
			$("#tabs .pre-actLogo:eq("+i+")").show();
		}
		i++;
		
	}
	return firstAct;
}

function initActXdrTab(xdrs) {
	var i = 0;
	var firstAct=0;
	for ( var act in xdrs) {
		if(act=="success"){
			continue;
		}
		if (i > 1) {
			return firstAct;
		}
		$("#tabs .pre-actLogo:eq(" + i + ") span ").text(act);
		if (i > 0) {
			$("#tabs .pre-actLogo:eq(" + i + ")").show();
		}
		if(i==0){
			firstAct = act;
		}
		i++;
	}
	return firstAct;
}

function changeTabBg(i){
	$("#tabs .actLogo").css("background-color", "#B3B1C6");//#535262
	$("#tabs .actLogo img").attr("src","image/actB.png");
	$("#tabs .actLogo:eq("+i+") img").attr("src","image/actL.png");
	$("#tabs .actLogo:eq("+i+")").css("background-color", "#535262");//#535262
}

function chageActBill(bills){
	$("#tabs .actLogo").each(function(i){
		$(this).click(function(){
			changeTabBg(i);
			if(i<2){
				var act = $(this).siblings("span").text();
				var bs = bills[act];
				fillBill(bs[0]);
			}else if(i==2){
				window.location.href="qrybill.html" ;
			}
		});
		
	});
}

function fillCdrs(cdrs){
	$("#xdr tbody").html("");
	for(var i in cdrs){
		var cdr = cdrs[i];
		$("#xdr tbody").append("<tr><td>"+cdr.userNumber+"</td>"+"<td>"+cdr.date.substr(0,10)+"</td>"+"<td><a href='javascript:;'>"+cdr.endRes+"<a></td>"+"<td>"+cdr.amount/1000+"</td>"+"<td>"+cdr.fee/1000+"</td>"+"<td>"+cdr.picPath+"</td></tr>");
	}
}
function changeXdr(cdrs){
	$("#xdrBody #tabs .actLogo").each(function(i){
		$(this).click(function(){
			changeTabBg(i);
			if(i>=2){
				window.location.href="qryxdr.html" ;
			}
			var act = $(this).siblings("span").text();
			var actCdrs = cdrs[act];
			fillCdrs(actCdrs);
		});
	});
}

function clearXdrCond(){
	$("input[name='acctId']").val("");
	$("input[name='startDate']").val("");
	$("input[name='endDate']").val("");
}

function getUrlParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); // 构造一个含有目标参数的正则表达式对象
	var r = window.location.search.substr(1).match(reg); // 匹配目标参数
	if (r != null)
		return unescape(r[2]);
	return null; // 返回参数值
}