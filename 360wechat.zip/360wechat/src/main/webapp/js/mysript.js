function reqServ(url,param){
    $.ajax({
		type: "get",
		url: url,//修改url
	 	data: param,
	 	dataType: 'json',
	 	success: function(data){
	 	if(data){
 			//var user={"accountId":"111","custName":"testName","stdRes":"111","telNum":"1321212","adress":"浙江省杭州市萧山区城厢街道西兴路金辰之光5幢1单元"};
 			return data;
 		    
	 	  }
	 	}
	}); 
}



function createTable(label, data, tableElement) {
	// 创建表格
	var table = $("<table> </table>");
	// 也可以为元素对象设定id,class等属性.
	/*
	 * var table = $("<table>",{ "id" : "tableId", "class" : "table_class" });
	 */
	// 设定样式
	table.css({
		width : "98%",
		"border-collapse" : "collapse",
		border : "0px solid #d0d0d0",
		margin : "3px",
		"font-size" : "10px"
	});
	// 标题行
	var tr = $("<tr></tr>");
	tr.css({
		border : "1px solid #d0d0d0",
		height : "30px",
		color : "#FFF",
		background : "#37b5ad",
		"text-align" : "center"
	});
	$.each(label, function(index, value) {
		var th = $("<th>" + value + "</th>");
		th.appendTo(tr);
	});
	tr.appendTo(table);

	$.each(data, function(index, row) {
		// 数据行
		var tr = $("<tr></tr>");
		// 数据列
		$.each(row, function(key, value) {
			// console.info(key + ":" + value);
			var td = $("<td>" + value + "</td>");
			td.css({
				border : "1px solid #d0d0d0",
				height : "24px",
				"text-overflow" : "ellipsis",
				"text-align" : "center"
			});
			td.appendTo(tr);
		});
		tr.appendTo(table);
	});
	table.appendTo(tableElement);
}

// 相同内容的合并
jQuery.fn.rowspan = function(colIdx) {
	return this.each(function() {
		var that;
		$('tr', this).each(
				function(row) {
					$('td:eq(' + colIdx + ')', this).filter(':visible').each(
							function(col) {
								if (that != null
										&& $(this).html() == $(that).html()) {
									rowspan = $(that).attr("rowSpan");
									if (rowspan == undefined) {
										$(that).attr("rowSpan", 1);
										rowspan = $(that).attr("rowSpan");
									}
									rowspan = Number(rowspan) + 1;
									$(that).attr("rowSpan", rowspan);
									$(this).hide();
								} else {
									that = this;
								}
							});
				});
	});
}

function createHead(label, tableElement) {
	// 创建表格
	var table = $("<table> </table>");
	// 也可以为元素对象设定id,class等属性.
	/*
	 * var table = $("<table>",{ "id" : "tableId", "class" : "table_class" });
	 */
	// 设定样式
	table.css({
		width : "98%",
		"border-collapse" : "collapse",
		border : "0px solid #d0d0d0",
		margin : "3px",
		"font-size" : "10px"
	});
	// 标题行
	var tr = $("<tr></tr>");
	tr.css({
		border : "1px solid #d0d0d0",
		height : "30px",
		color : "#FFF",
		background : "#37b5ad",
		"text-align" : "center"
	});
	$.each(label, function(index, value) {
		var th = $("<th>" + value + "</th>");
		th.appendTo(tr);
	});
	tr.appendTo(table);
	table.appendTo(tableElement);
}

function createCdrRow(data, table) {
	var t = $(table);
	// 数据行
	var tr = $("<tr></tr>");
	//var data = {"data":[{"accoutId":19991010,"cycle":31,"custName":"张芳","status":"未缴费","payStartTime":"2017/01/01","payEndTime":"2017/01/26","billTime":"2017/01/01","billMonth":201611,"unpayFee":37700,"billFee":37700,"amount":500,"payMeasure":"元","amountMeasure":"立方米","payRate":1000,"amountRate":1000,"cycleStartDate":"2017/01/01","cycleEndDate":"2016/12/01","adress":"test adreesss","ratingVal":123,"lastRatingVal":120,"identity":"219991010","imsi":"216012000000019991010","resourceId":19991010,"billNo":145009},{"accoutId":19991010,"cycle":31,"custName":"张芳","status":"未缴费","payStartTime":"2017/01/01","payEndTime":"2017/01/26","billTime":"2017/01/01","billMonth":201612,"unpayFee":29000,"billFee":29000,"amount":2000,"payMeasure":"元","amountMeasure":"立方米","payRate":1000,"amountRate":1000,"cycleStartDate":"2017/01/01","cycleEndDate":"2016/12/01","adress":"test adreesss","ratingVal":123,"lastRatingVal":123,"identity":"219991010","imsi":"216012000000019991010","resourceId":19991010,"billNo":145009},{"accoutId":19991010,"cycle":31,"custName":"张芳","status":"未缴费","payStartTime":"2017/01/01","payEndTime":"2017/01/26","billTime":"2017/01/01","billMonth":201611,"unpayFee":37700,"billFee":37700,"amount":500,"payMeasure":"元","amountMeasure":"立方米","payRate":1000,"amountRate":1000,"cycleStartDate":"2017/01/01","cycleEndDate":"2016/12/01","adress":"test adreesss","ratingVal":123,"lastRatingVal":120,"identity":"219991010","imsi":"216012000000019991010","resourceId":19991010,"billNo":145009},{"accoutId":19991020,"cycle":31,"custName":"张芳","status":"未缴费","payStartTime":"2017/01/01","payEndTime":"2017/01/26","billTime":"2017/01/01","billMonth":201612,"unpayFee":29000,"billFee":29000,"amount":2000,"payMeasure":"元","amountMeasure":"立方米","payRate":1000,"amountRate":1000,"cycleStartDate":"2017/01/01","cycleEndDate":"2016/12/01","adress":"test adreesss","ratingVal":123,"lastRatingVal":123,"identity":"219991010","imsi":"216012000000019991010","resourceId":19991010,"billNo":145009}],"success":true};
	var userNum = data.imsi;
	var cdrDate = data.date;
	var fee = data.fee;
	var amount = data.amount;
	var accumulate = data.endRes;

	$("<td>" + userNum + "</td>").appendTo(tr);
	$("<td>" + cdrDate + "</td>").appendTo(tr);
	$("<td>" + accumulate + "</td>").appendTo(tr);
	$("<td>" + amount/1000 + "</td>").appendTo(tr);
	$("<td>" + fee/1000 + "</td>").appendTo(tr);
	tr.appendTo($(table));
	$(table + " td").css({
		"border" : "1px solid #d0d0d0",
		"height" : "24px",
		"text-overflow" : "ellipsis",
		"text-align" : "center"
	});
}

function getUrlParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); // 构造一个含有目标参数的正则表达式对象
	var r = window.location.search.substr(1).match(reg); // 匹配目标参数
	if (r != null)
		return unescape(r[2]);
	return null; // 返回参数值
}

function printChart(d1, d2, container, lmax, rmax){
	var data2 = [ {
		name : '',
		value : d2,
		color : '#34a1d9',
		line_width : 5
	} ];
	var size = 6;
	var lspace = Math.ceil(lmax / size);// 向上去整
	var lend = lspace * size;

	var rspace = Math.ceil(rmax / size);// 向上去整
	var rend =rspace * size;
	
	var chart = new iChart.Column2D({
		render : container,
		data : d1,
		title : {
			text : '燃气使用情况',
			color : '#4572a7',
			textAlign : 'center',
			padding : '0 40',
			border : {
				enable : true,
				width : [ 0, 0, 4, 0 ],
				color : '#4572a7'
			},
			height : 70
		},
		footnote : {
			text : '单位：月份',
			height : 20,
			color : '#666666',
			fontweight : 600,
			padding : '-18 20'
		},
		width : 330,
		height : 480,
		padding : 0,
		label : {
			fontsize : 11,
			// fontweight:600,
			color : '#666666'
		},
		shadow : true,
		shadow_blur : 2,
		shadow_color : '#aaaaaa',
		shadow_offsetx : 1,
		shadow_offsety : 0,
		background_color : '#f7f7f7',
		column_width : 40,
		sub_option : {
			label : false,
			border : {
				width : 2,
				radius : '5 5 0 0',// 上圆角设置
				color : '#c0c0c0'
			}
		},
		coordinate : {
			background_color : null,
			grid_color : '#ffffff',
			width : 230,
			height : 300,
			axis : {
				color : '#c0d0e0',
				width : [ 0, 0, 1, 0 ]
			},
			scale : [ {
				position : 'left',
				start_scale : 0,// 向下去整
				end_scale : lend,
				scale_space : lspace,
				scale_enable : false,
				label : {
					fontsize : 11,
					// fontweight:600,
					color : '#666666'
				}
			}
			 ]
		}
	});
	// 构造折线图
	var line = new iChart.LineBasic2D({
		z_index : 1000,
		data : data2,
		coordinate : {
			background_color : null,
			grid_color : '#ffffff',
			width : 230,
			height : 300,
			axis : {
				enable:false,
			}
		},
		label : {
			color : '#4c4f48'
		},
		point_space : chart.get('column_width') + chart.get('column_space'),
		scaleAlign : 'right',
		sub_option : {
			label : false,
			point_size : 22
		}
		//coordinate : chart.coo
	// 共用坐标系
	});

	chart.plugin(line);

	// 利用自定义组件构造左侧说明文本
	chart.plugin(new iChart.Custom({
		drawFn : function() {
			// 计算位置
			var coo = chart.getCoordinate(), x = coo.get('originx'), y = coo
					.get('originy');
			// 在左上侧的位置，渲染一个单位的文字
			chart.target.textAlign('start').textBaseline('bottom').textFont(
					'600 16px Verdana').fillText('燃气使用量', x - 10, y - 20,
					false, '#c52120').textFont('600 11px Verdana').fillText(
					'单位：立方米', x - 10, y - 5, false, '#c52120');

			// 在右上侧的位置，渲染一个单位的文字
			chart.target.textAlign('end').textBaseline('bottom').textFont(
					'600 16px Verdana').fillText('燃气使用费用', x + 10 + coo.width,
					y - 20, false, '#34a1d9').textFont('600 11px Verdana')
					.fillText('单位：元', x + 10 + coo.width, y - 5, false,
							'#34a1d9');

		}
	}));

	chart.draw();
}




