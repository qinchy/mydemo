

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.taobao.common.tfs.TfsManager;

public class TestTfs {
	Log log = LogFactory.getLog(TestTfs.class);
	ApplicationContext contxt ;
	
	@Before
	public void init() {
		contxt = new ClassPathXmlApplicationContext("classpath:META-INF/applicationContext.xml");
	}
	@Test
	public void qryBindWechat(){
		String key =  "T15txTBXJT1RCvBVdK";
		TfsManager tfsManager =(TfsManager) contxt.getBean("tfsManager");
		tfsManager.fetchFile(key, null,key+".jpg");
	}
}
