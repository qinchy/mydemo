

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ailk.easyframe.web.common.session.ContextHolder;
import com.ailk.emcc.busi.user.UserInfo;
import com.ailk.emcc.service.user.BaseUserService;
import com.ailk.emcc.service.userServ.UserServService;

public class TestUser {
	Log log = LogFactory.getLog(TestUser.class);
	ApplicationContext contxt ;
	
	@Before
	public void init() {
		contxt = new ClassPathXmlApplicationContext("classpath:META-INF/applicationContext.xml");
		ContextHolder.requestInit();
		ContextHolder.setTenantId(22L);
	}
	/*@Test
	public void getProfile(){
		String wechatId =  "user_baseUserServicebind2";
		UserServService userServ_userServService =(UserServService) contxt.getBean("userServ_userServService");
		String profile=userServ_userServService.getMyProfile(wechatId);
		log.info(profile);
	}*/
	
	/*@Test
	public void getProfile(){
		String mobile =  "15967138540";
		UserServService userServ_userServService =(UserServService) contxt.getBean("userServ_userServService");
		List<UserInfo> actList = userServ_userServService.getActList(mobile);
		log.info(actList);
	}*/
	
}
