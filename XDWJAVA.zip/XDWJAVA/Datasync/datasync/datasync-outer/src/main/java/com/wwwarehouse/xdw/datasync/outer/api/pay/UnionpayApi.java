package com.wwwarehouse.xdw.datasync.outer.api.pay;

import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IPayApi;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.AcpService;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.LogUtil;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.SDKConfig;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.SDKUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chengwei on 2017/6/9 10:02.
 */
public class UnionpayApi extends BaseRequestApi implements IPayApi {
	private static final Logger log = LoggerFactory.getLogger(UnionpayApi.class);

    //银联支付相关
    public final static String UINIONPAY_VERSION = "5.0.0";
    public final static String CHARSET = "UTF-8";
    public final static String SIGN_METHOD = "01";	//01： 表示采用 RSA
    public final static String TXN_TYPE = "01";		//交易类型:00 查询交易,01 消费 ...
    public final static String TXN_SUBTYPE = "01";
    public final static String BIZ_TYPE = "000201"; //产品类型: 000201 B2C网关支付
    public final static String CHANNEL_TYPE = "08"; //渠道类型 08手机
    public final static String ACCESS_TYPE = "0";	//接入类型 0：普通商户直连接入 2：平台类商户接入
    public final static String ACC_TYPE = "01";		//账号类型 01:银行卡、02：存折、03：IC卡 04：对公账户
    public final static String CURRENCY_CODE = "156";// 交易币种	156（人民币）
	private String BACK_URL = ConstantsOuter.NOTIFY_URL + "/payNotify/unipay";

    private String appId;
    private String dataFormat;
    private String privateKey;
    private String merId;

    public UnionpayApi(AmAppSubscriptionDTO appSuber) {
        AmAppkeyDTO amAppkey = appSuber.getApp();
        this.appId = amAppkey.getAppKey();
        this.privateKey = appSuber.getPrivateKey();
        this.dataFormat = amAppkey.getDataFormat();
		this.merId = appSuber.getPlatformUserId();
//        this.merId = "310420147890001";
		SDKConfig.getConfig().loadPropertiesFromSrc();

    }

//    public UnionpayApi(){
//		//加载银联的匹配
//		SDKConfig.getConfig().loadPropertiesFromSrc();
//	}
//
//	public static void main(String[] args) {
//		UnionpayApi api = new UnionpayApi();
//		AbsResponse<String> absResponse = api.buildPayUrl("10001010","保证金", "",5.1);
//		absResponse.getData();
//	}

    @Override
    public AbsResponse<String> buildPayUrl(String tradeNo, String title, String body, double amount) throws Exception {
        AbsResponse<String> ret = new AbsResponse<>();
        try {
            Map<String, String> unionPayParam = this.getAppRequestParams(amount, tradeNo);
            String requestUrl = SDKConfig.getConfig().getAppRequestUrl();
            String resultString = this.callApi(requestUrl, unionPayParam);
            Map<String, String> rspData = SDKUtil.convertResultStringToMap(resultString);

            //3. 对应答码的处理，请根据您的业务逻辑来编写程序,以下应答码处理逻辑仅供参考 验证签名不成功
            if (rspData.isEmpty() || !AcpService.validate(rspData, CHARSET)) {
                ret.setResult(300, "验证签名不成功");
            } else {
                String respCode = rspData.get("respCode");
                if ("00".equals(respCode)) {
                    String tn = rspData.get("tn");// 成功,获取tn号
                    unionPayParam.put("tn", tn);
                    String rspDataJson = JsonUtils.toJson(unionPayParam);
                    ret.setResult(0, "成功", "", rspDataJson);
                } else {
                    ret.setResult(400, "应答码不正确:" + respCode);
                }
            }
        }catch (Exception e){
            log.error(tradeNo, e);
            ret.setResult(500, e.getMessage());
        }
        return ret;
    }

    private String callApi(String apiUrl, Map<String, String> params) throws IOException {
        String responseString = null;
        Date reqDate = new Date();


		Map<String, String> reqParams = null;
        try {
			reqParams = AcpService.sign(params, CHARSET);

            responseString = WebUtils.doPost(apiUrl, reqParams, CHARSET, 15000, 25000);
        }catch (IOException e){
            responseString = e.getMessage();
            throw e;
        } finally {
            appendReqAResp("UNIONPAY", reqDate, apiUrl, reqParams, null, responseString);
        }

        return responseString;
    }

    /**
     * 查询支付结果
     * @param orderNo
	 * @param sendTime
	 */
    public AbsResponse<String> singleOrderQuery(String orderNo, Date sendTime){
		AbsResponse<String> abs = new AbsResponse<>();
		String resultString = null;
		try {
			Map<String, String> map = getSingleQueryParams(orderNo, sendTime);

			String queryUrl = SDKConfig.getConfig().getSingleQueryUrl();
			resultString = this.callApi(queryUrl, map);
			Map<String, String> rspData = SDKUtil.convertResultStringToMap(resultString);

			abs.setBody(resultString);
			//应答码规范参考open.unionpay.com帮助中心 下载  产品接口规范  《平台接入接口规范-第5部分-附录》
			if (rspData == null || rspData.isEmpty()) {
				return abs.setResult(500, "未获取到返回报文或返回http状态码非200");
			}
			if (!AcpService.validate(rspData, CHARSET) ) {
				return abs.setResult(103, "验证签名失败");
			}

			LogUtil.writeLog("验证签名成功");
			if ("00".equals(rspData.get("respCode"))) {//如果查询交易成功
				String origRespCode = rspData.get("origRespCode");
				String data = null;
				switch (origRespCode) {
					case "00":
						data = "success";//支付成功
						break;
					case "03"://订单处理中或交易状态未明，需稍后发起交易状态查询交易 【如果最终尚未确定交易是否成功请以对账文件为准】
					case "04":
					case "05":
						data = "inProcess";//处理中
						break;
					default:
						data = "fail";
						break;
				}
				abs.setData(data);
				return abs;
			} else if ("34".equals(rspData.get("respCode"))) {
				//订单不存在，可认为交易状态未明，需要稍后发起交易状态查询，或依据对账结果为准
				abs.setData("inProcess");
				return abs;
			} else {//查询交易本身失败，如应答码10/11检查查询报文是否正确
				abs.setResult(101, "验证签名失败，检查查询报文是否正确");
				return abs;
			}
		}catch (Exception e){
			log.error(orderNo, e);
			abs.setResult(500, e.getMessage());
		}
		return abs;
    }

	/**
	 * 消费交易：后台异步交易，有后台通知<
	 * @param totalFee
	 * @param orderId
	 * @return
	 */
	private Map<String, String> getAppRequestParams(double totalFee, String orderId) {
		totalFee = StringUtils.comDouble(totalFee, 100D, '*');

		Map<String, String> params = new HashMap<>();
		/*** 银联全渠道系统，产品参数，除了encoding自行选择外其他不需修改 ***/
		params.put("version", UINIONPAY_VERSION);
		params.put("encoding", CHARSET);
		params.put("signMethod", SIGN_METHOD);
		params.put("bizType", BIZ_TYPE);

		params.put("txnType", TXN_TYPE);
		params.put("txnSubType", TXN_SUBTYPE);
		params.put("channelType", CHANNEL_TYPE);

		/*** 商户接入参数 ***/
		params.put("merId", this.merId);
		params.put("accessType", ACCESS_TYPE);
		params.put("orderId", orderId);
		params.put("txnTime", DateUtil.format(new Date(), "yyyyMMddHHmmss"));
		params.put("accType", ACC_TYPE);
		params.put("txnAmt", String.valueOf((int) totalFee));
		params.put("currencyCode", CURRENCY_CODE);
		params.put("backUrl", BACK_URL);

		return params;
	}

	/**
	 * 交易状态查询交易：只有同步应答
	 * @param orderId
	 * @param orderSendTime
	 * @return
	 */
	private Map<String, String> getSingleQueryParams(String orderId, Date orderSendTime) {
		Map<String, String> data = new HashMap<>();
		/***银联全渠道系统，产品参数，除了encoding自行选择外其他不需修改***/
		data.put("version", UINIONPAY_VERSION);		//版本号
		data.put("encoding", CHARSET);          	//字符集编码 可以使用UTF-8,GBK两种方式
		data.put("signMethod", SIGN_METHOD);    	//签名方法 目前只支持01-RSA方式证书加密
		data.put("txnType", "00");            		//交易类型 00-默认
		data.put("txnSubType", "00");           	//交易子类型  默认00
		data.put("bizType", BIZ_TYPE);         		//业务类型

		/***商户接入参数***/
		data.put("merId", this.merId);           	//商户号码，请改成自己申请的商户号或者open上注册得来的777商户号测试
		data.put("accessType", ACCESS_TYPE);     	//接入类型，商户接入固定填0，不需修改

		/***要调通交易以下字段必须修改***/
		data.put("orderId", orderId);        		//****商户订单号，每次发交易测试需修改为被查询的交易的订单号
		data.put("txnTime", DateUtil.format(orderSendTime, "yyyyMMddHHmmss"));      	//****订单发送时间，每次发交易测试需修改为被查询的交易的订单发送时间
		return data;
	}


    public static boolean validate(String jsonData){
        SDKConfig.getConfig().loadPropertiesFromSrc();
        return AcpService.validateAppResponse(jsonData, CHARSET);
    }

	@Override
	public AbsResponse<String> buildBatchPay(String tradeNo, String receivePaymentAccount, String receiveUserName,
											 String billMoney, String paymentRemark, String batchNo) throws Exception {
		return null;
	}
}
