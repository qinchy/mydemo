package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl;

import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.express.EMSShipApi;
import com.wwwarehouse.xdw.datasync.outer.api.express.YUNDAShipApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaExpressCode;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;

import java.util.HashMap;

public class ShipApiInstancer extends ApiInstancer {

	private static ShipApiInstancer _instance;
	private HashMap<Long, IShipApi> shipAPIMaps;

	public ShipApiInstancer() {
		shipAPIMaps = new HashMap<Long, IShipApi>();
		shipAPIMaps.put(BaExpressCode.EMS.getId(), new EMSShipApi());
		shipAPIMaps.put(BaExpressCode.YUNDA.getId(), new YUNDAShipApi());
	}

	public static ShipApiInstancer getInstance() {
		if (_instance == null) {
			_instance = new ShipApiInstancer();
		}
		return _instance;
	}

	public IShipApi getShipApi(AmAppSubscriptionDTO appSuber) {
		IShipApi factory = shipAPIMaps.get(appSuber.getPlatformId());
		return factory;
	}
}
