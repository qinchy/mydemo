package com.wwwarehouse.xdw.datasync.outer.api.interfaces;


import com.wwwarehouse.commons.utils.AbsResponse;

/**
 * Created by jiejun on 16/9/20.
 */
public interface IPayApi extends IRecordAble {
	
	/**
	 * 封装支付消息
	 * @param title ：支付主题
	 * @param body ：支付内容
	 * @param amount ：付款 金额
	 * @param tradeNo：账单ID
	 * @return
	 * @throws Exception
	 */
    public AbsResponse<String> buildPayUrl(String tradeNo, String title, String body,
                                           double amount) throws Exception;

    /**
     * 封装批量支付信息
     * @param tradeNo ：账单ukid
     * @param receivePaymentAccount：收款人账号
     * @param receiveUserName：收款人姓名
     * @param billMoney：付款金额
     * @param batchNo：
     * @return
     * @throws Exception
     */
    public AbsResponse<String> buildBatchPay(String tradeNo, String receivePaymentAccount,
                                             String receiveUserName, String billMoney, String paymentRemark, String batchNo) throws Exception;
}
