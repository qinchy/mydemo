package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

/**
 * Created by zhigang.huang on 2017/3/7.
 */
public interface IUnifiApi {

    boolean login(String username, String password);

    boolean logout();

//    public boolean authorizeGuest(String mac, String minutes, String up, String down, String MBytes, String apMac);
//
//    public boolean unauthorizeGuest(String mac);
//
//    public boolean reconnectSta(String mac);
//
//    public boolean blockSta(String mac);
//
//    public boolean unblockSta(String mac);
//
//    public boolean setStaNote(Long pptId,String note);
//
//    public boolean setStaName(Long pptId,String name);
//
//    public List<Object> statAllUsers(Long  historyhours);
//
//    public List<Object> listGuests(Long within);
//
//    public List<Object> statClient(String clientMac);
//
//    public List<Object> listClients(String clientMac);
//
//    public List<Object> statClients(String clientMac);
//
//    public List<Object> listUserGroups();
//
//    public boolean setUserGroups(Long pptId,Long groupId);
//
//    public List<Object> listHealth();
//
//    public List<Object> listDashboard();
//
//    public boolean listUser();
//
//    public List<Object> listAps(String deviceMac);
//
//    public List<Object> listAdmins();
//
//    public List<Object> listWlanGroups();
//
//    public List<Object> statSysinfo();
//
//    public List<Object> listSelf();
//
//    public List<Object> listNetworkConf();
//
//    public List<Object> listHotspotop();
//
//    public List<Object> listPortforwarding();
//
//    public List<Object> listDynamicdns();
//
//    public List<Object> listPortconf();
//
//    public List<Object> listExtension();
//
//    public List<Object> listSettings();
//
//    public List<Object> listEvents();
//
//    public List<Object> listWlanconf();
//
//    public List<Object> listAlarms();







}
