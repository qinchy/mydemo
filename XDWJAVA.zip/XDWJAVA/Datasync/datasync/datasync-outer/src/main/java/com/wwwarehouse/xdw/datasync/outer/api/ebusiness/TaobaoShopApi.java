package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.taobao.api.ApiException;
import com.taobao.api.TaobaoClient;
import com.taobao.api.TaobaoRequest;
import com.taobao.api.TaobaoResponse;
import com.taobao.api.domain.Shop;
import com.taobao.api.request.ShopGetRequest;
import com.taobao.api.response.ShopGetResponse;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.BaShopDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShopApi;
import com.wwwarehouse.xdw.datasync.outer.api.ots.DefaultTaobaoClient;
import com.wwwarehouse.xdw.datasync.outer.api.ots.OtsApiClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Date;
import java.util.Map;

/**
 * Created by jianjun.guan on 2017/6/8 0008.
 */
public class TaobaoShopApi extends BaseRequestApi implements IShopApi{

    protected static Logger log = LogManager.getLogger(TaobaoTradeApi.class);
    protected static final String ORDER_FULLINFO_FIELDS = "orders.title,orders.pic_path,orders.price,orders.num,orders.iid,orders.num_iid,orders.sku_id,orders.refund_status,orders.status,orders.oid,orders.total_fee,orders.payment,orders.discount_fee,orders.adjust_fee,orders.sku_properties_name,orders.item_meal_name,orders.buyer_rate,orders.seller_rate,orders.outer_iid,orders.outer_sku_id,orders.refund_id,orders.seller_type,orders.order_from,orders.modified,orders.end_time,orders.consign_time,orders.shipping_type,orders.divide_order_fee,orders.part_mjz_discount,orders.zhengji_status";
    protected static final String TRADE_FULLINFO_FIELDS = "buyer_message,seller_memo,alipay_no,buyer_alipay_no,seller_nick,buyer_nick,title,type,created,tid,seller_rate,buyer_rate,status,payment,discount_fee,adjust_fee,post_fee,total_fee,pay_time,end_time,modified,consign_time,buyer_obtain_point_fee,point_fee,real_point_fee,received_payment,commission_fee,pic_path,num_iid,num,price,cod_fee,cod_status,shipping_type,receiver_name,receiver_state,receiver_city,receiver_district,receiver_address,receiver_zip,receiver_mobile,receiver_phone,send_time,trade_from,express_agency_fee,service_tags," + ORDER_FULLINFO_FIELDS;
    protected static final String TRADE_SHORT_FIELDS = "type,created,tid,status,payment,pay_time,end_time,modified,received_payment,consign_time";
    protected static final String TRADE_INCREMENT_FIELDS = TRADE_SHORT_FIELDS + "," + ORDER_FULLINFO_FIELDS + "," + "seller_memo";
    protected static final String TRADE_RATE_FIELDS = "num_iid,valid_score,tid,oid,role,nick,result,created,rated_nick,item_title,item_price,content,reply";
    protected static final String TRADE_TYPE = "fixed,auction,guarantee_trade,step,independent_simple_trade,independent_shop_trade,auto_delivery,ec,cod,game_equipment,shopex_trade,netcn_trade,external_trade,instant_trade,b2c_cod,hotel_trade,super_market_trade,super_market_cod_trade,taohua,waimai,nopaid,step,eticket,tmall_i18n,nopaid";
    protected static final String PRO_ITEMS_FIELD = "detail_url,num_iid,title,nick,type,cid,"
            + "pic_url,num,valid_thru,list_time,stuff_status,location,price,post_fee,express_fee,ems_fee,"
            + "approve_status,product_id,auction_point,property_alias,item_img,prop_img,sku,outer_id,sub_stock,is_fenxiao,list_time,delist_time";

    protected static final String REFUND_FIELDS = "refund_id, tid, title, buyer_nick, seller_nick, total_fee, status,created, refund_fee, oid, good_status, company_name, sid, payment, reason, desc, has_good_return, modified, order_status,num_iid,address";
    protected static final String REFUND_TYPE = "fixed,auction,guarantee_trade,independent_simple_trade,independent_shop_trade,auto_delivery,ec,cod,fenxiao,game_equipment,shopex_trade,netcn_trade,external_trade,step";
    protected static final String PLATFORM_ITEM_FIELD = "after_sale_id,approve_status,auction_point,auto_fill,auto_repost,barcode,callbackUrl,change_prop,change_prop,chaoshi_extends_info,cid,cod_postage_id,cpv_memo,created,custom_made_type_id,delist_time,delivery_time,desc,desc_module_info,desc_modules,detail_url,ems_fee,express_fee,features,food_security,freight_payer,global_stock_country,global_stock_delivery_place,global_stock_tax_free_promise,global_stock_type,has_discount,has_invoice,has_showcase,has_warranty,iid,increment,inner_shop_auction_template_id,input_custom_cpv,input_pids,input_str,is_3D,is_area_sale,is_cspu,is_darwin,is_ex,is_fenxiao,is_lightning_consignment,is_offline,is_prepay,is_taobao,is_timing,is_virtual,is_xinpin,item_imgs,item_size,item_weight,list_time,locality_life,location,modified,mpic_video,ms_payment,newprepay,nick,num,num_iid,o2o_bind_service,one_station,open_iid,outer_id,outer_shop_auction_template_id,paimai_info,period_sold_quantity,pic_url,post_fee,postage_id,price,product_id,promoted_service,prop_imgs,property_alias,props,props_name,qualification,score,second_kill,second_result,sell_point,sell_promise,seller_cids,shop_type,skus,sold_quantity,spu_confirm,stuff_status,sub_stock,sub_title,template_id,title,type,valid_thru,video_id,videos,violation,volume,wap_desc,wap_detail_url,wireless_desc,with_hold_quantity,ww_status";
    protected String appKey;
    protected String appSecret;
    protected String sessionKey;
    protected String sellerNick; //店铺昵称

    protected boolean isEnableOts = true;
    protected TaobaoClient client = null;
    protected AmAppSubscriptionDTO subscription;


    public TaobaoShopApi() {

    }

    /**
     * 获取店铺信息
     *
     * @param nick
     * @return
     * @throws ApiException
     */
    @Override
    public AbsResponse<BaShopDTO> getShop(String nick) throws Exception {
        AbsResponse<BaShopDTO> abs = new AbsResponse<>();

        String fields = "sid,cid,title,nick,desc,bulletin,pic_path,created,modified";
        try {
//			Map<String,String> params = new HashMap<>();
//			params.put("nick", nick);
//			params.put("fields", fields);
//			this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/shopAction";
//			response = this.executeOts("getShopResponse", params, ShopGetResponse.class);

//			/* 模拟接口*/
//			Map<String, String> params = new HashMap<>();
//			params.put("nick", nick);
//			params.put("fields", fields);
//			this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/simulatorAction";
//			response = this.executeOts("getShopResponse", params, ShopGetResponse.class);
//			/* 模拟接口*/

            ShopGetRequest req = new ShopGetRequest();
            req.setNick(nick);
            req.setFields(fields);
            ShopGetResponse response = this.executeOtsOne(req);

            Shop shop = response.getShop();
            if (shop == null) {
                abs.setResult(905001, getErrorMsg(response));
            } else {
                BaShopDTO BaShopDTO = new BaShopDTO();

                BaShopDTO.setShopCreated(shop.getCreated());
                BaShopDTO.setSellerNick(shop.getNick());
                BaShopDTO.setShopName(shop.getTitle());
                abs.setData(BaShopDTO);
            }
        } catch (Exception e) {
            log.error(nick, e);
            abs.setResult(905001, "发生异常:" + e.getMessage());
        }
        return abs;
    }

    /**
     * 所有的接口都通过该方法调用
     *
     * @param request
     * @return
     * @throws ApiException
     */

    protected <T extends TaobaoResponse> T execute(TaobaoRequest<T> request) throws ApiException {
        return execute(this.client, request);
    }

    /**
     * 所有的接口都通过该方法调用
     *
     * @param request
     * @return
     * @throws ApiException
     */
    protected <T extends TaobaoResponse> T execute(TaobaoClient client, TaobaoRequest<T> request) throws ApiException {
        Date reqDate = new Date();
        T response = null;
        String errMsg = null;
        try {
            response = client.execute(request, this.sessionKey);
        } catch (Exception e) {
            errMsg = e.getMessage();
            throw e;
        } finally {
            if (response != null) {
                appendReqAResp(request.getApiMethodName(), reqDate, null,
                        response.getParams(), response.getBody());
            } else {
                appendReqAResp(request.getApiMethodName(), reqDate, null,
                        request.getTextParams(), errMsg);
            }
        }

        return response;
    }

    /**
     * OTS所有的接口都通过该方法调用
     *
     * @param apiMethod
     * @param params
     * @return
     * @throws ApiException
     */
    protected <T extends TaobaoResponse> T executeOts(String apiMethod,
                                                      Map<String, String> params, Class<T> clazz) throws Exception {
        Date reqDate = new Date();
        T response = null;
        String errMsg = null;
        try {
            Map<String, String> sysParams = OtsApiClient.getTaobaoApiParams(
                    this.appKey, this.appSecret, this.sessionKey);
            params.putAll(sysParams);
//			if(ConstantsExternal.ISCS_SHOP_NICK.equals(sellerNick)){
            params.put(OtsApiClient.V_STATE, "iscs");
//			}
            response = OtsApiClient.execute(this.apiUrl + "!" + apiMethod,
                    params, clazz);
        } catch (Exception e) {
            errMsg = e.getMessage();
            throw e;
        } finally {
            if (response != null) {
                appendReqAResp(apiMethod, reqDate, null, response.getParams(), response.getBody());
            } else {
                appendReqAResp(apiMethod, reqDate, null, params, errMsg);
            }
        }
        return response;
    }

    /**
     * 调用ots的统一方法：callApi
     *
     * @param request
     * @return
     * @throws ApiException
     */
    protected <T extends TaobaoResponse> T executeOtsOne(TaobaoRequest<T> request) throws ApiException {
        Map<String, String> sysParams = OtsApiClient.buildSysParams();
//		if(ConstantsExternal.ISCS_SHOP_NICK.equals(sellerNick)){
        sysParams.put(OtsApiClient.V_STATE, "iscs");
//		}
        String url = WebUtils.combineQueries(OtsApiClient.otsTaobaoHost
                + "/taobao/tradeAction!callApi", sysParams);

        TaobaoClient client = new DefaultTaobaoClient(url, this.appKey, this.appSecret);
        return this.execute(client, request);
    }

    /**
     * 组装错误信息
     * @param response
     * @return
     */
    protected static String getErrorMsg(TaobaoResponse response) {
        if (response == null) {
            return "返回数据异常";
        }
        String errorMsg = null;
        if (!"0".equals(response.getErrorCode())) {
            errorMsg = response.getSubMsg() + ":" + response.getSubCode();
            if (errorMsg.indexOf("blacklist") != -1) {
                errorMsg = "获取数据异常";
            }
        }
        return errorMsg;
    }


}
