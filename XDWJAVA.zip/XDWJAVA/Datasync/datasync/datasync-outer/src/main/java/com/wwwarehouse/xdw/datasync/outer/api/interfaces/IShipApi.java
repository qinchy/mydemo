package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressUploadWeightInfo;
import com.wwwarehouse.xdw.datasync.model.LogisticsInformation;

import java.util.List;

public interface IShipApi <T extends ExpressOrderInfoDTO> extends IRecordAble {

	/**
	 * 跟踪快递单的物流信息
	 * 
	 * @param outSid
	 *            快递单号
	 * @return 物流详情
	 * @throws Exception
	 */
	public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception;

	/**
	 * 对接生成快递物流信息
	 * 
	 * @param expressOrderInfo
	 *            快递面单的详细信息
	 * @return 带有快递单号的详细信息
	 * @throws Exception
	 */
	public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception;

	/**
	 * 对接批量生成快递物流信息
	 * 
	 * @param expressOrderInfoDTOs
	 *            快递面单的详细信息
	 * @return 带有快递单号的详细信息
	 * @throws Exception
	 */

	public  List<T> generateExpressInfos(List<T> expressOrderInfoDTOs) throws Exception;

	/**
	 * 上传包裹重量列表
	 * 
	 * @param weightInfos
	 * @throws Exception
	 */
	public void uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception;

	/**
	 * 取消快递单
	 * 
	 * @param orderId
	 * @param outSid
	 * @throws Exception
	 */
	public void cancelExpressOrder(String orderId, String outSid) throws Exception;

}
