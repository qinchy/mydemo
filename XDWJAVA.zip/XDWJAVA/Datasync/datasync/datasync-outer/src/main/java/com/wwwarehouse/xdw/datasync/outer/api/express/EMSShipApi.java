package com.wwwarehouse.xdw.datasync.outer.api.express;

import java.io.IOException;
import java.lang.reflect.Array;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.ServiceException;
import javax.xml.soap.SOAPException;

import com.wwwarehouse.commons.xml.XmlConverter;
import com.wwwarehouse.commons.xml.XmlUtils;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.commons.codec.binary.Base64;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmRequestLogDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressUploadWeightInfo;
import com.wwwarehouse.xdw.datasync.model.LogisticsInformation;
import com.wwwarehouse.xdw.datasync.model.SeShipmentTrack;
import com.wwwarehouse.xdw.datasync.model.ShipOrderDTO;
import com.wwwarehouse.xdw.datasync.model.TmTmsOrderCodeDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;

/**
 * EMS
 * 
 * @author chenshengnan
 *
 */
public class EMSShipApi implements IShipApi {
	private static final String targetNamespace = "http://printService.webservice.bigaccount.hollycrm.com";
	private String apiUrl = "http://os.ems.com.cn:8081/zkweb/services/getPrintDatas?wsdl";
	private String charset = "utf-8";
	private String customerCode;
	private String password;

	public EMSShipApi() {
	}

	// public EMSShipApi(AmAppSubscription subscription) {
	// AmAppkey app = subscription.getApp();
	// this.customerCode = app.getServiceCode(); // 先取serviceCode做为customerCode
	// this.password = app.getAppSecret();
	// if (StringUtils.isNotEmpty(app.getApiUrl())) {
	// this.apiUrl = app.getApiUrl();
	// }
	//
	// if (StringUtils.isNotEmpty(app.getCharset())) {
	// this.charset = app.getCharset();
	// }
	// }

	public static void main(String[] args) throws Exception {
		EMSShipApi api = new EMSShipApi();

		// //测试获取物流信息
		// AbsResponse<String> st = api.followShip("1146910013732");
		// System.out.println(st.getData());
		//
		// //测试物流信息转化为网仓的状态节点
		// final List<SeShipmentTrack> convert = api.convert(st.getData(), null,
		// null, null);
		// System.out.println("<----------------------------------------->");
		// for(SeShipmentTrack track : convert){
		// System.out.println(track);
		// }

		// //测试获取快递单号
		// List<ShipOrderDTO> shipOrderDTOs = new ArrayList<>();
		// ShipOrderDTO shipOrderDTO = new ShipOrderDTO();
		// shipOrderDTO.setOrderId("123111");
		// shipOrderDTO.setSenderName("张三");
		// shipOrderDTO.setSenderCompany("天羽服饰有限公司");
		// shipOrderDTO.setSenderCity("江苏省，徐州市，新沂市");
		// shipOrderDTO.setSenderAddress("江苏省徐州市新沂市湖东路999号");
		// shipOrderDTO.setSenderPostcode("221435");
		// shipOrderDTO.setSenderPhone("65000000");
		// shipOrderDTO.setSenderMobile("1360000000000");
		// shipOrderDTO.setReceiverName("李四");
		// shipOrderDTO.setReceiverCompany("");
		// shipOrderDTO.setReceiverCity("上海市，上海市，青浦区");
		// shipOrderDTO.setReceiverAddress("上海市青浦区盈港东路6655号");//上海市青浦区盈港东路6655号
		// shipOrderDTO.setReceiverPostcode("368200");
		// shipOrderDTO.setReceiverPhone("65000899");
		// shipOrderDTO.setReceiverMobile("1360123000000");
		// shipOrderDTO.setWeight(1.0);
		// shipOrderDTO.setSize("0.05");
		// List<ShipOrderItemDTO> items = new ArrayList<>();
		// ShipOrderItemDTO item = new ShipOrderItemDTO();
		// item.setName("iphone7 plus");
		// item.setNumber(1);
		// item.setRemark("");
		// ShipOrderItemDTO itemSec = new ShipOrderItemDTO();
		// itemSec.setName("iphone6s plus");
		// itemSec.setNumber(2);
		// itemSec.setRemark("");
		// items.add(item);
		// items.add(itemSec);
		// shipOrderDTO.setShipOrderItemDTOs(items);
		// shipOrderDTOs.add(shipOrderDTO);
		//
		// ShipOrderDTO shipOrderDTOOther = new ShipOrderDTO();
		// shipOrderDTOOther.setOrderId("123112");
		// shipOrderDTOOther.setSenderName("王五");
		// shipOrderDTOOther.setSenderCompany("天羽服饰有限公司");
		// shipOrderDTOOther.setSenderCity("江苏省，徐州市，新沂市");
		// shipOrderDTOOther.setSenderAddress("江苏省徐州市新沂市湖东路999号");
		// shipOrderDTOOther.setSenderPostcode("221435");
		// shipOrderDTOOther.setSenderPhone("65000000");
		// shipOrderDTOOther.setSenderMobile("1360000000000");
		// shipOrderDTOOther.setReceiverName("李四");
		// shipOrderDTOOther.setReceiverCompany("");
		// shipOrderDTOOther.setReceiverCity("上海市，上海市，青浦区");
		// shipOrderDTOOther.setReceiverAddress("上海市青浦区盈港东路6655号");//上海市青浦区盈港东路6655号
		// shipOrderDTOOther.setReceiverPostcode("368200");
		// shipOrderDTOOther.setReceiverPhone("65000899");
		// shipOrderDTOOther.setReceiverMobile("1360123000000");
		// shipOrderDTOOther.setWeight(1.0);
		// shipOrderDTOOther.setSize("0.05");
		// List<ShipOrderItemDTO> itemsO = new ArrayList<>();
		// ShipOrderItemDTO itemO = new ShipOrderItemDTO();
		// itemO.setName("iphone7 plus");
		// itemO.setNumber(1);
		// itemO.setRemark("");
		// itemsO.add(itemO);
		// shipOrderDTOOther.setShipOrderItemDTOs(itemsO);
		// shipOrderDTOs.add(shipOrderDTOOther);
		//
		// AbsResponse<List<TmTmsOrderCodeDTO>> tmsOrderCode =
		// api.getTmsOrderCode(shipOrderDTOs);
		// List<TmTmsOrderCodeDTO> data = tmsOrderCode.getData();
		//
		// System.out.println("d" + data + "<------>" + data.size());
		//
		// for(TmTmsOrderCodeDTO dto : data){
		// System.out.println(data);
		// }

		// 测试下载快递单
		api.downLoadOutSid(false, 1);
	}

	// 查询物流信息
	public AbsResponse<String> followShip(String outSid) throws Exception {
		AbsResponse<String> retBean = new AbsResponse<String>();
		retBean.setData(WebUtils.doGet("http://www.ems.com.cn/apple/query/" + outSid, null));
		return retBean;
	}

	// 将物流信息转化为网仓的状态节点
	public List<SeShipmentTrack> convert(String data, String state, String city, String county) throws Exception {
		Document doc = Jsoup.parse(data);

		Elements table = doc.getElementsByTag("table");
		List<SeShipmentTrack> list = new ArrayList<SeShipmentTrack>();
		if (table.size() < 3) {
			return list;
		}
		Elements trs = table.get(3).getElementsByTag("tr");
		for (int i = 2; i < trs.size(); i++) {
			Elements tds = trs.get(i).getElementsByTag("td");
			String operationDate = tds.get(1).text();
			String address = StringUtils.trim(tds.get(2).text());
			String remark = StringUtils.trim(tds.get(3).text());

			SeShipmentTrack track = new SeShipmentTrack();
			track.setOperationDate(strToDate(operationDate));
			track.setOperationRemark(remark);
			track.setOperationAddress(address);
			track.setFlowStatus(getFlowStatus(address, remark, state, city, county));

			list.add(track);
		}
		return list;
	}

	private Long getFlowStatus(String address, String remark, String state, String city, String county) {
		Long status = 0L;
		if (StringUtils.contains(remark, "收寄", "揽收")) {
			status = 550L;
		} else if (StringUtils.contains(remark, "离开处理中心", "到达处理中心")
				&& StringUtils.contains(address, getExpState(state))) {
			status = 555L;
		} else if (StringUtils.contains(remark, "到达处理中心", "离开处理中心")
				&& StringUtils.contains(address, getExpCity(city))) {
			status = 560L;
		} else if (StringUtils.contains(remark, "安排投递", "到达处理中心", "离开处理中心")
				&& StringUtils.contains(address, getExpCity(county))) {
			status = 565L;
		} else if (StringUtils.contains(remark, "签收", "未签收", "未妥投", "代收", "妥投")) {
			status = 600L;
		}
		return status;
	}

	public Date strToDate(String operationTime) {
		String date = operationTime.substring(0, 10);
		String time = operationTime.substring(11);
		return DateUtil.parse(date + " " + time, "yyyy-MM-dd HH:mm:ss");
	}

	// 获取快递单号
	public AbsResponse<List<TmTmsOrderCodeDTO>> getTmsOrderCode(List<ShipOrderDTO> shipOrders) throws Exception {
		// 封装数据--start
		Map<String, Object> m = Maps.newHashMap();
		m.put("sysAccount", "sysAccount");// 暂时还没有真实数据，所以传个固定的
		m.put("passWord", "passWord");
		m.put("appKey", "appKey");
		m.put("printKind", "printKind");
		// printDatas
		List<Map<String, Map<String, String>>> printDatal = Lists.newArrayList();
		if (null != shipOrders && shipOrders.size() > 0) {
			for (ShipOrderDTO sOrder : shipOrders) {
				Map<String, String> printDataM = Maps.newHashMap();
				printDataM.put("businessType", sOrder.getBusinessType() == null ? "" : sOrder.getBusinessType());
				printDataM.put("dateType", sOrder.getDateType() == null ? "" : sOrder.getDateType());
				printDataM.put("procdate", String.valueOf(sOrder.getCreateDate() == null
						? DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss") : sOrder.getCreateDate()));
				printDataM.put("scontactor", sOrder.getSenderName() == null ? "" : sOrder.getSenderName());
				printDataM.put("scustMobile", sOrder.getSenderMobile() == null ? "" : sOrder.getSenderMobile());
				printDataM.put("scustTelplus", sOrder.getSenderPhone() == null ? "" : sOrder.getSenderPhone());
				printDataM.put("scustPost", sOrder.getSenderPostcode() == null ? "" : sOrder.getSenderPostcode());
				printDataM.put("billno", sOrder.getDeliveryId() == null ? "" : sOrder.getDeliveryId());
				printDataM.put("cargoType", sOrder.getCargoType() == null ? "" : sOrder.getCargoType());
				printDataM.put("insurance", String.valueOf(sOrder.getInsurance()));
				printDataM.put("scustAddr", sOrder.getSenderAddress() == null ? "" : sOrder.getSenderAddress());
				printDataM.put("scustComp", sOrder.getSenderCompany() == null ? "" : sOrder.getSenderCompany());
				printDataM.put("tcontactor", sOrder.getReceiverName() == null ? "" : sOrder.getReceiverName());
				printDataM.put("tcustMobile", sOrder.getReceiverMobile() == null ? "" : sOrder.getReceiverMobile());
				printDataM.put("tcustTelplus", sOrder.getReceiverPhone() == null ? "" : sOrder.getReceiverPhone());
				printDataM.put("tcustPost", sOrder.getReceiverPostcode() == null ? "" : sOrder.getReceiverPostcode());
				printDataM.put("tcustAddr", sOrder.getReceiverAddress() == null ? "" : sOrder.getReceiverAddress());
				printDataM.put("tcustComp", sOrder.getReceiverCompany() == null ? "" : sOrder.getReceiverCompany());
				printDataM.put("tcustProvince",
						sOrder.getReceiverProvince() == null ? "" : sOrder.getReceiverProvince());
				printDataM.put("tcustCity", sOrder.getReceiverCity() == null ? "" : sOrder.getReceiverCity());
				printDataM.put("tcustCounty", sOrder.getReceiverCounty() == null ? "" : sOrder.getReceiverCounty());
				printDataM.put("weight", String.valueOf(sOrder.getWeight() == null ? 0 : sOrder.getWeight()));
				printDataM.put("length", String.valueOf(sOrder.getLength()));
				printDataM.put("insureType", sOrder.getInsureType() == null ? "" : sOrder.getInsureType());
				printDataM.put("insure", String.valueOf(sOrder.getInsure()));
				printDataM.put("fee", String.valueOf(sOrder.getFee()));
				// printDataM.put("feeUppercase", sOrder.getFeeUppercase() ==
				// null
				// ? "" : sOrder.getFeeUppercase());
				printDataM.put("cargoDesc", sOrder.getCargoDesc() == null ? "" : sOrder.getCargoDesc());
				printDataM.put("deliveryclaim", sOrder.getDeliveryclaim() == null ? "" : sOrder.getDeliveryclaim());
				printDataM.put("remark", sOrder.getRemark() == null ? "" : sOrder.getRemark());
				printDataM.put("bigAccountDataId",
						sOrder.getBigAccountDataId() == null ? "" : sOrder.getBigAccountDataId());
				printDataM.put("customerDn", sOrder.getOrderId() == null ? "" : sOrder.getOrderId());
				printDataM.put("productCode", sOrder.getProductCode() == null ? "" : sOrder.getProductCode());
				// printDataM.put("blank1",
				// sOrder.getBlank1() == null ? "" : sOrder.getBlank1());
				// printDataM.put("blank2",
				// sOrder.getBlank2() == null ? "" : sOrder.getBlank2());
				// printDataM.put("blank3",
				// sOrder.getBlank3() == null ? "" : sOrder.getBlank3());
				// printDataM.put("blank4",
				// sOrder.getBlank4() == null ? "" : sOrder.getBlank4());
				// printDataM.put("blank5",
				// sOrder.getBlank5() == null ? "" : sOrder.getBlank5());
				Map<String, Map<String, String>> parentM = Maps.newHashMap();
				parentM.put("printData", printDataM);
				printDatal.add(parentM);
			}
		}
		m.put("printDatas", printDatal);
		// 封装数据--end
		String strXml = XmlConverter.convert("XMLInfo", m);
		Map<String, String> params = Maps.newHashMap();
		Queue<Object[]> queue = new LinkedList<Object[]>();
		String xmlStr = new String(Base64.encodeBase64(strXml.getBytes(charset)), charset);
		params.put("xmlStr", xmlStr);
		queue.offer(new Object[] { "xmlStr", XMLType.XSD_STRING, xmlStr });
		String retXml = callApi("updatePrintEMSDatas", params, queue);
		retXml = new String(Base64.decodeBase64(retXml), charset);
		Element root = XmlUtils.getRootElementFromString(retXml);
		String retcode = root.getElementsByTagName("result").item(0).getTextContent();// 暂时没发现可以直接可以通过xml字符串来获取textcontent,所以自己写了一个方法
		AbsResponse<List<TmTmsOrderCodeDTO>> resp = new AbsResponse<List<TmTmsOrderCodeDTO>>();
		List<TmTmsOrderCodeDTO> ttOrderCodeL = Lists.newArrayList();
		if ("0".equals(retcode)) {// 失败
			resp.setCode(100);
			resp.setMsg(root.getElementsByTagName("errorDesc").item(0).getTextContent());
			NodeList errordetailL = root.getElementsByTagName("errorDetail");
			for (int i = 0; i < errordetailL.getLength(); i++) {
				NodeList errdetailchildL = errordetailL.item(i).getChildNodes();
				for (int j = 0; j < errdetailchildL.getLength(); i++) {
					TmTmsOrderCodeDTO ttordercode = new TmTmsOrderCodeDTO();
					if ("dataID".equals(errdetailchildL.item(j).getNodeName())) {
						// 预留
					} else if ("dataError".equals(errdetailchildL.item(j).getNodeName())) {
						// 预留
					} else if ("dErrorCode".equals(errdetailchildL.item(j).getNodeName())) {
						// 预留
					}
					ttOrderCodeL.add(ttordercode);
				}
			}
		}
		resp.setData(ttOrderCodeL);
		return resp;
	}

	// 上传重量给快递公司
	public AbsResponse uploadWeight(String content) throws Exception {
		throw new IscsException(100, "不支持");
	}

	public AbsResponse getTmsOrderCode(ShipOrderDTO order) throws Exception {
		// TODO Auto-generated method stub
		throw new IscsException(100, "不支持");
	}

	public AbsResponse cancelTmsOrderCode(ShipOrderDTO shipOrder) throws Exception {
		// TODO Auto-generated method stub
		throw new IscsException(100, "不支持");
	}

	public AbsResponse cancelTmsOrderCode(List<ShipOrderDTO> shipOrders) throws Exception {
		throw new IscsException(100, "不支持多个订单,请调用单个的");
	}

	// 下载快递单号
	public AbsResponse<List<TmTmsOrderCodeDTO>> downLoadOutSid(boolean isCod, int num) throws Exception {

		// 封装数据--start
		Map<String, Object> m = Maps.newHashMap();
		m.put("sysAccount", "sysAccount");// 暂时还没有真实数据，所以传个固定的
		m.put("passWord", "passWord");
		m.put("appKey", "appKey");
		m.put("businessType", "businessType");
		m.put("billNoAmount", String.valueOf(num));
		// 封装数据--end

		String strXml = XmlConverter.convert("XMLInfo", m);
		Map<String, String> params = Maps.newHashMap();
		Queue<Object[]> queue = new LinkedList<Object[]>();
		String xmlStr = new String(Base64.encodeBase64(strXml.getBytes(charset)), charset);
		params.put("xmlStr", xmlStr);
		queue.offer(new Object[] { "xmlStr", XMLType.XSD_STRING, xmlStr });
		String retXml = callApi("getBillNoBySys", params, queue);

		retXml = new String(Base64.decodeBase64(retXml), charset);
		Element root = XmlUtils.getRootElementFromString(retXml);
		String retcode = root.getElementsByTagName("result").item(0).getTextContent();
		AbsResponse<List<TmTmsOrderCodeDTO>> resp = new AbsResponse<List<TmTmsOrderCodeDTO>>();
		List<TmTmsOrderCodeDTO> ttOrderCodeL = Lists.newArrayList();
		if ("1".equals(retcode)) {// 成功
			NodeList assignIdL = root.getElementsByTagName("assignId");
			for (int i = 0; i < assignIdL.getLength(); i++) {
				NodeList assignidchildL = assignIdL.item(i).getChildNodes();
				for (int j = 0; j < assignidchildL.getLength(); i++) {
					TmTmsOrderCodeDTO ttordercode = new TmTmsOrderCodeDTO();
					if ("billno".equals(assignidchildL.item(j).getNodeName())) {
						ttordercode.setOutSid(assignidchildL.item(j).getTextContent());
					}
					;
					ttOrderCodeL.add(ttordercode);
				}
			}
		} else {
			resp.setCode(100);
			resp.setMsg(root.getElementsByTagName("errorDesc").item(0).getTextContent());
		}
		resp.setData(ttOrderCodeL);
		return resp;

	}

	// 访问WS
	private Object callService(String targetAddress, String namespaceURI, String localPart, Queue<Object[]> params,
			String headerName, Map<String, String> headerParams, int timeOut, QName returnType, Class<?> clazz)
					throws ServiceException, SOAPException, RemoteException {
		Call call = (Call) new Service().createCall();
		call.setTimeout(timeOut);
		call.setTargetEndpointAddress(targetAddress);
		call.setOperationName(new QName(namespaceURI, localPart));
		Object[] wsParams = new Object[params.size()];
		Object[] temp;
		int i = 0;
		while ((temp = params.poll()) != null) {
			QName type = (QName) temp[1];
			call.addParameter(temp[0].toString(), type, ParameterMode.IN);
			wsParams[i] = temp[2];
			i++;
		}
		if (clazz != null) {
			call.registerTypeMapping(clazz, returnType, new BeanSerializerFactory(clazz, returnType), // 序列化
					new BeanDeserializerFactory(clazz, returnType));
			call.setReturnClass(Array.newInstance(clazz, 100).getClass());
		} else {
			call.setReturnType(returnType);
		}

		// 由于需要认证，故需要设置调用的用户名和密码。
		if (StringUtils.isNotEmpty(headerName) && headerParams != null) {
			SOAPHeaderElement soapHeader = new SOAPHeaderElement(namespaceURI, headerName);
			soapHeader.setNamespaceURI(namespaceURI);
			for (String key : headerParams.keySet()) {
				soapHeader.addChildElement(key).setValue(headerParams.get(key));
			}
			call.addHeader(soapHeader);
		}

		return call.invoke(wsParams);
	}

	// 访问api
	private String callApi(String method, Map<String, String> appParams, Queue<Object[]> queue)
			throws IOException, ServiceException, SOAPException {
		String responseString = null;
		Date reqDate = new Date();
		try {
			responseString = callService(apiUrl, targetNamespace, method, queue, null, null, 3000, XMLType.XSD_STRING,
					null).toString();// 等工具类修改好了可以调用公用的
		} finally {
			// appendReqAResp(method, reqDate, apiUrl, appParams,
			// responseString);
			appendReqAResp(method, reqDate, apiUrl, appParams, null, responseString);
		}
		return responseString;
	}

	private String getExpState(String state) {
		if ((state == null) || (state.length() == 0)) {
			return "";
		}
		return state.replace("省", "").replace("壮族自治区", "").replace("自治区", "").replace("市", "");
	}

	private String getExpCity(String city) {
		if ((city == null) || (city.length() == 0)) {
			return "";
		}
		return city.replace("市", "").replace("县", "").replace("区", "");
	}

	@Override
	public void appendReqAResp(String apiMethod, Date reqDate, String reqString, Map<String, String> params,
			Map<String, String> headerParams, String responseString) {

	}

	@Override
	public List<AmRequestLogDTO> getAccessLogList() {
		return null;
	}

	@Override
	public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List generateExpressInfos(List expressOrderInfoDTOs) throws Exception {
		return null;
	}

	@Override
	public void uploadWeight(List list) throws Exception {

	}


	@Override
	public void cancelExpressOrder(String orderId, String outSid) throws Exception {
		// TODO Auto-generated method stub

	}

}
