package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;

import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.PlatformApiInstancer;

/**
 * <pre>
 * 电商平台、ERP、跨境电商平台
 * 电商平台编号范围：0xxx=0001 ~ 0999
 * </pre>
 * 
 * @author huangzhigang
 *
 */
public enum BaPlatform {
	// EC
	ENTITY_STORE(1L),
	
	TAOBAO(10L, new PlatformApiInstancer.TaobaoInstancer()),
	
//	TMALL(12L, new PlatformApiInstancer.TaobaoInstancer()),
//
//	TAOBAO_FENXIAO(15L, new PlatformApiInstancer.TaobaoFxInstancer()),
//
	JINGDONG(20L, new PlatformApiInstancer.JingdongInstancer()),
//
	YHD(30L, new PlatformApiInstancer.YhdInstancer()),
//
//	SUNING(40L, new PlatformApiInstancer.SuningInstancer()),
//
//	BEIBEI(50L, new PlatformApiInstancer.BeibeiInstancer()),
//
//	MIYABAOBEI(60L, new PlatformApiInstancer.MiyabaobeiInstancer()),
//
//	AMAZON(70L, new PlatformApiInstancer.AmazonInstancer()),
//
//	AMAZON_ZH(75L, new PlatformApiInstancer.AmazonInstancer()),
//
//	AMAZON_UK(76L, new PlatformApiInstancer.AmazonInstancer()),
//
//	DANGDANG(80L, new PlatformApiInstancer.DangDangInstancer()),
//
//	VJIA(90L, new PlatformApiInstancer.VjiaInstancer()),
//
//	ALIEXPRESS(100L, new PlatformApiInstancer.AliExpressInstancer()),
//
	ALI1688(105L, new PlatformApiInstancer.Ali1688Instancer()),

//	RONGEGOU(110L, new PlatformApiInstancer.RongegouInstancer()),
//
	WECHAT(27L, new PlatformApiInstancer.WeChatInstancer()),

	WECHAT_Co(29L, new PlatformApiInstancer.WeChatInstancer()),
//
//	YOUGOU(120L),
//
//	JUMEI(130L),
//
//	MOUGUJIE(140L),
//
//	YOUZAN(150L),
//
//	SHANGPAI(160L),
//
//	CHUCHUJIE(170L),
//
//	MINGXINGYICHU(180L),
//
//	MLS(190L),
//
//	VIP(200L),
//
//	// ERP
//	ERP(300L),
//
//	QIMEN(305L),
//
//	WDT(310L),
//
//	FURUN(320L),
//
//	EDB(330L),
//
//	EDB2(335L),
//
//	BAISHENG(340L),
//
//	EFUBAO(350L),
//
//	YYC(360L),
//
//	GUANYI(370L),
//
//	RUIXUE(380L),
//
//	// CBEC
//	WLB(400L),
//
//	WLB_ZY(410L),
//
//	WY_OVERSEA(420);
;
	private long id;
	private ApiInstancer apiInstancer;

	private BaPlatform(long id) {
		this.id = id;
	}

	private BaPlatform(long id, ApiInstancer instancer) {
		this.id = id;
		this.apiInstancer = instancer;
	}

	public ApiInstancer getApiInstancer() {
		return apiInstancer;
	}

	public long getId() {
		return this.id;
	}

	public boolean equalsByName(String apiName) {
		return this.name().equals(apiName);
	}

	public boolean equalsById(Long platformId) {
		return platformId != null && this.id == platformId.longValue();
	}

	public static BaPlatform getPlatform(String apiName) {
		try{
			return BaPlatform.valueOf(BaPlatform.class, apiName);
		}catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static BaPlatform getPlatform(long id) {
		for (BaPlatform item : values()) {
			if (item.id == id)
				return item;
		}

		return null;
	}

}
