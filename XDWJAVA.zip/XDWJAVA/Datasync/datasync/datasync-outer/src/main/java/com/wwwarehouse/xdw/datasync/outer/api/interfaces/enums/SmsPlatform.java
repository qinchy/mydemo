package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;


import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.SmsApiInstancer;

/**
 * <pre>
 * 短信平台编码
 * 短信平台格式：11xx=1100 ~ 1199
 * </pre>
 * @author Huangzhigang
 * 
 * 短信平台编号
 *
 */
public enum SmsPlatform {
	HSTX(1110L, "浩丝通讯", new SmsApiInstancer.HaosiInstancer()),
//	EUCP(1120L, "亿美软通", new SmsApiInstancer.YimeiInstancer()),
//	ETONENET(1130L, "移通网络" ,new SmsApiInstancer.EtonenetInstancer()),
	YPNET(1140L, "云片网络", new SmsApiInstancer.YpnetInstancer()),
//	MWTX(1150L, "梦网通讯", new SmsApiInstancer.MengWangInstancer())
;

	private String platformName;
	private String apiCode;
	private long id;
	private ApiInstancer apiInstancer;

	private SmsPlatform(long id, String platformName, ApiInstancer apiInstancer) {
		this.apiCode = name();
		this.id = id;
		this.platformName = platformName;
		this.apiInstancer = apiInstancer;
	}

	public boolean equalsByApiCode(String apiCode) {
		return this.apiCode.equals(apiCode);
	}

	public boolean equalsById(Long apiId) {
		return apiId != null && this.id == apiId.longValue();
	}

	public String getPlatformName() {
		return this.platformName;
	}

	public String getApiCode() {
		return this.apiCode;
	}

	public long getId() {
		return this.id;
	}

	public ApiInstancer getApiInstancer() {
		return apiInstancer;
	}

	public boolean equalsByName(String apiName) {
		return this.name().equals(apiName);
	}

	public static SmsPlatform getPlatform(String apiName) {
		try{
			return SmsPlatform.valueOf(SmsPlatform.class, apiName);
		}catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static SmsPlatform getPlatform(long id) {
		for (SmsPlatform item : values()) {
			if (item.id == id)
				return item;
		}

		return null;
	}

}
