package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.BaAreaWeatherDTO;

public interface IWeatherApi {
    public AbsResponse<BaAreaWeatherDTO> getWeather(String city, String date);

    /**
     * 下载天气情况
     * @param city:城市名称，国内城市支持中英文，国际城市支持英文
     * @return
     */
    public AbsResponse<BaAreaWeatherDTO> getWeather(String city);

    /**
     * 获取银行卡信息
     * @param cardNum
     * @return
     */
//    public AbsResponse<JSONObject> getBankCardInfo(String cardNum);

}
