package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.taobao.api.domain.TmcGroup;
import com.taobao.api.request.TmcGroupAddRequest;
import com.taobao.api.request.TmcGroupDeleteRequest;
import com.taobao.api.request.TmcGroupsGetRequest;
import com.taobao.api.request.TmcMessagesConfirmRequest;
import com.taobao.api.response.TmcGroupAddResponse;
import com.taobao.api.response.TmcGroupDeleteResponse;
import com.taobao.api.response.TmcGroupsGetResponse;
import com.taobao.api.response.TmcMessagesConfirmResponse;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import com.wwwarehouse.xdw.datasync.outer.api.ots.DefaultTaobaoClient;
import com.wwwarehouse.xdw.datasync.outer.api.ots.OtsApiClient;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by jianjun.guan on 2017/6/8 0008.
 */
public class TaobaoApi extends TaobaoProductApi {

    public TaobaoApi(AmAppSubscriptionDTO subscription) {
        this.subscription = subscription;
        this.relatedId = subscription.getSubscriptionBuId();
        AmAppkeyDTO app = subscription.getApp();
        this.platformId = app.getPlatformId();
        this.appKey = app.getAppKey();
        this.appSecret = app.getAppSecret();
        this.sessionKey = subscription.getAccessToken();
        this.sellerNick = subscription.getPlatformUserNick();

        if (this.isEnableOts) {
            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/tradeAction";
        } else {
            setApiUrl(app.getApiUrl());
            this.client = new DefaultTaobaoClient(this.apiUrl, this.appKey, this.appSecret);
        }
    }

    public TaobaoApi(AmAppSubscriptionDTO subscription, boolean isEnableOts) {
        this.subscription = subscription;
        this.relatedId = subscription.getSubscriptionBuId();
        AmAppkeyDTO app = subscription.getApp();
        this.platformId = app.getPlatformId();
        this.appKey = app.getAppKey();
        this.appSecret = app.getAppSecret();
        this.sessionKey = subscription.getAccessToken();
        this.sellerNick = subscription.getPlatformUserNick();
        this.isEnableOts = isEnableOts;

        if (this.isEnableOts) {
            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/tradeAction";
        } else {
            setApiUrl(app.getApiUrl());
            this.client = new DefaultTaobaoClient(this.apiUrl, this.appKey, this.appSecret);
        }
    }

    public TaobaoApi(String appKey, String appSecret, String sessionKey, String nick, boolean isEnableOts) {
        this.appKey = appKey;
        this.appSecret = appSecret;
        this.sellerNick = nick;
        this.sessionKey = sessionKey;
        if (isEnableOts) {
            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/tradeAction";
            this.isEnableOts = true;
        } else {
            this.apiUrl = "http://gw.api.taobao.com/router/rest";
            client = new DefaultTaobaoClient(this.apiUrl, this.appKey, this.appSecret);
        }
    }

    /**
     * 获取自定义用户分组列表
     * @param groupNames	要查询分组的名称, 最大列表长度：20
     * @return
     */
    public AbsResponse<List<?>> getTmcGroups(String groupNames) {
        AbsResponse<List<?>> retBean = new AbsResponse<>();
        try {
            List<TmcGroup> tradeList = new ArrayList<>();
            do {
                List<TmcGroup> poList = getTmcGroupPage(groupNames);
                if (poList != null && !poList.isEmpty()) {
                    tradeList.addAll(poList);
                }
            } while (hasNext());

            retBean.setData(tradeList);
        } catch (Exception e) {
            log.error("取消服务失败", e);
            retBean.setResult(503, e.getMessage());
        }
        return retBean;
    }

    private List<TmcGroup> getTmcGroupPage(String groupNames) {
        List<TmcGroup> list = null;
        try {
            TmcGroupsGetRequest req = new TmcGroupsGetRequest();
            req.setGroupNames(groupNames);
            req.setPageNo((long)pageNo);
            req.setPageSize((long)pageSize);
            TmcGroupsGetResponse response = this.executeOtsOne(req);
            if (response != null && response.getGroups() != null) {
                list = response.getGroups();

                if (pageNo == 1) {
                    itemTotal = response.getTotalResults().intValue();
                    setPageInfo(itemTotal);
                }
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
        } finally {
            pageNo--;
        }
        return list;
    }

    /**
     *	删除指定的分组或分组下的用户
     * @param groupName		分组名称，分组删除后，用户的消息将会存储于默认分组中
     * @param nicks			用户列表，不传表示删除整个分组，如果用户全部删除后，也会自动删除整个分组 最大列表长度：20
     * @param userPlatform	用户所属于的平台类型，tbUIC:淘宝用户; icbu: icbu用户
     * @return
     */
    public AbsResponse<String> delTmcGroup(String groupName, String nicks, String userPlatform) {
        AbsResponse<String> retBean = new AbsResponse<>();
        try {
            TmcGroupDeleteRequest req = new TmcGroupDeleteRequest();
            req.setGroupName(groupName);
            req.setNicks(nicks);
            req.setUserPlatform(userPlatform);
            TmcGroupDeleteResponse response = this.executeOtsOne(req);

            Boolean isSucces = null;
            if (response == null || response.getIsSuccess() == null) {
                isSucces = false;
            } else {
                isSucces = response.getIsSuccess();
            }

            if(!isSucces){
                retBean.setResult(500, getErrorMsg(response));
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
            retBean.setResult(503, e.getMessage());
        }
        return retBean;
    }

    /**
     * taobao.tmc.group.add (为已开通用户添加用户分组)
     * @param groupName		分组名称，同一个应用下需要保证唯一性，最长32个字符。添加分组后，消息通道会为用户的消息分配独立分组，但之前的消息还是存储于默认分组中。不能以default开头，default开头为系统默认组。
     * @param nicks			用户昵称列表，以半角逗号分隔，支持子账号，支持增量添加用户 最大列表长度：200
     * @param userPlatform	用户所属于的平台类型，tbUIC:淘宝用户; icbu: icbu用户
     * @return
     */
    public AbsResponse<String> addTmcGroup(String groupName, String nicks, String userPlatform) {
        AbsResponse<String> retBean = new AbsResponse<>();
        try {
            TmcGroupAddRequest req = new TmcGroupAddRequest();
            req.setGroupName(groupName);
            req.setNicks(nicks);
            req.setUserPlatform(userPlatform);
            TmcGroupAddResponse response = this.executeOtsOne(req);

            if (response == null || response.getGroupName() == null) {
                retBean.setResult(500, getErrorMsg(response));
            } else {
                retBean.setData(response.getGroupName());
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
            retBean.setResult(503, e.getMessage());
        }
        return retBean;
    }

    /**
     * taobao.tmc.messages.confirm (确认消费消息的状态)
     * @param groupName		分组名称，不传代表默认分组
     * @param sMessageids			处理成功的消息ID列表 最大 200个ID
     * @return
     */
    public AbsResponse<Boolean> confirmTmcGroup(String groupName, String sMessageids) {
        AbsResponse<Boolean> retBean = new AbsResponse<>();
        if(StringUtils.isEmpty(sMessageids)){
            return retBean.setResult(400, "sMessageids不能为空");
        }
        try {
            TmcMessagesConfirmRequest req = new TmcMessagesConfirmRequest();
            req.setGroupName(groupName);
            req.setsMessageIds(sMessageids);
            TmcMessagesConfirmResponse response = this.executeOtsOne(req);

            Boolean isSucces = null;
            if (response == null || response.getIsSuccess() == null) {
                isSucces = false;
            } else {
                isSucces = response.getIsSuccess();
            }

            if(!isSucces){
                retBean.setResult(500, getErrorMsg(response));
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
            retBean.setResult(503, e.getMessage());
        }
        return retBean;
    }

    public static void main(String[] args){
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
        ITradeApi api = new TaobaoApi(subscription);
    }
}
