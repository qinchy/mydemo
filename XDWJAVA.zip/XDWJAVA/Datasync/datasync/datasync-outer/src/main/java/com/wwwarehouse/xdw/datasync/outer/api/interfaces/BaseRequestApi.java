package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.utils.IscsHashMap;
import com.wwwarehouse.commons.utils.ServerUtil;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmRequestLogDTO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public abstract class BaseRequestApi {
	
	protected String apiUrl;
	protected Long relatedId;
	protected Long platformId;
	protected int pageNo = 1;
	protected int pageSize = 50;
	protected int itemTotal = 0;
	protected int pageTotal = 0;
	protected String status;
	protected boolean isFullField;
	protected boolean curved = false;
	protected Date startDate;
	protected Date endDate;
	protected String charset = "utf-8";
	private List<AmRequestLogDTO> accessLogList;
	

	private static Log log = LogFactory.getLog(BaseRequestApi.class);
	
	@SuppressWarnings("unchecked")
    protected BaseRequestApi() {
	}
	
	public String getApiUrl() {
		return this.apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}
	
	public int getItemTotal() {
		return this.itemTotal;
	}

	public void setItemTotal(int itemTotal) {
		this.itemTotal = itemTotal;
	}

	public int getPageTotal() {
		return this.pageTotal;
	}

	public void setPageTotal(int pageTotal) {
		this.pageTotal = pageTotal;
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return this.pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isFullField() {
		return this.isFullField;
	}

	public void setFullField(boolean isFullField) {
		this.isFullField = isFullField;
	}

	public List<AmRequestLogDTO> getAccessLogList() {
		return this.accessLogList;
	}

	public Long getRelatedId() {
		return this.relatedId;
	}

	public void setRelatedId(Long relatedId) {
		this.relatedId = relatedId;
	}

	public Long getPlatformId() {
		return this.platformId;
	}

	public void setPlatformId(Long platformId) {
		this.platformId = platformId;
	}

	public boolean hasNext() {
		return (this.pageNo >= 2) && (this.pageNo <= this.pageTotal);
	}

	public void clearAccessLogs() {
		if (this.accessLogList != null) {
			this.accessLogList.clear();
		}
	}

	protected void setBase(String status, Date startDate, Date endDate,
			boolean isFullField) {
		clearAccessLogs();
		if (this.pageNo == 1) {
			this.startDate = startDate;
			this.endDate = endDate;
			this.status = status;
			this.isFullField = isFullField;
		}
	}

	protected void setPageInfo(int itemTotal_) {
		if (this.curved) {
			return;
		}
		this.itemTotal = itemTotal_;
		this.pageTotal = (this.itemTotal + this.pageSize - 1) / this.pageSize;
		this.pageNo = this.pageTotal + 1;
		this.curved = true;
	}

	protected String getRequestString() {
		IscsHashMap param = new IscsHashMap();
		param.put("shopId", this.relatedId);
		param.put("pageNo", this.pageNo);
		param.put("pageSize", this.pageSize);
		param.put("pageTotal", this.pageTotal);
		param.put("isFullField", this.isFullField);
		param.put("status", this.status);
		param.put("startDate", this.startDate);
		param.put("endDate", this.endDate);
		
		String reqString = null;
		try{
			reqString = JsonUtils.toJson(param);
		}catch (Exception e) {
			log.error("请求数据获取失败", e);
		}
		return reqString;
	}
	
	public void appendAccessLog(String reqString, String respContent,
			Date requestDate, Date responseDate, String methodName, String requestIp) {
		appendAccessLog(reqString, respContent, requestDate, responseDate,
				methodName, requestIp, null);
	}

	public void addErrLog(String respContent, Date requestDate,
			Date responseDate, String methodName) {
		appendAccessLog(null, respContent, requestDate, responseDate, methodName, null);
	}

	public void appendAccessLog(String reqString, String respContent, Date requestDate,
			Date responseDate, String methodName, String requestIp, String headerParams) {
		AmRequestLogDTO downLog = new AmRequestLogDTO(this.relatedId, this.startDate,
				this.endDate, this.status, requestDate, responseDate, reqString,
				respContent, Long.valueOf(this.pageNo), methodName, requestIp, headerParams);
		
		if (this.accessLogList == null) {
			this.accessLogList = new ArrayList<AmRequestLogDTO>(5);
		}
		this.accessLogList.add(downLog);
	}

	/**
	 * 设置请求信息与响应内容
	 * @param requestString
	 * @param responseString
	 */
	public void appendReqAResp(String apiMethod, Date reqDate, String requestString,
			Map<String, String> params, String responseString) {
		appendReqAResp(apiMethod, reqDate, requestString, params, null, responseString);
	}

	public void appendReqAResp(String apiMethod, Date reqDate, String requestString,
			Map<String, String> params, Map<String, String> headerParams, String responseString) {
		StringBuilder reqBuider = new StringBuilder();
		boolean startWithHttp = requestString != null && requestString.startsWith("http");
		if(startWithHttp){
			reqBuider.append(requestString);
		} else {
			reqBuider.append(this.apiUrl);
		}
		if(reqBuider.indexOf("?") == -1){
			reqBuider.append("?");
		} else {
			reqBuider.append("&");
		}

		if(!startWithHttp && requestString != null){
			reqBuider.append(requestString).append("&");
		}
		if (params != null) {
			try {
				reqBuider.append(WebUtils.buildQuery(params, charset));
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		
		String headerParamsStr  = null;
		if (headerParams != null) {
			try {
				headerParamsStr = WebUtils.buildQuery(headerParams, charset);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		
		String requestIp = ServerUtil.getServerIp();
		appendAccessLog(reqBuider.toString(), responseString, reqDate,
				new Date(), apiMethod, requestIp, headerParamsStr);
	}

}
