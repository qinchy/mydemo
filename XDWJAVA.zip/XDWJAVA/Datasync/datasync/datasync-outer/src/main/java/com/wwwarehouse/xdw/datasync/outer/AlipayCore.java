package com.wwwarehouse.xdw.datasync.outer;

import com.wwwarehouse.commons.utils.WebUtils;

import java.util.*;

/* *
 *类名：AlipayFunction
 *功能：支付宝接口公用函数类
 *详细：该类是请求、通知返回两个文件所调用的公用函数核心处理文件，不需要修改
 *版本：1.0
 *日期：2016-06-06
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayCore {
	
	 /**
     * 支付宝提供给商户的服务接入网关URL(新)
     */
//  	public static String partner = "2088701477536734";
//  	public static String privatekey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBANgYnhOma93e4OtQRkR7BeMy6V6PFInG+TXe8un3ijdPHh4nxorj06Dih02eR7ZhRr2ymGGBsSXuWptgEJHfuJmhgkCjlqE9HRXZfRrmrJ+xNYBj58VbaKbZBUC+qLMnb5IiDg6q/X1LAvoS9Tty+z+kczENUnN0+bdmgeO80D3rAgMBAAECgYBzKKNNG3oOUdEQ9cWMhvb7Pc1py9wJFFUIZViUYItysCH/tfizWXgVG8M5FOlogux8+SkFhWTPLvdwJ8CMzGmF0t35Oub+vbrYorXBCtQUxHSI0fGPfdi6y9PKxc2W0GxLFZUTzewUIY/XJEuhgcwmedQhFy2XeukU4jMpLonp2QJBAPMqRXEpZVkWjhE7p5pgDQjuggzySF6opQcRlB+G6akzpANCwihI9+RaV7Lbvg5T5GyyahE0Z672tmxAZ7eqdsUCQQDjgJTTw/jtCX8R9LUJVraVxFHYxxQv+kw+qn6dPPoRodP3wN9u1Zu5NZW663scQ+amKQhJFam5TCL8lh7/U6zvAkEAht/4eocKhvqivF5JXbBPKpgYnJO6nn6OYrhWX5JWgpp5K7HYvb2Teh6+LCAEcDAKMFxZxsc5h2uizbJ/lPlBPQJARfqkTOtoI4mbQ6uxEDlTGohz4KmEBSoJz/Dj13wNM+VCbWAvmkksiHD6KLAMg2pDhXLzsH9wYKYR0P5gdIuJkwJAMkr2VeYp3CRsR+TtBgkM5yJsYHDDqbOnSiOzLmD8cQC6QzUmtKIM6k0dcvcLVAaX4AA5urslyAi1LtFmGAimBQ==";
//  	public static String publickey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB";
//  	public static String key = "sk4redn8xygs3ged8dwzzngl424c6ihc";
  	public static String log_path = "D:\\";
  	public static String input_charset = "utf-8";
  	public static String sign_type = "RSA";

    /**
     * 除去数组中的空值和签名参数
     * @param sArray 签名参数组
     * @return 去掉空值与签名参数后的新签名参数组
     */
    public static Map<String, String> paraFilter(Map<String, String> sArray) {

        Map<String, String> result = new HashMap<String, String>();

        if (sArray == null || sArray.size() <= 0) {
            return result;
        }
        for (String key : sArray.keySet()) {
            String value = sArray.get(key);
            if (value == null || value.equals("") || key.equalsIgnoreCase("sign")
                    || key.equalsIgnoreCase("sign_type")) {
                continue;
            }
            result.put(key, value);
        }

        return result;
    }

    /**
     * 把数组所有元素，并按照“参数=参数值”的模式用“&”字符拼接成字符串
     * @param params 需要参与字符拼接的参数组
     * @return 拼接后字符串
     */
    public static String createLinkString(Map<String, String> params) {
        return WebUtils.buildQuery(params, "utf-8");
    }


}
