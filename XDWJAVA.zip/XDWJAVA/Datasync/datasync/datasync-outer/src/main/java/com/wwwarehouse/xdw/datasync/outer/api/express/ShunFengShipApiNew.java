package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.google.common.collect.Maps;
import com.thoughtworks.xstream.XStream;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.model.sfmodel.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 14:19 on 2017/6/16.
 * @Modified By:
 */
public class ShunFengShipApiNew implements IShipApi<ExpressOrderSFInfoDTO> {

    private static final String checkword = "j8DzkIFgmlomPt0aLuwU";
    private static final String headtext = "BSPdevelop";
    private String apiUrl = "http://bsp-ois.sit.sf-express.com:9080/bsp-ois/sfexpressService";// 外网地址


    @Override
    public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
        //将请求封装为对象
        RouteRequest routeRequest = new RouteRequest("1", "1", outSid);
        Body<RouteRequest> body = new Body<>(routeRequest);
        Request request = new Request("RouteService", headtext, body);
        //将请求对象转为XML的字符串
        String requestXml = javaBeenToRequestXml(request, "RouteRequest", RouteRequest.class);

        //向顺丰发送请求XML字符串，获取返回的请求字符串
        String responseXml = callSfApi("RouteService", requestXml).replace("accept_time", "acceptTime").
                replace("accept_address", "acceptAddress");

        //将XML字符串转为返回对象
        Class[] classes =new Class[] {Response.RouteResponse.class, Body.RouteBody.class, RouteResponse.class, Route.class};
        Response.RouteResponse response = (Response.RouteResponse) responseXmlToJavaBean(responseXml, classes);

        //将返回对象的信息进一步封装
        LogisticsInformation information = new LogisticsInformation();
        //判断路由查询是否成功
        if("OK".equals(response.getHead())){
            information.setOutSid(outSid);
            Body.RouteBody responseBody = response.getBody();
            RouteResponse routeResponse = responseBody == null ? null : responseBody.getRouteResponse();
            List<Route> routes = routeResponse == null ? new ArrayList<Route>() : routeResponse.getRoutes();
            List<LogisticsInfomationDetail> details = new ArrayList<>();
            for(Route route : routes){
                LogisticsInfomationDetail detail = new LogisticsInfomationDetail();
                detail.setAddress(route.getAcceptAddress());
                detail.setDescription(route.getRemark());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(route.getAcceptTime());
                detail.setOperatingTime(date);
                details.add(detail);
            }
            information.setInfomationDetails(details);
        }else {
            throw new IscsException(100, response.getError());
        }
        return information;
    }

    @Override
    public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
        if(!(expressOrderInfo instanceof ExpressOrderSFInfoDTO)){
            throw new IscsException(3000, "参数类型必须是ExpressOrderInfoDTO");
        }
        ExpressOrderSFInfoDTO infoDTO = (ExpressOrderSFInfoDTO) expressOrderInfo;

        //将请求封装为对象
        Order order = new Order(infoDTO);
        Body<Order> body = new Body<>(order);
        Request request = new Request("OrderService", headtext, body);
        //将请求对象转为XML的字符串
        String requestXml = javaBeenToRequestXml(request, "Order", Order.class);

        //向顺丰发送请求XML字符串，获取返回的请求字符串
        String responseXml = callSfApi("RouteService", requestXml).replace("res_status", "resStatus");

        //将XML字符串转为返回对象
        Class[] classes =new Class[] {Response.OrderResponse.class, Body.OrderBody.class, OrderResponse.class};
        Response.OrderResponse response = (Response.OrderResponse) responseXmlToJavaBean(responseXml, classes);

        if("ERR".equals(response.getHead())){
            throw new IscsException(300, response.getError());
        }
        Body.OrderBody orderBody = response.getBody();
        OrderResponse orderResponse = orderBody == null? null : orderBody.getOrderResponse();
        infoDTO.setExpressId(orderResponse == null ? null : orderResponse.getMailno());
        
        return infoDTO;
    }

    @Override
    public List<ExpressOrderSFInfoDTO> generateExpressInfos(List<ExpressOrderSFInfoDTO> expressOrderInfoDTOs) throws Exception {
        throw new IscsException(100, "不支持批量生成快递物流信息!");
    }

    @Override
    public void uploadWeight(List weightInfos) throws Exception {
        if(weightInfos == null){
            return;
        }
        List<ExpressUploadWeightInfo> infos = weightInfos;

        StringBuilder success = new StringBuilder("上传成功单号：");
        StringBuilder fal = new StringBuilder("上传失败单号 ：");
        boolean allOK = true;

        for(ExpressUploadWeightInfo info : infos){
            OrderConfirmOption confirmOption = new OrderConfirmOption(info.getWeight().toString());
            //将请求封装为对象
            OrderConfirm confirm = new OrderConfirm(info.getOrderId(), info.getExpressId(), "1", confirmOption);
            Body<OrderConfirm> body = new Body<>(confirm);
            Request request = new Request("OrderConfirmService", headtext, body);
            //将请求对象转为XML的字符串
            String requestXml = javaBeenToRequestXml(request, "OrderConfirm", OrderConfirm.class);

            //向顺丰发送请求XML字符串，获取返回的请求字符串
            String responseXml = callSfApi("RouteService", requestXml).replace("res_status", "resStatus");

            //将XML字符串转为返回对象
            Class[] classes =new Class[] {Response.ConfirmResponse.class, Body.ConfirmBody.class, OrderConfirmResponse.class};
            Response.ConfirmResponse response = (Response.ConfirmResponse) responseXmlToJavaBean(responseXml, classes);

            if("OK".equals(response.getHead())){
                success.append(info.getExpressId() + ", ");
            }else{
                allOK = false;
                fal.append(info.getExpressId() + "  (失败原因" + response.getError() + ")");
            }
        }
        if(!allOK){
            throw new IscsException(300, success.append(fal.toString()).toString());
        }
    }

    public static void main(String[] args) throws Exception{
        ShunFengShipApiNew sf = new ShunFengShipApiNew();
//        sf.cancelExpressOrder("123356","123456789");
        List<ExpressUploadWeightInfo> infos = new ArrayList<>();
        ExpressUploadWeightInfo info = new ExpressUploadWeightInfo();
        info.setOrderId("123356");
        info.setExpressId("123456789");
        info.setWeight(12.11d);
        infos.add(info);
        sf.uploadWeight(infos);
    }

    @Override
    public void cancelExpressOrder(String orderId, String outSid) throws Exception {
        //将请求封装为对象
        OrderConfirm confirm = new OrderConfirm(orderId, outSid, "2", null);
        Body<OrderConfirm> body = new Body<>(confirm);
        Request request = new Request("OrderConfirmService", headtext, body);
        //将请求对象转为XML的字符串
        String requestXml = javaBeenToRequestXml(request, "OrderConfirm", OrderConfirm.class);

        //向顺丰发送请求XML字符串，获取返回的请求字符串
        String responseXml = callSfApi("RouteService", requestXml).replace("res_status", "resStatus");

        //将XML字符串转为返回对象
        Class[] classes =new Class[] {Response.ConfirmResponse.class, Body.ConfirmBody.class, OrderConfirmResponse.class};
        Response.ConfirmResponse response = (Response.ConfirmResponse) responseXmlToJavaBean(responseXml, classes);

        if("ERR".equals(response.getHead())){
            throw new IscsException(200, response.getError());
        }
    }


    @Override
    public void appendReqAResp(String apiMethod, Date reqDate, String reqString, Map<String, String> params, Map<String, String> headerParams, String responseString) {

    }

    @Override
    public List<AmRequestLogDTO> getAccessLogList() {
        return null;
    }

    /**
    * @author: sunkuo
    * @description: 根据请求的XML字符串，向顺丰发送请求并返回 回应的XML字符串
    * @param
    * @return
    * @throws
    */
    private String callSfApi(String method, String requestXml) throws Exception{

        String responseXml = null;

        Map<String, String> params = Maps.newHashMap();
        params.put("xml", requestXml);
        params.put("verifyCode", CodecUtils.encBase64Md5(requestXml + checkword));

        Date reqDate = new Date();
        try {
            responseXml = WebUtils.doPost(apiUrl, params);
        } finally {
            appendReqAResp(method, reqDate, apiUrl, params, null, responseXml);

        }
        return responseXml;
    }

    /**
     * @author: sunkuo
     * @description: 将java对象转换为对应的XML字符串。由于采用注解方式，所以需要传入class进行注解的注册
     * @param
     * @return
     * @throws
     */
    private String javaBeenToRequestXml(Request request, String bodyFieldName, Class bodyFieldClass){
        XStream xStream = new XStream();
        xStream.aliasField(bodyFieldName, Body.class, "data");
        xStream.processAnnotations(new Class[]{Request.class, bodyFieldClass});
        String strXml = xStream.toXML(request).replace("__","_");
        return  strXml;
    }

    /**
     * @author: sunkuo
     * @description: 将XML字符串转为java对象。由于采用注解方式，需要传入calss进行注解的注册
     * @param
     * @return
     * @throws
     */
    private Object responseXmlToJavaBean(String responseXml,  Class[] classes){
        XStream xStream = new XStream();
        xStream.processAnnotations(classes);
        return xStream.fromXML(responseXml);
    }
}
