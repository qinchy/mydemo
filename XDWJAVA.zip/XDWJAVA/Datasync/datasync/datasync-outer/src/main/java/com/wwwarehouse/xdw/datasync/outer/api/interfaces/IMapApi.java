package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.utils.AbsResponse;

import java.util.Map;

/**
 * Created by huahui.wu on 2017/6/15.
 */
public interface IMapApi {
	AbsResponse<Object> geocodeGeo(String address, String city);

	AbsResponse<Object> geocodeRegeo(String location);

	AbsResponse<Object> directionDriving(String origin, String destination, String strategy);

	AbsResponse<Object> directionWalking(String origin, String destination);

	Map<String, Double> getLocation(String city, String keywords);
}
