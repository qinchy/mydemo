package com.wwwarehouse.xdw.datasync.outer.api.interfaces;


import com.wwwarehouse.commons.utils.AbsResponse;

import java.util.Date;
import java.util.List;

public interface IProductApi extends IRecordAble {

	/**
	 * 查询平台商品资料
	 *
	 * @param fetchType
	 * @param productNumId
	 */
	public AbsResponse<List<?>> queryProducts(int fetchType, String productNumId, Date startModified, Date endModified);

	/**
	 * 全量更新平台库存
	 *
	 * @param productNumId
	 * @param skuNumId
	 * @param qtyAvailable   可销售数
	 * @param qtyOnLocation  在架数
	 * @param qtyUnqualified 次品数
	 * @return 0开头表示成功
	 */
	public String uploadInventory(String productNumId, String skuNumId,
								  Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified);

	/**
	 * 增量更新平台库存
	 *
	 * @param productNumId
	 * @param skuNumId
	 * @param qtyOnLocation
	 * @param qtyAvailable
	 * @return
	 */
	public String uploadInventoryAdd(String productNumId, String skuNumId,
									 Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified);

	/**
	 * 按指定productNumId查询平台商品信息
	 * @param productNumId
	 * @param skuNumId
	 * @return
	 */
	public AbsResponse<?> getSku(String productNumId, String skuNumId);

	/**
	 * 查找商品类目
	 * @param parentCid
	 * @param cids
	 * @return
	 */
	public AbsResponse<?> getTaobaoItemcats(Long parentCid, String cids);
}
