package com.wwwarehouse.xdw.datasync.outer.api.ots;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class OtsApiClient {

    private static Logger log = LogManager.getLogger(OtsApiClient.class);
    public static final String otsTaobaoHost = "http://" + ConstantsOuter.OtsTaobaoHost;
    public static final String otsAli1688Host = "http://" + ConstantsOuter.OtsAli1688Host;
    public static final String otsJdHost = "http://" + ConstantsOuter.OtsJdHost;

    private static final String APP_KEY = "v_appkey";
    private static final String APP_SIGN = "v_appsign";
    private static final String APP_TIME = "v_timestamp";
    public static final String V_STATE = "v_state";
    private static String appKey = "ISCS_OTS_TAOBAO";
    private static String appSecret = "ISCS_OTS_TAOBAO_20131010";

    public static Map<String, String> getTaobaoApiParams(String appKey, String appSecret, String sessionKey) throws Exception {
        Map<String, String> params = new HashMap<String, String>();
        params.put("appKey", appKey);
        params.put("appSecret", appSecret);
        params.put("sessionKey", sessionKey);

        return params;
    }

    public static Map<String, String> buildSysParams() {
        Map<String, String> params = new HashMap<>();
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timestamp = sdf.format(new Date());

        // 添加签名
        String sign = null;
        try{
        	sign = sign(appKey, appSecret, timestamp);
        }catch (IOException e) {
        	throw new RuntimeException(e);
		}

        params.put(APP_KEY, appKey);
        params.put(APP_SIGN, sign);
        params.put(APP_TIME, timestamp);
        
        return params;
    }

    public static <T> T execute(String apiUrl, Map<String, String> params, Class<T> clazz) throws Exception {
        Map<String, String> sysParams = buildSysParams();

        String response = WebUtils.doPost(apiUrl + "?" + WebUtils.buildQuery(sysParams, "utf-8"), params, 10000, 30000);
        JSONObject rsp = JSON.parseObject(response);
        Object data = rsp.get("data");
        if (rsp.getIntValue("errorCode") != 100) {
            throw new Exception(String.valueOf(rsp.getIntValue("errorCode")) + ":" + rsp.getString("errorText"));
        }

        if (clazz == null) {
            return null;
        }

        if (clazz == String.class) {
            return (T)data.toString();
        }

        T resp = parse(data.toString(), clazz);
        return resp;
    }

    private static String sign(String appKey, String appSecret, String timestamp) throws IOException {
        String encryptStr = appKey + appSecret + timestamp;
        byte[] bytes = CodecUtils.encryptMD5(encryptStr.getBytes("utf-8"));
        return CodecUtils.byte2hex(bytes);
    }

    public static <T> T parse(String rsp, Class<T> clazz) throws Exception {
    	
    	Gson gson = buildGson();
    	
    	
        T response = null;
        try {
        	response = gson.fromJson(rsp, clazz);
        } catch (Exception e) {
            throw e;
        }
        return response;
    }
    
	public static Gson buildGson() {
		Gson gson = new GsonBuilder().enableComplexMapKeySerialization()
				.serializeNulls().setDateFormat("yyyy-MM-dd HH:mm:ss")
				.setVersion(1.0).create();
		return gson;
	}

    
}
