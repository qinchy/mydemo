
package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl;


import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ISmsApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.sms.HaosiSmsApi;
import com.wwwarehouse.xdw.datasync.outer.api.sms.YpnetSmsApi;


/**
 * 短信接口实例化工具类
 * @author Huangzhigang
 *
 */

public class SmsApiInstancer {

	public static class HaosiInstancer extends ApiInstancer {
		@Override
		public ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
			return new HaosiSmsApi(subscription);
		}
	}
//
//	public static class EtonenetInstancer extends ApiInstancer {
//		@Override
//		public ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
//			return new EtonenetSmsApi(subscription);
//		}
//	}
//
//	public static class YimeiInstancer extends ApiInstancer {
//		@Override
//		public ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
//			return new YimeiSmsApi(subscription);
//		}
//	}
//
//	public static class MengWangInstancer extends ApiInstancer {
//		@Override
//		public ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
//			return new MengWangSmsApi(subscription);
//		}
//	}
//
	public static class YpnetInstancer extends ApiInstancer {
		@Override
		public ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
			return new YpnetSmsApi(subscription);
		}
	}

}

