package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer;

import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.*;

/**
 * Api接口获取适配类
 * 
 * @author huangzhenjie
 */
public abstract class ApiInstancer {
	/**
	 * 创建订单接口实例
	 * 
	 * @param appSuber
	 * @return ITradeApi
	 */
	public ITradeApi getTradeApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getTradeApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建商品接口实例
	 * 
	 * @param appSuber
	 * @return IProductApi
	 */
	public IProductApi getProductApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getProductApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建退款接口实例
	 * 
	 * @param appSuber
	 * @return IRefundApi
	 */
	public IRefundApi getRefundApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getRefundApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建授权接口实例
	 * 
	 * @param amAppkey
	 * @return IAuthApi
	 */
	public IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getAuthApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建Ship接口实例
	 * 
	 * @param appSuber
	 * @return IShopApi
	 */
	public IShipApi getShipApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getShipApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建店铺接口实例
	 * 
	 * @param appSuber
	 * @return IShopApi
	 */
	public IShopApi getShopApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getShopApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建短信接口实例
	 * 
	 * @param appSuber
	 * @return ISmsApi
	 */
	public ISmsApi getSmsApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getSmsApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 得到原始订单处理的service服务名称
	 * 
	 * @return 原始订单处理的service服务名称
	 */
	public String getTradeService() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getTradeService()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 得到原始退款处理的service服务名称
	 *
	 * @return 得到原始退款处理的service服务名称
	 */
	public String getRefundService() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[ApiInstance.getRefundService()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建支付接口实例
	 *
	 * @param appSuber
	 * @return IShopApi
	 */
	public IPayApi getPayApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[PayApiInstance.getPayApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}

	/**
	 * 创建地图接口实例
	 *
	 * @param appSuber
	 * @return IShopApi
	 */
	public IMapApi getMapApi(AmAppSubscriptionDTO appSuber) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("类：").append(this.getClass().getName());
		strBuilder.append("未重写[MapApiInstance.getMapApi()]方法");

		throw new RuntimeException(strBuilder.toString());
	}



}
