package com.wwwarehouse.xdw.datasync.outer.api.map;

/**
 * Created by zhigang.huang on 2017/6/8.
 */
public class empty {
}
