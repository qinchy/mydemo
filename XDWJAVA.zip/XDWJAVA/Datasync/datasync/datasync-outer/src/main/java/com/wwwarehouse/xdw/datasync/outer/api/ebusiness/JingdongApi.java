package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jd.open.api.sdk.JdClient;
import com.jd.open.api.sdk.JdException;
import com.jd.open.api.sdk.domain.afsservice.PartReceiveProvider.PartReceiveDto;
import com.jd.open.api.sdk.domain.afsservice.PartReceiveProvider.PartReceivePageResultDto;
import com.jd.open.api.sdk.domain.order.*;
import com.jd.open.api.sdk.domain.refundapply.RefundApplySoaService.RefundApplyVo;
import com.jd.open.api.sdk.domain.ware.Sku;
import com.jd.open.api.sdk.domain.ware.Ware;
import com.jd.open.api.sdk.request.JdRequest;
import com.jd.open.api.sdk.request.afsservice.PartReceiveProviderFindPartReceiveListRequest;
import com.jd.open.api.sdk.request.order.*;
import com.jd.open.api.sdk.request.refundapply.PopAfsSoaRefundapplyQueryByIdRequest;
import com.jd.open.api.sdk.request.refundapply.PopAfsSoaRefundapplyQueryPageListRequest;
import com.jd.open.api.sdk.request.seller.VenderShopQueryRequest;
import com.jd.open.api.sdk.request.ware.*;
import com.jd.open.api.sdk.response.AbstractResponse;
import com.jd.open.api.sdk.response.afsservice.PartReceiveProviderFindPartReceiveListResponse;
import com.jd.open.api.sdk.response.order.*;
import com.jd.open.api.sdk.response.refundapply.PopAfsSoaRefundapplyQueryByIdResponse;
import com.jd.open.api.sdk.response.refundapply.PopAfsSoaRefundapplyQueryPageListResponse;
import com.jd.open.api.sdk.response.seller.VenderShopQueryResponse;
import com.jd.open.api.sdk.response.ware.*;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.ots.DefaultJdClient;
import com.wwwarehouse.xdw.datasync.outer.api.ots.OtsApiClient;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 京东
 * Created by xuchun on 16/3/5.
 */
public class JingdongApi extends BaseRequestApi implements ITradeApi,
		IProductApi, IRefundApi, IShopApi {
	private static Logger log = LogManager.getLogger(JingdongApi.class);

    private static final String ORDER_FIELDS = "order_id,order_source,customs,customs_model,vender_id,pay_type,order_total_price,order_payment,freight_price,seller_discount,order_state,delivery_type,invoice_info,order_remark,order_start_time,order_end_time,consignee_info,item_info_list,coupon_detail_list,pin,return_order,payment_confirm_time,logistics_id,order_type,store_order,order_seller_price,vender_remark,balance_used,waybill,vat_invoice_info,modified"; 
	private static final String ORDER_SHORT_FIELDS = "vender_id,order_id,order_state,order_start_time,order_end_time,modified,payment_confirm_time";
    private String accessToken = null;
    private String appKey = null;
    private String appSecret = null;
    private JdClient jdClient = null;
    private AmAppSubscriptionDTO subscription;
	private boolean isEnableOts = true;

	private Long shopId = null;

    public JingdongApi(AmAppSubscriptionDTO subscription) {
        this.subscription = subscription;
        AmAppkeyDTO app = subscription.getApp();

        this.shopId = this.subscription.getSubscriptionBuId();
        this.platformId = app.getPlatformId();
        this.appKey = app.getAppKey();
        this.appSecret = app.getAppSecret();
        this.accessToken = subscription.getAccessToken();
        
        String apiUrl = app.getApiUrl();
        if(isEnableOts){
        	apiUrl = OtsApiClient.otsJdHost + "/taobao/jdAction!callApi";
			this.jdClient = new DefaultJdClient(OtsApiClient.buildSysParams(),
					apiUrl, this.accessToken, this.appKey, this.appSecret, 30000, 25000);
        } else {
        	apiUrl = app.getApiUrl();
        	this.jdClient = new DefaultJdClient(apiUrl, this.accessToken,
        			this.appKey, this.appSecret, 30000, 25000);
        }
		setApiUrl(apiUrl);
    }

	public static void main(String[] args) throws Exception {
        AmAppkeyDTO app = new AmAppkeyDTO();
        app.setApiUrl("https://api.jd.com/routerjson");
        app.setAppKey("F5FA8C15F2EAE053A65C9541641A43DC");
        app.setAppSecret("b06568639e2046778fb9cbfacbbb1184");
        app.setAppUkid(1L);
//        app.setPlatformId(BaPlatform.JINGDONG.getId());
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
        subscription.setAppUkid(1L);
        subscription.setAccessToken("f83c68d6-99c3-4c6e-8684-7a2404f12b90");
        subscription.setApp(app);
        subscription.setSubscriptionBuId(1L);
        JingdongApi api = new JingdongApi(subscription);
        
        Date endTime = new Date();
        Date startTime = DateUtil.addHours(endTime, -2);
   		
		AbsResponse<List<?>> rsp = api.catchTradesPerPage(
				startTime, endTime, "WAIT_SELLER_STOCK_OUT", true);
		if (rsp.isSuccess()) {
            List<?> pTrades = rsp.getData();
			
//			List<AmTradeDownLog> errList = api.getErrLogList();
        } 
//        api.fetchRefund("684038263");
//        Date startDate = DateUtil.parseDateTime("2016-05-03 00:00:00");
//		Date endDate = DateUtil.parseDateTime("2016-05-04 16:00:00");
////		api.fetchRefunds(startDate, endDate, "");
//		api.catchReceiveAfs("F5FA8C15F2EAE053A65C9541641A43DC", "jd_artka", "jd_artka");
	}

	@Override
	public String uploadInventory(String productNumId, String skuNumId,
			Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified) {
		try {
			// 1.更新库存
			String updateReponse = updateWareSkuStock(skuNumId, qtyAvailable);
			if (!"OK".equals(updateReponse)) {
				return updateReponse;
			}

			// 2.查询商品库存总数量
			long n = 0;
			String wareStatus = null;
			List<Ware> wareList = getWareList(productNumId);
			if (wareList.size() > 0) {
				n = wareList.get(0).getStockNum();
				wareStatus = wareList.get(0).getWareStatus();
			}

			// 3.判断商品数量为0，下架
			if (n <= 0 && "ON_SALE".equals(wareStatus)) {
				delistingWare(productNumId);// 下架
			} else if (n > 0 && qtyOnLocation == 1
					&& !"ON_SALE".equals(wareStatus)) {
				updateWareListing(productNumId);// 上架
			}
		} catch (Exception ex) {
			log.error("jd_uploadStock:" + skuNumId, ex);
			return "调用接口异常";
		}
		return "0";
	}

	@Override
	public String uploadInventoryAdd(String productNumId, String skuNumId,
			Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified) {
		long stock = 0L;
		try {
			Sku sku = getWareSku(skuNumId, "stock_num");
			if (sku != null) {
				stock = sku.getStockNum();
			}
		} catch (Exception ex) {
			log.error(skuNumId, ex);
			return "没找到京东Sku:" + ex.getMessage();
		}
		stock -= qtyAvailable.longValue();
		if (stock < 0L) {
			stock = 0L;
		}

		return uploadInventory(productNumId, skuNumId, stock, qtyOnLocation,
				qtyUnqualified);
	}

	// 1.更新库存
	private String updateWareSkuStock(String skuNumId, Long qty)
			throws JdException {
		WareSkuStockUpdateRequest request = new WareSkuStockUpdateRequest();
		request.setTradeNo(Long.toString(System.currentTimeMillis()));
		request.setSkuId(skuNumId);
		request.setQuantity(String.valueOf(qty));
		WareSkuStockUpdateResponse res = this.execute(request);
		if (res == null || !"0".equals(res.getCode())) {
			return getMsg(res);
		} else {
			return "OK";
		}
	}
	
	private Sku getWareSku(String skuNumId, String fields) throws JdException {
		WareSkuGetRequest request = new WareSkuGetRequest();
		request.setSkuId(skuNumId);
		request.setFields(fields);
		WareSkuGetResponse res = this.execute(request);
		return res.getSku();
	}

	/**
	 * 查询商品库存总数量
	 * @param productNumId
	 * @return
	 */
	private List<Ware> getWareList(String productNumId) throws JdException {
		WareListRequest request = new WareListRequest();
		request.setWareIds(productNumId);
		request.setFields("ware_id,stock_num,ware_status");
		WareListResponse response = this.execute(request);

		return response.getWareList();
	}
	
	private String delistingWare(String productNumId) {
		try {
			WareUpdateDelistingRequest req = new WareUpdateDelistingRequest();
			req.setWareId(productNumId);
			WareUpdateDelistingResponse resp = this.execute(req);
			if (!"0".equals(resp.getCode())) {
				return getErrMsg(resp);
			}
			return "OK";
		} catch (Exception e) {
			log.error(productNumId, e);
			return "发生异常";
		}
	}
	
	private String updateWareListing(String productNumId) {
		try {
			WareUpdateListingRequest request = new WareUpdateListingRequest();
			request.setWareId(productNumId);
			WareUpdateListingResponse resp = this.execute(request);
			if (!"0".equals(resp.getCode())) {
				return getErrMsg(resp);
			}
			return "OK";
		} catch (Exception e) {
			log.error(productNumId, e);
			return "发生异常";
		}
	}
	
	private String getErrMsg(AbstractResponse response){
		if (response == null)
			return "发生异常";

		if (StringUtils.isNotEmpty(response.getCode()) &&
				response.getCode().equals("0")) {
			return null;
		}
		return response.getCode() + " : " + response.getZhDesc();
	}
	
    @Override
	public AbsResponse getRefund(String tid) {
		AbsResponse retBean = new AbsResponse();

		PopAfsSoaRefundapplyQueryByIdRequest request = null;
		request = new PopAfsSoaRefundapplyQueryByIdRequest();
		request.setId(Long.valueOf(tid));
		try {
			PopAfsSoaRefundapplyQueryByIdResponse response = this.execute(request);
			if (response.getQueryResult() != null
					&& response.getQueryResult().getResult().size() >= 1) {
				retBean.setData(convertRefund(response.getQueryResult()
						.getResult().get(0)));
			} else {
				retBean.setResult(500, "退款单数据为空");
			}
		} catch (Exception e) {
			log.error("调用京东API出错：", e);
			retBean.setResult(500, "调用京东API出错:" + e.getMessage());
		}

		return retBean;
	}

	private SeJingdongRefundDTO convertRefund(RefundApplyVo query) {
		SeJingdongRefundDTO refund = new SeJingdongRefundDTO(); 
		refund.setRefundId(String.valueOf(query.getId()));
		refund.setOrderId(String.valueOf(query.getOrderId()));
		refund.setBuyerId(query.getBuyerId());
		refund.setBuyerNick(query.getBuyerName());
		if(StringUtils.isNotEmpty(query.getCheckTime())){
			refund.setCheckTime(DateUtil.parseDateTime(query.getCheckTime()));
		}
		if(StringUtils.isNotEmpty(query.getApplyTime())){
			refund.setRefundCreateTime(DateUtil.parseDateTime(query.getApplyTime()));
		}
		refund.setApplyRefundSum(new BigDecimal(query.getApplyRefundSum()/100.0));
		refund.setStatus(query.getStatus().toString());
		refund.setCheckUsername(query.getCheckUserName());
		refund.setRefundType("0");
		return refund;
	}

	/**
	 * 退款申请单状态 0、未审核 1、审核通过2、审核不通过 3、京东财务审核通过 4、京东财务审核不通过 
	 * 5、人工审核通过 6、拦截并退款 7、青龙拦截成功 8、青龙拦截失败 9、强制关单并退款。不传是查询全部状态 
	 */
	@Override
	public AbsResponse<List<?>> fetchRefunds(Date startDate, Date endDate,
			String refundStatus) {
		setBase(refundStatus, startDate, endDate, false);
		List<SeJingdongRefundDTO> refundList = catchRefunds();

		AbsResponse<List<?>> retBean = new AbsResponse<>();
		retBean.setData(refundList);
		return retBean;
	}


    private List<SeJingdongRefundDTO> catchRefunds() {
		List<SeJingdongRefundDTO> refundList = new ArrayList<SeJingdongRefundDTO>();

		try {
			PopAfsSoaRefundapplyQueryPageListResponse response = getRefundResponse(
					pageNo, pageSize, startDate, endDate, null);
			if (response != null && "0".equals(response.getCode())) {
				if (response.getQueryResult() != null) {
					for (RefundApplyVo query : response.getQueryResult()
							.getResult()) {
						refundList.add(convertRefund(query));
					}
	
					if (pageNo == 1 && !curved) {
						int totleResults = response.getQueryResult().getResult().size(); // 总条数
						setPageInfo(totleResults);
					}
				}
			}
		} catch (Exception e) {
			log.error("京东API:" + accessToken, e);
		} finally {
			pageNo--;
		}
		return refundList;
	}

	private PopAfsSoaRefundapplyQueryPageListResponse getRefundResponse(
			int pageNO, int pageSize, Date startDate, Date endDate,
			Long status) throws Exception {
		PopAfsSoaRefundapplyQueryPageListRequest request = null;
		request = new PopAfsSoaRefundapplyQueryPageListRequest();
		request.setStatus(status);
		request.setApplyTimeStart(DateUtil.toDateTimeString(startDate));
		request.setApplyTimeEnd(DateUtil.toDateTimeString(endDate));
		request.setPageIndex(pageNO);
		request.setPageSize(pageSize);
		return this.execute(request);
	}


    /**
     * 抓取京东服务单
     * jingdong.PartReceiveProvider.findPartReceiveList  待收货查询列表
     * @param buId
     * @param operatorPin
     * @param operatorNick
     * @return
     * @throws Exception
     */
	public List<SeJingdongRefundDTO> catchReceiveAfs(String buId,
			String operatorPin, String operatorNick) {
		List<SeJingdongRefundDTO> refundList = new ArrayList<SeJingdongRefundDTO>();
		int platformSrc = 228;// 调用系统值为228

		PartReceiveProviderFindPartReceiveListResponse response = null;
		try {
			response = getAfsReceiveResponse(buId, operatorPin, operatorNick,
					platformSrc, pageSize, pageNo);
			if (response != null && "0".equals(response.getCode())) {
				PartReceivePageResultDto data = response.getResultExport().getData();
				if (data != null) {
					for (int i = 0; i < data.getPageSize(); i++) {
						PartReceiveDto receiveDto = data.getPartReceiveDtoList().get(i);
						if (receiveDto != null) {
							SeJingdongRefundDTO refund = convertPartReceiveDto(receiveDto);
							if (StringUtils.isNotEmpty(refund.getWareId())) {// 返回的服务单没有商品信息的话，不保存
								refundList.add(refund);
							}
						}
					}

					if (pageNo == 1) {
						int totalResults = data.getTotalNum();// 总条数
						setPageInfo(totalResults);
					}
				}
			}
		} catch (Exception e) {
			log.error("京东API:" + accessToken, e);
		} finally {
			pageNo--;
		}
		return refundList;
	}

	private SeJingdongRefundDTO convertPartReceiveDto(PartReceiveDto afs) {
		SeJingdongRefundDTO refund = new SeJingdongRefundDTO();
		//暂得不到返回的数据，字段解析按照以前2号对应的
		refund.setRefundId(String.valueOf(afs.getAfsServiceId()));
		refund.setOrderId(String.valueOf(afs.getOrderId()));
		refund.setWareName(String.valueOf(afs.getWareName()));
		if(StringUtils.isNotEmpty(String.valueOf(afs.getWareId()))){
			refund.setWareId(String.valueOf(afs.getWareId()));
		}
		refund.setBuyerNick(String.valueOf(afs.getCustomerName()));
		if(StringUtils.isNotEmpty(DateUtil.toDateString(afs.getAfsApprovedTime()[0]))){
			refund.setCheckTime(afs.getAfsApprovedTime()[0]);
		}
		if(StringUtils.isNotEmpty(DateUtil.toDateString(afs.getAfsApplyTime()[0]))){
			refund.setRefundCreateTime(afs.getAfsApplyTime()[0]);
		}
		if(afs.getCustomerExpect() != null && afs.getCustomerExpect().length > 0){
			refund.setCustomerExpect(afs.getCustomerExpect()[0].longValue());
		}
		refund.setRefundType("1");
		refund.setStatus("10");//新抓下来的服务单初始状态是 ‘10’等待买家发货-同步平台就是针对‘10’状态的（‘20’-等待仓库收货-已完结）
		return refund;
	}

	private PartReceiveProviderFindPartReceiveListResponse getAfsReceiveResponse(
			String buId, String operatorPin, String operatorNick,
			int platformSrc, int pageSize, int pageNO) throws JdException {
		PartReceiveProviderFindPartReceiveListRequest request = null;
		request = new PartReceiveProviderFindPartReceiveListRequest();
		request.setBuId(buId);
		request.setOperatorPin(operatorPin);
		request.setOperatorNick(operatorNick);
		request.setOperatorDate(new Date());
		request.setPlatformSrc(platformSrc);
		request.setPageSize(pageSize);
		request.setPageIndex(pageNO);
		return this.execute(request);
	}

	@Override
    public AbsResponse updateRefundStatus(String tid, String status) {
        return null;
    }


    public SeJingdongTradeDTO coverTradeBean(OrderInfo info) throws Exception {
        SeJingdongTradeDTO tTrade = new SeJingdongTradeDTO();
        // Todo 将获取的bean 转换为我们自己的bean,然后一些关键属性要赋值比如orderId,
        tTrade.setOrderId(info.getOrderId());
        tTrade.setCustoms(info.getCustoms());
        tTrade.setCustomsModel(info.getCustomsModel());
        tTrade.setVenderId(info.getVenderId());
        tTrade.setPayType(info.getPayType());
        tTrade.setPlatformOrderStatus(info.getOrderState());
        tTrade.setOrderTotalPrice(new BigDecimal(info.getOrderTotalPrice()));
        tTrade.setOrderSellerPrice(new BigDecimal(info.getOrderSellerPrice()));
        tTrade.setOrderPayment(new BigDecimal(info.getOrderPayment()));
        tTrade.setFreightPrice(new BigDecimal(info.getFreightPrice()));
        tTrade.setSellerDiscount(new BigDecimal(info.getSellerDiscount()));
        tTrade.setDeliveryType(info.getDeliveryType());
        tTrade.setInvoiceInfo(info.getInvoiceInfo());
        tTrade.setBuyerMessage(info.getOrderRemark());
        tTrade.setOrderCreateTime(DateUtil.parseDateTime(info.getOrderStartTime()));
        tTrade.setOrderPayTime(DateUtil.parseDateTime(info.getPaymentConfirmTime()));
        tTrade.setOrderModifyTime(DateUtil.parseDateTime(info.getModified()));
        tTrade.setOrderEndTime(DateUtil.parseDateTime(info.getOrderEndTime()));

        //用户信息
        UserInfo userInfo = info.getConsigneeInfo();
        if(userInfo != null) {
	        tTrade.setReceiverName(userInfo.getFullname());
	        tTrade.setReceiverPhone(userInfo.getTelephone());
	        tTrade.setReceiverMobile(userInfo.getMobile());
	        tTrade.setReceiverAddress(userInfo.getFullAddress());
	        tTrade.setReceiverState(userInfo.getProvince());
	        tTrade.setReceiverCity(userInfo.getCity());
	        tTrade.setReceiverCounty(userInfo.getCounty());
        }

        tTrade.setBalanceUsed(info.getBalanceUsed());
        tTrade.setBuyerNick(info.getPin());
        tTrade.setReturnOrder(info.getReturnOrder());
        tTrade.setWayBill(info.getWaybill());
        tTrade.setLogisticsId(info.getLogisticsId());

        tTrade.setParentOrderId(info.getParentOrderId());
//        tTrade.setOrderType(info.getorde);
        tTrade.setStoreOrder(info.getStoreOrder());
        
        VatInvoiceInfo atInvoice = info.getVatInvoiceInfo();
        if(atInvoice != null){
	        tTrade.setTaxPayerIdent(atInvoice.getTaxpayerIdent());
	        tTrade.setRegisteredAddress(atInvoice.getRegisteredAddress());
	        tTrade.setDepositBank(atInvoice.getDepositBank());
	        tTrade.setBankAccount(atInvoice.getBankAccount());
        }
        tTrade.setIsCod("1".equals(info.getPayType()) ? 1L : 0L);
       
        List<SeJingdongItemDTO> orders = new ArrayList<SeJingdongItemDTO>(4);
        if(info.getItemInfoList() != null) for (ItemInfo det : info.getItemInfoList()) {
            SeJingdongItemDTO order = new SeJingdongItemDTO();
            // Todo 将获取的bean 转换为我们自己的bean,然后一些关键属性要赋值比如productCode,qty,
            BeanUtils.copyProperties(det, order);
            order.setProductCode(det.getOuterSkuId());
            order.setQty(NumberUtils.toLong(det.getItemTotal()));
            orders.add(order);
        }
        tTrade.setItemList(orders);
        return tTrade;
    }

    /**
     * 将OrderSearchInfo 转化为 OrderInfo
     * @param searchInfo
     * @return
     */
    private SeJingdongTradeDTO coverTradeBean(OrderSearchInfo searchInfo) throws Exception{
    	OrderInfo orderInfo = new OrderInfo();
    	BeanUtils.copyProperties(searchInfo, orderInfo);
    	return coverTradeBean(orderInfo);
	}

    @Override
    public AbsResponse<SeJingdongTradeDTO> catchOneTrade(String tid) {
        AbsResponse<SeJingdongTradeDTO> rsp = new AbsResponse<SeJingdongTradeDTO>();
        if (StringUtils.isEmpty(tid)) {
            return rsp.setResult(500, "订单号不允许为空!");
        }
        try{
	        OrderGetRequest request = new OrderGetRequest();
	        request.setOrderId(tid);
	        OrderGetResponse response = this.execute(request);
	        if (response.getOrderDetailInfo() != null && "0".equals(response.getCode())) {
	            rsp.setData(coverTradeBean(response.getOrderDetailInfo().getOrderInfo()));
	        } else {
	            rsp.setResult(500, getMsg(response));
	        }
        }catch (Exception e) {
        	log.error(tid, e);
        	rsp.setResult(530, "发生异常:" + e.getMessage());
		}
        return rsp;
    }

	public AbsResponse<List<?>> catchTradesPerPage(Date startDate,
			Date endDate, String aStatus, boolean isFullField) {
		setBase(aStatus, startDate, endDate, isFullField);
		
		List<SeJingdongTradeDTO> pTradeList = catchTrades(false);

		AbsResponse<List<?>> retBean = new AbsResponse<>();
		retBean.setData(pTradeList);
		return retBean;
	}

	@Override
	public AbsResponse<List<?>> catchTrades(Date startTime,
			Date endDate, String status, boolean isFullFields) {
    	setBase(status, startTime, endDate, isFullFields);
    	
		List<SeJingdongTradeDTO> tradeList = new ArrayList<SeJingdongTradeDTO>();
		do {
			List<SeJingdongTradeDTO> poList = catchTrades(false);
			if (!poList.isEmpty()) {
				tradeList.addAll(poList);
			}
		} while (hasNext());

		AbsResponse<List<?>> retBean = new AbsResponse<>();
		retBean.setData(tradeList);
		return retBean;
	}
    	
    /**
     * 查询时间类型，默认按修改时间查询。 1为按订单创建时间查询；其它数字为按订单（订单状态、修改运单号）修改时间 
     * @param pageNum
     * @param pageSize
     * @param startDate
     * @param endDate
     * @param status
     * @return
     * @throws Exception
     */
	private OrderSearchResponse getSearchResponse(int pageNum, int pageSize,
			Date startDate, Date endDate, String status, boolean isInc) throws Exception {
		if (pageNum <= 0) {
			return null;
		}
		OrderSearchRequest req = new OrderSearchRequest();
		req.setOptionalFields(isFullField ? ORDER_FIELDS : ORDER_SHORT_FIELDS);
        req.setStartDate(DateUtil.toDateTimeString(startDate));
        req.setEndDate(DateUtil.toDateTimeString(endDate));
        req.setOrderState(status);
        req.setPageSize(String.valueOf(pageSize));
        req.setPage(String.valueOf(pageNum));
		req.setDateType(isInc ? "0" : "1");
		
		return this.execute(req);
    }

    private List<SeJingdongTradeDTO> catchTrades(boolean isInc) {
        List<SeJingdongTradeDTO> tradeList = new ArrayList<SeJingdongTradeDTO>();
        OrderSearchResponse response = null;
        try {
			response = getSearchResponse(this.pageNo, this.pageSize,
					this.startDate, this.endDate, this.status, isInc);
            if (response != null && response.getOrderInfoResult() != null
                    && response.getOrderInfoResult().getOrderInfoList() != null) {
                OrderResult result = response.getOrderInfoResult();
                List<OrderSearchInfo> oOrderInfoList = result.getOrderInfoList();
                for (OrderSearchInfo orderInfo : oOrderInfoList) {
					tradeList.add(coverTradeBean(orderInfo));
                }
                
                if (this.pageNo == 1) {
                    int total = result.getOrderTotal();
                    setPageInfo(total);
                }
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
        }
        
        --this.pageNo;
        return tradeList;
    }

	private String getMsg(AbstractResponse response) {
		String errorMsg = null;
		if (response == null) {
			errorMsg = "平台服务器异常";
		} else {
			errorMsg = response.getCode() + ":" + response.getMsg();
		}
		return errorMsg;
	}

    @Override
    public AbsResponse updateTradeMemo(String tid, String memo) {
		AbsResponse<OrderVenderRemarkUpdateResponse> rsp = new AbsResponse<OrderVenderRemarkUpdateResponse>();
		OrderVenderRemarkUpdateRequest request=new OrderVenderRemarkUpdateRequest();
		JdClient client=new DefaultJdClient(OtsApiClient.otsJdHost + "/taobao/jdAction!callApi",accessToken,appKey,appSecret);
		request.setOrderId(tid);
		request.setRemark(memo);
//		request.setTradeNo( "jingdong" ); //流水号，不能重复的随机数
//		request.setFlag( "jingdong" );	//商家备注提示文字颜色值（默认为灰色） 0:灰色 1:红色 2:黄色 3:绿色 4:蓝色 5:紫色。
		try {
			OrderVenderRemarkUpdateResponse response=client.execute(request);
			rsp.setData(response);
		} catch (JdException e) {
			log.error(tid, e);
			rsp.setResult(530, "发生异常:" + e.getMessage());
		}
		return rsp;
    }

    @Override
    public AbsResponse updateTradeStatus(String tid, String status) {
        return null;
    }
    
	@Override
	public AbsResponse shipNotice(String tid, String tmsCode, String tmsName,
			String outSid, Double weight, boolean isSplit, String subTids) {
		AbsResponse abs = new AbsResponse();
		try {
			abs = shipNoticeSop(tid, outSid, tmsName, tmsCode);
		
		if(abs.getCode() != 0){
			String errorInfo = abs.getMsg();
			if (errorInfo != null && errorInfo.contains("已出库")) {
				return abs;
			}
			abs = shipNoticeLbp(tid, outSid, tmsName, tmsCode);
			abs.setMsg(errorInfo + ";" + abs.getMsg());
		}
		if (abs.getCode() != 0) {
			String errorInfo = abs.getMsg();
			if (errorInfo != null && errorInfo.contains("已出库")) {
				return abs;
			}
			abs = shipNoticeSopl(tid, "1");
			abs.setMsg(errorInfo + ";" + abs.getMsg());
		}
		} catch (Exception e) {
			abs.setResult(503, e.getMessage());
			log.error(tid, e);
		}
		return abs;
	}

	public AbsResponse shipNoticeSop(String tid, String outSid,
			String tmsName, String tmsCode) throws Exception {
		AbsResponse abs = new AbsResponse();
		
		if (StringUtils.isEmpty(tid)) {
			return abs.setResult(400, "来源单号为空");
		}
		if (StringUtils.isEmpty(outSid)) {
			return abs.setResult(401, "快递单号为空");
		}
		if ((StringUtils.isEmpty(tmsCode)) && (StringUtils.isEmpty(tmsName))) {
			return abs.setResult(402, "快递公司为空");
		}
		OrderSopOutstorageRequest request = new OrderSopOutstorageRequest();
		request.setOrderId(tid);
		request.setTradeNo(tid);
		request.setLogisticsId(tmsCode);
		request.setWaybill(outSid);

		OrderSopOutstorageResponse response = this.execute(request);
		String subCode = response.getCode();
		if ("0".equals(subCode)) {
			abs.setResult(0, "OK");
		} else {
			abs.setResult(500, response.getZhDesc());
		}
		return abs;
	}
	
	public AbsResponse shipNoticeLbp(String tid, String outSid,
			String tmsName, String tmsCode) throws Exception {
		AbsResponse abs = new AbsResponse();
		if (StringUtils.isEmpty(tid)) {
			return abs.setResult(400, "来源单号为空");
		}
		if (StringUtils.isEmpty(outSid)) {
			return abs.setResult(401, "快递单号为空");
		}
		if ((StringUtils.isEmpty(tmsCode)) && (StringUtils.isEmpty(tmsName))) {
			return abs.setResult(402, "快递公司为空");
		}
		OrderLbpOutstorageRequest request = new OrderLbpOutstorageRequest();
		request.setOrderId(tid);
		request.setPackageNum("1");
		request.setLogisticsId(tmsCode);
		request.setWaybill(outSid);
		request.setTradeNo("1111" + tid);
		OrderLbpOutstorageResponse response = this.execute(request);
		String subCode = response.getCode();
		if ("0".equals(subCode)) {
			abs.setResult(0, "OK");
		} else {
			abs.setResult(500, response.getZhDesc());
		}
		return abs;
	}
	
	public AbsResponse shipNoticeSopl(String tid, String packageNum) throws Exception {
		AbsResponse abs = new AbsResponse();
		if (StringUtils.isEmpty(tid)) {
			abs.setResult(400, "来源单号为空");
			return abs;
		}

		OrderSoplOutstorageRequest request = new OrderSoplOutstorageRequest();
		request.setOrderId(tid);
		request.setPackageNum(packageNum);
		request.setSendType("1");
		request.setTradeNo("1111" + tid);
		OrderSoplOutstorageResponse response = this.execute(request);
		String subCode = response.getCode();
		if ("0".equals(subCode)) {
			abs.setResult(0, "OK");
		} else {
			abs.setResult(500, response.getZhDesc());
		}
		return abs;
	}
	
	public int catchTradeCount(Date aStartDate, Date aEndDate, String aStatus) {
		try {
			OrderSearchResponse response = getSearchResponse(1, 1, aStartDate,
					aEndDate, aStatus, false);
			if (response == null) {
				return 0;
			}
			if (!"0".equals(response.getCode())) {
				log.error(this.shopId + "京东API：" + response.getCode() + ":"
						+ response.getMsg());

				return 0;
			}
			OrderResult result = response.getOrderInfoResult();
			if (result == null || result.getOrderInfoList() == null) {
				return 0;
			}
			return result.getOrderTotal();
		} catch (Exception e) {
			log.error(this.shopId, e);
		}
		return 0;
	}

	@Override
	public AbsResponse<List<?>> catchTradesIncPerPage(Date startTime, Date endTime,
			String status, boolean isFullField) {
		setBase(status, startTime, endTime, isFullField);
		
		List<SeJingdongTradeDTO> pTradeList = catchTrades(true);

		AbsResponse<List<?>> retBean = new AbsResponse<>();
		retBean.setData(pTradeList);
		return retBean;

	}

	@Override
	public AbsResponse getSku(String productNumId, String skuNumId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AbsResponse getTaobaoItemcats(Long parentCid, String cids) {
		return null;
	}

//	@Override
//	public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode) {
//		Map<String, String> param = new HashMap<String, String>();
//		param.put("scope", "read");
//		param.put("grant_type", "authorization_code");
//		param.put("code", authCode);
//		param.put("client_id", this.appKey);
//		param.put("client_secret", this.appSecret);
//		//param.put("redirect_uri", BaShopAction.feedbackUrl);
//		param.put("state", null);
//
//		return grant(param);
//	}
//	@Override
//	public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken) {
//		Map<String, String> param = new HashMap<String, String>();
//		param.put("grant_type", "refresh_token");
//		param.put("scope", "read");
//		param.put("view", "web");
//		param.put("state", null);
//		param.put("client_id", this.appKey);
//		param.put("client_secret", this.appSecret);
//		param.put("refresh_token", refreshToken);
//		return grant(param);
//	}
	
//	private AbsResponse<AmAuthRecordDTO> grant(Map<String, String> param) {
//		AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<AmAuthRecordDTO>();
//
//		String u = "https://oauth.jd.com/oauth/token";
//		try{
//			String ret = WebUtils.doPost(u, param);
//			retObject.setBody(ret);
//
//			JSONObject obj = JSON.parseObject(ret);
//
//			AmAuthRecordDTO auth = new AmAuthRecordDTO();
//			auth.setRelatedId(shopId);
//			auth.setExpiresIn(obj.getLong("expires_in"));
//			auth.setReExpiresIn(obj.getLong("re_expires_in"));
//			auth.setR1ExpiresIn(obj.getLong("r1_expires_in"));
//			auth.setR2ExpiresIn(obj.getLong("r2_expires_in"));
//			auth.setW1ExpiresIn(obj.getLong("w1_expires_in"));
//			auth.setW2ExpiresIn(obj.getLong("w2_expires_in"));
//			auth.setAccessToken(obj.getString("access_token"));
//			auth.setRefreshToken(obj.getString("refresh_token"));
//			auth.setTokenType(obj.getString("token_type"));
//
//			String nick = obj.getString("user_nick");
//			auth.setPlatformUserNick(nick);
//
//			String uid = obj.getString("uid");
//			auth.setPlatformUserId(uid);
//
//			retObject.setData(auth);
//		}catch (Exception e) {
//			log.error("授权异常:" + shopId, e);
//			retObject.setResult(500, "授权异常" + e.getMessage());
//		}
//		return retObject;
//	}
	
	private <T extends AbstractResponse> T execute(JdRequest<T> request)
			throws JdException {
		Date reqDate = new Date();
		T response = null;
		try {
			response = this.jdClient.execute(request);
		} finally {
			appendReqAResp(request.getApiMethod(), reqDate, response==null?null:response.getUrl(),
					null, response==null?null:response.getMsg());
		}

		return response;
	}

	@Override
	public AbsResponse getShop(String nick) throws Exception {
		VenderShopQueryRequest request=new VenderShopQueryRequest();
		VenderShopQueryResponse response=this.execute(request);
		AbsResponse abs = new AbsResponse();
		abs.setData(response);
		return abs;
	}
	@Override
	public AbsResponse<?> tmcUserPermit(String topics) {
		return null;
	}
	@Override
	public AbsResponse<?> tmcUserCancel(String nick, String userPlatform) {
		return null;
	}

	@Override
	public AbsResponse<List<?>> queryProducts(int fetchType, String productNumId, Date startModified, Date endModified){
		return null;
	}
}
