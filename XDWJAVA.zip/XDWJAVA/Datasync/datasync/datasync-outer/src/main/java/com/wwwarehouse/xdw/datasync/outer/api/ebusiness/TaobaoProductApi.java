package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.taobao.api.ApiException;
import com.taobao.api.domain.Item;
import com.taobao.api.domain.ItemCat;
import com.taobao.api.domain.PropImg;
import com.taobao.api.domain.Sku;
import com.taobao.api.internal.util.RequestCheckUtils;
import com.taobao.api.request.*;
import com.taobao.api.response.*;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.model.ImPlatformCategoryDTO;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IProductApi;
import com.wwwarehouse.xdw.datasync.outer.api.ots.OtsApiClient;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by jianjun.guan on 2017/6/8 0008.
 */
public class TaobaoProductApi extends TaobaoRefundApi implements IProductApi{

    public TaobaoProductApi() {

    }
    /**
     * 查询平台商品资料
     *
     * @param fetchType     1 所有  2 在售商品 3 库存商品
     * @param startModified
     * @param endModified
     * @return
     * @throws Exception
     */
    @Override
    public AbsResponse queryProducts(int fetchType, String productNumId, Date startModified, Date endModified) {

        //铺货信息
        List<ImPlatformItemDTO> platformItems = new ArrayList<>();
        try {
            //num_iid item
            List<Item> numiidItems = new ArrayList<>();
            //在售商品
            if (fetchType == 1 || fetchType == 2) {
                List<Item> onsaleItems = getItemsOnsale(pageSize, startModified, endModified);
                if (onsaleItems.size() > 0) {
                    numiidItems.addAll(onsaleItems);
                }
            }

            if (fetchType == 1 || fetchType == 3) {
                //库存商品
                List<Item> inventoryItems = getItemsInventory(pageSize, null, startModified, endModified);
                if (inventoryItems.size() > 0) {
                    numiidItems.addAll(inventoryItems);
                }

                List<Item> inventorySoldOutItems = getItemsInventory(pageSize, "sold_out", startModified, endModified);
                if (inventorySoldOutItems.size() > 0) {
                    numiidItems.addAll(inventorySoldOutItems);
                }
            }

            int i = 0;
            int groupSize = 20;
            String itemIds = "";
            for (Item item : numiidItems) {
                i++;
                if (itemIds.length() > 0) {
                    itemIds += ",";
                }
                itemIds += item.getNumIid();

                if (i % groupSize == 0 || i == numiidItems.size()) {// 50一组，最大为100
                    List<Item> searchItems = getItemByNumIds(itemIds);
                    if (searchItems != null) {
                        for (Item searchItem : searchItems) {
                            List<ImPlatformItemDTO> pItems = convert(searchItem);
                            if (pItems.size() > 0) {
                                platformItems.addAll(pItems);
                            }
                        }
                    }
                    itemIds = "";
                }
            }
        } catch (Exception e) {
            log.error("", e);
        }

        AbsResponse abs = new AbsResponse();
        abs.setData(platformItems);
        return abs;
    }

    /**
     * 全量更新平台库存
     *
     * @param productNumId
     * @param skuNumId
     * @param qtyAvailable   可销售数
     * @param qtyOnLocation  在架数
     * @param qtyUnqualified 次品数
     * @return 0开头表示成功
     */
    @Override
    public String uploadInventory(String productNumId, String skuNumId,
                                  Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified) {
        this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
        long autoSale = 1;//暂时设定默认自动上架，以后要改。
        try {
            Long lProductNumId = productNumId == null ? 0L : Long.valueOf(productNumId);
            Long lSkuNumId = skuNumId == null ? 0L : Long.valueOf(skuNumId);
            String flag = "0";

            ItemQuantityUpdateResponse response = updateItemQuantity(lProductNumId, lSkuNumId, qtyAvailable, 1L);
            if (response.getErrorCode() != null) {
                flag = getErrorMsg(response);
                flag += "," + getSkuNum(lProductNumId, lSkuNumId);
                return flag;
            }

            flag += "," + getSkuNum(lProductNumId, lSkuNumId);

            // 1.商品所有规格数量为0，taobao自动下架
             return inventoryCalculation(qtyAvailable, response, autoSale, lProductNumId, flag);
        } catch (Exception ex) {
//            log.error("tb-uploadStock:" + skuNumId, ex);
            return "异常" + ex.getMessage();
        }
    }

    /**
     * 增量更新平台库存
     *
     * @param productNumId
     * @param skuNumId
     * @param qtyOnLocation
     * @param qtyAvailable
     * @return
     */
    @Override
    public String uploadInventoryAdd(String productNumId, String skuNumId, Long qtyAvailable, Long qtyOnLocation,
                                     Long qtyUnqualified) {
        long autoSale = 1;// 暂时设定默认自动上架，以后要改。
        try {
            String flag = "0";
            ItemQuantityUpdateResponse response = updateItemQuantity(Long.valueOf(productNumId), Long.valueOf(skuNumId),
                    qtyAvailable, 2L);
            if (response.getErrorCode() != null) {
                flag = getErrorMsg(response);
                if (flag.indexOf("宝贝库存数量不允许小于0") != -1) {
                    flag = updateItemQuantity(productNumId, skuNumId, 0L, 0L, 0L, autoSale); // 将宝贝库存调整为0
                }
                return flag;
            }
            Item item = response.getItem();

            // 1.商品所有规格数量为0，taobao自动下架
            if (item != null && item.getNum() > 0 && autoSale == 1) { // 设置了自动上架
                String upRet = updateItemListing(Long.valueOf(productNumId), item.getNum());
                flag += "," + upRet;
            }
            return flag;
        } catch (Exception ex) {
            log.error("tb-uploadStockAdd:" + skuNumId, ex);
            return "异常" + ex.getMessage();
        }
    }

    /**
     * 按指定productNumId查询平台商品信息
     * @param productNumId
     * @param skuNumId
     * @return
     */
    @Override
    public AbsResponse<List<ImPlatformItemDTO>> getSku(String productNumId, String skuNumId) {
        AbsResponse<List<ImPlatformItemDTO>> abs = new AbsResponse<>();
        try {
            RequestCheckUtils.checkNotEmpty(productNumId, "productNumId");
            AbsResponse<Item> itemAbs = this.getItemByNumId(Long.valueOf(productNumId));
            if (!itemAbs.isSuccess()) {
                return abs.setResult(itemAbs);
            }

            List<ImPlatformItemDTO> list = convert(itemAbs.getData());
            if (list != null && list.isEmpty()) {
                abs.setResult(500, "下载商品资料失败");
                return abs;
            }
            abs.setData(list);
//        } catch (ApiCheckException e){
//            abs.setResult(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            abs.setResult(500,"下载商品资料出现异常"+e);
            log.error(500,e);
        }
        return abs;

    }

    /**
     * 查找商品类目
     *
     * @param parentCid
     * @param cids
     * @return
     */
    @Override
    public AbsResponse getTaobaoItemcats(Long parentCid, String cids) {
        AbsResponse abs = new AbsResponse();
        ItemcatsGetRequest req = new ItemcatsGetRequest();
        if (parentCid == null && StringUtils.isEmpty(cids)) {
            parentCid = 0L;
            req.setParentCid(parentCid);
        }
        if (StringUtils.isNotEmpty(cids)) {
            req.setCids(cids);
        }

        if (parentCid != null) {
            req.setParentCid(parentCid);
        }
        req.setFields("cid,parent_cid,name,is_parent");
        try {
            ItemcatsGetResponse response = this.executeOtsOne(req);
            if (response.isSuccess() && response.getItemCats() != null) {
                //TODO 转换成网仓的类
                List<ImPlatformCategoryDTO> list = new ArrayList<>();
                for (ItemCat cat : response.getItemCats()) {
                    ImPlatformCategoryDTO platformCategory = new ImPlatformCategoryDTO();
                    platformCategory.setPlatformId(10L);
                    platformCategory.setCategoryId(String.valueOf(cat.getCid()));
                    platformCategory.setCategoryName(cat.getName());
                    platformCategory.setParentId(String.valueOf(cat.getParentCid()));
//                    platformCategory.setPlatformCategoryUkid(UKID.getUKID());
                    if (cat.getIsParent()) {
                        platformCategory.setHasChild(1L);
                    } else {
                        platformCategory.setHasChild(0L);
                    }
                    list.add(platformCategory);
                }
                abs.setData(list);
            } else {
                abs.setResult(500, response.getMsg());
            }
        } catch (ApiException e) {
            abs.setResult(500, e.getErrMsg());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return abs;
    }



    /**
     * 查询在售商品
     * @param pageSize
     * @param startModified
     * @param endModified
     * @return
     * @throws Exception
     */
    private List<Item> getItemsOnsale(int pageSize, Date startModified, Date endModified) throws Exception {

        List<Item> itemList = new ArrayList<>();

        int pageNo = 1;
        int pageTotal = 0;
        ItemsOnsaleGetResponse resp = null;
        do {
            resp = getItemsOnsaleResponse(pageSize, pageNo, startModified, endModified);
            List<Item> items = resp.getItems();
            if (items != null) {
                itemList.addAll(resp.getItems());
            }
            pageNo++;
        } while (pageNo <= pageTotal);
        return itemList;
    }

    /**
     * 查询在售商品
     * @param pageSize
     * @param pageNo
     * @param startModified
     * @param endModified
     * @return
     * @throws Exception
     */
    private ItemsOnsaleGetResponse getItemsOnsaleResponse(int pageSize, int pageNo, Date startModified, Date endModified)
            throws Exception {
        String fields = "num_iid,approve_status";
        ItemsOnsaleGetResponse resp = null;
        if (isEnableOts) {
            Map<String, String> params = new HashMap<>();
            params.put("page", String.valueOf(pageNo));
            params.put("pageSize", String.valueOf(pageSize));
            params.put("fields", fields);

            if (startModified != null && endModified != null) {
                params.put("startModified", DateUtil.toDateTimeString(startModified));
                params.put("endModified", DateUtil.toDateTimeString(endModified));
            }

            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
            resp = this.executeOts("getItemsOnsaleResponse", params, ItemsOnsaleGetResponse.class);
        } else {
            ItemsOnsaleGetRequest req = new ItemsOnsaleGetRequest();
            req.setFields(fields);
            req.setPageNo((long) pageNo);
            req.setPageSize((long) pageSize);

            if (startModified != null && endModified != null) {
                req.setStartModified(startModified);
                req.setEndModified(endModified);
            }

            resp = client.execute(req, sessionKey);
        }
        return resp;
    }

    /**
     * 获取了一下售完的商品 : banner=sold_out
     * String banner = "sold_out";
     *
     * @param pageSize
     * @return
     * @throws Exception
     */
    private List<Item> getItemsInventory(int pageSize, String banner, Date startModified, Date endModified) throws Exception {

        List<Item> itemList = new ArrayList<Item>();

        int pageNo = 1;
        int pageTotal = 0;
        ItemsInventoryGetResponse resp;
        do {
            try {
                resp = getItemsInventoryResponse(pageSize, pageNo, banner, startModified, endModified);
                if (resp != null) {
                    itemList.addAll(resp.getItems());

                    if (pageNo == 1) {
                        int total = resp.getTotalResults().intValue();
                        pageTotal = (total + pageSize - 1) / pageSize;
                    }
                }

            } catch (Exception e) {
            }
            pageNo++;
        } while (pageNo <= pageTotal);

        return itemList;
    }

    /**
     * banner:sold_out
     */
    private ItemsInventoryGetResponse getItemsInventoryResponse(long pageSize, long pageNo,
                                                                String banner, Date startModified, Date endModified) throws Exception {
        String fields = "num_iid,approve_status";
        ItemsInventoryGetResponse resp = null;
        if (isEnableOts) {
            Map<String, String> params = new HashMap<>();
            params.put("page", String.valueOf(pageNo));
            params.put("pageSize", String.valueOf(pageSize));
            params.put("fields", fields);
            if (StringUtils.isNotEmpty(banner)) {
                params.put("banner", banner);
            }
            if (startModified != null && endModified != null) {
                params.put("startModified", DateUtil.toDateTimeString(startModified));
                params.put("endModified", DateUtil.toDateTimeString(endModified));
            }

            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
            resp = this.executeOts("getItemsInventoryResponse", params, ItemsInventoryGetResponse.class);
        } else {
            ItemsInventoryGetRequest req = new ItemsInventoryGetRequest();
            req.setPageNo(pageNo);
            req.setPageSize(pageSize);
            req.setFields(fields);
            if (StringUtils.isNotEmpty(banner)) {
                req.setBanner(banner);
            }
            if (startModified != null && endModified != null) {
                req.setStartModified(startModified);
                req.setEndModified(endModified);
            }
            resp = client.execute(req, sessionKey);
        }

        return resp;
    }

    /**
     *
     * @param numIids
     * @return
     * @throws Exception
     */
    private List<Item> getItemByNumIds(String numIids) throws Exception {
        List<Item> items = null;
        try {
            ItemsSellerListGetResponse response = null;
            if (isEnableOts) {
                Map<String, String> params = new HashMap<>();
                params.put("numIids", numIids);
                params.put("fields", PRO_ITEMS_FIELD);
                params.put("nick", sellerNick);

                this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
                response = this.executeOts("getItemByNumIds", params, ItemsSellerListGetResponse.class);
            } else {
                ItemsSellerListGetRequest req = new ItemsSellerListGetRequest();
                req.setFields(PRO_ITEMS_FIELD);
                req.setNumIids(numIids);
                response = client.execute(req, sessionKey);
            }
            items = response.getItems();
        } catch (ApiException e) {
            log.error(numIids, e);
        }
        return items;
    }

    /**
     * 铺货 淘宝商品信息转换成本地铺货信息
     *
     * @param it
     * @return
     * @throws Exception
     */
    public List<ImPlatformItemDTO> convert(Item it) throws Exception {
        List<ImPlatformItemDTO> spcList = new ArrayList<>();
        List<Sku> skulist = it.getSkus();
        if (skulist != null && skulist.size() > 0) {
            for (Sku sku : skulist) {
                ImPlatformItemDTO imspc = new ImPlatformItemDTO();
                imspc.setProductNumId(it.getNumIid() == null ? null : it.getNumIid().toString());
                imspc.setProductOuterId(StringUtils.trim(it.getOuterId()));
                imspc.setSkuNumId(sku.getSkuId() == null ? null : sku.getSkuId().toString());
                imspc.setSkuOuterId(StringUtils.trim(sku.getOuterId()));
                imspc.setProductTitle(it.getTitle());
                imspc.setSkuName(getSkuName(it.getPropertyAlias(), sku.getPropertiesName(), sku.getProperties()));
                imspc.setSellPrice(new BigDecimal(sku.getPrice())); //NumberUtils.toDouble(sku.getPrice())
                imspc.setPlatformImgUrl(it.getPicUrl());
                imspc.setPlatformImgUrl(getSkuImg(it.getPropImgs(), sku.getProperties(), it.getPicUrl()));
                imspc.setBrandName(it.getPropsName());
                imspc.setItemCount(it.getNum());//商品数量
                if(it.getCid() != null) {
                    imspc.setCategoryId(it.getCid().toString());//商品类目ID
                }
                spcList.add(imspc);
            }
        } else {
            ImPlatformItemDTO imspc = new ImPlatformItemDTO();
            if ("auction".equals(it.getType())) {// 拍卖
                imspc.setSkuOuterId(StringUtils.trim(it.getOuterId()));
                imspc.setSkuNumId(it.getNumIid().toString());
            } else {
                imspc.setSkuOuterId("");
                imspc.setSkuNumId("");
            }
            imspc.setProductNumId(it.getNumIid() == null ? "" : it.getNumIid().toString());
            imspc.setProductOuterId(it.getOuterId() == null ? "" : StringUtils.trim(it.getOuterId()));
            imspc.setSkuName("");
            imspc.setProductTitle(it.getTitle());
            imspc.setSellPrice(new BigDecimal(it.getPrice())); //NumberUtils.toDouble(it.getPrice())
            imspc.setPlatformImgUrl(it.getPicUrl());
            imspc.setBrandName(it.getPropsName());
            if(it.getCid() != null) {
                imspc.setCategoryId(it.getCid().toString());//商品类目ID
            }
            spcList.add(imspc);
        }
        return spcList;
    }

    /**
     *
     * @param alias
     * @param propName
     * @param properties
     * @return
     */
    private String getSkuName(String alias, String propName, String properties) {
        String skuName = "";
        try {
            Map<String, String> skuNameMap = getAliasSkuNameMap(alias);
            skuNameMap = getSkuNameMap(skuNameMap, propName);

            String[] propArr = properties.split(";");
            for (int i = 0; i < propArr.length; i++) {
                String name = skuNameMap.get(propArr[i]);
                if (name != null) {
                    skuName = skuName + name + " ";
                }
            }
            return skuName.trim();
        } catch (Exception ex) {
            log.error(alias, ex);
        }
        return "";
    }

    /**
     *
     * @param propImgs
     * @param prop
     * @param picUrl
     * @return
     */
    private String getSkuImg(List<PropImg> propImgs, String prop, String picUrl) {
        try {
            String imgUrl = "";
            Iterator iter;
            if (propImgs != null) {
                for (iter = propImgs.iterator(); iter.hasNext(); ) {
                    PropImg propImg = (PropImg) iter.next();
                    if ((prop.indexOf(";") == -1 ? prop : prop.substring(0, prop.indexOf(";"))).equals(propImg.getProperties())) {
                        return propImg.getUrl();
                    }
                }
            }
            return picUrl;
        } catch (Exception ex) {
        }
        return "";
    }

    /**
     *
     * @param skuNameMap
     * @param propertiesName
     * @return
     */
    private Map<String, String> getSkuNameMap(Map<String, String> skuNameMap, String propertiesName) {
        if (StringUtils.isNotEmpty(propertiesName)) {
            String[] boolx = propertiesName.trim().split(";");
            for (String skuStr : boolx) {
                if (skuStr.length() != 0) {
                    String[] skuItems = skuStr.split(":");
                    String skuCid = skuItems[0] + ":" + skuItems[1];
                    if (!skuNameMap.containsKey(skuCid)) {
                        skuNameMap.put(skuCid, skuItems[3]);
                    }
                }
            }
        }
        return skuNameMap;
    }

    /**
     * 获取SKU数量
     * @param numIid
     * @param skuId
     * @return
     */
    private String getSkuNum(Long numIid, Long skuId) {
        this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
        try {
            AbsResponse<Sku> ret = getSku(numIid, skuId, "quantity");
            if (!ret.isSuccess()) {
                return ret.getMsg();
            }
            Sku sku = ret.getData();
            if (sku == null || sku.getQuantity() == null) {
                return null;
            } else {
                return sku.getQuantity().toString();
            }
        } catch (Exception e) {
            log.error("numIid:" + numIid + ",skuId:" + skuId, e);
            return "发生异常：" + e.getMessage();
        }
    }

    /**
     *
     * @param aliasName
     * @return
     */
    private Map<String, String> getAliasSkuNameMap(String aliasName) {
        Map<String, String> skuNameMap = new HashMap();
        if (StringUtils.isNotEmpty(aliasName)) {
            String[] boolx = aliasName.trim().split(";");
            for (String skuStr : boolx) {
                if (skuStr.length() != 0) {
                    String[] skuItems = skuStr.split(":");
                    String skuCid = skuItems[0] + ":" + skuItems[1];
                    skuNameMap.put(skuCid, skuItems[2]);
                }
            }
        }
        return skuNameMap;
    }

    /**
     * 淘宝首次失败后，再次调用
     * uploadtype:1全量，2增量
     */
    private ItemQuantityUpdateResponse updateItemQuantity(Long productNumId,
                                                          Long skuNumId, Long qty, Long uploadType) throws Exception {
        if (uploadType == 1L && qty < 0L) {
            qty = 0L;
        }
        ItemQuantityUpdateRequest req = new ItemQuantityUpdateRequest();
        req.setNumIid(productNumId);
        if (skuNumId != null)
            req.setSkuId(skuNumId);
        req.setType(uploadType); // 1为全量更新， 2增量
        req.setQuantity(qty);

        ItemQuantityUpdateResponse response = this.executeOtsOne(req);
        return response;
    }

    /**
     * type:1为全量更新，2为增量更新。如果不填，默认为全量更新
     */
    public String updateItemQuantity(String productNumId, String skuNumId, Long qty, Long qtyOnLocation,
                                     Long qtyUnqualified, Long autoSale) throws Exception {
        this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
        try {
            RequestCheckUtils.checkNotEmpty(productNumId, "productNumId");
            RequestCheckUtils.checkNotEmpty(skuNumId, "skuNumId");

            Long lProductNumId = Long.valueOf(productNumId);
            Long lSkuNumId = Long.valueOf(skuNumId);

            String flag = "0";
            ItemQuantityUpdateResponse response = updateItemQuantity(lProductNumId, lSkuNumId, qty, 1L);
            if (response.getErrorCode() != null) {
                if (response.getSubMsg() == null) { // 调用失败时，再次调用
                    flag = uploadStock2(lProductNumId, lSkuNumId, qty, autoSale);
                    return flag;
                } else {
                    flag = getErrorMsg(response);
                    flag = flag + "," + getSkuNum(lProductNumId, lSkuNumId);
                    return flag;
                }
            }

            flag += "," + getSkuNum(lProductNumId, lSkuNumId);

            // 1.商品所有规格数量为0，taobao自动下架
            return flag;
//        }catch (ApiCheckException e){
//            return e.getErrMsg();
        } catch (Exception ex) {
            log.error("tb-uploadStock:" + skuNumId, ex);
            return "异常";
        }
    }

    // 淘宝首次失败后，再次调用
    public String uploadStock2(Long productNumId, Long skuNumId, Long qty,
                               Long autoSale) throws Exception {
        this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
        String flag = "0";

        ItemQuantityUpdateResponse response = updateItemQuantity(productNumId, skuNumId, qty, 1L);
        if (response.getErrorCode() != null) {
            flag = getErrorMsg(response);
            return flag;
        }

        flag += "," + getSkuNum(productNumId, skuNumId);

        // 1.商品所有规格数量为0，taobao自动下架

        return inventoryCalculation(qty, response, autoSale, productNumId, flag);
    }

    private String inventoryCalculation(Long qty, ItemQuantityUpdateResponse response, Long autoSale, Long productNumId,String flag)throws Exception {
        if (qty > 0) {
            Item item = response.getItem();
            if (item != null && item.getNum() > 0 && autoSale == 1) { // 设置了自动上架
                String upRet = updateItemListing(productNumId, item.getNum());
                flag += "," + upRet;
            }
        }
        return flag;
    }

    /**
     * 获取SKU数量
     * @param numIid
     * @param skuId
     * @param fields
     * @return
     * @throws Exception
     */
    private AbsResponse<Sku> getSku(Long numIid, Long skuId, String fields)
            throws Exception {
        AbsResponse<Sku> ret = new AbsResponse<>();
        if (skuId == null)
            return ret.setResult(404, "skuId为空， 没有对应sku");

        ItemSkuGetResponse response = null;
        if (isEnableOts) {
            Map<String, String> params = new HashMap<>();
            params.put("numIid", numIid == null ? "0" : numIid.toString());
            params.put("skuId", skuId.toString());
            params.put("fields", fields);
            params.put("nick", this.sellerNick);

            this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
            response = this.executeOts("getItemSku", params, ItemSkuGetResponse.class);
        } else {
            ItemSkuGetRequest req = new ItemSkuGetRequest();
            req.setNick(this.sellerNick);
            req.setNumIid(numIid);
            req.setSkuId(skuId);
            req.setFields(fields);
            response = this.execute(req);
        }
        Sku sku = response.getSku();
        if (sku == null) {
            ret.setResult(500, getErrorMsg(response));
        } else {
            ret.setData(sku);
        }
        return ret;
    }

    /**
     *
     * @param productNumId
     * @param num
     * @return
     * @throws Exception
     */
    public String updateItemListing(Long productNumId, Long num) throws Exception {
        try {
            AbsResponse ret = getItemByNumId(productNumId);
            if (ret.getCode() != 0) {
                return ret.getMsg();
            }

            Item item = (Item) ret.getData();
            if (!"instock".equals(item.getApproveStatus())) {
                return "在售状态，不需要上架";
            }
            ItemUpdateListingResponse resp = null;
            ItemUpdateListingRequest req = new ItemUpdateListingRequest();
            req.setNumIid(productNumId);
            req.setNum(item.getNum());
            resp = this.executeOtsOne(req);
            if (resp != null && resp.getItem() != null) {
                return "OK";
            } else {
                return getErrorMsg(resp);
            }
        } catch (Exception e) {
            log.error(productNumId, e);
            return "发生异常:" + e.getMessage();
        }
    }

    /**
     *
     * @param numIid
     * @return
     * @throws Exception
     */
    private AbsResponse<Item> getItemByNumId(Long numIid) throws Exception {
        AbsResponse<Item> ret = new AbsResponse<Item>();
        ItemSellerGetResponse response = null;
        try {
            if (isEnableOts) {
                Map<String, String> params = new HashMap<>();
                params.put("numIid", numIid.toString());
                params.put("fields", PRO_ITEMS_FIELD);
                params.put("nick", this.sellerNick);

                this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/productAction";
                response = this.executeOts("getItemByNumId", params, ItemSellerGetResponse.class);
            } else {
                ItemSellerGetRequest req = new ItemSellerGetRequest();
                req.setFields(PRO_ITEMS_FIELD);
                req.setNumIid(numIid);
                response = this.execute(req);
            }
        } catch (ApiException e) {
            log.error(numIid, e);
            ret.setResult(503, "发生异常:" + numIid + ":" + e.getErrMsg());
        }

        if (response == null || (response.getItem() == null && response.getErrorCode() != null)) {//添加错误信息至前端
            String error = getErrorMsg(response);
            ret.setResult(500, error);
        } else {
            ret.setCode(0);//成功
            ret.setData(response.getItem());
        }

        return ret;
    }

}
