package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.*;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.*;

/**
 * @author linhuaheng 错误代码(暂用,等完善了再定义ErrorCode): 101参数非法 102快递公司返回错误 103网络错误 100
 *         其他
 * @Title 申通快递接口
 */
public class StoShipApi extends BaseRequestApi implements IShipApi<ExpressOrderStoInfoDTO> {

    // private static Logger log = LogManager.getLogger(StoShipApi.class);

    private static final String API_FOLLOW_URL = "http://222.66.109.133/test.aspx";// 查询物流信息地址
    // http://222.66.109.133/test.aspx 测试地址
    // http://222.66.109.133/track.aspx 正式地址
    private String userName = "东商";
    private String password = "limx_1234";
    private String sessionKey = "ec30c4dd6d04325b72688384753c2952";

    private static final String CHARSET = "utf-8";
    private static final String PARTNER_ID = "iscs";

    private static final String METHOD_GET = "GET";

    private String apiUrl = "http://szdqh.wicp.net:9096/msd_vip/PreviewInterfaceAction.action";// 快递单下载和订单信息上传地址
    // http://vip.sto.cn/PreviewInterfaceAction.action 正式地址
    // http://szdqh.wicp.net:9096/msd_vip/PreviewInterfaceAction.action 给的测试地址
    // http://222.66.109.133:22221/stosy/trackToXml.action 404 not found

    private Long transporterId = 11L;// 运输商编码 暂定 先定死
    private Long transporterUnitId = 11L;// 运输商位编码 暂定 先定死
    private Long expressServiceUkid = 1L;// 服务产品 暂定 先定死
    private String cusite = "上海陈行公司";// 网点名称 测试暂时定死
    private String uploadCode = "vip0007";// 运单信息上传方法名
    private String getCode = "vip0008";// 大字查询方法名
    private String downCode = "vip0009";// 热敏单号下载方法名

    private static Map<String, String> errorCode;// 错误代码

    static {
        errorCode = new HashMap<String, String>();
        errorCode.put("100", "转换请求参数对象失败");
        errorCode.put("101", "签名不正确");

        errorCode.put("102vip0001", "查询面单发放信息异常,请求参数:params");
        errorCode.put("102vip0002", "查询传统面单模版数据异常");
        errorCode.put("102vip0005", "查询快件跟踪异常,请求参数:params");
        errorCode.put("102vip0007", "上传订单数据异常,exception简要信息");
        errorCode.put("102vip0009", "获取热敏单号失败,exception简要信息");
        errorCode.put("102vip0010", "撤销运单异常!运单编号:billno");

        errorCode.put("103", "查询成功");
        errorCode.put("104", "没有足够的单号");
        errorCode.put("105", "推送记录不能大于1000");
        errorCode.put("106", "运单编号未发放,不允许录单");
        errorCode.put("107", "运单编号已录单,不允许重复录入");
        errorCode.put("108", "发放客户或者发放网点必须要填写");
        errorCode.put("109", "请填写需要推送过来的数据");
        errorCode.put("110", "撤销运单数量大于100");
        errorCode.put("111", "参数有误");
        errorCode.put("112", "运单撤销失败!");
        errorCode.put("113", "含有无法解析字符,请检查传入的JSON数据是否正确");
        errorCode.put("114", "推送数据中必须要有运单编号");
        errorCode.put("115", "运单编号【xxx】,寄件日期必须要填写");
        errorCode.put("116", "运单编号【xxx】,网点名称必须要填写");
        errorCode.put("133", "客户密码不正确");
        errorCode.put("134", "验证通过");
    }

    // 无参构造方法
    public StoShipApi() {
    }

    // 有参构造方法
    public StoShipApi(AmAppSubscriptionDTO sub) {
        this.userName = sub.getPlatformUserId();
        this.cusite = sub.getPlatformUserNick();
        // this.sessionKey = sub.getAccessToken();
        AmAppkeyDTO app = sub.getApp();
        // this.apiUrl = app.getApiUrl();
        this.password = app.getAppSecret();

    }

    private String callApi(String method, Map<String, String> appParams) throws IOException {
        String responseString = null;
        Date reqDate = new Date();
        Map<String, String> params = new TreeMap<String, String>();
        try {
            params.putAll(appParams);
            params.put("code", method);
            params.put("data_digest", sessionKey);
            params.put("cuspwd", password);
        } finally {
            appendReqAResp(method, reqDate, null, params, responseString);
        }
        return responseString;
    }

    /**
     * 订单信息上传
     *
     * @param userName
     * @param ExpressOrderStoInfoDTO
     * @return
     * @throws IOException
     */
    private String submitOrder(String userName, List<ExpressOrderStoInfoDTO> ExpressOrderStoInfoDTO) throws Exception {
        Map<String, String> urlParam = new HashMap<String, String>();
        ArrayList<JSONObject> orders = new ArrayList<JSONObject>();
        for (int i = 0; i < ExpressOrderStoInfoDTO.size(); i++) {
            orders.add(mosaicJSON(userName, ExpressOrderStoInfoDTO.get(i)));
        }
        String data = orders.toString();// urlParam要求放入的为String类型的

        urlParam.put("data", data);// 请求参数对象
        String response = callApi(uploadCode, urlParam);
        return response;
    }


    // json数据的拼接
    private JSONObject mosaicJSON(String userName, ExpressOrderStoInfoDTO expressOrderStoInfoDTO) throws Exception {
        JSONObject json = new JSONObject();
        ExpressShiperDetail SendShiperDetail = expressOrderStoInfoDTO.getSendShiperDetail();
        ExpressShiperDetail receiverShiperDetail = expressOrderStoInfoDTO.getReceiverShiperDetail();
        json.put("billno", expressOrderStoInfoDTO.getExpressId());// 运单编号
        json.put("senddate", DateUtil.format(new Date(System.currentTimeMillis()), DateUtil.DATE_FORMAT));// 寄件日期yyyy-mm-dd
        // 获取服务器的时间
        json.put("sendsite", this.cusite);// 网点名称
        json.put("systemcode",expressOrderStoInfoDTO.getSystemCode()); //系统编号
        json.put("sitecode",expressOrderStoInfoDTO.getSiteCode());  //网点编码
        json.put("ordersource",expressOrderStoInfoDTO.getOrderSource()); //合作伙伴编码
        json.put("sendcus", SendShiperDetail.getCompany());// 客户(商家)名称
        json.put("sendperson", SendShiperDetail.getName());// 寄件人 对应senderName
        json.put("sendtel", SendShiperDetail.getMobile());// 寄件人电话 对应senderMobile
        json.put("receivecus", "");// 收件客户 可以为空
        json.put("receiveperson", receiverShiperDetail.getName());// 收件人对应receiverName
        json.put("receivetel", receiverShiperDetail.getMobile());// 收件人电话对应receiverMobile
        json.put("goodsname", "");// 内件品名,如服装、食品,对应ShipOrderItems中ShipOrderItem的name,
        // 可以为空
        json.put("inputdate", DateUtil.format(new Date(System.currentTimeMillis()), DateUtil.DATE_FORMAT));// 录入时间yyyy-mm-dd
        // 获取服务器的时间
        json.put("inputperson", userName);// 录入人 在.net里可以和寄件人一样
        json.put("inputsite", receiverShiperDetail.getCompany());// 录入网点对应receiverCompany
        json.put("lasteditdate", "");// 最后编辑时间 可以为空
        json.put("lasteditperson", "");// 最后编辑人 可以为空
        json.put("lasteditsite", "");// 最后编辑网点 可以为空
        if (StringUtils.isNotEmpty(expressOrderStoInfoDTO.getRemark())) {
            json.put("remark", expressOrderStoInfoDTO.getRemark());// 备注 可以为空
        }

        // 收件人地址
        json.put("receiveprovince", receiverShiperDetail.getProvince());// 收件省份对应receiverProvince
        json.put("receivecity", receiverShiperDetail.getCity());// 收件城市对应receiverCity
        json.put("receivearea", receiverShiperDetail.getCountry());// 收件地区对应receiverCounty
        json.put("receiveaddress", receiverShiperDetail.getAddress());// 收件地址对应receiverAddress

        // 寄件人地址
        json.put("sendprovince", SendShiperDetail.getProvince());// 寄件省份对应senderProvince
        json.put("sendcity", SendShiperDetail.getCity());// 寄件城市 对应senderCity
        json.put("sendarea", SendShiperDetail.getCity());// 寄件地区对应senderCity
        json.put("sendaddress", SendShiperDetail.getAddress());// 寄件地址对应senderAddress

        if (expressOrderStoInfoDTO.getWeight() >= 0) {
            json.put("weight", expressOrderStoInfoDTO.getWeight());// 重量 可以为空 对应weight
        }
        json.put("productcode", "");// 产品代码 可以为空
        json.put("sendpcode", "");// 寄件省份编号 可以为空
        json.put("sendccode", "");// 寄件城市编号 可以为空
        if (StringUtils.isNotEmpty(SendShiperDetail.getPostcode())) {
            json.put("sendacode", SendShiperDetail.getPostcode());// 寄件地区编号 可以为空
            // 对应receiverPostcode
        }
        json.put("receivepcode", "");// 收件省份编号 可以为空
        json.put("receiveccode", "");// 收件城市编号 可以为空
        if (StringUtils.isNotEmpty(receiverShiperDetail.getPostcode())) {
            json.put("receiveacode", receiverShiperDetail.getPostcode());// 收件地区编号
            // 可以为空
            // 对应senderPostcode
        }
        json.put("bigchar", receiverShiperDetail.getCity() + receiverShiperDetail.getCountry());// 大字可以为空
        if (StringUtils.isNotEmpty(expressOrderStoInfoDTO.getOrderId())) {
            json.put("orderno", expressOrderStoInfoDTO.getOrderId());// 订单号 可以为空 对应orderId
        }
        return json;
    }

    // @Override
    public List<SeShipmentTrack> convert(String data, String state, String city, String county) throws Exception {
        List<SeShipmentTrack> retList = new ArrayList<SeShipmentTrack>();
        if ((data == null) || (data.length() == 0)) {
            return retList;
        }
        if (!data.startsWith("<?xml")) {
            data = "<?xml version='1.0' encoding='utf-8'?>" + data;
        }
        Element ele = XmlUtils.getRootElementFromString(data);
        Element trackEle = XmlUtils.getChildElement(ele, "track");
        List<Element> detailNodeList = XmlUtils.getChildElements(trackEle, "detail");
        for (Element node : detailNodeList) {
            Element detailNode = node;
            String acceptTime = XmlUtils.getChildElementValue(detailNode, "time");
            String scantype = XmlUtils.getChildElementValue(detailNode, "scantype");
            String remark = XmlUtils.getChildElementValue(detailNode, "memo");

            SeShipmentTrack track = new SeShipmentTrack();
            track.setDateUpdated(new Date());
            track.setOperationRemark(scantype);
            track.setOperationAddress(remark);
            track.setOperationDate(DateUtil.parse(acceptTime, "yyyy/MM/dd HH:mm:ss"));
            track.setFlowStatus(getFlowStatus(remark, remark, state, city, county));
            retList.add(track);
        }
        return retList;
    }

    public List<SeShipmentTrack> convert1(String data, String state, String city, String county) throws Exception {
        List<SeShipmentTrack> retList = new ArrayList<SeShipmentTrack>();
        if ((data == null) || (data.length() == 0)) {
            return retList;
        }
        if (data.indexOf("error_info") > -1) {
            return retList;
        }
        data = data.replace("<div class=\"result_table\"><table>", "");
        data = data.replace("</table></div>", "");
        data = data.replace("<tr>", "").replace("<th>", "<td>").replace("<td>", "");
        String[] rows = data.split("</tr>");
        int i = 0;
        for (String row : rows) {
            i++;
            if (i != 1) {
                String[] cells = row.split("</td>");
                String acceptTime = cells[0];
                String remark = cells[1];

                SeShipmentTrack track = new SeShipmentTrack();
                track.setDateUpdated(new Date());
                track.setFlowStatus(getFlowStatus(remark, remark, state, city, county));
                track.setOperationDate(DateUtil.parseDay(acceptTime));
                track.setOperationRemark(remark);
                track.setOperationAddress(remark);
                retList.add(track);
            }
        }
        return retList;
    }

    private Long getFlowStatus(String address, String remark, String state, String city, String county) {
        Long status = 0L;
        if (ZtoShipApi.indexOf(remark, "到件扫描", "地点扫描", "揽件扫描", "已收件") > -1) {
            status = 550L;
        } else {
            if (ZtoShipApi.indexOf(remark, "进行中转", "已到达") > -1
                    && ZtoShipApi.indexOf(address, ZtoShipApi.getExpState(state)) > -1) {
                status = 555L;
            } else if (ZtoShipApi.indexOf(remark, "进入分拨中心", "已到达") > -1
                    && ZtoShipApi.indexOf(address, ZtoShipApi.getExpCity(city)) > -1) {
                status = 560L;
            } else if (ZtoShipApi.indexOf(remark, "到达目的地网点", "派送扫描", "开始派送", "已到达", "正在派件") > -1
                    && ZtoShipApi.indexOf(address, ZtoShipApi.getExpCity(county)) > -1) {
                status = 565L;
            } else if (ZtoShipApi.indexOf(remark, "签收", "正常签收扫描") > -1) {
                status = 600L;
            }
        }
        return status;
    }

    // 解析返回的值
    private ExpressOrderStoInfoDTO analysis(JSONObject oneObj) throws Exception {
        ExpressOrderStoInfoDTO ttoc = new ExpressOrderStoInfoDTO();
        String orderId = oneObj.getString("tradeNo");// 订单号
        String expNo = oneObj.getString("waybillNo");// 运单编号
        ttoc.setExpressId(expNo);// 运单编号
        ttoc.setOrderId(orderId);// 运输商位编码
        return ttoc;
    }

    @Override
    public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
        LogisticsInformation logisticsInformation = new LogisticsInformation();
        if (StringUtils.isEmpty(outSid)) {
            throw new IscsException("快递单号不能为空");
        }
        String responseString = null;
        String msg = "";
        Date reqDate = new Date();
        Map<String, String> urlParam = new HashMap<String, String>();
        try {
            urlParam.put("billcode", outSid);
            responseString = WebUtils.doPost(API_FOLLOW_URL, urlParam);
        } finally {
            appendReqAResp(null, reqDate, API_FOLLOW_URL, urlParam, responseString);
        }
        List<Element> elements = XmlUtils.getChildElements(XmlUtils.getRootElementFromString(responseString), "track");
        for (int i = 0; i < elements.size(); i++) {
            if (StringUtils.isEmpty(XmlUtils.getChildElementValue(elements.get(i), "detail"))) {
                msg += "," + XmlUtils.getChildElementValue(elements.get(i), "billcode");// 获取错误的单号
            }
        }
        if (StringUtils.isNotEmpty(msg)) {
            throw new IscsException(msg.substring(1));
        }
        logisticsInformation = JSON.parseObject(responseString, LogisticsInformation.class);
        return logisticsInformation;
    }

    @Override
    public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
        // TODO Auto-generated method stub
        throw new IscsException(101, "不支持单个订单,请调用批量下载的接口");
    }

    @Override
    public List<ExpressOrderStoInfoDTO> generateExpressInfos(List<ExpressOrderStoInfoDTO> expressOrderStoInfoDTOS) throws Exception {
        // TODO Auto-generated method stub
//        List<ExpressOrderStoInfoDTO> retBean = new ArrayList<>();
        List<ExpressOrderStoInfoDTO> orderCodelist = new ArrayList<ExpressOrderStoInfoDTO>();
        if (expressOrderStoInfoDTOS.isEmpty()) {
            throw new IscsException("没有传入参数");
        } else {
            String response = submitOrder(userName, expressOrderStoInfoDTOS);
            JSONObject jsonObj = JSON.parseObject(response);
            if ("102".equals(jsonObj.getString("message"))) {
//                retBean.setResult(102, jsonObj.getString("data"));// 错误代码先设置为102
                // 有时候回查询数据失败,是接口的问题
                String data = jsonObj.getString("data");
                throw new IscsException("调用接口数据失败" + data);
            } else {
                JSONArray obj = jsonObj.getJSONArray("data");// 从错误处开始后面默认全部错误,不返回数据
                for (int i = 0; i < obj.size(); i++) {
                    JSONObject oneObj = obj.getJSONObject(i);
                    ExpressOrderStoInfoDTO ttos = analysis(oneObj);
                    orderCodelist.add(ttos);
                }
                return orderCodelist;
            }
        }
    }

    @Override
    public void uploadWeight(List<ExpressUploadWeightInfo> weightInfo) throws Exception {
        throw new IscsException(101, "不支持上传重量给快递公司");
    }

    @Override
    public void cancelExpressOrder(String orderId, String outSid) throws Exception {
        // TODO Auto-generated method stub
        throw new IscsException(101, "不支持取消单个订单");
    }

    public void cancelExpressOrder(List<String> orderIds, List<String> outSids) throws Exception {
        throw new IscsException(101, "不支持取消多个订单");
    }

}
