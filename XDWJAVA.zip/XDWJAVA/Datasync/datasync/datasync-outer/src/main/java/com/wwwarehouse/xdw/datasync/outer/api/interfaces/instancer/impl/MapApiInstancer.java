package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl;

import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IMapApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.map.IbsMapApi;

/**
 * Created by huahui.wu on 2017/6/16.
 */
public class MapApiInstancer {
	public static class IbsMapInstancer extends ApiInstancer {
		@Override
		public IMapApi getMapApi(AmAppSubscriptionDTO subscription) {
			return new IbsMapApi(subscription);
		}
	}

//	public static class BaiduMapInstancer extends ApiInstancer {
//		@Override
//		public IMapApi getMapApi(AmAppSubscriptionDTO subscription) {
//			return new BaiduMapApi(subscription);
//		}
//	}
}
