package com.wwwarehouse.xdw.datasync.outer.api.sms;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yinsheng.wang on 2017/6/8.
 */
public class HaosiSmsApi extends BaseRequestApi implements com.wwwarehouse.xdw.datasync.outer.api.interfaces.ISmsApi {
    private String USERNAME = "iscs";
    private String PASSWORD = "123456";
    private String PRODUCT_ID = "695857";

    public HaosiSmsApi(AmAppSubscriptionDTO suber) {
        AmAppkeyDTO amAppkey = suber.getApp();

        this.apiUrl = amAppkey.getApiUrl();
        this.USERNAME = amAppkey.getAppKey();
        this.PASSWORD = amAppkey.getAppSecret();
        this.PRODUCT_ID = suber.getAccessToken();
    }

    @Override
    public AbsResponse<String> sendSms(String mobile, String content) throws Exception {
        String result = callApi(mobile, content);
        return getResult(result);
    }

    @Override
    public AbsResponse<String> sendSms(String[] mobiles, String content)
            throws Exception {
        String mobileNo = StringUtils.joinString(mobiles, ",");
        return sendSms(mobileNo, content);
    }

    private String callApi(String mobile, String content)
            throws IOException {
        String responseString = null;
        Date reqDate = new Date();
        Map<String, String> params = new HashMap<>();
        try {
            params.put("username", this.USERNAME);
            params.put("password", this.PASSWORD);
            params.put("productid", this.PRODUCT_ID);
            params.put("mobile", mobile);
            params.put("content", content);
            params.put("dstime", "");
            responseString = WebUtils.doPost(this.apiUrl, params);
        } finally {
            appendReqAResp("sendSms", reqDate, null, params, responseString);
        }

        return responseString;
    }

    private AbsResponse<String> getResult(String result) {
        AbsResponse<String> absResponse = new AbsResponse<String>();
        if (result.startsWith("1,")) {
            absResponse.setResult(0, null, result, null);
        } else if (result.equals("0")) {
            absResponse.setCode(1);
            absResponse.setMsg("1-失败");
        } else if (result.equals("2")) {
            absResponse.setCode(2);
            absResponse.setMsg("2-失败:余额不够");
        } else if (result.equals("3")) {
            absResponse.setCode(3);
            absResponse.setMsg("失败:黑词审核中");
        } else if (result.equals("4")) {
            absResponse.setCode(4);
            absResponse.setMsg("4-失败:提交频率太快");
        } else if (result.equals("5")) {
            absResponse.setCode(5);
            absResponse.setMsg("失败:黑词审核中");
        } else if (result.equals("6")) {
            absResponse.setCode(6);
            absResponse.setMsg("失败:有效号码为空");
        } else if (result.equals("7")) {
            absResponse.setCode(7);
            absResponse.setMsg("失败:短信内容为空");
        } else if (result.startsWith("8,")) {
            absResponse.setCode(8);
            absResponse.setMsg("失败:一级黑词" + result);
        } else if (result.equals("9")) {
            absResponse.setCode(9);
            absResponse.setMsg("失败:没有url提交权限");
            return absResponse;
        } else if (result.equals("10")) {
            absResponse.setCode(10);
            absResponse.setMsg("失败:发送号码过多");
            return absResponse;
        } else if (result.equals("11")) {
            absResponse.setCode(11);
            absResponse.setMsg("失败:产品ID异常");
        } else if (result.equals("12")) {
            absResponse.setCode(12);
            absResponse.setMsg("失败:参数异常");
        } else {
            absResponse.setCode(540);
            absResponse.setMsg(result);
        }
        return absResponse;
    }
}
