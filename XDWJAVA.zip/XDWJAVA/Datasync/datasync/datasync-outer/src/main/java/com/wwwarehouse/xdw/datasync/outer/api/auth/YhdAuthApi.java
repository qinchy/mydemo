package com.wwwarehouse.xdw.datasync.outer.api.auth;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class YhdAuthApi extends BaseRequestApi implements IAuthApi {

	private String appKey;
	private String appSecret;

	public YhdAuthApi(AmAppkeyDTO amAppkey) {
		this.appKey = amAppkey.getAppKey();
		this.appSecret = amAppkey.getAppSecret();
	}

	@Override
	public AbsResponse<String> buildAuthUrl(String state) {
		return null;
	}

	@Override
	public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("client_id", this.appKey);
		param.put("client_secret", this.appSecret);
		param.put("grant_type", "authorization_code");
		param.put("code", authCode);
//		param.put("redirect_uri", BaShopAction.feedbackUrl);
		param.put("scope", "read");
//		param.put("state", shopId.toString());
		param.put("view", "web");

		return grant(param);
	}

	private AbsResponse grant(Map<String, String> param) {
		AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<AmAuthRecordDTO>();

		String u = "https://member.yhd.com/login/token.do";
		String lRet = null;
		String lRet2 = "";
		try{
			lRet = WebUtils.doPost(u, param);
			lRet2=lRet;
			System.out.println(lRet);
			retObject.setBody(lRet);
			lRet = lRet.replace("000,", ",");

			JSONObject obj = JSON.parseObject(lRet);

			AmAuthRecordDTO auth = new AmAuthRecordDTO();
			auth.setRelatedId(relatedId);
			auth.setAccessToken(obj.getString("accessToken"));
			auth.setPlatformUserNick(obj.getString("nickName"));
			auth.setPlatformUserId(obj.getString("merchantId"));

			if(obj.containsKey("expiresIn")){
				Long expiresTime = obj.getLong("expiresIn");//"expires_in"到期时间（日期）
				Date expiresInDate = new Date(expiresTime);//"expires_in"到期时间（日期）
				long expiresIn = expiresInDate.getTime() - System.currentTimeMillis();
				auth.setExpiresIn(expiresIn);
			}

			retObject.setData(auth);
		}catch (Exception e) {
//			log.error("授权异常:" + relatedId + lRet, e);
			retObject.setResult(500, "授权异常"+lRet2+"---"+ e.getMessage());
		}
		return retObject;
	}

	@Override
	public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken) {
		AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<AmAuthRecordDTO>();
		return retObject.setResult(500, " 不支持刷新");
	}

}
