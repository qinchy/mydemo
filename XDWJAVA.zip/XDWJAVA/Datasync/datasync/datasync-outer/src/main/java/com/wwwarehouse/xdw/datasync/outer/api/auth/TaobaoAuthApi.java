package com.wwwarehouse.xdw.datasync.outer.api.auth;

import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jianjun.guan on 2017/6/9 0008.
 */
public class TaobaoAuthApi extends BaseRequestApi implements IAuthApi {
    private static Logger log = LogManager.getLogger(TaobaoAuthApi.class);

    private String appKey;
    private String appSecret;

	private String authorizeUrl;
	private String grantUrl;


    public TaobaoAuthApi(String appKey, String appSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;
        
        this.init();
    }

    public TaobaoAuthApi(AmAppkeyDTO amAppkey) {
        this.appKey = amAppkey.getAppKey();
        this.appSecret = amAppkey.getAppSecret();
        
        this.init();
    }
    
    private void init(){
    	if(true){
	    	this.authorizeUrl = "https://oauth.taobao.com/authorize";
 			this.grantUrl = "https://oauth.taobao.com/token";
	    } else {
	    	this.authorizeUrl = "https://oauth.tbsandbox.com/authorize";
	    	this.grantUrl = "https://oauth.tbsandbox.com/token";
	    }
    }

    /**
     * 构建授权地址url
     * @param state
     * @return
     */
    @Override
    public AbsResponse<String> buildAuthUrl(String state) {
        Map<String, String> params = new HashMap<>();
        params.put("response_type", "code");
        params.put("client_id", this.appKey);
//        params.put("view", "web");
        params.put("view", "wap");
        params.put("state", state);
        params.put("redirect_uri", ConstantsOuter.AUTH_FEEDBACK_URL);

        String fullUrl = WebUtils.combineQueries(this.authorizeUrl, params);

        AbsResponse<String> resp = new AbsResponse<>();
        resp.setData(fullUrl);
        return resp;
    }

    /**
     * 刷新授权，通过上一步得到的refresh_token刷新授权时间
     * @param refreshToken
     * @return
     */
    @Override
    public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken) {
        Map<String, String> param = new HashMap<>();
        param.put("grant_type", "refresh_token");
        param.put("client_id", this.appKey);
        param.put("client_secret", this.appSecret);
        param.put("view", "web");
        param.put("refresh_token", refreshToken);
//        param.put("state", null);

        return grant(param);
    }

    /**
     * 通过上一步得到的code换取access_token
     * @param authCode
     * @return
     */
    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode) {
        Map<String, String> param = new HashMap<>();
        param.put("grant_type", "authorization_code");
        param.put("code", authCode);
        param.put("client_id", this.appKey);
        param.put("client_secret", this.appSecret);
        param.put("redirect_uri", ConstantsOuter.AUTH_FEEDBACK_URL);
        param.put("view", "web");
//        param.put("state", "");

        return grant(param);
    }
    private AbsResponse<AmAuthRecordDTO> grant(Map<String, String> params) {
        AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<>();

        try {
            String response = callApi(params);
            retObject.setBody(response);
            response = response.replaceAll("/n", "");
            JSONObject obj = JSONObject.parseObject(response);
            String error = obj.getString("error");
            if(StringUtils.isNotEmpty(error)){
                retObject.setResult(905001, "授权异常" + obj.getString("error_description"));
                return retObject;
            }
            AmAuthRecordDTO auth = convertAuth(obj);
            retObject.setData(auth);
        } catch (Exception e) {
            log.error("授权异常:" + appKey, e);
            retObject.setResult(905001 , "授权异常" + e.getMessage());
        }
        return retObject;
    }

    private String callApi(Map<String, String> params) throws IOException{
        String responseString = null;
        Date reqDate = new Date();
        try {
            responseString = com.taobao.api.internal.util.WebUtils.doPost(
                    this.grantUrl, params, 30000, 30000);
        }catch (IOException e){
            responseString = e.getMessage();
            throw e;
        } finally {
            appendReqAResp("grant", reqDate, this.grantUrl, params, responseString);
        }

        return responseString;
    }

    private AmAuthRecordDTO convertAuth(JSONObject jsonObject){
        AmAuthRecordDTO auth = new AmAuthRecordDTO();
        auth.setExpiresIn(jsonObject.getLong("expires_in"));
        auth.setReExpiresIn(jsonObject.getLong("re_expires_in"));
        auth.setR1ExpiresIn(jsonObject.getLong("r1_expires_in"));
        auth.setR2ExpiresIn(jsonObject.getLong("r2_expires_in"));
        auth.setW1ExpiresIn(jsonObject.getLong("w1_expires_in"));
        auth.setW2ExpiresIn(jsonObject.getLong("w2_expires_in"));
        auth.setAccessToken(jsonObject.getString("access_token"));
        auth.setRefreshToken(jsonObject.getString("refresh_token"));
        auth.setTokenType(jsonObject.getString("token_type"));

        String nick = jsonObject.getString("taobao_user_nick");
		nick = CodecUtils.urlDecode(nick);//url解码
        auth.setPlatformUserNick(nick);

        String uid = jsonObject.getString("taobao_user_id");
        auth.setPlatformUserId(uid);
        
        return auth;
    }



}
