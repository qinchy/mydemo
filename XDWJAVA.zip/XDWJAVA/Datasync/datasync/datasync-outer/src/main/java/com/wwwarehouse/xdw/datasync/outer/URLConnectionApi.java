package com.wwwarehouse.xdw.datasync.outer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;

import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Created by lidan.wu on 2017/5/2 0002.
 */
public class URLConnectionApi {

    private String cookies;
    private String baseUrl;

    public URLConnectionApi(String baseUrl, String cookies) {
        this.cookies = cookies;
        this.baseUrl = baseUrl;
    }

    public void setCookies(String cookies) {
        this.cookies = cookies;
    }

    /**
     * @param apiMethod
     * @param params
     * @return
     * @throws IOException
     */
    public String callApi(String apiMethod, Map<String, String> params, Map<String, String> headerMap)throws IOException {
        String responseString = null;
        Date reqDate = new Date();
        String requestUrl =buildUrl(apiMethod,true);
        try {
            if (StringUtils.isNotEmpty(this.cookies)) {
                if (headerMap == null) {
                    headerMap = new HashMap<>();
                }
                    headerMap.put("Cookie", this.cookies);
            }
            String apiBody = JsonUtils.toJson(params);
            responseString = doPost(requestUrl, apiBody, "utf-8", 10000, 10000, headerMap);
        } catch (IOException e) {
            responseString = e.getMessage();
            throw e;
        } finally {
//            appendReqAResp(apiMethod, reqDate, requestUrl, params, headerMap, responseString);
        }

        return responseString;
    }

    public Map<String, String> callGetApi(String apiMethod, Map<String, String> params, Map<String, String> headerMap
            ) throws IOException {
        Map<String, String> responseString = new HashMap<>();
        Date reqDate = new Date();
        String getUrl = buildUrl(apiMethod, true);
        try {
            if (StringUtils.isNotEmpty(this.cookies)) {
                if (headerMap == null) {
                    headerMap = new HashMap<>();
                }
                headerMap.put("Cookie", this.cookies);
            }
            responseString = doGet(getUrl, cookies);
        } finally {
//            appendReqAResp(apiMethod, reqDate, getUrl, params, headerMap, JsonUtils.toJson(responseString));
        }

        return responseString;
    }

    /**
     * @param apiMethod
     * @param params
     * @return
     * @throws IOException
     */
    public Map<String, String> callApiWithCookie(String apiMethod, Map<String, String> params, Map<String, String> headerMap
            ) throws IOException {
        Map<String, String> responseString = new HashMap<>();
        Date reqDate = new Date();
        String postUrl = buildUrl(apiMethod, true);
        try {
            if (StringUtils.isNotEmpty(this.cookies)) {
                if (headerMap == null) {
                    headerMap = new HashMap<>();
                }
                headerMap.put("Cookie", this.cookies);
            }

            String apiBody = JsonUtils.toJson(params);
            responseString = doPost1(postUrl, apiBody, "utf-8", 10000, 10000, headerMap);
        } catch (IOException e) {
            responseString.put("response", e.getMessage());
            throw e;
        } finally {
//            appendReqAResp(apiMethod, reqDate, postUrl, params, headerMap, JsonUtils.toJson(responseString));
        }

        return responseString;
    }


   protected String buildUrl(String subUrl, boolean appendHost, String... args) {
        StringBuilder strBuilder = new StringBuilder();
        if(appendHost) {
            strBuilder.append(this.baseUrl);
        }

        if (subUrl.contains("%")) {
            strBuilder.append(String.format(subUrl, args));
        } else {
            strBuilder.append(subUrl);
        }
        return strBuilder.toString();
    }

   public AbsResponse<JSONObject> isOK(String resp) {
        AbsResponse<JSONObject> abs = new AbsResponse<>();
        abs.setBody(resp);
        if (StringUtils.isEmpty(resp) || !resp.startsWith("{")) {
            return abs.setResult(100, "返回数据不是json格式");
        }
        JSONObject rootObj = JSON.parseObject(resp);
        abs.setData(rootObj);

        String errorMsg = null;
        if (rootObj.containsKey("meta")) {
            JSONObject meta = rootObj.getJSONObject("meta");
            if ("ok".equals(meta.getString("rc"))) {
                return abs.setResult(0, "OK");
            }

            errorMsg = meta.getString("msg");
        }

        return abs.setResult(300, errorMsg);
    }


    public String doPost(String url, String apiBody, String charset, int connectTimeout,
                                int readTimeout, Map<String, String> headerMap) throws IOException {
        String ctype = "text/plain;charset=" + charset;
        byte[] content = apiBody.getBytes(charset);

        HttpURLConnection conn = null;
        String rsp = null;
        try {

            conn = _doPost(url, ctype, content, connectTimeout, readTimeout, headerMap);
            rsp = getResponseAsString(conn);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }


    public Map<String, String> doPost1(String url, String apiBody, String charset, int connectTimeout,
                                              int readTimeout, Map<String, String> headerMap) throws IOException {
        String ctype = "text/plain;charset=" + charset;
        byte[] content = apiBody.getBytes(charset);

        Map<String, String> result = new HashMap<>();
        HttpURLConnection conn = null;

        try {
            conn = _doPost(url, ctype, content, connectTimeout, readTimeout, headerMap);
            String rsp = getResponseAsString(conn);

            result.put("response", rsp);

            Map<String, List<String>> headerFields = conn.getHeaderFields();
            for(Map.Entry<String, List<String>> entry : headerFields.entrySet()){
                List<String> values = entry.getValue();

                StringBuilder strBuilder = new StringBuilder();
                for(String item : values) {
                    if ("SET-COOKIE".equalsIgnoreCase(entry.getKey())){
                        if(item == null || item.length() == 0){
                            continue;
                        }
                        if(item.contains(";")) {
                            strBuilder.append(item.substring(0, item.indexOf(";")));
                            strBuilder.append(";");
                        } else {
                            strBuilder.append(item);
                        }
                    } else {
                        strBuilder.append(item);
                    }
                }

                result.put(entry.getKey(), strBuilder.toString());
            }
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return result;
    }

   public HttpURLConnection _doPost(String url, String ctype, byte[] content, int connectTimeout, int readTimeout, Map<String, String> headerMap
            ) throws IOException {
        HttpURLConnection conn = null;
        OutputStream out = null;
        try {
            conn = getConnection(new URL(url), ctype, headerMap);

            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            conn.setConnectTimeout(connectTimeout);
            conn.setReadTimeout(readTimeout);
            out = conn.getOutputStream();
            out.write(content);
        } finally {
            if (out != null) {
                out.close();
            }
        }

        return conn;
    }

    public Map<String, String> doGet(String url,String cookie){
        String ctype = "text/plain;charset=utf-8" ;
        Map<String, String> result = new HashMap<>();
        try {

            HttpURLConnection conn = getConnection(new URL(url), ctype, null);

            conn.setRequestMethod("GET");
            conn.setDoOutput(false);
            conn.setRequestProperty("Cookie", cookie);
            conn.connect();

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));
            String lines ;
            StringBuilder sbd = new StringBuilder();
            while ((lines = reader.readLine()) != null){
                sbd.append(lines);
            }
            result.put("response", sbd.toString());
            reader.close();

            conn.disconnect();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public HttpURLConnection getConnection(URL url, String ctype, Map<String, String> headerMap) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (conn instanceof HttpsURLConnection) {
            boolean ignoreSSLCheck = true;
            boolean ignoreHostCheck = true;
            HttpsURLConnection connHttps = (HttpsURLConnection) conn;
            if (ignoreSSLCheck) {
                try {
                    SSLContext ctx = SSLContext.getInstance("TLS");
                    ctx.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new SecureRandom());
                    connHttps.setSSLSocketFactory(ctx.getSocketFactory());
                    connHttps.setHostnameVerifier(new HostnameVerifier() {
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    });
                } catch (Exception e) {
                    throw new IOException(e);
                }
            } else {
                try {
                    SSLContext ctx = SSLContext.getInstance("TLS");
                    ctx.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new SecureRandom());
                    connHttps.setSSLSocketFactory(ctx.getSocketFactory());
                    if (ignoreHostCheck) {
                        connHttps.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) {
                                return true;
                            }
                        });
                    }
                } catch (Exception e) {
                    throw new IOException(e);
                }
            }
            conn = connHttps;
        }

        conn.setDoInput(true);
        conn.setRequestProperty("Host", url.getHost());
        conn.setRequestProperty("User-Agent", "Iscs-Http-Client");
        conn.setRequestProperty("Content-Type", ctype);
        if (headerMap != null) {
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                conn.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        return conn;
    }

    protected String getResponseAsString(HttpURLConnection conn) throws IOException {
        String charset = getResponseCharset(conn.getContentType());
        if (conn.getResponseCode() < 400) {
            String contentEncoding = conn.getContentEncoding();
            if (WebUtils.CONTENT_ENCODING_GZIP.equalsIgnoreCase(contentEncoding)) {
                return getStreamAsString(new GZIPInputStream(conn.getInputStream()), charset);
            } else {
                return getStreamAsString(conn.getInputStream(), charset);
            }
        } else {// Client Error 4xx and Server Error 5xx
            throw new IOException(conn.getResponseCode() + " " + conn.getResponseMessage());
        }
    }

    public String getStreamAsString(InputStream stream, String charset) throws IOException {
        try {
            Reader reader = new InputStreamReader(stream, charset);
            StringBuilder response = new StringBuilder();

            final char[] buff = new char[1024];
            int read = 0;
            while ((read = reader.read(buff)) > 0) {
                response.append(buff, 0, read);
            }

            return response.toString();
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }

    public String getResponseCharset(String ctype) {
        String charset = "UTF-8";

        if (!StringUtils.isEmpty(ctype)) {
            String[] params = ctype.split(";");
            for (String param : params) {
                param = param.trim();
                if (param.startsWith("charset")) {
                    String[] pair = param.split("=", 2);
                    if (pair.length == 2) {
                        if (!StringUtils.isEmpty(pair[1])) {
                            charset = pair[1].trim();
                        }
                    }
                    break;
                }
            }
        }

        return charset;
    }

}

class TrustAnyHostnameVerifier implements HostnameVerifier {
    public boolean verify(String hostname, SSLSession session) {
        return true;
    }
}

class TrustAnyTrustManager implements X509TrustManager {
    public void checkClientTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {
    }

    public void checkServerTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {
    }

    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
    }

}

