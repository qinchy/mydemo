package com.wwwarehouse.xdw.datasync.outer.task;

/**
 * Created by zhigang.huang on 2017/6/8.
 */
public class empty {
}
