package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;


import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.PayApiInstancer;

/**
 * <pre>
 * 支付平台编码
 * 支付平台区间：13xx=1300~1399
 * </pre>
 * 
 * @author huangzhigang
 * 
 */

public enum PayPlatform {
	ALIPAY(1310L, "支付宝", new PayApiInstancer.AlipayInstancer()),
	WECHATPAY(1320L, "微信支付", new PayApiInstancer.WeinxinInstancer()),
	UNIONPAY(1330L, "银联", new PayApiInstancer.UnionInstancer())
	;

	private long id;
	private String platformName;
	private String apiCode;
	private ApiInstancer apiInstancer;

	private PayPlatform(long id, String platformName, ApiInstancer apiInstancer) {
		this.apiCode = name();
		this.id = id;
		this.platformName = platformName;
		this.apiInstancer = apiInstancer;
	}

	public boolean equalsByApiCode(String apiCode) {
		return this.apiCode.equals(apiCode);
	}

	public boolean equalsById(Long apiId) {
		return apiId != null && this.id == apiId.longValue();
	}

	public String getPlatformName() {
		return this.platformName;
	}

	public String getApiCode() {
		return this.apiCode;
	}

	public long getId() {
		return this.id;
	}

	public ApiInstancer getApiInstancer() {
		return apiInstancer;
	}

	public boolean equalsByName(String apiName) {
		return this.name().equals(apiName);
	}

	public static PayPlatform getPlatform(String apiName) {
		try {
			return PayPlatform.valueOf(PayPlatform.class, apiName);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static PayPlatform getPlatform(long id) {
		for (PayPlatform item : values()) {
			if (item.id == id)
				return item;
		}

		return null;
	}

}
