package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl;


import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.auth.JingdongAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.auth.TaobaoAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.auth.WeChatAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.auth.YhdAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.JingdongApi;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.TaobaoApi;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.YhdApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;

public class PlatformApiInstancer {
	public static class Ali1688Instancer extends ApiInstancer {
		public Ali1688Instancer() {
		}

//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new Ali1688AuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new Ali1688Api(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new Ali1688Api(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new Ali1688Api(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new Ali1688Api(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
	}

//	public static class AliExpressInstancer extends ApiInstancer {
//		public AliExpressInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new AliExpressAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new AliExpressApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new AliExpressApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new AliExpressApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new AliExpressApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//	}
//
//	public static class AmazonInstancer extends ApiInstancer {
//		public AmazonInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new AmazonAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new AmazonApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new AmazonApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new AmazonApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new AmazonApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "amazonTradeService";
//		}
//
//	}
//
//	public static class BeibeiInstancer extends ApiInstancer {
//		public BeibeiInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new BeibeiAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new BeibeiApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new BeibeiApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new BeibeiApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new BeibeiApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//	}
//
//	public static class DangDangInstancer extends ApiInstancer {
//		public DangDangInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new DangDangAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new DangDangApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new DangDangApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new DangDangApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new DangDangApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//	}
//
	public static class JingdongInstancer extends ApiInstancer {
		public JingdongInstancer() {
		}
  		@Override
		public IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
			return new JingdongAuthApi(amAppkey);
		}

		@Override
		public ITradeApi getTradeApi(AmAppSubscriptionDTO subscription) {
			return new JingdongApi(subscription);
		}

		@Override
		public IProductApi getProductApi(AmAppSubscriptionDTO subscription) {
			return new JingdongApi(subscription);
		}

		@Override
		public IShopApi getShopApi(AmAppSubscriptionDTO subscription) {
			return new JingdongApi(subscription);
		}

		@Override
		public IRefundApi getRefundApi(AmAppSubscriptionDTO subscription) {
			return new JingdongApi(subscription);
		}
		@Override
		public String getTradeService() {
			return "jingdongTradeService";
		}

	}
//
//	public static class MiyabaobeiInstancer extends ApiInstancer {
//		public MiyabaobeiInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new MiyabaobeiAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new MiyabaobeiApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new MiyabaobeiApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new MiyabaobeiApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new MiyabaobeiApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//
//	}
//
//	public static class RongegouInstancer extends ApiInstancer {
//		public RongegouInstancer() {
//		}
//
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new RongegouAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new RongegouApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new RongegouApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new RongegouApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new RongegouApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//	}
//
//	public static class SuningInstancer extends ApiInstancer {
//		public SuningInstancer() {
//		}
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new SuningAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new SuningApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new SuningApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new SuningApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new SuningApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "suningTradeService";
//		}
//
//		@Override
//		public String getRefundService() {
//			return "suningRefundService";
//		}
//	}
//
	public static class TaobaoInstancer extends ApiInstancer {
		@Override
		public IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
			return new TaobaoAuthApi(amAppkey);
		}

		@Override
		public ITradeApi getTradeApi(AmAppSubscriptionDTO subscription) {
			return new TaobaoApi(subscription);
		}

		@Override
		public IProductApi getProductApi(AmAppSubscriptionDTO subscription) {
			return new TaobaoApi(subscription);
		}

		@Override
		public IShopApi getShopApi(AmAppSubscriptionDTO subscription) {
			return new TaobaoApi(subscription);
		}

		@Override
		public IRefundApi getRefundApi(AmAppSubscriptionDTO subscription) {
			return new TaobaoApi(subscription);
		}

		@Override
		public String getTradeService() {
			return "seTaobaoTradeManagerImpl";
		}

		@Override
		public String getRefundService() {
			return "SeTaobaoRefundManagerImpl";
		}
	}
//
//	public static class TaobaoFxInstancer extends ApiInstancer {
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new TaobaoFxAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new TaobaoFenxiaoApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new TaobaoFenxiaoApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new TaobaoFenxiaoApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new TaobaoFenxiaoApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "taobaoFxTradeService";
//		}
//
//	}
//
//	public static class VjiaInstancer extends ApiInstancer {
//		@Override
//		public IAuthApi getAuthApi(AmAppkeyDO amAppkey) {
//			return new VjiaAuthApi(amAppkey);
//		}
//
//		@Override
//		public ITradeApi getTradeApi(AmAppSubscriptionDO subscription) {
//			return new VjiaApi(subscription);
//		}
//
//		@Override
//		public IProductApi getProductApi(AmAppSubscriptionDO subscription) {
//			return new VjiaApi(subscription);
//		}
//
//		@Override
//		public IShopApi getShopApi(AmAppSubscriptionDO subscription) {
//			return new VjiaApi(subscription);
//		}
//
//		@Override
//		public IRefundApi getRefundApi(AmAppSubscriptionDO subscription) {
//			return new VjiaApi(subscription);
//		}
//
//		@Override
//		public String getTradeService() {
//			return "seOriginTradeService";
//		}
//	}
//
	public static class YhdInstancer extends ApiInstancer {
		@Override
		public IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
			return new YhdAuthApi(amAppkey);
		}

		@Override
		public ITradeApi getTradeApi(AmAppSubscriptionDTO subscription) {
			return new YhdApi(subscription);
		}

		@Override
		public IProductApi getProductApi(AmAppSubscriptionDTO subscription) {
			return new YhdApi(subscription);
		}

		@Override
		public IShopApi getShopApi(AmAppSubscriptionDTO subscription) {
			return new YhdApi(subscription);
		}


		@Override
		public IRefundApi getRefundApi(AmAppSubscriptionDTO subscription) {
			return new YhdApi(subscription);
		}

		@Override
		public String getTradeService() {
			return "yhdTradeService";
		}
	}

	public static class WeChatInstancer extends ApiInstancer {
		public WeChatInstancer() {
		}
		@Override
		public IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
			return new WeChatAuthApi(amAppkey);
		}
	}

}
