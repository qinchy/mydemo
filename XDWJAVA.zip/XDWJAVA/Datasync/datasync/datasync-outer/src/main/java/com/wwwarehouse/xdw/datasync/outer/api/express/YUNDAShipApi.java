package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.*;
import com.wwwarehouse.commons.xml.XmlConverter;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaExpressCode;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.ExpressStatus;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.ShipApiInstancer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.*;

/**
 * 韵达接口
 *
 * @author yejunjun
 */
public class YUNDAShipApi extends BaseRequestApi implements IShipApi<ExpressOrderYUNDAInfoDTO> {

	private static Logger log = LogManager.getLogger(YUNDAShipApi.class);

	/******************
	 * 参数暂时都有用到，当需要修改老代码的时候把老参数配置给去掉
	 ******************/
	//物流单号信息查询配置
	private static final String FOLLOW_API_URL = "http://join.yundasys.com/query/xml.php";
	private static final String FOLLOW_PARTNER_ID = "iscs";
	//	private static final String FOLLOW_PASSWORD = "Mtd2sqDRF58zaRpqhPLT";
	private static final String FOLLOW_CHARSET = "utf-8";

	//上传重量配置信息
	private static final String UPLOAD_PARTNERID = "ISCS";
	private static final String UPLOAD_VERSION = "1.0";
	private static final String UPLOAD_KEY64 = "PZLBGDZ2ZN30IGBW";
	private static final String UPLOAD_SECRET = "YMIXQHPKG9YZSZD2";
	private static final String UPLOAD_CHARSET = "utf-8";
	private static final String UPLOAD_URL = "http://180.153.139.84:21376/InfoCall/order/weight.action";
	private static final String SCAN_SITE = "685021";
	private static final String SCAN_MAN = "6850211001";
	private static final String GUN_ID = "862493060724337";


	//新的参数配置
	private static final String RECEIVER_URL = "interface_receive_order__mailno.php";
	private static final String CANCLE_URL = "interface_cancel_order.php";
	private static final String QUERY_URL = "interface_order_info.php";//后期可能会用到先预先定义
	private static final String QUERYPDF_URL = "interface_print_file.php";//后期可能会用到先预先定义
	private String apiUrl = "http://order.yundasys.com:10235/cus_order/order_interface/";
	private String partnerid = "iscs";
	private String password = "Mtd2sqDRF58zaRpqhPLT";
	private String version = "1.0";
	private AmAppSubscriptionDTO subscription;

	//"http://orderdev.yundasys.com:10110/cus_order/order_interface/" interfaceUrl测试地址
	public YUNDAShipApi(AmAppSubscriptionDTO subscription) {
		AmAppkeyDTO app = subscription.getApp();
		this.partnerid = app.getServiceCode();
		this.password = app.getAppSecret();
		if (StringUtils.isNotEmpty(app.getApiUrl())) {
			apiUrl = app.getApiUrl();
		}
		this.subscription = subscription;
	}

	public YUNDAShipApi() {

	}


	@Override
	public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
		return convertToLogisticsInformation(callApiByOutSid(outSid));
	}


	@Override
	public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {

		if (expressOrderInfo == null) {
			throw new IscsException("订单为空");
		}
		ExpressOrderYUNDAInfoDTO expressOrderYUNDAInfo = (ExpressOrderYUNDAInfoDTO) expressOrderInfo;
		List<ExpressOrderYUNDAInfoDTO> expressOrderInfoDTOs = new ArrayList<>();
		expressOrderInfoDTOs.add(expressOrderYUNDAInfo);
		String xmlString = getOrderXml(expressOrderInfoDTOs, "shipOrderDTO");
		String responseString = callApi(xmlString, apiUrl + RECEIVER_URL, "data");

		Element responses = XmlUtils.getRootElementFromString(responseString);
		Element response = XmlUtils.getChildElement(responses, "response");
		String status = XmlUtils.getChildElementValue(response, "status");
		if ("1".equals(status)) {
			String orderSerialNo = XmlUtils.getChildElementValue(response, "order_serial_no");
			expressOrderInfo.setOrderId(orderSerialNo);
			String mailNo = XmlUtils.getChildElementValue(response, "mail_no");
			expressOrderInfo.setExpressId(mailNo);
		} else {
			String orderSerialNo = XmlUtils.getChildElementValue(response, "order_serial_no");
			String errorMsg = XmlUtils.getChildElementValue(response, "msg");
			log.error("系统错误，获取快递单失败 " + orderSerialNo + errorMsg);
			throw new IscsException("系统错误，获取快递单失败");
		}
		return expressOrderYUNDAInfo;
	}


	@Override
	public  List<ExpressOrderYUNDAInfoDTO> generateExpressInfos(List<ExpressOrderYUNDAInfoDTO> expressOrderInfoDTOs)
			throws Exception {

		if (expressOrderInfoDTOs == null || expressOrderInfoDTOs.size() == 0) {
			throw new IscsException("订单为空");
		}

		Map<String, ExpressOrderYUNDAInfoDTO> expressOrderMap = new HashMap<>();
		for (ExpressOrderYUNDAInfoDTO shipOrderDTO : expressOrderInfoDTOs) {
			expressOrderMap.put(shipOrderDTO.getOrderId(), shipOrderDTO);
		}

		String xmlString = getOrderXml(expressOrderInfoDTOs, "shipOrder");
		String responseString = callApi(xmlString, apiUrl + RECEIVER_URL, "data");

		StringBuilder errorMsgAll = new StringBuilder();
		Element responses = XmlUtils.getRootElementFromString(responseString);
		List<Element> response = XmlUtils.getChildElements(responses, "response");
		for (Element ele : response) {
			String status = XmlUtils.getChildElementValue(ele, "status");
			if ("1".equals(status)) {
				String orderSerialNo = XmlUtils.getChildElementValue(ele, "order_serial_no");
				expressOrderMap.get(orderSerialNo).setOrderId(orderSerialNo);
				String mailNo = XmlUtils.getChildElementValue(ele, "mail_no");
				expressOrderMap.get(orderSerialNo).setExpressId(mailNo);
			} else {
				String orderSerialNo = XmlUtils.getChildElementValue(ele, "order_serial_no");
				String errorMsg = XmlUtils.getChildElementValue(ele, "msg");
				if (errorMsgAll.length() > 0) {
					errorMsgAll.append(", ");
				}
				errorMsgAll.append(orderSerialNo + errorMsg);
			}
		}

		return expressOrderInfoDTOs;
	}

	@Override
	public void cancelExpressOrder(String orderId, String outSid) throws Exception {
		if (outSid == null) {
			throw new IscsException("运单号为空");
		}
		if (orderId == null) {
			throw new IscsException("订单号为空");
		}
		List<ExpressOrderYUNDAInfoDTO> shipOrderDTOs = new ArrayList<>();
		ExpressOrderYUNDAInfoDTO expressOrderYUNDAInfoDTO = new ExpressOrderYUNDAInfoDTO();
		expressOrderYUNDAInfoDTO.setExpressId(outSid);
		expressOrderYUNDAInfoDTO.setOrderId(orderId);
		shipOrderDTOs.add(expressOrderYUNDAInfoDTO);

		String xmlString = getOrderXml(shipOrderDTOs, "cancelOrder");
		String responseString = callApi(xmlString, apiUrl + CANCLE_URL, "cancel_order");

		Element responses = XmlUtils.getRootElementFromString(responseString);
		Element response = XmlUtils.getChildElement(responses, "response");
		String status = XmlUtils.getChildElementValue(response, "status");
		if ("1".equals(status)) {
//			retObject.setCode(0);//成功
			return;
		} else {
			String orderSerialNo = XmlUtils.getChildElementValue(response, "order_serial_no");
			String errorMsg = XmlUtils.getChildElementValue(response, "msg");
//			retObject.setResult(102, orderSerialNo + errorMsg);
			log.error("取消快递单失败" + orderSerialNo + errorMsg);
		}
		return;
	}


	@Override
	public void uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception {

		String retString = callApiByMethod(buildRequestParams(weightInfos), "upload_order");
		Element responses = XmlUtils.getRootElementFromString(retString);
		if (responses == null) {
			throw new IscsException("返回数据异常");
//			retObject.setResult(400, "返回数据异常");
		}
		String error = XmlUtils.getChildElementValue(responses,
				"error_code");
		if (error != null && "0".equals(error)) {
			Element response = XmlUtils
					.getChildElement(responses, "orders");
			List<Element> listN = XmlUtils.getChildElements(response,
					"order");

			if ((listN != null) && (listN.size() > 0)) {
				for (Element node : listN) {
					String id = XmlUtils.getChildElementValue(node, "id");
					String errorCode = XmlUtils.getChildElementValue(node,
							"error_code");

				}
				// retObject.setData(packList);
			}
		} else {
//			retObject.setResult(400, "异常:" + error);
		}

		return;
	}


	private String buildRequestParams(List<ExpressUploadWeightInfo> weightInfos) throws Exception {
		StringBuffer sb = new StringBuffer();
		String date = DateUtil.toDateTimeString(new Date());
		sb.append("<orders>")
				.append("<request_time>")
				.append(date)
				.append("</request_time>")
				.append("<gun_id>")
				.append(GUN_ID)
				.append("</gun_id>");
		for (ExpressUploadWeightInfo sePack : weightInfos) {
			Map<String, String> packMap = new HashMap<String, String>();
			packMap.put("id", sePack.getPackageId().toString());
			packMap.put("doc_id", sePack.getExpressId());
			packMap.put("scan_site", SCAN_SITE);
			packMap.put("scan_time", DateUtil.toDateString(sePack.getScanTime()));
			packMap.put("scan_man", SCAN_MAN);
			packMap.put("obj_wei", StringUtils.toString(sePack.getWeight()));

			String orderString = XmlUtils.XmlFromObject("order", packMap, false);
			sb.append(orderString);
		}
		sb.append("</orders>");
		return sb.toString();
	}


	public AbsResponse<List<TmTmsOrderCodeDTO>> downLoadOutSid(boolean isCod,
	                                                           int num) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



	private String callApiByOutSid(String outSid) throws IOException {
		Map<String, String> params = new HashMap<String, String>();
		params.put("partnerid", FOLLOW_PARTNER_ID);
		params.put("charset", FOLLOW_CHARSET);
		params.put("mailno", outSid);

		return WebUtils.doPost(FOLLOW_API_URL, params);
	}

	public String callApiByMethod(String content, String method)
			throws IOException {

		Map<String, String> params = new HashMap<String, String>();
		params.put("partnerid", UPLOAD_PARTNERID);
		params.put("version", UPLOAD_VERSION);
		params.put("request", method);

		String xmldata = CodecUtils.encodeBase64(UPLOAD_KEY64,
				content.getBytes(UPLOAD_CHARSET));
		params.put("xmldata", xmldata);
		byte[] validation = CodecUtils.encryptMD5(xmldata + UPLOAD_PARTNERID + UPLOAD_SECRET);
		params.put("validation", new String(validation, UPLOAD_CHARSET));
		String retString = WebUtils.doPost(UPLOAD_URL, params, UPLOAD_CHARSET, 1500, 1500);
		return retString;
	}


	public String callApi(String content, String url, String method) throws IOException {
		Map<String, String> params = new HashMap<String, String>();
		String responseString = null;
		Date reqDate = new Date();

		try {
			params.put("partnerid", CodecUtils.urlEncode(partnerid));
			params.put("version", CodecUtils.urlEncode(version));
			params.put("request", CodecUtils.urlEncode(method));
			String xmldata = CodecUtils.encodeBase64(content);
			params.put("xmldata", CodecUtils.urlEncode(xmldata));
			String validation = CodecUtils.byte2hex(CodecUtils.encryptMD5(xmldata + partnerid + password)).toLowerCase();
			params.put("validation", validation);

			responseString = WebUtils.doPost(url, params);
		} finally {
//			appendReqAResp(url, reqDate, null, params, responseString);
		}
		System.out.println(responseString);

		return responseString;
	}

	private String getOrderXml(List <ExpressOrderYUNDAInfoDTO>shipOrderDTOs, String type) {
		List<Map<String, Map<String, Object>>> orderList = new ArrayList<>();
		for (ExpressOrderYUNDAInfoDTO shipOrderDTO : shipOrderDTOs) {
			Map<String, Map<String, Object>> params = new HashMap<>();
			Map<String, Object> itemMap = new HashMap<>();
			if ("shipOrderDTO".equals(type)) {
				getShipOrderXml(shipOrderDTO, itemMap);
			} else if ("cancelOrder".equals(type)) {
				getCancelOrderXml(shipOrderDTO, itemMap);
			}
			params.put("order", itemMap);
			orderList.add(params);
		}
		return XmlConverter.convert("orders", orderList);
	}

	private void getShipOrderXml(ExpressOrderYUNDAInfoDTO shipOrderDTO, Map<String, Object> itemMap) {
		itemMap.put("order_serial_no", shipOrderDTO.getOrderId());//必填
		itemMap.put("khddh", shipOrderDTO.getOrderId());//必填
		Map<String, Object> sender = new HashMap<>();
		sender.put("name", shipOrderDTO.getSendShiperDetail().getName());//必填
		sender.put("company", shipOrderDTO.getSendShiperDetail().getCompany());
		sender.put("city", shipOrderDTO.getSendShiperDetail().getCity());//cod订单必填
		sender.put("address", shipOrderDTO.getSendShiperDetail().getAddress());//必填
		sender.put("postcode", shipOrderDTO.getSendShiperDetail().getPostcode());
		sender.put("phone", shipOrderDTO.getSendShiperDetail().getPhone());//寄件人联系方式必填一项
		sender.put("mobile", shipOrderDTO.getSendShiperDetail().getMobile());//寄件人联系方式必填一项
		itemMap.put("sender", sender);
		Map<String, Object> receiver = new HashMap<>();
		receiver.put("name", shipOrderDTO.getReceiverShiperDetail().getName());//必填
		receiver.put("company", shipOrderDTO.getReceiverShiperDetail().getCompany());
		receiver.put("city", shipOrderDTO.getReceiverShiperDetail().getCity());//cod订单必填
		receiver.put("address", shipOrderDTO.getReceiverShiperDetail().getAddress());//必填
		receiver.put("postcode", shipOrderDTO.getReceiverShiperDetail().getPostcode());
		receiver.put("phone", shipOrderDTO.getReceiverShiperDetail().getPhone());//收件人联系方式必填一项
		receiver.put("mobile", shipOrderDTO.getReceiverShiperDetail().getMobile());//收件人联系方式必填一项
		itemMap.put("receiver", receiver);
		itemMap.put("weight", shipOrderDTO.getWeight());
		itemMap.put("size", shipOrderDTO.getSize());
		List<Map<String, Map<String, Object>>> itemsList = new ArrayList<>();
		List<ShipOrderItemDTO> shipOrderItemDTOs = shipOrderDTO.getShipOrderItemDTO();
		for (ShipOrderItemDTO shipOrderItemDTO : shipOrderItemDTOs) {
			Map<String, Map<String, Object>> items = new HashMap<>();
			Map<String, Object> item = new HashMap<>();
			item.put("name", shipOrderItemDTO.getName());//cod订单必填
			item.put("number", shipOrderItemDTO.getNumber());
			item.put("remark", shipOrderItemDTO.getRemark());
			items.put("item", item);
			itemsList.add(items);
		}
		itemMap.put("items", itemsList);
		if (shipOrderDTO.isCOD()) {
			itemMap.put("collection_value", shipOrderDTO.getCollectionValue());//cod订单必填
		}
	}

	private void getCancelOrderXml(ExpressOrderInfoDTO shipOrderDTO, Map<String, Object> itemMap) {
		itemMap.put("order_serial_no", shipOrderDTO.getOrderId());
	}


	public static void main(String[] args) throws Exception {

		AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
		subscription.setPlatformId(BaExpressCode.YUNDA.getId());
		AmAppkeyDTO app = new AmAppkeyDTO();
		app.setServiceCode("31011612345");
		app.setAppSecret("123456");
//		app.setApiUrl("http://order.yundasys.com:10235/cus_order/order_interface/");
		subscription.setApp(app);

		ApiInstancer apiInstancer = ShipApiInstancer.getInstance();
		IShipApi ishipApi = apiInstancer.getShipApi(subscription);

		List<ShipOrderDTO> shipOrderDTOs = new ArrayList<>();
		ShipOrderDTO shipOrderDTO = new ShipOrderDTO();
		shipOrderDTO.setOrderId("123111");
		shipOrderDTO.setSenderName("张三");
		shipOrderDTO.setSenderCompany("天羽服饰有限公司");
		shipOrderDTO.setSenderCity("江苏省，徐州市，新沂市");
		shipOrderDTO.setSenderAddress("江苏省徐州市新沂市湖东路999号");
		shipOrderDTO.setSenderPostcode("221435");
		shipOrderDTO.setSenderPhone("65000000");
		shipOrderDTO.setSenderMobile("1360000000000");
		shipOrderDTO.setReceiverName("李四");
		shipOrderDTO.setReceiverCompany("");
		shipOrderDTO.setReceiverCity("上海市，上海市，青浦区");
		shipOrderDTO.setReceiverAddress("上海市青浦区盈港东路6655号");//上海市青浦区盈港东路6655号
		shipOrderDTO.setReceiverPostcode("368200");
		shipOrderDTO.setReceiverPhone("65000899");
		shipOrderDTO.setReceiverMobile("1360123000000");
		shipOrderDTO.setWeight(1.0);
		shipOrderDTO.setSize("0.05");
		List<ShipOrderItemDTO> items = new ArrayList<>();
		ShipOrderItemDTO item = new ShipOrderItemDTO();
		item.setName("iphone7 plus");
		item.setNumber(1);
		item.setRemark("");
		ShipOrderItemDTO itemSec = new ShipOrderItemDTO();
		itemSec.setName("iphone6s plus");
		itemSec.setNumber(2);
		itemSec.setRemark("");
		items.add(item);
		items.add(itemSec);
		shipOrderDTO.setShipOrderItemDTOs(items);
		shipOrderDTOs.add(shipOrderDTO);

		ShipOrderDTO shipOrderDTOOther = new ShipOrderDTO();
		shipOrderDTOOther.setOrderId("123112");
		shipOrderDTOOther.setSenderName("王五");
		shipOrderDTOOther.setSenderCompany("天羽服饰有限公司");
		shipOrderDTOOther.setSenderCity("江苏省，徐州市，新沂市");
		shipOrderDTOOther.setSenderAddress("江苏省徐州市新沂市湖东路999号");
		shipOrderDTOOther.setSenderPostcode("221435");
		shipOrderDTOOther.setSenderPhone("65000000");
		shipOrderDTOOther.setSenderMobile("1360000000000");
		shipOrderDTOOther.setReceiverName("李四");
		shipOrderDTOOther.setReceiverCompany("");
		shipOrderDTOOther.setReceiverCity("上海市，上海市，青浦区");
		shipOrderDTOOther.setReceiverAddress("上海市青浦区盈港东路6655号");//上海市青浦区盈港东路6655号
		shipOrderDTOOther.setReceiverPostcode("368200");
		shipOrderDTOOther.setReceiverPhone("65000899");
		shipOrderDTOOther.setReceiverMobile("1360123000000");
		shipOrderDTOOther.setWeight(1.0);
		shipOrderDTOOther.setSize("0.05");
		List<ShipOrderItemDTO> itemsO = new ArrayList<>();
		ShipOrderItemDTO itemO = new ShipOrderItemDTO();
		itemO.setName("iphone7 plus");
		itemO.setNumber(1);
		itemO.setRemark("");
		itemsO.add(itemO);
		shipOrderDTOOther.setShipOrderItemDTOs(itemsO);
		shipOrderDTOs.add(shipOrderDTOOther);

		try {
			//TODO 因重新修改接口被我注释掉，请注意修改*****************王海超
		    ishipApi.trackLogisticsInfo("1901818007192");
//			ishipApi.getTmsOrderCode(shipOrderDTO);
//			api.cancelTmsOrderCode(shipOrderDTOs);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	private LogisticsInformation convertToLogisticsInformation(String responseString) throws IscsException, IOException {
		Element responses = XmlUtils.getRootElementFromString(responseString);
		LogisticsInformation result = new LogisticsInformation();
		result.setExpressCompany(BaExpressCode.YUNDA.getExpName());
		result.setOutSid(XmlUtils.getChildElementValue(responses, "mailno"));
		ExpressStatus expressStatu = convertToExpressStatus(XmlUtils.getChildElementValue(responses, "status"));
		if (expressStatu != null) {
			result.setStatus(expressStatu.getCode());
			result.setStatusDesc(expressStatu.getDesc());
		}


		List<LogisticsInfomationDetail> infomationDetails = new ArrayList<>();
		result.setInfomationDetails(infomationDetails);
		NodeList nodeSteps = XmlUtils.getChildElement(responses, "steps").getChildNodes();
		for (int i = 0; i < nodeSteps.getLength(); i++) {
			LogisticsInfomationDetail logisticsInfomationDetail = new LogisticsInfomationDetail();
			Element step = (Element)nodeSteps.item(i);
			logisticsInfomationDetail.setAddress(XmlUtils.getChildElementValue(step, "address"));
			logisticsInfomationDetail.setDescription(XmlUtils.getChildElementValue(step, "remark"));
			logisticsInfomationDetail.setOperatingTime(DateUtil.parse(XmlUtils.getChildElementValue(step, "time"),"yyyy-MM-dd hh:mm:ss"));
			ExpressStatus subExpressStatu = convertToExpressStatus(XmlUtils.getChildElementValue(step, "status"));
			if(subExpressStatu != null){
				logisticsInfomationDetail.setStatus(subExpressStatu.getCode());
			}
			infomationDetails.add(logisticsInfomationDetail);
		}

		return result;
	}

	private ExpressStatus convertToExpressStatus(String status) {
		switch (status) {
			case "got":
				return ExpressStatus.START;
			case "transite":
				return ExpressStatus.TRANSPORT;
			case "signed":
				return ExpressStatus.SIGNED;
		}
		return null;
	}



}
