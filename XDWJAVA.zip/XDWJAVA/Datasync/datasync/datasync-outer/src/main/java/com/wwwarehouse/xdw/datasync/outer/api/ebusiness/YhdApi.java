package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.*;
import com.yhd.YhdClient;
import com.yhd.common.Request;
import com.yhd.common.Response;
import com.yhd.object.ErrDetailInfo;
import com.yhd.object.ErrDetailInfoList;
import com.yhd.object.order.*;
import com.yhd.object.refund.Refund;
import com.yhd.object.refund.RefundDetail;
import com.yhd.object.refund.RefundItem;
import com.yhd.object.refund.RefundItemList;
import com.yhd.request.logistics.LogisticsOrderShipmentsUpdateRequest;
import com.yhd.request.order.OrderDetailGetRequest;
import com.yhd.request.order.OrdersGetRequest;
import com.yhd.request.product.ProductStockUpdateRequest;
import com.yhd.request.refund.RefundDetailGetRequest;
import com.yhd.request.refund.RefundGetRequest;
import com.yhd.request.store.StoreGetRequest;
import com.yhd.response.logistics.LogisticsOrderShipmentsUpdateResponse;
import com.yhd.response.order.OrderDetailGetResponse;
import com.yhd.response.order.OrdersGetResponse;
import com.yhd.response.product.ProductStockUpdateResponse;
import com.yhd.response.refund.RefundDetailGetResponse;
import com.yhd.response.refund.RefundGetResponse;
import com.yhd.response.store.StoreGetResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 一号店
 * @author TecD01
 *
 */
public class YhdApi extends BaseRequestApi implements ITradeApi, IProductApi,
		IRefundApi, IShopApi {
	private static Logger log = LogManager.getLogger(YhdApi.class);

	private String sessionKey = null;
	private String appKey = null;
	private String appSecret = null;
	private YhdClient yhdClient = null;
	private AmAppSubscriptionDTO subscription;
//    private final static int dateType = 2;// @see dateType 时间类型 :1、申请时间 2、更新时间

	public YhdApi(AmAppSubscriptionDTO subscription){
		this.subscription = subscription;
		AmAppkeyDTO app = subscription.getApp();
		this.relatedId=subscription.getSubscriptionBuId();
		this.platformId = app.getPlatformId();
		this.appKey = app.getAppKey();
		this.appSecret = app.getAppSecret();
		this.sessionKey = subscription.getAccessToken();

		setApiUrl(app.getApiUrl());
		this.yhdClient = new YhdClient(this.apiUrl, this.appKey, this.appSecret);
	}

	@Override
	public AbsResponse<?> getShop(String nick) throws Exception {
		YhdClient yhd = new YhdClient(apiUrl,appKey,appSecret);
		StoreGetRequest request = new StoreGetRequest();
		StoreGetResponse response = yhd.excute(request, sessionKey);
		AbsResponse abs = new AbsResponse();
		abs.setData(response);
		return abs;
	}

	// 订单日期类型(1：订单生成日期，2：订单付款日期，3：订单发货日期，4：订单收货日期，5：订单更新日期)
	// 退款单时间类型 :1、申请时间 2、更新时间
	private static enum DateType {
		create(1, "订单生成日期"), pay(2, "订单付款日期"), ship(3, "订单发货日期"),
		receive(4, "订单收货日期"), update(5, "订单更新日期"), refund(2, "退款单更新时间");
		public final Integer value;
		public final String name;
		DateType(Integer value, String name) {
			this.value = value;
			this.name = name;
		}
	}

	@Override
	public AbsResponse catchOneTrade(String tid) {
		AbsResponse<SeYhdTradeDTO> rsp = new AbsResponse<SeYhdTradeDTO>();
		if (StringUtils.isEmpty(tid)) {
			return rsp.setResult(500, "订单号不允许为空!");
		}
		try {
			OrderDetailGetRequest request = new OrderDetailGetRequest();
			request.setOrderCode(tid);
			OrderDetailGetResponse response = this.execute(request,
					sessionKey);
			if (response.getErrorCount() != null && response.getErrorCount() > 0) {
				String errorDes = errorInfo(response.getErrInfoList());
				rsp.setResult(500, errorDes);
			} else {
				OrderDetail od = response.getOrderInfo().getOrderDetail();
				OrderItemList oi = response.getOrderInfo().getOrderItemList();
				rsp.setData(convertTrade(od, oi));
			}
		} catch (Exception e) {
			log.error(tid, e);
			rsp.setResult(530, "发生异常:" + e.getMessage());
		}
		return rsp;
	}

	private SeYhdTradeDTO convertTrade(OrderDetail od, OrderItemList oi) throws Exception {
		SeYhdTradeDTO trade = new SeYhdTradeDTO();

		trade.setShopId(this.relatedId);
		trade.setOrderId(od.getOrderId().toString());
		trade.setOrderCode(od.getOrderCode());
		trade.setPlatformOrderStatus(od.getOrderStatus());
		if (od.getOrderCreateTime() != null)
			trade.setOrderCreateTime(DateUtil.parseDateTime(od.getOrderCreateTime()));
		if (od.getUpdateTime() != null)
			trade.setOrderModifyTime(DateUtil.parseDateTime(od.getUpdateTime()));
		trade.setOrderAmount(new BigDecimal(od.getOrderAmount()));
		trade.setProductAmount(new BigDecimal(od.getProductAmount()));
		trade.setOrderPromotionDiscount(new BigDecimal(od.getOrderPromotionDiscount()));
		trade.setFreightFee(new BigDecimal(od.getOrderDeliveryFee()));
		trade.setOrderNeedInvoice(od.getOrderNeedInvoice().longValue());
		trade.setReceiverName(od.getGoodReceiverName());
		trade.setReceiverAddress(od.getGoodReceiverAddress());
		trade.setReceiverState(od.getGoodReceiverProvince());
		trade.setReceiverCity(od.getGoodReceiverCity());
		trade.setReceiverCounty(od.getGoodReceiverCounty());
		trade.setReceiverZip(od.getGoodReceiverPostCode());
		trade.setReceiverPhone(od.getGoodReceiverPhone());
		trade.setReceiverMobile(od.getGoodReceiverMoblie());
		trade.setBuyerMessage(od.getDeliveryRemark());
		trade.setSellerMemo(od.getMerchantRemark());
		trade.setDeliverySupplierId(od.getDeliverySupplierId());
		trade.setMerchantExpressNbr(od.getMerchantExpressNbr());
		trade.setPayServiceType(od.getPayServiceType().longValue());
		trade.setInvoiceContent(od.getInvoiceContent());
		trade.setInvoiceTitle(od.getInvoiceTitle());
		trade.setRealAmount(new BigDecimal(od.getRealAmount()));
		trade.setIsMobileOrder(Long.valueOf(od.getIsMobileOrder()));
		trade.setIsDepositOrder(Long.valueOf(od.getIsDepositOrder()));
		trade.setBusinessType(Long.valueOf(od.getBusinessType()));
		trade.setOrderDeposit(new BigDecimal(od.getOrderDeposit()));
		trade.setWarehouseId(od.getWarehouseId());
		if (od.getDepositPaidTime() != null)
			trade.setDepositPaidTime(DateUtil.parseDateTime(od.getDepositPaidTime()));
		if (od.getOrderPaymentConfirmDate() != null)
			trade.setOrderPayTime(DateUtil.parseDateTime(od.getOrderPaymentConfirmDate()));
		if (od.getDeliveryDate() != null)
			trade.setDeliveryDate(DateUtil.parseDateTime(od.getDeliveryDate()));
		if (od.getReceiveDate() != null)
			trade.setConsignTime(DateUtil.parseDateTime(od.getReceiveDate()));
		if (od.getCollectOnDeliveryAmount() != null) {
			trade.setCollectOnDeliveryAmount(new BigDecimal(od.getCollectOnDeliveryAmount()));
		}
		trade.setOrderCouponDiscount(new BigDecimal(od.getOrderCouponDiscount()));
		trade.setOrderPlatformDiscount(new BigDecimal(od.getOrderPlatformDiscount()));
		//用平台的用户id代替买家昵称
		trade.setBuyerNick(od.getEndUserId().toString());
		trade.setOrderDeposit(new BigDecimal(od.getOrderDeposit()));
		trade.setApplyCancel(Long.valueOf(od.getApplyCancel()));
		trade.setStoreId(od.getStoreId());
		trade.setStoreName(od.getStoreName());
		trade.setExternalStoreId(od.getExternalStoreId());
		trade.setOrderProdType(od.getOrderProdType());
		trade.setPaymentNo(od.getPaymentNo());
		trade.setGatewayName(od.getGatewayName());
		trade.setPaymentTransaction(od.getPaymentTransaction());

		// 明细
		if (oi != null && oi.getOrderItem() != null) {
			List<SeYhdItemDTO> orderList = new ArrayList<SeYhdItemDTO>();
			for (OrderItem item : oi.getOrderItem()) {
				orderList.add(convertOrder(item));
			}
			trade.setItemList(orderList);
		}
		return trade;
	}

	private SeYhdItemDTO convertOrder(OrderItem item) throws Exception {
		SeYhdItemDTO oOrder = new SeYhdItemDTO();

		oOrder.setSubOrderId(item.getId());
		oOrder.setOrderId(item.getOrderId());
		oOrder.setMerchantId(item.getMerchantId());
		oOrder.setProductId(item.getProductId());
		oOrder.setOuterId(item.getOuterId());
		oOrder.setProductCname(item.getProductCName());
		oOrder.setOrderItemNum(item.getOrderItemNum().longValue());
		oOrder.setQty(oOrder.getOrderItemNum());//SeBaseItem
		oOrder.setOrderItemAmount(new BigDecimal(item.getOrderItemAmount()));
		oOrder.setOrderItemPrice(new BigDecimal(item.getOrderItemPrice()));
		oOrder.setOriginalPrice(new BigDecimal(item.getOriginalPrice()));
		oOrder.setPromotionAmount(new BigDecimal(item.getPromotionAmount()));

		oOrder.setCouponAmountMerchant(new BigDecimal(item.getCouponAmountMerchant()));
		oOrder.setCouponPlatformDiscount(new BigDecimal(item.getCouponPlatformDiscount()));
		oOrder.setDeliveryFeeAmount(new BigDecimal(item.getDeliveryFeeAmount()));
		oOrder.setGroupFlag(item.getGroupFlag() == null ? 0L : item.getGroupFlag().longValue());
		oOrder.setSubsidyAmount(new BigDecimal(item.getSubsidyAmount()));
		oOrder.setProductDeposit(new BigDecimal(item.getProductDeposit()));
		oOrder.setDiscountAmount(new BigDecimal(item.getDiscountAmount()));
		if (item.getProcessFinishDate() != null)
			oOrder.setProcessFinishDate(DateUtil.parseDateTime(item.getProcessFinishDate()));
		if (item.getUpdateTime() != null)
			oOrder.setUpdateTime(DateUtil.parseDateTime(item.getUpdateTime()));
		return oOrder;
	}


	/**
	 * dateType:日期类型(1：订单生成日期 create,2：订单付款日期 pay,3：订单发货日期 ship,4：订单收货日期 receive,5：订单更新日期 update)
	 * (时间差为15天)
	 * status: ORDER_WAIT_SEND
	 * @throws IOException
	 */
	@Override
	public AbsResponse<List<?>> catchTrades(Date startTime, Date endDate,
											String status, boolean fullFields) {
		setBase(status, startTime, endDate, fullFields);

		List<SeYhdTradeDTO> trades = new ArrayList<SeYhdTradeDTO>();
		do {
			List<SeYhdTradeDTO> poList = catchTrades(DateType.create);
			if (poList.size() > 0) {
				trades.addAll(poList);
			}
		} while (hasNext());

		AbsResponse<List<?>> rsp = new AbsResponse<>();
		rsp.setData(trades);
		return rsp;
	}


	private List<SeYhdTradeDTO> catchTrades(DateType dateType) {
		List<SeYhdTradeDTO> tradeList = new ArrayList<SeYhdTradeDTO>();

		OrdersGetResponse response = null;
		try{
			response = getOrdersGetResponse(status, pageNo, pageSize,
					startDate, endDate, dateType);
			if (response != null && response.getOrderList() != null) {
				addTradeList(tradeList, response, isFullField);

				if (this.pageNo == 1) {
					int itemTotal_ = response.getTotalCount();;
					setPageInfo(itemTotal_);
				}
			}
		}catch (Exception e) {
			log.error(getRequestString(), e);
		} finally {
			this.pageNo --;
		}

		return tradeList;
	}

	private void addTradeList(List<SeYhdTradeDTO> trades,
							  OrdersGetResponse response, boolean fullFields) {
		if (response.getOrderList() == null) {
			return;
		}
		OrderList ol = response.getOrderList();
		List<Order> orderList = ol.getOrder();
		for (Order o : orderList) {
			if (!fullFields) {
				// 主订单中没有子订单信息，取得订单编号抓取单个订单信息
				AbsResponse<SeYhdTradeDTO> ro = catchOneTrade(o.getOrderCode());
				if (ro.getCode() == 0) {
					trades.add(ro.getData());
				}
			} else {
				trades.add(convertTradeFromQuery(o));
			}
		}
	}

	private SeYhdTradeDTO convertTradeFromQuery(Order o) {
		SeYhdTradeDTO trade = new SeYhdTradeDTO();
		trade.setShopId(this.relatedId);
		trade.setOrderId(o.getOrderId().toString());
		trade.setOrderCode(o.getOrderCode());
		trade.setPlatformOrderStatus(o.getOrderStatus());
		if (o.getOrderCreateTime() != null)
			trade.setOrderCreateTime(DateUtil.parseDateTime(o.getOrderCreateTime()));
		if (o.getUpdateTime() != null)
			trade.setOrderModifyTime(DateUtil.parseDateTime(o.getUpdateTime()));

		trade.setOrderAmount(new BigDecimal(o.getOrderAmount()));
		trade.setProductAmount(new BigDecimal(o.getProductAmount()));
		trade.setFreightFee(new BigDecimal(o.getOrderDeliveryFee()));
		trade.setOrderNeedInvoice(o.getOrderNeedInvoice().longValue());
		return trade;
	}

	private OrdersGetResponse getOrdersGetResponse(String status, int pageNo,
												   int pageSize, Date startDate, Date endDate, DateType create) {
		OrdersGetRequest request = new OrdersGetRequest();
		request.setOrderStatusList(status);
		request.setDateType(create.value);
		request.setCurPage(pageNo);
		request.setPageRows(pageSize);
		request.setStartTime(DateUtil.toDateTimeString(startDate));
		request.setEndTime(DateUtil.toDateTimeString(endDate));
		return this.execute(request, sessionKey);
	}

	@Override
	public AbsResponse updateTradeMemo(String tid, String memo) {
		return null;
	}

	@Override
	public AbsResponse updateTradeStatus(String tid, String status) {
		return null;
	}

	/**
	 *  orderCode 	String 	是 	11111080EB4D 		订单号(订单编码)
	 *  deliverySupplierId 	Long 	是 	1759 		配送商ID(从获取物流信息接口中获取)
	 *  expressNbr 	String 	是 	H4578DFSA78 		运单号(快递编号)
	 */
	public AbsResponse shipNotice(String tid, String tmsCode, String tmsName,
								  String outSid, Double weight, boolean isSplit, String subTids) {
		AbsResponse<Map<String, Object>> lRetBean = new AbsResponse<Map<String, Object>>();
		if (!StringUtils.isNumeric(outSid)) {
			lRetBean.setCode(401);
			lRetBean.setMsg("配送商ID不为数字");
			return lRetBean;
		}

		try {
			LogisticsOrderShipmentsUpdateRequest request = new LogisticsOrderShipmentsUpdateRequest();
			request.setDeliverySupplierId(Long.valueOf(outSid));
			request.setOrderCode(tid);
			request.setExpressNbr(outSid);
			LogisticsOrderShipmentsUpdateResponse response = this.execute(request, sessionKey);

			if (response.getErrorCount() != null && response.getErrorCount() > 0) {
				lRetBean.setResult(500, errorInfo(response.getErrInfoList()));
			} else {
				lRetBean.setResult(0, "OK");
			}
		} catch (Exception e) {
			log.error(tid, e);
			lRetBean.setResult(503, "发生异常:" + e.getMessage());
		}
		return lRetBean;
	}

	@Override
	public AbsResponse getRefund(String refundCode) {
		AbsResponse<SeYhdRefundDTO> retBean = new AbsResponse<SeYhdRefundDTO>();
		if (StringUtils.isEmpty(refundCode)) {
			return retBean.setResult(500, "退款单号不允许为空!");
		}

		try {
			RefundDetailGetRequest request = new RefundDetailGetRequest();
			request.setRefundCode(refundCode);
			RefundDetailGetResponse response = this.execute(request, sessionKey);

			if (response.getErrorCount() != null && response.getErrorCount() > 0) {
				String errorDes = errorInfo(response.getErrInfoList());
				log.error(sessionKey + ":" + errorDes);
				return retBean.setResult(500, errorDes);
			}

			RefundDetail refundDetail = response.getRefundInfoMsg().getRefundDetail();
			RefundItemList refundItemList = response.getRefundInfoMsg().getRefundItemList();
			retBean.setCode(0);
			retBean.setData(convertRefund(refundDetail, refundItemList));
		} catch (Exception e) {
			log.error(refundCode, e);
			retBean.setResult(530, "发生异常:" + e.getMessage());
		}

		return retBean;
	}


	private SeYhdRefundDTO convertRefund(RefundDetail refundDetail,
									  RefundItemList refundItemList) {
		SeYhdRefundDTO refund = new SeYhdRefundDTO();
		refund.setRefundId(refundDetail.getRefundCode());
		refund.setOrderId(refundDetail.getOrderId().toString());
		refund.setOrderCode(refundDetail.getOrderCode());
		refund.setRefundStatus(refundDetail.getRefundStatus().toString());
		refund.setDeliveryFee(new BigDecimal(refundDetail.getDeliveryFee()));
		refund.setProductAmount(new BigDecimal(refundDetail.getProductAmount()));
		refund.setContactName(refundDetail.getContactName());
		refund.setContactPhone(refundDetail.getContactName());
		refund.setSendBackAddress(refundDetail.getSendBackAddress());
		refund.setReasonMsg(refundDetail.getReasonMsg());
		refund.setRefundProblem(refundDetail.getRefundProblem());
		refund.setBuyerNick(refundDetail.getReceiverName());
		refund.setReceiverPhone(refundDetail.getReceiverPhone());
		refund.setReceiverAddress(refundDetail.getReceiverAddress());
		refund.setMerchantMark(refundDetail.getMerchantMark());
		refund.setMerchantRemark(refundDetail.getMerchantRemark());
		refund.setExpressName(refundDetail.getExpressName());
		refund.setExpressNbr(refundDetail.getExpressNbr());
		refund.setEvidencePicUrls(StringUtils.stringCut(refundDetail.getEvidencePicUrls(), 200, ""));

		if (StringUtils.isNotEmpty(refundDetail.getApplyDate())){
			refund.setRefundCreateTime(DateUtil.parseDateTime(refundDetail.getApplyDate()));
		}

		if (StringUtils.isNotEmpty(refundDetail.getApproveDate())){
			refund.setApproveDate(DateUtil.parseDateTime(refundDetail.getApproveDate()));
		}

		if (StringUtils.isNotEmpty(refundDetail.getSendBackDate())){
			refund.setSendBackDate(DateUtil.parseDateTime(refundDetail.getSendBackDate()));
		}

		if (StringUtils.isNotEmpty(refundDetail.getRejectDate())){
			refund.setRejectDate(DateUtil.parseDateTime(refundDetail.getRejectDate()));
		}

		if (StringUtils.isNotEmpty(refundDetail.getCancelTime())){
			refund.setCancelTime(DateUtil.parseDateTime(refundDetail.getCancelTime()));
		}
		List<SeYhdRefundItemDTO> itemList = new ArrayList<SeYhdRefundItemDTO>();
		for (int i = 0; i < refundItemList.getRefundItem().size(); i++) {
			RefundItem refundItemObj = refundItemList.getRefundItem().get(i);
			itemList.add(convertRefundItem(refundItemObj));
		}
		refund.setItemList(itemList);

		return refund;
	}

	private SeYhdRefundItemDTO convertRefundItem(RefundItem i) {
		SeYhdRefundItemDTO refundItem = new SeYhdRefundItemDTO();
		refundItem.setOrderItemId(i.getOrderItemId());
		refundItem.setProductId(i.getProductId().toString());
		refundItem.setProductCname(i.getProductCname());
		refundItem.setOrderItemNum(i.getOrderItemNum());
		refundItem.setOrderItemPrice(new BigDecimal(i.getOrderItemPrice()));
		refundItem.setProductRefundNum(i.getProductRefundNum());
		refundItem.setOriginalRefundNum(i.getOriginalRefundNum());
		return refundItem;
	}

	@Override
	public AbsResponse updateRefundStatus(String tid, String status) {
		return null;
	}

	@Override
	public AbsResponse queryProducts(int fetchType, String productNumId, Date startModified, Date endModified) {
		return null;
	}

	@Override
	public String uploadInventory(String productNumId, String skuNumId,
								  Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified) {
		// 1：全量更新
		return uploadStock(Long.parseLong(productNumId), qtyAvailable.intValue(), 1);
	}


	@Override
	public String uploadInventoryAdd(String productNumId, String skuNumId,
									 Long qtyAvailable, Long qtyOnLocation, Long qtyUnqualified) {
		// 2：增量更新
		return uploadStock(Long.parseLong(productNumId), qtyAvailable.intValue(), 2);
	}

	/**
	 * // 默认为1（1：全量更新，2：增量更新）
	 * @param productNumId
	 * @param qty
	 * @param updateType
	 * @return
	 */
	private String uploadStock(Long productNumId, int qty, int updateType) {
		try {
			ProductStockUpdateRequest request = new ProductStockUpdateRequest();
			request.setProductId(productNumId);
			request.setVirtualStockNum(qty);
			request.setUpdateType(updateType);
			ProductStockUpdateResponse response = this.execute(request, sessionKey);
			// request.setOuterId ( "1");
			// request.setWarehouseId ( 1L);

			if (response.getErrorCount() != null
					&& response.getErrorCount() > 0) {
				String errorDes = errorInfo(response.getErrInfoList());
				log.error(productNumId + "出错：" + errorDes);
				return errorDes;
			}
			if(response.getUpdateStockNum()!= null) {
				return "0," + response.getUpdateStockNum();
			}
		} catch (Exception e) {
			log.error(productNumId, e);
		}
		return "0";
	}


	private static String errorInfo(ErrDetailInfoList errInfo) throws Exception {
		if (errInfo.getErrDetailInfo().size() > 0) {
			ErrDetailInfo info = errInfo.getErrDetailInfo().get(0);
			return info.getErrorCode() + ":" + info.getErrorDes();
		}
		return null;
	}

	public static void main(String[] args) throws Exception {
//		AmAppkey app = new AmAppkey();
////      app.setApiUrl("http://119.97.231.228:2001/app/api/rest/router");
//		app.setApiUrl("http://openapi.yhd.com/app/api/rest/router");
//		app.setAppKey("10210014122900002799");
//		app.setAppSecret("69866822497fa496c92e9ab45816edc0");
//
//		AmAppSubscription subscription = new AmAppSubscription();
//		subscription.setAppUkid(1L);
//		subscription.setSubscriptionBuId(10L);
//		subscription.setApp(app);
//		subscription.setAccessToken("bae42230dc62b6718300ed1efc9456cd");
//		YhdApi api=new YhdApi(subscription);

//		api.catchOneTrade("8005140575636");
//		AbsResponse ro = api.catchOneTrade("8000286735032");
//		if(ro.getErrorCode() == 0 && ro.getData() != null){
//			SeYhdTrade trade = (SeYhdTrade) ro.getData();
//			System.out.println(trade.getOrderCode()+"--" +trade.getOrderCreateTime()+"--" + trade.getOrderStatus());
//		} else {
//			System.out.println("====未找到该订单===");
//		}

		Date startDate = DateUtil.parseDateTime("2016-02-01 00:00:00");
		Date endDate = DateUtil.parseDateTime("2016-04-08 19:00:00");
//
//		api.catchTrades(startDate, endDate, "ORDER_WAIT_SEND", false);
//		api.shipNotice("8005140575636", "", "", "9974205016451", 3.2, false, "");
//		api.getRefund("000075951187");
//		api.fetchRefunds(startDate, endDate, "1000");
	}

	@Override
	public int catchTradeCount(Date startTime, Date endDate, String status) {
		try {
			OrdersGetResponse response = getOrdersGetResponse(status, 1, 1,
					startTime, endDate, DateType.create);
			if (response.getErrorCount() != null && response.getErrorCount() > 0) {
				log.error(relatedId + errorInfo(response.getErrInfoList()));
			}
			return response.getTotalCount();
		} catch (Exception e) {
			log.error(this.relatedId);
		}
		return 0;
	}

	@Override
	public AbsResponse<List<?>> catchTradesPerPage(Date startTime,
												   Date endTime, String status, boolean fullFields) {
		if (status == null) {
			status = "ORDER_WAIT_PAY,ORDER_PAYED,ORDER_WAIT_SEND,ORDER_ON_SENDING,ORDER_RECEIVED,ORDER_FINISH,ORDER_CANCEL";
		}
		setBase(status, startTime, endTime, fullFields);

		List<SeYhdTradeDTO> tradeList = catchTrades(DateType.create);

		AbsResponse<List<?>> rsp = new AbsResponse<>();
		rsp.setData(tradeList);
		return rsp;
	}

	@Override
	public AbsResponse<List<?>> catchTradesIncPerPage(Date startTime, Date endTime,
													  String status, boolean fullFields) {
		if(status == null){
			status = "ORDER_WAIT_PAY,ORDER_PAYED,ORDER_WAIT_SEND,ORDER_ON_SENDING,ORDER_RECEIVED,ORDER_FINISH,ORDER_CANCEL";
		}
		setBase(status, startTime, endTime, fullFields);
		List<SeYhdTradeDTO> tradeList = catchTrades(DateType.update);

		AbsResponse<List<?>> rsp = new AbsResponse<>();
		rsp.setData(tradeList);
		return rsp;
	}

//	@Override
//	public AbsResponse<AmAuthRecord> grantAuth(String authCode) {
//		Map<String, String> param = new HashMap<String, String>();
//		param.put("client_id", this.appKey);
//		param.put("client_secret", this.appSecret);
//		param.put("grant_type", "authorization_code");
//		param.put("code", authCode);
////		param.put("redirect_uri", BaShopAction.feedbackUrl);
//		param.put("scope", "read");
//		param.put("state", shopId.toString());
//		param.put("view", "web");
//
//		return grant(param);
//	}
//
//	@Override
//	public AbsResponse refreshAuth(String refreshToken) {
//		AbsResponse<AmAuthRecord> retObject = new AbsResponse<AmAuthRecord>();
//		return retObject.setResult(500, " 不支持刷新");
//	}

	//{"accessToken":"ffaa64ec30fb5815c02b974a97de14fc","merchantId":138908,"nickName":"杭州界内电子商务有限公司","userCode":"yhd_artka","userId":258423,"userType":1}
	//授权
	private AbsResponse grant(Map<String, String> param) {
//		AbsResponse<AmAuthRecord> retObject = new AbsResponse<AmAuthRecord>();
//
//		String u = "https://member.yhd.com/login/token.do";
//		String lRet = null;
//		String lRet2 = "";
//		try{
//			lRet = WebUtils.doPost(u, param);
//			lRet2=lRet;
//			System.out.println(lRet);
//			retObject.setBody(lRet);
//			lRet = lRet.replace("000,", ",");
//
//			JSONObject obj = JSON.parseObject(lRet);
//
//			AmAuthRecord auth = new AmAuthRecord();
//			auth.setRelatedId(relatedId);
//			auth.setAccessToken(obj.getString("accessToken"));
//			auth.setPlatformUserNick(obj.getString("nickName"));
//			auth.setPlatformUserId(obj.getString("merchantId"));
//
//			if(obj.containsKey("expiresIn")){
//				Long expiresTime = obj.getLong("expiresIn");//"expires_in"到期时间（日期）
//				Date expiresInDate = new Date(expiresTime);//"expires_in"到期时间（日期）
//				long expiresIn = expiresInDate.getTime() - System.currentTimeMillis();
//				auth.setExpiresIn(expiresIn);
//			}
//
//			retObject.setData(auth);
//		}catch (Exception e) {
//			log.error("授权异常:" + relatedId + lRet, e);
//			retObject.setResult(500, "授权异常"+lRet2+"---"+ e.getMessage());
//		}
//		return retObject;
		return null;
	}

	@Override
	public AbsResponse getSku(String productNumId, String skuNumId) {
		return null;
	}

	@Override
	public AbsResponse getTaobaoItemcats(Long parentCid, String cids) {
		return null;
	}

	@Override
	public AbsResponse<List<?>> fetchRefunds(Date startDate, Date endDate,
											 String refundStatus) {
		if (this.pageNo == 1) {
			if (endDate.getTime() - startDate.getTime() < 1800000L) {
				startDate = DateUtil.addHours(startDate, -1);
			}
		}
		setBase(refundStatus, startDate, endDate, false);
		List<SeYhdRefundDTO> tradeList = catchRefunds();

		AbsResponse<List<?>> retBean = new AbsResponse<>();
		retBean.setData(tradeList);
		return retBean;

	}

	private List<SeYhdRefundDTO> catchRefunds() {
		List<SeYhdRefundDTO> refundList = new ArrayList<SeYhdRefundDTO>();
		try {
			RefundGetResponse response = getRefundResponse(this.pageNo, this.pageSize,
					this.startDate, this.endDate);
			if (response != null && response.getRefundList() != null) {
				for (Refund refund : response.getRefundList().getRefund()) {
					AbsResponse responseObject = getRefund(refund.getRefundCode());
					if (responseObject.getCode() == 0) {
						refundList.add((SeYhdRefundDTO) responseObject.getData());
					}
				}

				if (this.pageNo == 1) {
					int itemTotal_ = response.getTotalCount();;
					setPageInfo(itemTotal_);
				}
			}
		}catch (Exception e) {
			log.error(getRequestString(), e);
		} finally {
			pageNo--;
		}

		return refundList;
	}

	private RefundGetResponse getRefundResponse(int pageNo, int pageSize,
												Date startDate, Date endDate) {
		RefundGetRequest request = new RefundGetRequest();
		request.setStartTime(DateUtil.toDateTimeString(startDate));
		request.setEndTime(DateUtil.toDateTimeString(endDate));
		request.setCurPage(pageNo);
		request.setPageRows(pageSize);
		request.setDateType(DateType.refund.value);
		// request.setProductId ( );
		// request.setOrderCode ( "a");
		// request.setRefundStatus ( a);
		RefundGetResponse response = this.execute(request, sessionKey);

		return response;
	}

	private <T extends Response> T execute(Request<T> request, String sessionKey) {
		Date reqDate = new Date();
		T response = null;
		try {
			response = this.yhdClient.excute(request, sessionKey);
		} finally {
			appendReqAResp(request==null?null:request.getApiMethodName(), reqDate, null,
					response==null?null:response.getParams(), response==null?null:response.getBody());
		}

		return response;
	}


	@Override
	public AbsResponse<?> tmcUserPermit(String topics) {
		return null;
	}
	@Override
	public AbsResponse<?> tmcUserCancel(String nick, String userPlatform) {
		return null;
	}
}
