package com.wwwarehouse.xdw.datasync.outer.api.auth;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by dan.han on 2017/6/8.
 */
public class WeChatAuthApi  extends BaseRequestApi implements IAuthApi {
    private static Logger log = LogManager.getLogger(WeChatAuthApi.class);

    private String appKey;
    private String appSecret;

    private enum API_URL {
        AUTH_WEB("https://open.weixin.qq.com/connect/qrconnect"),
        GRANT_AUTH("https://api.weixin.qq.com/sns/oauth2/access_token"),
        REFRESH_AUTH("https://api.weixin.qq.com/sns/oauth2/refresh_token"),
        SNS_AUTH("https://api.weixin.qq.com/sns/auth"),
        USER_INFO("https://api.weixin.qq.com/sns/userinfo"),
        ;

        private String url;

        private API_URL(String url){
            this.url = url;
        }
    }

    public WeChatAuthApi(String appKey, String appSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;

        this.init();
    }

    public WeChatAuthApi(AmAppkeyDTO amAppkey) {
        this.appKey = amAppkey.getAppKey();
        this.appSecret = amAppkey.getAppSecret();

        this.init();
    }

    private void init(){
    }

    /**
     * 拼装web的请求地址
     * https://open.weixin.qq.com/cgi-bin/showdocument?action=dir_list&t=resource/res_list&verify=1&id=open1419316505&token=&lang=zh_CN
     *
     * @param state
     * @return
     */
    @Override
    public AbsResponse<String> buildAuthUrl(String state) {
        Map<String, String> params = new HashMap<>();
        params.put("appid", this.appKey);
        params.put("response_type", "code");
        params.put("scope", "SCOPE");
        params.put("state", state);
        params.put("redirect_uri", ConstantsOuter.AUTH_FEEDBACK_URL);

        String fullUrl = WebUtils.combineQueries(API_URL.AUTH_WEB.url, params);
        fullUrl += "#wechat_redirect";

        AbsResponse<String> resp = new AbsResponse<>();
        resp.setData(fullUrl);
        return resp;
    }

    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode) {
        Map<String, String> param = new HashMap<>();
        param.put("appid", this.appKey);
        param.put("secret", this.appSecret);
        param.put("code", authCode);
        param.put("grant_type", "authorization_code");
        return grant(param);
    }

    private AbsResponse<AmAuthRecordDTO> grant(Map<String, String> params) {
        AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<>();

        try {
            String response = callApi(API_URL.GRANT_AUTH.url, params);
            retObject.setBody(response);
            JSONObject obj = JSONObject.parseObject(response);
            String error = obj.getString("errcode");
            if(StringUtils.isNotEmpty(error)){
                retObject.setResult(Integer.valueOf(error), "授权异常:" + obj.getString("errmsg"));
                return retObject;
            }
            AmAuthRecordDTO auth = convertAuth(obj);
            retObject.setData(auth);
        } catch (Exception e) {
            log.error("授权异常:" + appKey, e);
            retObject.setResult(605001 , "授权异常" + e.getMessage());
        }
        return retObject;
    }

    @Override
    public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken) {
        AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<>();

        Map<String, String> params = new HashMap<>();
        params.put("appid", this.appKey);
        params.put("refresh_token", refreshToken);
        params.put("grant_type", "refresh_token");

        try {
            String response = callApi(API_URL.REFRESH_AUTH.url, params);
            retObject.setBody(response);

            JSONObject obj = JSONObject.parseObject(response);
            String error = obj.getString("errcode");
            if(StringUtils.isNotEmpty(error)){
                retObject.setResult(Integer.valueOf(error), "刷新授权异常:" + obj.getString("errmsg"));
                return retObject;
            }
            AmAuthRecordDTO auth = convertAuth(obj);
            retObject.setData(auth);
        } catch (Exception e) {
            log.error("授权异常:" + appKey, e);
            retObject.setResult(605001 , "授权异常" + e.getMessage());
        }

        return retObject;
    }

    private AmAuthRecordDTO convertAuth(JSONObject jsonObject){
        AmAuthRecordDTO auth = new AmAuthRecordDTO();
        auth.setAccessToken(jsonObject.getString("access_token"));
        auth.setPlatformUserId(jsonObject.getString("openid"));
        Integer expiresIn = jsonObject.getInteger("expires_in");  //access_token接口调用凭证超时时间，单位（秒）
        String unionid = jsonObject.getString("unionid");   //unionid 当且仅当该移动应用已获得该用户的userinfo授权时，才会出现该字段

        auth.setRefreshToken(jsonObject.getString("refresh_token"));
        auth.setPlatformUserNick(unionid);

        Date date = DateUtil.addSeconds(new Date(), expiresIn);
        Long lExpiresIn = date.getTime() / 1000L;
        auth.setExpiresIn(lExpiresIn);

        return auth;
    }

    /**
     * 检验授权凭证（access_token）是否有效
     * @param token
     * @param openid
     * @return
     * @throws IOException
     */
    public boolean authToken(String token, String openid) throws IOException {
        Map<String, String> params = new HashMap<>();
        params.put("access_token", token);
        params.put("openid", openid);

        String response = callApi(API_URL.SNS_AUTH.url, params);
        JSONObject obj = JSON.parseObject(response);
        if(obj.containsKey("errcode")){
            return "0".equals(obj.get("errcode"));
        }
        return false;
    }

    /**
     * 获取用户信息
     * @param token
     * @param openid
     * @return
     * @throws IOException
     */
    public AbsResponse<JSONObject> getUserInfo(String token, String openid) throws IOException {
        AbsResponse<JSONObject> ret = new AbsResponse<>();

        Map<String, String> params = new HashMap<>();
        params.put("access_token", token);
        params.put("openid", openid);
        params.put("lang", "zh_CN");

        try {
            String response = callApi(API_URL.USER_INFO.url, params);
            ret.setBody(response);

            JSONObject obj = JSONObject.parseObject(response);
            ret.setData(obj);

            String error = obj.getString("errcode");
            if (StringUtils.isNotEmpty(error)) {
                String errorMsg = "失败:" + obj.getString("errcode") + "-" + obj.getString("errmsg");
                return ret.setResult(300, errorMsg);
            }
        } catch (Exception e) {
            log.error("异常:" + appKey, e);
            ret.setResult(605001, "异常" + e.getMessage());
        }

        return ret;
    }

    private String callApi(String apiUrl, Map<String, String> params) throws IOException {
        String response = null;
        Date reqDate = new Date();

        try {
            response = WebUtils.doGet(apiUrl, params);
        } catch (Exception e) {
            response = e.getMessage();
            throw e;
        } finally {
            appendReqAResp("WECHATAUTH", reqDate, apiUrl, params, response);
        }
        return response;
    }

}
