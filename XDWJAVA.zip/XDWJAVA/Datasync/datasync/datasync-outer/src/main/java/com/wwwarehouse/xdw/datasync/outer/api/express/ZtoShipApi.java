package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.*;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.*;

//中通快递接口

/**
 * @author linhuaheng 错误代码(暂用,等完善了再定义ErrorCode): 101参数非法 102快递公司返回错误 103网络错误 100
 *         其他
 */
public class ZtoShipApi extends BaseRequestApi implements IShipApi<ExpressOrderZtoInfoDTO> {
    private static Logger log = LogManager.getLogger(ZtoShipApi.class);
    private String apiUrl = "http://testpartner.zto.cn/client/interface.php";// 测试阶段
    // http://testpartner.zto.cn/client/interface.php 正式接口
    // "http://api.zto.cn/TrackBill.aspx";报404错误
    private static final String USER_ID = "ISCS";
    private static final String PASSWORD = "5ED9160FA6";
    private static final String CHARSET = "utf-8";

    private String partner = "test";// 该参数指明合作方代码，由中通速递提供，一般为合作方官方网站域名，请合作方在申请时提供。现在为测试的
    private String pass = "ZTO123";// 测试用的
    private String style = "json";

    private Integer isCod = 0;// 是否货到付款
    private Integer[] cods;// 是否货到付款的集合 先认为1为货到付款

    private String cancelFunc = "order.cancel";// 订单取消
    private String cancleFunc = "bind.cancle";// 订单解绑方法名
    private String markeFunc = "order.marke";// 获取大头笔方法名
    private String expQuery = "mail.trace";// 快递查询

    private static Map<String, String> orderStatus;// 订单状态
    private static Map<String, String> shipStatus;// 运单状态
    private static Map<String, String> errorCode;// 错误代码

    // 无参构造方法
    public ZtoShipApi() {
    }

    // 有参构造方法
    public ZtoShipApi(AmAppSubscriptionDTO sub) {
        this.partner = sub.getPlatformUserId();
        AmAppkeyDTO app = sub.getApp();
        this.apiUrl = app.getApiUrl();
        this.pass = app.getAppSecret();
        this.style = app.getDataFormat();
    }

    // 进行接口的调用
    private String callApi(String func, String dateTime, String content) throws IOException {
        String responseString = null;
        Date reqDate = new Date();
        Map<String, String> params = new TreeMap<String, String>();
        try {
            params.put("content", content);
            params.put("style", style);
            params.put("func", func);
            params.put("partner", partner);
            params.put("datetime", dateTime);
            params.put("verify", CodecUtils.encodeMD5ToHex(partner + dateTime + content + pass));

            responseString = WebUtils.doPost(apiUrl, params);
        } finally {
            appendReqAResp(func, reqDate, null, params, responseString);
        }
        return responseString;
    }

    // 快件追踪接口 (mail.trace)
    // 签收图片接口 (mail.billimg)
    // 快件状态查询 (mail.status)
    // 电子运单号可用数量查询 (mail.counter)
    public String getMail(String outSid, String func) throws IOException {
        String data = "{\"mailno\": \"" + outSid + "\"}";
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(data);
        String response = callApi(func, dateTime, content);
        return response;
    }

    // 批量下单 (order.batch_submit)
    public String batchSubmitOrder(List<ExpressOrderZtoInfoDTO> expressOrderZtoInfoDTO, String func) throws IOException, JSONException {
        ArrayList<JSONObject> orders = new ArrayList<JSONObject>();
        cods = new Integer[1 + expressOrderZtoInfoDTO.size()];
        for (int i = 0; i < expressOrderZtoInfoDTO.size(); i++) {
            ExpressOrderInfoDTO order = expressOrderZtoInfoDTO.get(i);
            orders.add(mosaicJSON((ExpressOrderZtoInfoDTO) (order)));
            cods[i] = isCod;
        }

        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(orders.toString());
        String response = callApi(func, dateTime, content);
        return response;
    }

    // 订单取消 (order.cancel) 需要订单编号暂时无
    public String cancelOrder(String orderId, String remark) throws IOException {
        String data = "{\"id\": \"" + orderId + "\",\"remark\": \"" + remark + "\"}";
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(data);
        String response = callApi(cancelFunc, dateTime, content);
        return response;
    }

    // 订单解绑 (bind.cancle)
    public String cancelBind(String orderId) throws IOException {
        String data = "{\"orderId\": \"" + orderId + "\"}";
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(data);
        String response = callApi(cancleFunc, dateTime, content);
        return response;
    }

    // 获取大头笔 (order.marke)
    public String getMark(String sendcity, String sendaddress, String receivercity, String receiveraddress)
            throws IOException, JSONException {//
        JSONObject json = new JSONObject();
        json.put("sendcity", sendcity);
        json.put("sendaddress", sendaddress);
        json.put("receivercity", receivercity);
        json.put("receiveraddress", receiveraddress);
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(json.toString());
        String response = callApi(markeFunc, dateTime, content);
        return response;
    }

    // json数据的拼接
    private JSONObject mosaicJSON(ExpressOrderZtoInfoDTO expressOrderZtoInfoDTO) throws JSONException {
        JSONObject json = new JSONObject();
        ExpressShiperDetail SendShiperDetail = expressOrderZtoInfoDTO.getSendShiperDetail();
        json.put("id", expressOrderZtoInfoDTO.getOrderId());// 订单号
        // json.put("type", "");//可以为空 订单类型
        // 空字符串=普通订单；bland=线下订单；cod=COD订单；limit=限时物流；ensure=快递保障订单。一般订单都为空
        // json.put("tradeid", "2701843");//交易号，由合作商平台产生。 可以为空
        json.put("mailno", expressOrderZtoInfoDTO.getExpressId());// 运单号，如下单时已有，请提供。
        // 放入快递单号，传回的为新的快递单号
        // json.put("seller", "1023123709");//卖家，最好是卖家ID 可以为空
        // json.put("buyer", "6123928182");//买家，最好是买家ID 可以为空

        // 发件人信息
        JSONObject senderJson = new JSONObject();
        // senderJson.put("id", "130520142010");//发件人在合作商平台中的ID号
        senderJson.put("name", SendShiperDetail.getName());// 发件人姓名
        senderJson.put("company", SendShiperDetail.getCity());// 发件公司名 可以为空
        senderJson.put("mobile", SendShiperDetail.getMobile());// 发件人手机号码 与phone二选一
        // senderJson.put("phone", "021-87654321");//发件人电话号码 与mobile二选一
        // senderJson.put("area", "310118");//可以为空
        // 发件人区域ID，如提供区域ID，请参考中通速递提供的国家行政区划代码。
        senderJson.put("city", SendShiperDetail.getCity());// 发件人所在城市，必须逐级指定，用英文半角逗号分隔，目前至少需要指定到区县级
        senderJson.put("address", SendShiperDetail.getAddress());// 发件人路名门牌等地址信息
        senderJson.put("zipcode", SendShiperDetail.getPostcode());// 发件人邮政编码 可以为空
        senderJson.put("email", SendShiperDetail.getEmail());// 发件人电子邮件 可以为空
        // senderJson.put("im", "1924656234");//发件人即时通讯工具 可以为空
        senderJson.put("starttime", "");// 取件起始时间 可以为空 暂时先写死
        senderJson.put("endtime", "");// 取件截至时间 可以为空 暂时先写死
        json.put("sender", senderJson);

        // 发件人信息
        JSONObject reeciverJson = new JSONObject();
        ExpressShiperDetail receiverShiperDetail = expressOrderZtoInfoDTO.getReceiverShiperDetail();
        // reeciverJson.put("id", "130520142097");//收件人在合作商平台中的ID号 可以为空
        reeciverJson.put("name", receiverShiperDetail.getName());// 发件人姓名
        reeciverJson.put("company", receiverShiperDetail.getCompany());// 发件公司名 可以为空
        reeciverJson.put("mobile", receiverShiperDetail.getMobile());// 收件人手机号码
        // 与phone二选一
        // reeciverJson.put("phone", "010-22226789");//收件人电话号码 与mobile二选一
        // reeciverJson.put("area", "501022");//可以为空
        // 收件人区域ID，如提供区域ID，请参考中通速递提供的国家行政区划代码。
        reeciverJson.put("city", receiverShiperDetail.getCity());// 收件人所在城市，必须逐级指定，用英文半角逗号分隔，目前至少需要指定到区县级
        reeciverJson.put("address", receiverShiperDetail.getAddress());// 收件人路名门牌等地址信息
        reeciverJson.put("zipcode", receiverShiperDetail.getPostcode());// 收件人邮政编码 可以为空
        reeciverJson.put("email", receiverShiperDetail.getEmail());// 收件人电子邮件 可以为空
        // reeciverJson.put("im", "yangyijia-abc");//收件人即时通讯工具 可以为空
        json.put("receiver", reeciverJson);

        // 商品信息
        ArrayList<JSONObject> item = new ArrayList<JSONObject>();
        if (null != expressOrderZtoInfoDTO.getexpressOrderItemInfoDTOs()) {
            for (int i = 0; i < expressOrderZtoInfoDTO.getexpressOrderItemInfoDTOs().size(); i++) {
                ExpressOrderItemInfoDTO expressOrderItemInfoDTO = expressOrderZtoInfoDTO.getexpressOrderItemInfoDTOs().get(i);
                JSONObject jsonProduct = new JSONObject();
                if (StringUtils.isNotEmpty(expressOrderItemInfoDTO.getId())) {
                    jsonProduct.put("id", expressOrderItemInfoDTO.getId());// 货品ID 可以为空
                }
                if (StringUtils.isNotEmpty(expressOrderItemInfoDTO.getName())) {
                    jsonProduct.put("name", expressOrderItemInfoDTO.getName());// 货品名称
                    // 可以为空
                }
                if (StringUtils.isNotEmpty(expressOrderItemInfoDTO.getCategory())) {
                    jsonProduct.put("category", expressOrderItemInfoDTO.getCategory());// 商品分类
                    // 可以为空
                }
                jsonProduct.put("material", "");// 商品材质 可以为空 暂时先写死
                jsonProduct.put("size", "");// 可以为空 暂时先写死
                // 大小（长,宽,高）(单位：厘米),用半角的逗号来分隔长宽高
                jsonProduct.put("weight", expressOrderItemInfoDTO.getWeight());// 重量（单位：千克)
                // 可以为空
                if (StringUtils.isNotEmpty(expressOrderItemInfoDTO.getUnitprice())) {
                    jsonProduct.put("unitprice", expressOrderItemInfoDTO.getUnitprice());// 单价可以为空
                }
                jsonProduct.put("url", "");// 商品链接 可以为空 暂时先写死
                jsonProduct.put("quantity", "");// 货品数量 可以为空 暂时定死为空
                if (StringUtils.isNotEmpty(expressOrderItemInfoDTO.getRemark())) {
                    jsonProduct.put("remark", expressOrderItemInfoDTO.getRemark());// 货品备注可以为空
                }
                item.add(jsonProduct);
            }
            json.put("items", item);
        }

        // 其他信息
        if (expressOrderZtoInfoDTO.getWeight() >= 0) {
            json.put("weight", expressOrderZtoInfoDTO.getWeight());// 订单总重量 （千克） 可以为空
        }
        if (StringUtils.isNotEmpty(expressOrderZtoInfoDTO.getSize())) {
            json.put("size", expressOrderZtoInfoDTO.getSize());// 订单包裹大小（厘米）, 用半角的逗号来分隔长宽高 可以为空
        }
        // json.put("quantity", "2");//订单包裹内货物总数量 可以为空
        json.put("price", expressOrderZtoInfoDTO.getPayment());// 订单包裹中商品总价值 可以为空
        // json.put("freight", "10.00");//运输费 可以为空
        // json.put("premium", "0.50");//保险费 可以为空
        // json.put("pack_charges", "1.00");//保险费 可以为空
        // json.put("other_charges", "0.00");//其他费用 可以为空
        // json.put("order_sum", "0.00");//订单总金额 可以为空
        // json.put("collect_moneytype", "CNY");//到达收取币种 可以为空
        json.put("collect_sum", expressOrderZtoInfoDTO.getCollectionValue());// 可以为空
        // 到达收取金额，一般代收货款或者到付件才需指定
        json.put("remark", expressOrderZtoInfoDTO.getRemark());// 订单备注 可以为空
        if (expressOrderZtoInfoDTO.getCollectionValue() > 0) {
            isCod = 1;
        }
        return json;
    }

    // 将物流信息转化为网仓的状态节点
    // @Override
    public List<SeShipmentTrack> convert(String data, String state, String city, String county) throws Exception {
        List<SeShipmentTrack> retList = new ArrayList<SeShipmentTrack>();
        if ((data == null) || (data.length() == 0)) {
            return retList;
        }
        if (!data.startsWith("<?xml")) {
            data = "<?xml version='1.0' encoding='utf-8'?>" + data;
        }
        Element ele = XmlUtils.getRootElementFromString(data);
        Element ordersEle = XmlUtils.getChildElement(ele, "track");
        List<Element> stepNodeList = XmlUtils.getChildElements(ordersEle, "detail");

        int i = 0;
        for (Element node : stepNodeList) {
            i++;
            Element stepNode = node;
            String acceptDate = XmlUtils.getChildElementValue(stepNode, "date");
            String acceptTime = XmlUtils.getChildElementValue(stepNode, "time");
            String process = XmlUtils.getChildElementValue(stepNode, "Process");

            SeShipmentTrack track = new SeShipmentTrack();
            track.setDateUpdated(new Date());
            track.setOperationDate(DateUtil.parseDateTime(acceptDate + " " + acceptTime + ":00"));
            track.setOperationRemark(process);
            String[] remarks = process.split(" ");
            if (remarks.length > 1) {
                track.setOperationAddress(remarks[1]);
            }
            track.setFlowStatus(getFlowStatus(track.getOperationAddress(), process, state, city, county));

            retList.add(track);
        }
        return retList;
    }

    // 将物流信息转化为网仓的状态节点
    public List<SeShipmentTrack> convertTest(String data, String state, String city, String county) throws Exception {
        List<SeShipmentTrack> retList = new ArrayList<SeShipmentTrack>();
        if ((data == null) || (data.length() == 0)) {
            return retList;
        }
        JSONObject jObj = JSON.parseObject(data);
        JSONArray traces = jObj.getJSONArray("traces");
        for (int i = 0; i <= traces.size(); i++) {
            JSONObject oneObj = traces.getJSONObject(i);
            System.out.println(oneObj);
        }
        return retList;
    }

    public Long getFlowStatus(String address, String remark, String state, String city, String county) {
        Long status = 0L;
        if (indexOf(remark, "快件到达", "到达") > -1 && indexOf(address, getExpState(state)) > -1) {
            status = 555L;
        } else if (indexOf(remark, "快件到达", "到达", "发往") > -1 && indexOf(address, getExpCity(city)) > -1) {
            status = 560L;
        } else if (indexOf(remark, "发往", "上一站") > -1 && indexOf(address, getExpCity(city)) > -1) {
            status = 565L;
        } else if (indexOf(remark, "派件中", "派送扫描", "开始派送", "到达") > -1 && indexOf(address, getExpCity(county)) > -1) {
            status = 565L;
        } else if (indexOf(remark, "派件中") > -1) {
            status = 565L;
        } else if (indexOf(remark, "签收", "已送达") > -1) {
            status = 600L;
        }
        return status;
    }

    public static String getExpState(String state) {
        if ((state == null) || (state.length() == 0)) {
            return "";
        }
        return state.replace("省", "").replace("壮族自治区", "").replace("自治区", "").replace("市", "");
    }

    public static String getExpCity(String city) {
        if ((city == null) || (city.length() == 0)) {
            return "";
        }
        return city.replace("市", "").replace("县", "").replace("区", "");
    }

    public static int indexOf(String source, String... args) {
        if (source == null) {
            return -2;
        }
        for (String arg : args) {
            int x = source.indexOf(arg);
            if (x > -1) {
                return x;
            }
        }
        return -1;
    }

    public static void main(String[] args) throws Exception {
        ZtoShipApi api = new ZtoShipApi();
        api.cancelExpressOrder("aa", "aa");

        ExpressOrderZtoInfoDTO expressOrderZtoInfoDTO = new ExpressOrderZtoInfoDTO();
        ExpressShiperDetail sendShiperDetail = expressOrderZtoInfoDTO.getSendShiperDetail();
        ExpressShiperDetail receiverShiperDetail = expressOrderZtoInfoDTO.getReceiverShiperDetail();
        expressOrderZtoInfoDTO.setOrderId("130520142013300");
        expressOrderZtoInfoDTO.setExpressId("378624663788");
        sendShiperDetail.setName("李琳");
        sendShiperDetail.setMobile("13912345678");
        sendShiperDetail.setCity("13912345678");
        sendShiperDetail.setAddress("华新镇华志路123号");
        sendShiperDetail.setPostcode("610012");
        sendShiperDetail.setEmail("ll@abc.com");
        sendShiperDetail.setCompany("新南电子商务有限公司");
        expressOrderZtoInfoDTO.setSendShiperDetail(sendShiperDetail);

        receiverShiperDetail.setName("杨逸嘉");
        receiverShiperDetail.setMobile("13687654321");
        receiverShiperDetail.setCity("四川省,成都市,武侯区");
        receiverShiperDetail.setAddress("育德路497号");
        receiverShiperDetail.setPostcode("610012");
        receiverShiperDetail.setEmail("yyj@abc.com");
        receiverShiperDetail.setCompany("逸嘉实业有限公司");
        expressOrderZtoInfoDTO.setReceiverShiperDetail(receiverShiperDetail);

        expressOrderZtoInfoDTO.setPartner("test");
        expressOrderZtoInfoDTO.setId("xfs101100111011");
        expressOrderZtoInfoDTO.setTypeId("");
        expressOrderZtoInfoDTO.setOrderType("1");
        expressOrderZtoInfoDTO.setRemark("请勿摔货");

        System.out.println("一个--获取快递单号：" + api.generateExpressInfo(expressOrderZtoInfoDTO));

        List<ExpressOrderZtoInfoDTO> expressOrderZtoInfoDTOS = new ArrayList<ExpressOrderZtoInfoDTO>();
        // System.out.println("零个--获取快递单号：" + api.getTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));
        // System.out.println("零个--取消订单：" + api.cancelTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));
        expressOrderZtoInfoDTOS.add(expressOrderZtoInfoDTO);
        // System.out.println(api.submitOrder(shipOrders));
        // System.out.println("一个--获取快递单号：" + api.getTmsOrderCode(shipOrders));
        // System.out.println("一个--取消订单：" + api.cancelTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));
        ExpressOrderZtoInfoDTO expressOrderZtoInfoDTO1 = new ExpressOrderZtoInfoDTO();
        // shipOrder2.setOrderId("130520142013301");
        // shipOrder2.setDeliveryId("378624663788");
        // shipOrder2.setSenderName("李琳");
        // shipOrder2.setSenderMobile("13912345678");
        // shipOrder2.setSenderCity("13912345678");
        // shipOrder2.setSenderAddress("华新镇华志路123号");
        // shipOrder2.setReceiverName("杨逸嘉");
        // shipOrder2.setReceiverMobile("13687654321");
        // shipOrder2.setReceiverCity("四川省,成都市,武侯区");
        // shipOrder2.setReceiverAddress("育德路497号");
        expressOrderZtoInfoDTOS.add(expressOrderZtoInfoDTO1);

        AmAppSubscriptionDTO sub = new AmAppSubscriptionDTO();
        sub.setPlatformUserId("test");
        AmAppkeyDTO app = new AmAppkeyDTO();
        app.setApiUrl("http://testpartner.zto.cn/client/interface.php");
        app.setDataFormat("json");
        app.setAppSecret("ZTO123");
        sub.setApp(app);
        ZtoShipApi zt = new ZtoShipApi(sub);

        LogisticsInformation logisticsInformation = zt.trackLogisticsInfo("zz");
        System.out.println(logisticsInformation);
        System.out.println("一个--获取快递单号：" + zt.generateExpressInfo(expressOrderZtoInfoDTO));
        // System.out.println("两个--获取快递单号：" + zt.getTmsOrderCode(shipOrders));
        // System.out.println("两个--取消订单：" + api.cancelTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));
        // shipOrder.setOrderId(130520142013236L);
        // shipOrders.add(shipOrder);
        // System.out.println("三个--获取快递单号：" + api.getTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));
        // System.out.println("三个--取消订单：" + api.cancelTmsOrderCode("aa", "bb",
        // "cc", "dd", shipOrders));

        // List<SeShipmentTrackDTO> list = api.convertTest(data2, "海南省", "海口市",
        // null);
        // for (SeShipmentTrackDTO track : list) {
        // System.out.println(track.getFlowStatus() + "---"
        // + track.getOperationDate() + "--"
        // + track.getOperationRemark());
        // }
    }

    static {
        orderStatus = new HashMap<String, String>();
        orderStatus.put("await", "待处理");// 订单已录入系统，等待处理
        orderStatus.put("refuse", "拒绝订单");// 由于某种原因不接受此订单，会注明原因
        orderStatus.put("accept", "接单");// 接受此订单，正在安排取件
        orderStatus.put("getfail", "揽收失败");// 由于某种原因此订单揽件失败，会注明原因
        orderStatus.put("got", "已揽收");// 快件已揽收，正在安排转运，会在注明运单号码
        orderStatus.put("running", "转运中");// 快件转运中，会注明运单号码
        orderStatus.put("deliver", "派件中	");// 快件派送中
        orderStatus.put("signfail", "签收异常");// 由于某种原因此订单签收异常，会注明原因及运单号码，可能还有拒签客户姓名。同时会延期再次安排派送，但超过3日没有变更为signed，此订单即永久为签收失败
        orderStatus.put("signed", "已送达");// 快件已揽收，会注明运单号码及签收人姓名
        orderStatus.put("goback", "退回中");// 快件派送不成功，快件退回发件网点。
        orderStatus.put("backed", "已退签");// 快件退回发件网点并已签收。
        orderStatus.put("relay", "转单/重发");// 由于某种原因，快件需要重新发送，或者需要转其他物流公司协助运送（特殊业务中使用）
        orderStatus.put("cancel", "订单取消");// 由客户发起的取消操作

        shipStatus = new HashMap<String, String>();
        shipStatus.put("got", "已揽收");// 快件已从客户那里成功揽收
        shipStatus.put("in", "到达站点");// 快件进入站点
        shipStatus.put("out", "站点发出");// 快件从站点发出
        shipStatus.put("pack", "站点集包");// 快件在站点进行集包操作
        shipStatus.put("unpack", "大包拆卸");// 快件在站点进行大包拆卸操作
        shipStatus.put("dispatch", "派件中");// 快件正在派件
        shipStatus.put("signed", "	已签收");// 快件已被客户签收

        errorCode = new HashMap<String, String>();
        errorCode.put("s00", "未知错误");
        errorCode.put("s01", "服务器异常");
        errorCode.put("s02", "非法的IP来源");
        errorCode.put("s03", "无效的指令操作");
        errorCode.put("s04", "非法的数据签名");
        errorCode.put("s05", "缺少完整的参数");
        errorCode.put("s06", "非法的数据格式");
        errorCode.put("s07", "数据内容不符合要求");
        errorCode.put("s08", "非法的账户信息");
        errorCode.put("s30", "图形验证码不正确");
        errorCode.put("s31", "短信验证码不正确");
        errorCode.put("s50", "没有指定有效的查询条件");
        errorCode.put("s51", "可用单号不足");
        errorCode.put("s52", "未从数据源中获取到有效的数据内容");
        errorCode.put("s53", "无权操作指定的数据");
        errorCode.put("s60", "提交的数据与服务器中的数据一致，忽略更新");
        errorCode.put("s70", "数据保存失败");
        errorCode.put("s90", "重复操作");
        errorCode.put("e01", "缺少业务所必须的数据内容");
        errorCode.put("e02", "业务所需要的数据内容不符合要求");

    }

    // 解析返回的值
    private ExpressOrderZtoInfoDTO analysis(JSONObject oneObj) throws JSONException {
        ExpressOrderZtoInfoDTO ttoc = new ExpressOrderZtoInfoDTO();
        String id = oneObj.getString("id");// 返回的值 暂时没用
        String siteCode = oneObj.getString("siteCode");// 网店编码
        Boolean isUpdate = oneObj.getBoolean("isUpdate");// 是否更新
        String billCode = oneObj.getString("billCode");// 网点名称
        String orderId = oneObj.getString("orderid");// 提示信息
        String siteName = oneObj.getString("siteName"); //网店名称
        String message = oneObj.getString("message"); //提示信息
        ttoc.setOrderId(orderId);// 订单号
        ttoc.setExpressId(billCode);// 单号
        ttoc.setUpdate(isUpdate);// 服务产品 暂时不知道怎么传入 先定死
        ttoc.setSiteCode(siteCode);//  网店编码
        ttoc.setSiteName(siteName);// 快递单号
        ttoc.setMessage(message);
        return ttoc;
    }


    // 新增或修改订单(order.submit)
    // 获取单个订单
    @Override
    public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
        ExpressOrderInfoDTO retBean = new ExpressOrderInfoDTO();
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(mosaicJSON((ExpressOrderZtoInfoDTO) expressOrderInfo).toString());
        String response = callApi("order.submit", dateTime, content);
        JSONObject jsonObj = JSON.parseObject(response);
        if ("true".equals(jsonObj.getString("result"))) {
            JSONObject oneObj = jsonObj.getJSONObject("keys");
            ExpressOrderZtoInfoDTO ttos = analysis(oneObj);
            return ttos;
        } else {
            throw new IscsException("系统错误，获取快递单失败");
        }
    }

    // 批量获取快递单号
    @Override
    public List<ExpressOrderZtoInfoDTO> generateExpressInfos(List<ExpressOrderZtoInfoDTO> expressOrderZtoInfoDTO) throws Exception {
        Boolean flag = false;// 用于判断是否有返回成功的数据
        String msg = "";// 存放错误信息
        List<ExpressOrderZtoInfoDTO> orderCodelist = new ArrayList<ExpressOrderZtoInfoDTO>();
        if (expressOrderZtoInfoDTO.isEmpty()) {
            throw new IscsException("传入参数为空");
        } else {
            String response = batchSubmitOrder(expressOrderZtoInfoDTO, "order.batch_submit");
            JSONObject jsonObj = JSON.parseObject(response);
            JSONArray obj = jsonObj.getJSONArray("keys");

            for (int i = 0; i < obj.size(); i++) {
                JSONObject oneObj = obj.getJSONObject(i);
                if ("true".equals(oneObj.getString("result"))) {
                    isCod = cods[i];
                    ExpressOrderZtoInfoDTO ttos = analysis(oneObj);
                    orderCodelist.add(ttos);
                    flag = true;
                } else {
//					msg += oneObj.toString();// 错误的存信息的拼接
                    throw new IscsException("返回数据失败" + oneObj.toString());// 错误
                }
            }
        }
        return orderCodelist;
    }

    @Override
    public void uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception {
        throw new IscsException(101, "不支持上传重量给快递公司");
    }

    @Override
    public void cancelExpressOrder(String orderId, String outSid) throws Exception {
        AbsResponse retBean = new AbsResponse();
        if (orderId.isEmpty()) {
            throw new IscsException("未传入订单号");
        } else {
            String data = "{\"id\": \"" + orderId;
            String dateTime = DateUtil.toDateTimeString(new Date());
            String content = CodecUtils.encodeBase64(data);
            String response = callApi(cancelFunc, dateTime, content);
            JSONObject jsonObj = JSON.parseObject(response);
            if ("false".equals(jsonObj.getString("result"))) {
                throw new Exception("取消订单失败");
            }
        }
    }

    @Override
    public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
        LogisticsInformation logisticsInformation = new LogisticsInformation();
        if (StringUtils.isEmpty(outSid)) {
            throw new Exception("传入的运单号为空");
        }
        String data = "{\"mailno\": \"" + outSid + "\"}";
        String dateTime = DateUtil.toDateTimeString(new Date());
        String content = CodecUtils.encodeBase64(data);
        String response = callApi(expQuery, dateTime, content);
        if (response.matches("[sSeE](.*)")) {
//            retBean.setResult(100, response);// 记录返回的错误信息
            throw new IscsException("未找到物流信息");
        } else {
//            retBean.setCode(0);// 记录正确信息
//            retBean.setData(response);// 记录正确信息
//            JSONObject jsonObj = JSON.parseObject(response);
//            logisticsInformation.setExpressCompany(jsonObj.getString("expressCompany"));
//            logisticsInformation.setOutSid(jsonObj.getString("outSid"));
//            logisticsInformation.setStatus(jsonObj.getLong("status"));
//            logisticsInformation.setStatusDesc(jsonObj.getString("statusDesc"));
//            logisticsInformation.setInfomationDetails(JSONObject.parseArray(jsonObj.get("infomationDetails").toString(), LogisticsInfomationDetail.class));

//            logisticsInformation = (LogisticsInformation) JSON.parse(response);
            logisticsInformation = JSON.parseObject(response, LogisticsInformation.class);
        }
        return logisticsInformation;
    }
}