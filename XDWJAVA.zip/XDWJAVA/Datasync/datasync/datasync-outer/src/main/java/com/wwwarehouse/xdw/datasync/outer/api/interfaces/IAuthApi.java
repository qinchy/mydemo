package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;

public interface IAuthApi extends IRecordAble {

	/**
	 * 构建授权地址url
	 * @param state
	 * @return
	 */
	public AbsResponse<String> buildAuthUrl(String state);

	/**
	 * 通过上一步得到的code换取access_token
	 * @param authCode
	 * @return
	 */
	public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode);


	/**
	 * 刷新授权，通过上一步得到的refresh_token刷新授权时间
	 * @param refreshToken
	 * @return
	 */
	public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken);
	
}