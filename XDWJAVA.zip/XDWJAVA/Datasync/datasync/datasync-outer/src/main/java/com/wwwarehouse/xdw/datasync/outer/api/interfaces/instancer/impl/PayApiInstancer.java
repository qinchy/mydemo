package com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl;


import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IPayApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.pay.AlipayApi;
import com.wwwarehouse.xdw.datasync.outer.api.pay.UnionpayApi;
import com.wwwarehouse.xdw.datasync.outer.api.pay.WechatApi;

/**
 * 支付实例化工具类
 * 
 * @author Huangzhigang
 * 
 */
public class PayApiInstancer {

	public static class AlipayInstancer extends ApiInstancer {
		@Override
		public IPayApi getPayApi(AmAppSubscriptionDTO subscription) {
			return new AlipayApi(subscription);
		}
	}

	public static class UnionInstancer extends ApiInstancer {
		@Override
		public IPayApi getPayApi(AmAppSubscriptionDTO subscription) {
			return new UnionpayApi(subscription);
		}
	}

	public static class WeinxinInstancer extends ApiInstancer {
		@Override
		public IPayApi getPayApi(AmAppSubscriptionDTO subscription) {
			return new WechatApi(subscription);
		}
	}
}
