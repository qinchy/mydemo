package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;


import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.ShipApiInstancer;

/**
 * <pre>
 * 快递公司编码
 * 快递编码格式：10xx=1000~1099
 * </pre>
 *
 * @author huangzhigang
 *
 */
public enum BaExpressCode {
	YTO(1001L, "圆通速递", "YTO", null/*new ShipApiInstancer.YtoInstancer()*/),
	//	JD(1002L, "京东", new ShipApiInstancer.JdInstancer()),
//	STO(1004L, "申通快递", new ShipApiInstancer.StoInstancer()),
//	ZTO(1006L, "中通快递", new ShipApiInstancer.ZtoInstancer()),
//	HTKY(1008L, "百世汇通"),
	YUNDA(1010, "韵达快递"),
	EMS(1012L, "EMS"),
	TTKDEX(1014L, "天天快递"),
	QFKD(1016L, "全峰快递"),
	POSTB(1018L, "邮政国内小包"),
	HOAU(1020L, "天地华宇"),
	DBL(1022L, "德邦物流"),
	CPAM(1024L,"CHINA POST AIR MAIL"),
	EYB(1026L, "E邮宝"),
	FEDEX(1028L, "联邦快递"),
	FAST(1030L, "快捷快递"),
	GTO(1034L, "国通快递"),
	QYKD(1036L, "全一快递"),
	SEKD(1038L, "速尔快递"),
	SF(1040L, "顺丰速运"),
	UC(1042L, "优速快递"),
	ZJS(1044L, "宅急送"),
	UPS(1048L, "美国联合包裹"),
	DHL(1050, "DHL"),
	CAINIAO(1052L, "菜鸟网络"),
	EXER(1054L, "赛澳递速递"),
	T4PX(1056L, "递四方"),
	XBWL(1058L, "新邦物流");

	private long id;
	private String expName;
	private String expCode;
	private ApiInstancer apiInstancer;

	private BaExpressCode(long id, String expName) {
		this.id = id;
		this.expName = expName;
	}

	private BaExpressCode(long id, String expName, String expCode, ApiInstancer apiInstancer) {
		this.id = id;
		this.expName = expName;
		this.expCode = expCode;
		this.apiInstancer = apiInstancer;
	}

	private BaExpressCode(long id, String expName, ApiInstancer apiInstancer) {
		this.id = id;
		this.expName = expName;
		this.apiInstancer = apiInstancer;
	}

	public boolean equalsByName(String apiName) {
		return this.name().equals(apiName);
	}

	public boolean equalsById(Long platformId) {
		return platformId != null && this.id == platformId.longValue();
	}

	public long getId() {
		return this.id;
	}

	public String getExpName() {
		return this.expName;
	}

	public ApiInstancer getApiInstancer() {
		return apiInstancer;
	}

	public String getExpCode() {
		return this.expCode;
	}

	public static BaExpressCode getBaExpressCode(long id) {
		for (BaExpressCode item : values()) {
			if (item.id == id)
				return item;
		}

		return null;
	}
}
