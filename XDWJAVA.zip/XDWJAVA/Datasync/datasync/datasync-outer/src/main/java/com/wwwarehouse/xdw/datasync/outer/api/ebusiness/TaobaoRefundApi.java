package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.taobao.api.ApiException;
import com.taobao.api.domain.Refund;
import com.taobao.api.request.RefundGetRequest;
import com.taobao.api.request.RefundsReceiveGetRequest;
import com.taobao.api.response.RefundGetResponse;
import com.taobao.api.response.RefundsReceiveGetResponse;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoRefundDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRefundApi;
import com.wwwarehouse.xdw.datasync.outer.api.ots.OtsApiClient;
import org.apache.commons.lang.math.NumberUtils;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by jianjun.guan on 2017/6/8 0008.
 */
public class TaobaoRefundApi extends TaobaoTradeApi implements IRefundApi{
    public TaobaoRefundApi() {

    }
    /**
     * 按单号查询退款单
     *
     * @param refundId
     * @return
     */
    @Override
    public AbsResponse<SeTaobaoRefundDTO> getRefund(String refundId) {
        AbsResponse<SeTaobaoRefundDTO> retObject = new AbsResponse<>();
        RefundGetResponse response = null;
        try {
            if (isEnableOts) {
                Map<String, String> params = new HashMap<>();
                params.put("fields", REFUND_FIELDS);
                params.put("refundId", refundId);

                this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/refundAction";
                response = this.executeOts("catchOneRefund", params, RefundGetResponse.class);
            } else {
                RefundGetRequest req = new RefundGetRequest();
                req.setFields(REFUND_FIELDS);
                req.setRefundId(Long.valueOf(refundId));
                response = this.execute(req);
            }
            if (response == null) {
                retObject.setResult(500, "发生异常");
            } else if (response.getRefund() == null && response.getMsg() != null) {
                retObject.setResult(500, getErrorMsg(response));
            } else {
                retObject.setData(this.convertTaobaoRefund(response.getRefund()));
            }
            //retObject.setData(this.convertTaobaoRefund(response.getRefund()));
        } catch (ApiException e) {
            retObject.setResult(500, "发生异常");
            log.error(refundId, e);
        } catch (Exception e) {
            retObject.setResult(500, "发生异常");
            log.error(refundId, e);
        }

        return retObject;
    }

    /**
     * 查询退款单
     *
     * @param startDate
     * @param endDate
     * @param status
     * @return
     */
    @Override
    public AbsResponse fetchRefunds(Date startDate, Date endDate, String status) {
        setBase(status, startDate, endDate, true);

        AbsResponse retObject = new AbsResponse();
        List<SeTaobaoRefundDTO> refundList = new ArrayList<>();
        RefundsReceiveGetResponse response = null;
        do {
            try {
                if (isEnableOts) {
                    response = getOtsRefundsResponse(pageNo, pageSize, startDate, endDate, status);
                } else {
                    response = getRefundsResponse(pageNo, pageSize, startDate, endDate, status);
                }
                if (response != null && response.getRefunds() != null) {
                    for (Refund pRefund : response.getRefunds()) {
                        refundList.add(this.convertTaobaoRefund(pRefund));
                    }
                    if (pageNo == 1) {
                        itemTotal = response.getTotalResults().intValue();// 总条数
                        setPageInfo(itemTotal);// 总页数
                    }
                }
                pageNo--;

            } catch (Exception e) {
                // TODO: handle exception
                log.error(e);
            }
        } while (hasNext());

        retObject.setData(refundList);
        return retObject;
    }

    /**
     * 更新退款单状态
     *
     * @param tid
     * @param status
     * @return
     */
    @Override
    public AbsResponse updateRefundStatus(String tid, String status) {
        return null;
    }

    private SeTaobaoRefundDTO convertTaobaoRefund(Refund pRefund) throws Exception {
        SeTaobaoRefundDTO taobaoRefund = new SeTaobaoRefundDTO();
        taobaoRefund.setAddress(pRefund.getAddress());
        taobaoRefund.setAdvanceStatus(pRefund.getAdvanceStatus());
        taobaoRefund.setAlipayNo(pRefund.getAlipayNo());
        taobaoRefund.setAttribute(pRefund.getAttribute());
        taobaoRefund.setBuyerNick(pRefund.getBuyerNick());
        taobaoRefund.setCompanyName(pRefund.getCompanyName());
        taobaoRefund.setRefundCreateTime(pRefund.getCreated());
        taobaoRefund.setCsStatus(pRefund.getCsStatus());
        taobaoRefund.setDownTime(new Date());
        taobaoRefund.setGoodReturnTime(pRefund.getGoodReturnTime());
        taobaoRefund.setGoodStatus(pRefund.getGoodStatus());
        taobaoRefund.setHasGoodReturn(pRefund.getHasGoodReturn() == null || !pRefund.getHasGoodReturn() ? 0L : 1L);
        taobaoRefund.setModified(pRefund.getModified());// 淘宝上的修改时间
        taobaoRefund.setModifyTime(new Date());
        taobaoRefund.setNum(pRefund.getNum());
        taobaoRefund.setNumIid(pRefund.getNumIid());
        taobaoRefund.setSubOrderId(pRefund.getOid().toString());
        taobaoRefund.setOperationContraint(pRefund.getOperationContraint());
        taobaoRefund.setOrderStatus(pRefund.getOrderStatus());
        taobaoRefund.setRefundFee(new BigDecimal(pRefund.getRefundFee()));
        if (pRefund.getRefundId() != null) {
            taobaoRefund.setRefundId(pRefund.getRefundId().toString());
        }
        taobaoRefund.setRefundPhase(pRefund.getRefundPhase());
        taobaoRefund.setRefundVersion(pRefund.getRefundVersion());
        taobaoRefund.setSellerNick(pRefund.getSellerNick());
        taobaoRefund.setShippingType(pRefund.getShippingType());
        taobaoRefund.setSid(pRefund.getSid());
        taobaoRefund.setSku(pRefund.getSku());
        if (StringUtils.isNotEmpty(pRefund.getSplitSellerFee())) {
            taobaoRefund.setSplitSellerFee(new BigDecimal(pRefund.getSplitSellerFee()));
        }
        if (StringUtils.isNotEmpty(pRefund.getSplitTaobaoFee())) {
            taobaoRefund.setSplitTaobaoFee(new BigDecimal(pRefund.getSplitTaobaoFee()));
        }
        taobaoRefund.setStatus(pRefund.getStatus());
        if (pRefund.getTid() != null) {
            taobaoRefund.setOrderId(pRefund.getTid().toString());
        }
        if (pRefund.getRefundRemindTimeout() != null) {
            taobaoRefund.setExistTimeout(pRefund.getRefundRemindTimeout().getExistTimeout() ? 1L : 0L);
            taobaoRefund.setRemindType(pRefund.getRefundRemindTimeout().getRemindType());
            taobaoRefund.setTimeout(pRefund.getRefundRemindTimeout().getTimeout());
        }
        taobaoRefund.setTitle(pRefund.getTitle());
        if (StringUtils.isNotEmpty(pRefund.getTotalFee())) {
            taobaoRefund.setTotalFee(new BigDecimal(pRefund.getTotalFee()));
        }

        return taobaoRefund;
    }

    /**
     * 退款列表Response对象
     *
     * @param pageNo
     * @param pageSize
     * @param startModified
     * @param endModified
     * @param status
     * @return
     */
    private RefundsReceiveGetResponse getOtsRefundsResponse(int pageNo,
                                                            int pageSize, Date startModified, Date endModified, String status) throws Exception {
        Map<String, String> params = new HashMap<>();
        params.put("page", pageNo + "");
        params.put("pageSize", String.valueOf(pageSize));
        params.put("startDate", DateUtil.toDateTimeString(startModified));
        params.put("endDate", DateUtil.toDateTimeString(endModified));
        params.put("status", status);
        params.put("fields", REFUND_FIELDS);
        params.put("type", REFUND_TYPE);

        this.apiUrl = OtsApiClient.otsTaobaoHost + "/taobao/refundAction";
        return this.executeOts("getRefundsResponse", params, RefundsReceiveGetResponse.class);
    }
    /**
     * 退款列表Response对象
     *
     * @param pageNo
     * @param pageSize
     * @param startModified
     * @param endModified
     * @param status
     * @return
     */
    private RefundsReceiveGetResponse getRefundsResponse(int pageNo,
                                                         int pageSize, Date startModified, Date endModified, String status) throws ApiException {
        RefundsReceiveGetRequest req = new RefundsReceiveGetRequest();
        req.setStatus(status);
        req.setStartModified(startModified);
        req.setEndModified(endModified);
        req.setPageSize((long) pageSize); // 设置每页返回条数 默认每页40条 最大100
        req.setPageNo((long) pageNo); // 每回第一页
        req.setFields(REFUND_FIELDS);
        req.setType(REFUND_TYPE);

        return this.execute(req);
    }

}
