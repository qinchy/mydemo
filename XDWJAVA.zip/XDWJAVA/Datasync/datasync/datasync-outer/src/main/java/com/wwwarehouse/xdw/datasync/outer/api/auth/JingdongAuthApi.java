package com.wwwarehouse.xdw.datasync.outer.api.auth;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

public class JingdongAuthApi extends BaseRequestApi implements IAuthApi {
	private static Logger log = LogManager.getLogger(JingdongAuthApi.class);
	private String appKey;
	private String appSecret;

	public JingdongAuthApi(AmAppkeyDTO amAppkey) {
		this.appKey = amAppkey.getAppKey();
		this.appSecret = amAppkey.getAppSecret();
	}

	@Override
	public AbsResponse<String> buildAuthUrl(String state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("scope", "read");
		param.put("grant_type", "authorization_code");
		param.put("code", authCode);
		param.put("client_id", this.appKey);
		param.put("client_secret", this.appSecret);
		//param.put("redirect_uri", BaShopAction.feedbackUrl);
		param.put("state", null);

		return grant(param);
	}

	@Override
	public AbsResponse<AmAuthRecordDTO> refreshAuth(String refreshToken) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("grant_type", "refresh_token");
		param.put("scope", "read");
		param.put("view", "web");
		param.put("state", null);
		param.put("client_id", this.appKey);
		param.put("client_secret", this.appSecret);
		param.put("refresh_token", refreshToken);
		return grant(param);
	}

	private AbsResponse<AmAuthRecordDTO> grant(Map<String, String> param) {
		AbsResponse<AmAuthRecordDTO> retObject = new AbsResponse<AmAuthRecordDTO>();

		String u = "https://oauth.jd.com/oauth/token";
		try{
			String ret = WebUtils.doPost(u, param);
			retObject.setBody(ret);

			JSONObject obj = JSON.parseObject(ret);

			AmAuthRecordDTO auth = new AmAuthRecordDTO();
//			auth.setRelatedId(shopId);
			auth.setExpiresIn(obj.getLong("expires_in"));
			auth.setReExpiresIn(obj.getLong("re_expires_in"));
			auth.setR1ExpiresIn(obj.getLong("r1_expires_in"));
			auth.setR2ExpiresIn(obj.getLong("r2_expires_in"));
			auth.setW1ExpiresIn(obj.getLong("w1_expires_in"));
			auth.setW2ExpiresIn(obj.getLong("w2_expires_in"));
			auth.setAccessToken(obj.getString("access_token"));
			auth.setRefreshToken(obj.getString("refresh_token"));
			auth.setTokenType(obj.getString("token_type"));

			String nick = obj.getString("user_nick");
			auth.setPlatformUserNick(nick);

			String uid = obj.getString("uid");
			auth.setPlatformUserId(uid);

			retObject.setData(auth);
		}catch (Exception e) {
//			log.error("授权异常:" + shopId, e);
			retObject.setResult(500, "授权异常" + e.getMessage());
		}
		return retObject;
	}

}
