package com.wwwarehouse.xdw.datasync.outer.api.map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IMapApi;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Created by chengwei on 2017/6/14 14:14.
 */
public class IbsMapApi extends BaseRequestApi implements IMapApi{
	private static Logger log = LogManager.getLogger(IbsMapApi.class);
	private static final String CHILDREN = "1";//是否按照层级展示子POI数据
	private static final String EXTENSIONS = "all";//返回结果控制   此项默认返回基本地址信息；取值为all返回地址信息、附近POI、道路以及道路交叉口信息。
//	private static final String key = "84239aa87021b8d2a5d99b4108b7802c";

	private String appId;

	public IbsMapApi(AmAppSubscriptionDTO appSuber) {
		AmAppkeyDTO amAppkey = appSuber.getApp();
		this.appId = "84239aa87021b8d2a5d99b4108b7802c";
	}

	public IbsMapApi() {
		this.appId = "84239aa87021b8d2a5d99b4108b7802c";
	}

	/**
	 * 地理编码
	 *
	 * @param address 结构化地址信息(规则遵循：国家、省份、城市、城镇、乡村、街道、门牌号码、屋邨、大厦，如：北京市朝阳区阜通东大街6号。)
	 * @param city    指定查询的城市(无，会进行全国范围内搜索)
	 * @return location 坐标点(经度，纬度)
	 */
	@Override
	public AbsResponse<Object> geocodeGeo(String address, String city) {
		AbsResponse<Object> abs = new AbsResponse<>();
		try {
			String apiUrl = "http://restapi.amap.com/v3/geocode/geo";

			Map<String, String> params = new TreeMap<>();
			params.put("key", appId);
			params.put("address", address);
			params.put("city", city);

			String response = callApi(apiUrl, params);
			JSONObject geocodeGeo = JSON.parseObject(response);
			String status = geocodeGeo.getString("status");
			if ("1".equals(status)) {
				abs.setData(geocodeGeo);
			}

		} catch (Exception e) {
			log.error("高德地图地理编码:address:" + address + ",city" + city, e);
		}
		return abs;
	}

	/**
	 * 逆地理编码
	 *
	 * @param location 传入内容规则：经度在前，纬度在后，经纬度间以“,”分割
	 * @return
	 */
	@Override
	public AbsResponse<Object> geocodeRegeo(String location) {
		AbsResponse<Object> abs = new AbsResponse<>();
		try {
			String apiUrl = "http://restapi.amap.com/v3/geocode/regeo";

			Map<String, String> params = new TreeMap<>();
			params.put("key", appId);
			params.put("location", location);
			params.put("extensions", EXTENSIONS);
			params.put("roadlevel", "0");

			String response = callApi(apiUrl, params);
			JSONObject geocodeRegeo = JSON.parseObject(response);
			String status = geocodeRegeo.getString("status");
			if ("1".equals(status)) {
				abs.setData(geocodeRegeo);
			}

		} catch (Exception e) {
			log.error("高德地图逆地理编码:location:" + location, e);
		}
		return abs;
	}

	/**
	 * 驾车路径规划
	 *
	 * @param origin      出发点(经度在前，纬度在后)
	 * @param destination 目的地(经度在前，纬度在后)
	 * @param strategy    驾车选择策略 0，会考虑路况，选择时间最短的策略
	 *                    1，费用优先（不走收费路段的最快道路）
	 *                    2，距离优先
	 *                    3，不走快速路
	 *                    4，躲避拥堵
	 *                    5，多策略（同时使用速度优先、费用优先、距离优先三个策略计算路径）。
	 *                    其中必须说明，就算使用三个策略算路，会根据路况不固定的返回一~三条路径规划信息。
	 *                    6，不走高速
	 *                    7，不走高速且避免收费
	 *                    8，躲避收费和拥堵
	 *                    9，不走高速且躲避收费和拥堵
	 * @return
	 */
	@Override
	public AbsResponse<Object> directionDriving(String origin, String destination, String strategy) {
		AbsResponse<Object> abs = new AbsResponse<>();
		try {
			String apiUrl = "http://restapi.amap.com/v3/direction/driving";

			Map<String, String> params = new TreeMap<>();
			params.put("key", appId);
			params.put("origin", origin);
			params.put("destination", destination);
			params.put("strategy", strategy);

			String response = callApi(apiUrl, params);
			JSONObject directionDriving = JSON.parseObject(response);
			String status = directionDriving.getString("status");
			if ("1".equals(status)) {
				abs.setData(directionDriving);
			}

		} catch (Exception e) {
			log.error("高德地图驾车路径规划:origin:" + origin + ",destination" + destination + ",strategy" + strategy, e);
		}
		return abs;
	}


	/**
	 * 步行路径规划
	 *
	 * @param origin      origin 出发点(经度在前，纬度在后)
	 * @param destination destination 目的地(经度在前，纬度在后)
	 * @return
	 */
	@Override
	public AbsResponse<Object> directionWalking(String origin, String destination) {
		AbsResponse<Object> abs = new AbsResponse<>();
		try {
			String apiUrl = "http://restapi.amap.com/v3/direction/walking";

			Map<String, String> params = new TreeMap<>();
			params.put("key", appId);
			params.put("origin", origin);
			params.put("destination", destination);

			String response = callApi(apiUrl, params);
			JSONObject directionWalking = JSON.parseObject(response);
			String status = directionWalking.getString("status");
			if ("1".equals(status)) {
				abs.setData(directionWalking);
			}

		} catch (Exception e) {
			log.error("高德地图驾车路径规划:origin:" + origin + ",destination" + destination, e);
		}
		return abs;
	}

	/**
	 * 关键字搜索
	 *
	 * @param city     查询城市(无 全国范围内搜索)
	 * @param keywords 查询关键字
	 * @return
	 */
	@Override
	public Map<String, Double> getLocation(String city, String keywords) {
		Map<String, Double> location = new HashMap<>();
		try {
			String apiUrl = "http://restapi.amap.com/v3/place/text";

			Map<String, String> params = new TreeMap<>();
			params.put("key", appId);
			params.put("keywords", keywords);//查询关键字
			params.put("city", city);
			params.put("children", CHILDREN);
			params.put("offset", "20");//每页记录数据
			params.put("page", "1");//当前页数
			params.put("extensions", EXTENSIONS);

			String response = callApi(apiUrl, params);
			JSONObject json = JSON.parseObject(response);
			List<String> lists = getMapPointByJson(json);
			if (lists.size() > 0) {
				double[] xy = getDistanceToStr(lists);
				location.put("lng", xy[0]);//经度
				location.put("lat", xy[1]);//纬度
			}

		} catch (Exception e) {
			log.error("高德地图定位:city:" + city + ",keywords" + keywords, e);
		}

		return location;
	}

	/**
	 * 根据欧式距离算出最小的坐标
	 */
	private double[] getDistanceToStr(List<String> lists) {
		double[][] point = new double[lists.size()][2];
		for (int i = 0; i < lists.size(); i++) {
			point[i][0] = NumberUtils.toDouble(lists.get(i).toString().split(",")[0]);
			point[i][1] = NumberUtils.toDouble(lists.get(i).toString().split(",")[1]);
		}
		double x = 0, y = 0;
		for (int i = 0; i < point.length; i++) {
			x += point[i][0];
			y += point[i][1];
		}
		double[] zhixin = {x / point.length, y / point.length};// 平均值求质心
		double maxDistance = 99999;
		int minimumIndex = 0;
		for (int i = 0; i < point.length; i++) {// 质心到所有点的距离
			double distanc = norm2(zhixin, point[i]);
			if (distanc < maxDistance) {
				maxDistance = distanc;
				minimumIndex = i;
			}
		}
		return point[minimumIndex];
	}

	/**
	 * 求欧式距离
	 */
	private double norm2(double[] arrA, double[] arrB) {
		double sum = 0.0;
		for (int i = 0; i < arrA.length; i++) {
			sum += Math.pow(arrA[i] - arrB[i], 2);
		}
		return Math.sqrt(sum);
	}

	/**
	 * 解析json获取所有的点
	 */
	private List<String> getMapPointByJson(JSONObject jsonObject) {
		List<String> list = new ArrayList();

		if ("OK".equals(jsonObject.get("info").toString())) {
			/*
			 * JSONObject JSONObjecturlja = (JSONObject) JSONObjecturl
			 * .get("route");
			 */
			JSONArray pois = (JSONArray) jsonObject.get("pois");
			Iterator<Object> it = pois.iterator();

			while (it.hasNext()) {
				JSONObject ob = (JSONObject) it.next();
				String location = (String) ob.get("location");
				list.add(location);
			}
		}
		return list;
	}

	private String callApi(String url, Map<String, String> params) throws Exception {
		String responseString = null;
		Date reqDate = new Date();
		try {
			responseString = WebUtils.doGet(url, params, this.charset);
		} finally {
			appendReqAResp(url, reqDate, null, params, responseString);
		}
		return responseString;
	}

	public static void main(String[] args) {
		IbsMapApi api = new IbsMapApi();
		System.out.println(api.geocodeRegeo("120.382613,30.317101"));
//		Map<String, Double> map = api.getLocation("安庆市", "杨湾镇");
//		System.out.println(api.directionWalking("120.382613,30.317101", "120.374394,30.309838"));
	}
}
