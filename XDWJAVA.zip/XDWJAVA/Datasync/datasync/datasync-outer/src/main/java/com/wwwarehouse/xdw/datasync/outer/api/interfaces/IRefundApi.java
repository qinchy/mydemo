package com.wwwarehouse.xdw.datasync.outer.api.interfaces;



import com.wwwarehouse.commons.utils.AbsResponse;

import java.util.Date;
import java.util.List;

public interface IRefundApi extends com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRecordAble {

	/**
	 * 按单号查询退款单
	 * 
	 * @param refundId
	 * @return
	 */
	public AbsResponse getRefund(String refundId);

	/**
	 * 查询退款单
	 * 
	 * @param startDate
	 * @param endDate
	 * @param refundStatus
	 * @return
	 */
	public AbsResponse<List<?>> fetchRefunds(Date startDate, Date endDate,
											 String refundStatus);

	/**
	 * 更新退款单状态
	 * 
	 * @param tid
	 * @param status
	 * @return
	 */
	public AbsResponse updateRefundStatus(String tid, String status);

	/**
	 * 订单下载时判断是否还有下一页
	 * @return
	 */
	public boolean hasNext();
}
