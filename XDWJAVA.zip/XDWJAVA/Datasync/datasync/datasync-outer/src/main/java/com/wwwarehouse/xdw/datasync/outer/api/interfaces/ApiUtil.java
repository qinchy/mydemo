package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.MapPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.PayPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.SmsPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.ShipApiInstancer;

/**
 * 接口工厂类
 * <p>
 * Created by xuchun on 16/3/12.
 */
public class ApiUtil {

	private ApiUtil() {
	}

	/**
	 * 获取订单Api
	 *
	 * @param subscription
	 * @return
	 */
	public static ITradeApi getTradeApi(AmAppSubscriptionDTO subscription) {
		Long platformId = subscription.getPlatformId();
		BaPlatform platform = BaPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getTradeApi(subscription);
		} else {
			return null;
		}
	}


	/**
	 * 获取短信Api
	 *
	 * @param subscription
	 * @return ISmsApi
	 */
	public static ISmsApi getSmsApi(AmAppSubscriptionDTO subscription) {
		SmsPlatform platform = SmsPlatform.getPlatform(subscription.getPlatformId());

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getSmsApi(subscription);
		} else {
			return null;
		}
	}

	public static /*<T> IBaseTradeService<T>*/String getTradeService(Long platformId) {
		BaPlatform platform = BaPlatform.getPlatform(platformId);
		ApiInstancer apiInstancer = platform.getApiInstancer();

		String serviceName = null;
		if (apiInstancer != null) {
			serviceName = apiInstancer.getTradeService();
		} else {
			serviceName = "seOriginTradeService";
		}
		return serviceName;
//		if (serviceName != null) {
//			return null;
////            return (IBaseTradeService<? extends SeBaseTrade<? extends SeBaseItem>, ? extends SeBaseItem>)
////					SpringUtil.getBean(serviceName);
//		} else {
//			return null;
//		}
	}

	public static /*<T> IBaseRefundService<T>*/ String getRefundService(Long platformId) {
		BaPlatform platform = BaPlatform.getPlatform(platformId);
		ApiInstancer apiInstancer = platform.getApiInstancer();

		String serviceName = null;
		if (apiInstancer != null) {
			serviceName = apiInstancer.getRefundService();
		} else {
			serviceName = "seOriginRefundService";
		}
        return serviceName;
//		if (serviceName != null) {
//			return null;
////			return (IBaseRefundService<? extends SeBaseRefund>) SpringCon
////					.getBean(serviceName);
//		} else {
//			return null;
//		}
	}

	/**
	 * 获取快递处理接口类
	 *
	 * @param appSuber 对象中要包含有platformId的信息
	 * @return
	 */
	public static IShipApi getShipApi(AmAppSubscriptionDTO appSuber) {

		return ShipApiInstancer.getInstance().getShipApi(appSuber);
	}

	public static void main(String[] args) {
		ApiUtil.getShipApi(new AmAppSubscriptionDTO());
	}

	/**
	 * 获取AuthApi
	 *
	 * @param amAppkey
	 * @return
	 */
	public static IAuthApi getAuthApi(AmAppkeyDTO amAppkey) {
		Long platformId = amAppkey.getPlatformId();
		BaPlatform platform = BaPlatform.getPlatform(platformId);
		ApiInstancer apiInstancer = platform.getApiInstancer();

		if (apiInstancer != null) {
			return apiInstancer.getAuthApi(amAppkey);
		}

		PayPlatform payPlatform = PayPlatform.getPlatform(platformId);
		ApiInstancer payApiInstancer = payPlatform.getApiInstancer();
		if (payApiInstancer != null) {
			return payApiInstancer.getAuthApi(amAppkey);
		}

		return null;
	}

	/**
	 * 创建退款接口实例
	 *
	 * @param appSuber
	 * @param appSuber
	 * @return IRefundApi
	 */
	public static IRefundApi getRefundApi(AmAppSubscriptionDTO appSuber) {
		Long platformId = appSuber.getPlatformId();
		BaPlatform platform = BaPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getRefundApi(appSuber);
		} else {
			return null;
		}
	}

	/**
	 * 获取AuthApi
	 *
	 * @param appSuber
	 * @return
	 */
	public static IProductApi getProductApi(AmAppSubscriptionDTO appSuber) {
		Long platformId = appSuber.getPlatformId();
		BaPlatform platform = BaPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getProductApi(appSuber);
		} else {
			return null;
		}
	}

	/**
	 * 获取IShopApi
	 *
	 * @param appSuber
	 * @return IShopApi
	 */
	public static IShopApi getShopApi(AmAppSubscriptionDTO appSuber) {
		Long platformId = appSuber.getPlatformId();
		BaPlatform platform = BaPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getShopApi(appSuber);
		} else {
			return null;
		}
	}

	/**
	 * 获取支付APi
	 *
	 * @param appSuber
	 * @return IShopApi
	 */
	public static IPayApi getPayApi(AmAppSubscriptionDTO appSuber) {
		Long platformId = appSuber.getPlatformId();
		PayPlatform platform = PayPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getPayApi(appSuber);
		} else {
			return null;
		}
	}

	/**
	 * 获取地图APi
	 *
	 * @param appSuber
	 * @return IShopApi
	 */
	public static IMapApi getMapApi(AmAppSubscriptionDTO appSuber) {
		Long platformId = appSuber.getPlatformId();
		MapPlatform platform = MapPlatform.getPlatform(platformId);

		ApiInstancer apiInstancer = platform.getApiInstancer();
		if (apiInstancer != null) {
			return apiInstancer.getMapApi(appSuber);
		} else {
			return null;
		}
	}


}
