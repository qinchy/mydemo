package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;
/**
 * 快递的物流状态
 * @author haichao.wang
 *
 */
public enum ExpressStatus {

	START(550L, "揽收"),
	TRANSPORT(551L, "运输"), 
	DELIVERY(552L, "派送"),
	SIGNED(553L, "签收");

	private long code;
	private String desc;

	private ExpressStatus(long code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public long getCode() {
		return this.code;
	}

	public String getDesc() {
		return this.desc;
	}

	public static ExpressStatus getBaExpressStatus(long code) {
		for (ExpressStatus item : values()) {
			if (item.code == code)
				return item;
		}

		return null;
	}

}
