package com.wwwarehouse.xdw.datasync.outer.api.sms;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;

import java.io.IOException;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yinsheng.wang on 2017/6/12.
 */
public class YpnetSmsApi extends BaseRequestApi implements com.wwwarehouse.xdw.datasync.outer.api.interfaces.ISmsApi {
    //	private static Logger log = LogManager.getLogger(YpnetSmsApi.class);
    private static String BASE_URI = "http://yunpian.com";
    private static String VERSION = "v1";
    private static String ENCODING = "UTF-8";
    private static String URI_GET_USER_INFO = BASE_URI + "/" + VERSION + "/user/get.json";
    private static String URI_SEND_SMS = BASE_URI + "/" + VERSION + "/sms/send.json";
    private static String URI_TPL_SEND_SMS = BASE_URI + "/" + VERSION + "/sms/tpl_send.json";
    private String apikey;
    private String password;
    private String sourceMobileNo;

    public YpnetSmsApi(AmAppSubscriptionDTO suber) {
        //AmAppkeyDTO amAppkey = suber.getApp();
        this.apikey = suber.getAccessToken();
    }
    // 单发短信
    @Override
    public AbsResponse<String> sendSms(String mobile, String content) throws Exception {
        AbsResponse<String> absResponse = new AbsResponse<String>();
        String result = sendSmsYp(this.apikey, content, mobile);
        JSONObject jsonObject = JSON.parseObject(result);
        Integer code = jsonObject.getInteger("code");
        String msg = jsonObject.getString("msg");
        if ((code != null) && (code.intValue() == 0)) {
            JSONObject jResult = jsonObject.getJSONObject("result");
            absResponse.setResult(0, null, msg + ":" + ("1," + (jResult == null ? "" : jResult.get("sid"))), null);
            return absResponse;
        }
        absResponse.setCode(code == null ? 111 : code.intValue());
        absResponse.setMsg(msg);
        return absResponse;
    }

    // 群发短信
    @Override
    public AbsResponse<String> sendSms(String[] mobiles, String content)
            throws Exception {
        AbsResponse<String> absResponse = new AbsResponse<String>();
        absResponse.setCode(1);
        absResponse.setMsg("网柜每条短信内容都不一样，不能批量发送");
        return absResponse;
    }

    public static String sendSmsYp(String apikey, String text, String mobile) throws IOException {
        try {
            Map<String, String> params = new HashMap<String, String>();
            params.put("apikey", apikey);
            params.put("text", text);
            params.put("mobile", mobile);
            String result = WebUtils.doPost(URI_SEND_SMS, params);
            return result;
        } catch (SocketException e) {
            return "{\"code\":100,\"msg\":\"网络异常\"}";
        } catch (Exception e) {
        }
        return "{\"code\":100,\"msg\":\"接口异常\"}";
    }


//	public static void main(String[] args) throws Exception {
//		YpnetSmsApi api=new YpnetSmsApi((AmAppSubscription)null);
//		AbsResponse<String> absResponse=api.sendSms("18329031977", "我是天才");
//		System.out.println(absResponse.getCode());
//		System.out.println(absResponse.getMsg());
//	}

}
