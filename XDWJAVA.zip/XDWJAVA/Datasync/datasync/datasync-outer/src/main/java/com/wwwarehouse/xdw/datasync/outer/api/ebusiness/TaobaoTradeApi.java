package com.wwwarehouse.xdw.datasync.outer.api.ebusiness;

import com.taobao.api.domain.*;
import com.taobao.api.internal.util.RequestCheckUtils;
import com.taobao.api.request.*;
import com.taobao.api.response.*;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoItemDTO;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoTradeDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import org.apache.commons.lang.math.NumberUtils;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by jianjun.guan on 2017/6/8 0008.
 */
public class TaobaoTradeApi extends TaobaoShopApi implements ITradeApi{

    public TaobaoTradeApi() {

    }

    /**
     * 查询订单
     *
     * @param tid
     * @return
     */
    @Override
    public AbsResponse<?> catchOneTrade(String tid) {
        AbsResponse<SeTaobaoTradeDTO> rsp = new AbsResponse<SeTaobaoTradeDTO>();
        if (StringUtils.isEmpty(tid)) {
            return rsp.setResult(500, "订单号不允许为空!");
        }

        TradeFullinfoGetResponse response = null;
        try {
            if (isEnableOts) {
                Map<String, String> params = new HashMap<>();
                params.put("tid", tid);
                params.put("fields", TRADE_FULLINFO_FIELDS);
                response = this.executeOts("catchOneTrade", params, TradeFullinfoGetResponse.class);
            } else {
                TradeFullinfoGetRequest req = new TradeFullinfoGetRequest();
                req.setFields(TRADE_FULLINFO_FIELDS);
                req.setTid(Long.valueOf(tid));
                response = this.execute(req);
            }
            if (response != null && response.getTrade() != null) {
//                rsp.setCode(0); // 成功
                rsp.setData(convertTaobaoTrade(response.getTrade()));
            } else {
                rsp.setResult(530, getErrorMsg(response));
            }
        } catch (Exception e) {
            log.error(tid, e);
            rsp.setResult(530, "发生异常:" + e.getMessage());
        }
        return rsp;
    }

    /**
     * 查询订单
     * @param startDate
     * @param endDate
     * @param status
     * @param isFullField
     * @return
     */
    @Override
    public AbsResponse<List<?>> catchTrades(Date startDate, Date endDate,
                                            String status, boolean isFullField) {
        setBase(status, startDate, endDate, isFullField);

        List<SeTaobaoTradeDTO> tradeList = new ArrayList<SeTaobaoTradeDTO>();
        do {
            List<SeTaobaoTradeDTO> poList = catchTradesLimitDate();
            if (poList.size() > 0) {
                tradeList.addAll(poList);
            }
        } while (hasNext());


        AbsResponse<List<?>> retBean = new AbsResponse<>();
        retBean.setData(tradeList);
        return  retBean;
    }

    /**
     * 每次查询一页数据 查询订单
     * @param startDate
     * @param endDate
     * @param status
     * @param isFullField
     * @return
     */
    @Override
    public AbsResponse<List<?>> catchTradesPerPage(Date startDate,
                                                   Date endDate, String status, boolean isFullField) {
        setBase(status, startDate, endDate, isFullField);
        List<SeTaobaoTradeDTO> tradeList = catchTradesLimitDate();

        AbsResponse<List<?>> retBean = new AbsResponse<>();
        retBean.setData(tradeList);
        return  retBean;
    }

    /**
     * 增量每次查询一页数据 查询订单
     * @param startDate
     * @param endDate
     * @param status
     * @param isFullField
     * @return
     */
    @Override
    public AbsResponse<List<?>> catchTradesIncPerPage(Date startDate,
                                                      Date endDate, String status, boolean isFullField) {
        setBase(status, startDate, endDate, isFullField);

        List<SeTaobaoTradeDTO> tradeList = catchTradesIncLimit();

        AbsResponse<List<?>> retBean = new AbsResponse<>();
        retBean.setData(tradeList);
        return  retBean;
    }


    /**
     * 订单下载时判断是否还有下一页
     *
     * @return
     */
    public boolean hasNext() {
        return (this.pageNo >= 2) && (this.pageNo <= this.pageTotal);
    }
    /**
     * 抓取平台订单数量
     * @param startTime
     * @param endTime
     * @param status
     * @return
     */
    @Override
    public int catchTradeCount(Date startTime, Date endTime, String status) {
        int cnt = 0;
        try {
            TradesSoldGetResponse resq = getTradesSoldResponse(1, 1, startTime,
                    endTime, status, false);
            cnt = resq.getTotalResults() == null ? 0 : resq.getTotalResults()
                    .intValue();
        } catch (Exception e) {
            log.error(relatedId, e);
        }
        return cnt;
    }
    /**
     * 更新订单备注
     *
     * @param tid
     * @param memo
     * @return
     */
    @Override
    public AbsResponse updateTradeMemo(String tid, String memo) {
        return null;
    }

    /**
     * 更新订单状态
     *
     * @param tid
     * @param status
     * @return
     */
    @Override
    public AbsResponse updateTradeStatus(String tid, String status) {
        return null;
    }

    /**
     * 线上发货通知
     *
     * @param tid
     *            平台订单号
     * @param tmsCode
     *            平台运输商编码
     * @param tmsName
     *            平台运输商名称
     * @param outSid
     *            快递单号
     * @param weight
     *            包裹重量
     * @param subTids
     *            备注
     * @return
     */
    @Override
    public AbsResponse shipNotice(String tid, String tmsCode, String tmsName,
                                  String outSid, Double weight, boolean isSplit, String subTids) {

        String[] sec = subTids.split("&");
        subTids = sec[0];
        String isCod = null;
        String isResend = null;
        for (String v : sec) {
            if (v.contains("is_cod=")) {
                isCod = v.replace("is_cod=", "");
            }
            if (v.contains("is_resend=")) {
                isResend = v.replace("is_resend=", "");
            }
        }

        AbsResponse<String> lRetBean = new AbsResponse<>();
        if (!StringUtils.isNumeric(tid)) {
            return lRetBean.setResult(400, "来源单号格式不正确");
        }
        if (StringUtils.isEmpty(outSid)) {
            return lRetBean.setResult(401, "快递单号为空");
        }
        if (StringUtils.isEmpty(tmsCode) || StringUtils.isEmpty(tmsName)) {
            return lRetBean.setResult(402, "快递公司为空");
        }
        if ("1".equals(isResend)) {
            return reShipNotice(tid, outSid, tmsCode, tmsName, isSplit, subTids);
        } else if ("1".equals(isCod)) {
            return shipNoticeOnline(tid, outSid, tmsCode, tmsName, isSplit, subTids);
        } else {
            return shipNoticeOffline(tid, outSid, tmsCode, tmsName, isSplit, subTids);
        }
    }


    /**
     * 为已授权的用户开通消息服务
     * topics ："taobao_trade_TradeCreate,taobao_refund_RefundCreate";
     * @return
     */
    @Override
    public AbsResponse<String> tmcUserPermit(String topics) {
        AbsResponse<String> abs = new AbsResponse<String>();

        try {
            TmcUserPermitRequest req = new TmcUserPermitRequest();
            if(!StringUtils.isEmpty(topics)){
                req.setTopics(topics);
            }
            TmcUserPermitResponse response = this.executeOtsOne(req);
            Boolean isSuccess = response.getIsSuccess();
            if(isSuccess == null || !isSuccess){
                log.error("开通服务失败",getErrorMsg(response));
                abs.setResult(500,getErrorMsg(response));
            }
        } catch (Exception e) {
            log.error("开通服务失败",e);
            abs.setResult(503, e.getMessage());
        }
        return abs;
    }


    /**
     * 取消用户的消息服务
     * @param nick
     * @param userPlatform  tbUIC
     * @return
     */
    @Override
    public AbsResponse<String> tmcUserCancel(String nick, String userPlatform) {

        AbsResponse<String> abs = new AbsResponse<String>();
        try {
            TmcUserCancelRequest  req = new TmcUserCancelRequest();
            req.setNick(nick);
            if(!StringUtils.isEmpty(userPlatform)){
                req.setUserPlatform(userPlatform);
            }
            TmcUserCancelResponse response = this.executeOtsOne(req);
            Boolean isSuccess = response.getIsSuccess();
            if(isSuccess == null || !isSuccess){
                log.error("取消服务失败",getErrorMsg(response));
                abs.setResult(500,getErrorMsg(response));
            }
        } catch (Exception e) {
            log.error("取消服务失败",e);
            abs.setResult(503,e.getMessage());
        }
        return abs;
    }


    /**
     * 转化淘宝原始订单
     *
     * @param pTrade
     * @return
     * @throws Exception
     */
    private SeTaobaoTradeDTO convertTaobaoTrade(Trade pTrade) throws Exception {
        SeTaobaoTradeDTO taobaoTrade = new SeTaobaoTradeDTO();
        taobaoTrade.setShopId(this.relatedId);
        taobaoTrade.setPlatformId(platformId);
        taobaoTrade.setOrderId(pTrade.getTid().toString());
        taobaoTrade.setPlatformOrderStatus(pTrade.getStatus());
        taobaoTrade.setTitle(pTrade.getTitle());
        taobaoTrade.setType(pTrade.getType());
        taobaoTrade.setShippingType(pTrade.getShippingType());
//        taobaoTrade.setPostFee(Converter.toDouble(pTrade.getPostFee()));
//        taobaoTrade.setTotalFee(Converter.toDouble(pTrade.getTotalFee()));
//        taobaoTrade.setDiscountFee(Converter.toDouble(pTrade.getDiscountFee()));
//        taobaoTrade.setAdjustFee(Converter.toDouble(pTrade.getAdjustFee()));
//        taobaoTrade.setPayment(Converter.toDouble(pTrade.getPayment()));
//        taobaoTrade.setBuyerCodFee(Converter.toDouble(pTrade.getBuyerCodFee()));
//        taobaoTrade.setSellerCodFee(Converter.toDouble(pTrade.getSellerCodFee()));
//        taobaoTrade.setCodFee(Converter.toDouble(pTrade.getCodFee()));

        taobaoTrade.setPostFee(new BigDecimal(pTrade.getPostFee()));
        taobaoTrade.setTotalFee(new BigDecimal(pTrade.getTotalFee()));
        taobaoTrade.setDiscountFee(new BigDecimal(pTrade.getDiscountFee()));
        taobaoTrade.setAdjustFee(new BigDecimal(pTrade.getAdjustFee()));
        taobaoTrade.setPayment(new BigDecimal(pTrade.getPayment()));
        taobaoTrade.setBuyerCodFee(new BigDecimal(pTrade.getBuyerCodFee()));
        taobaoTrade.setSellerCodFee(new BigDecimal(pTrade.getSellerCodFee()));
        taobaoTrade.setCodFee(new BigDecimal(pTrade.getCodFee()));
        taobaoTrade.setCodStatus(pTrade.getCodStatus());
        taobaoTrade.setPointFee(pTrade.getPointFee());
        taobaoTrade.setHasPostFee(pTrade.getHasPostFee() == null || !pTrade.getHasPostFee() ?  0 : 1L);
        taobaoTrade.setOrderCreateTime(pTrade.getCreated());
        taobaoTrade.setOrderPayTime(pTrade.getPayTime());
        taobaoTrade.setOrderModifyTime(pTrade.getModified());
        taobaoTrade.setBuyerMessage(pTrade.getBuyerMessage());
        taobaoTrade.setSellerMemo(pTrade.getSellerMemo());
        taobaoTrade.setBuyerNick(pTrade.getBuyerNick());
        taobaoTrade.setBuyerArea(pTrade.getBuyerArea());
        taobaoTrade.setBuyerAlipayNo(pTrade.getBuyerAlipayNo());
        taobaoTrade.setTradeFrom(pTrade.getTradeFrom());
        taobaoTrade.setBuyerFlag(pTrade.getBuyerFlag());

        taobaoTrade.setServiceTags(concatServiceTags(pTrade.getServiceTags()));
        taobaoTrade.setReceiverName(pTrade.getReceiverName());
        taobaoTrade.setReceiverMobile(pTrade.getReceiverMobile());
        taobaoTrade.setReceiverPhone(pTrade.getReceiverPhone());
        taobaoTrade.setReceiverCountry(pTrade.getReceiverCountry());
        taobaoTrade.setReceiverState(pTrade.getReceiverState());
        taobaoTrade.setReceiverCity(pTrade.getReceiverCity());
        taobaoTrade.setReceiverTown(pTrade.getReceiverTown());
        taobaoTrade.setReceiverCounty(pTrade.getReceiverDistrict());
        taobaoTrade.setReceiverAddress(pTrade.getReceiverAddress());
        taobaoTrade.setReceiverZip(pTrade.getReceiverZip());

        taobaoTrade.setEstConTime(pTrade.getEstConTime());
        taobaoTrade.setPaidCouponFee(pTrade.getPaidCouponFee());
		/*-发票-*/
        taobaoTrade.setInvoiceName(pTrade.getInvoiceName());
        taobaoTrade.setInvoiceType(pTrade.getInvoiceType());
        taobaoTrade.setInvoiceKind(pTrade.getInvoiceKind());

        taobaoTrade.setReceivedPayment(pTrade.getReceivedPayment());
        taobaoTrade.setEticketServiceAddr(pTrade.getEticketServiceAddr());
        taobaoTrade.setIsShShip(pTrade.getIsShShip().toString());
        taobaoTrade.setO2oSnatchStatus(pTrade.getO2oSnatchStatus());
        taobaoTrade.setMarket(pTrade.getMarket());
        taobaoTrade.setEtType(pTrade.getEtType());
        taobaoTrade.setEtShopId(pTrade.getEtShopId());
        taobaoTrade.setObs(pTrade.getObs());

        List<SeTaobaoItemDTO> orders = new ArrayList<>();
        if (pTrade.getOrders() != null) for (Order pOrder : pTrade.getOrders()) {
            SeTaobaoItemDTO order = new SeTaobaoItemDTO();
            order = convertTaotaoOrder(pOrder);
            orders.add(order);

            if (StringUtils.isNotEmpty(pOrder.getZhengjiStatus())) {
                taobaoTrade.setZhengjiStatus(Long.parseLong(pOrder.getZhengjiStatus()));
            }
        }
        taobaoTrade.setItemList(orders);
        return taobaoTrade;
    }

    /**
     * 组装 serviceTags
     *
     * @param tbServiceTags eg:813589541785507^FAST^comFee=1211;comTim=1;companyCode=SF;
     * @return
     */
    private String concatServiceTags(List<LogisticsTag> tbServiceTags) {
        String serviceTags = null;// 813589541785507^FAST^comFee=1211;comTim=1;companyCode=SF;
        if (tbServiceTags != null) {
            serviceTags = "";
            for (LogisticsTag tag : tbServiceTags) {
                if (serviceTags.length() > 0) serviceTags += "~";
                serviceTags += tag.getOrderId();

                // service_tag:comFee=1211;comTim=1;companyCode=SF;
                // service_type 服务类型=编码 平邮=POST 快递=FAST EMS=EMS 消费者选快递时为FAST
                for (LogisticServiceTag servTag : tag.getLogisticServiceTagList()) {
                    if (StringUtils.isNotEmpty(servTag.getServiceType())) {
                        serviceTags += "^" + servTag.getServiceType();
                    }
                    if (StringUtils.isNotEmpty(servTag.getServiceTag())) {
                        serviceTags += "^" + servTag.getServiceTag();
                    }
                }
            }
            serviceTags = StringUtils.stringCut(serviceTags, 500, "");
        }
        return serviceTags;
    }

    /** 淘宝订单明细
     *
     */
    private SeTaobaoItemDTO convertTaotaoOrder(Order pOrder) {
        SeTaobaoItemDTO o = new SeTaobaoItemDTO();
        o.setQty(pOrder.getNum());
        o.setSubOrderId(pOrder.getOid());
        o.setBuyerNick(pOrder.getBuyerNick());
        o.setBuyerRate(pOrder.getBuyerRate() == null || !pOrder.getBuyerRate() ? 0L : 1L);
//        o.setAdjustFee(Converter.toDouble(pOrder.getAdjustFee()));
//        o.setDiscountFee(Converter.toDouble(pOrder.getDiscountFee()));
        o.setAdjustFee(new BigDecimal(pOrder.getAdjustFee()));
        o.setDiscountFee(new BigDecimal(pOrder.getDiscountFee()));
        o.setIsOversold(pOrder.getIsOversold() == null || !pOrder.getIsOversold() ?  0 : 1L);
        o.setIsServiceOrder(pOrder.getIsServiceOrder() == null || !pOrder.getIsServiceOrder() ?  0 : 1L);
        o.setItemMealId(pOrder.getItemMealId());
        o.setItemMealName(pOrder.getItemMealName());
        o.setQty(pOrder.getNum());
        o.setProductNumId(pOrder.getNumIid());
        o.setProductOuterId(pOrder.getOuterIid());
        o.setSkuOuterId(pOrder.getOuterSkuId());
        o.setSkuNumId(pOrder.getSkuId());

//        o.setPayment(Converter.toDouble(pOrder.getPayment()));
        o.setPayment(new BigDecimal(pOrder.getPayment()));

        o.setPicPath(pOrder.getPicPath());

//        o.setPrice(Converter.toDouble(pOrder.getPrice()));
        o.setPrice(new BigDecimal(pOrder.getPrice()));

        o.setRefundId(pOrder.getRefundId());
        o.setRefundStatus(pOrder.getRefundStatus());
        o.setSellerNick(pOrder.getSellerNick());
        o.setSellerRate(pOrder.getSellerRate() == null || !pOrder.getSellerRate() ? 0L : 1L);
        o.setOrderFrom(pOrder.getOrderFrom());
        o.setSkuPropertiesName(pOrder.getSkuPropertiesName());
        o.setSellerType(pOrder.getSellerType());
        o.setSubOrderStatus(pOrder.getStatus());
        o.setProductName(pOrder.getTitle());

//        o.setTotalFee(Converter.toDouble(pOrder.getTotalFee()));
        o.setTotalFee(new BigDecimal(pOrder.getTotalFee()));

        o.setCid(pOrder.getCid());
        o.setEndTime(pOrder.getEndTime());
        o.setShippingType(pOrder.getShippingType());
        o.setLogisticsCompany(pOrder.getLogisticsCompany());

        if (StringUtils.isNotEmpty(pOrder.getConsignTime())) {
            o.setConsignTime(DateUtil.parse(pOrder.getConsignTime(), "yyyy-MM-dd HH:mm:ss"));
        }
        if (StringUtils.isNotEmpty(pOrder.getDivideOrderFee())) {
//            o.setDivideOrderFee(Converter.toDouble(pOrder.getDivideOrderFee()));
            o.setDivideOrderFee(new BigDecimal(pOrder.getDivideOrderFee()));
        }
        if (StringUtils.isNotEmpty(pOrder.getPartMjzDiscount())) {
//            o.setPartMjzDiscount(Converter.toDouble(pOrder.getPartMjzDiscount()));
            o.setDivideOrderFee(new BigDecimal(pOrder.getDivideOrderFee()));
        }
        //征集订单状态
        if (StringUtils.isNotEmpty(pOrder.getZhengjiStatus())) {
            o.setZhengjiStatus(NumberUtils.toLong(pOrder.getZhengjiStatus()));
        }

        return o;
    }
    /**
     * @return
     * @throws Exception
     */
    private List<SeTaobaoTradeDTO> catchTradesLimitDate() {
        List<SeTaobaoTradeDTO> tradeList = new ArrayList<SeTaobaoTradeDTO>();

        TradesSoldGetResponse response = null;
        try {
            response = getTradesSoldResponse(pageNo, pageSize, startDate,
                    endDate, this.status, isFullField);
            if (response != null && response.getTrades() != null) {
                for (Trade pTrade : response.getTrades()) {
                    tradeList.add(convertTaobaoTrade(pTrade));
                }

                if (pageNo == 1) {
                    itemTotal = response.getTotalResults().intValue();
                    setPageInfo(itemTotal);
                }
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
        } finally {
            pageNo--;
        }

        return tradeList;
    }

    /**
     * 查询订单
     * @param pageNO
     * @param pageSize
     * @param startCreated
     * @param endCreated
     * @param status
     * @param isFullField
     * @return
     * @throws Exception
     */
    private TradesSoldGetResponse getTradesSoldResponse(int pageNO, int pageSize,
                                                        Date startCreated, Date endCreated, String status, boolean isFullField) throws Exception {
        TradesSoldGetResponse response = null;
        String fields = isFullField ? TRADE_FULLINFO_FIELDS : TRADE_SHORT_FIELDS;
        if (isEnableOts) {
            Map<String, String> params = new HashMap<>();
            params.put("isFullField", isFullField ? "1" : "0");
            params.put("fullFields", isFullField ? TRADE_FULLINFO_FIELDS : "");
            params.put("page", String.valueOf(pageNO));
            params.put("pageSize", String.valueOf(pageSize));
            params.put("startDate", DateUtil.toDateTimeString(startCreated));
            params.put("endDate", DateUtil.toDateTimeString(endCreated));
            params.put("status", status);
            params.put("fields", fields);
            params.put("type", TRADE_TYPE);
            params.put("useHasNext", pageNO == 1 ? "0" : "1");// 第1页不启用


            response = this.executeOts("getTradesSoldResponse",
                    params, TradesSoldGetResponse.class);
        } else {
            TradesSoldGetRequest req = new TradesSoldGetRequest();
            req.setFields(fields);
            req.setType(TRADE_TYPE);
            if (startCreated != null) {
                req.setStartCreated(startCreated);
            }
            if (endCreated != null) {
                req.setEndCreated(endCreated);
            }
            if (status != null && status.trim().length() > 0) {
                req.setStatus(status);
            }
            req.setPageSize((long) pageSize); // 设置每页返回条数 默认每页40条 最大100
            req.setPageNo((long) pageNO); // 每回第一页
            req.setUseHasNext(pageNO == 1 ? false : true);// 第1页不启用
            response = this.execute(req);
        }
        return response;
    }

    /**增量
     *
     */
    private List<SeTaobaoTradeDTO> catchTradesIncLimit() {
        List<SeTaobaoTradeDTO> tradeList = new ArrayList<SeTaobaoTradeDTO>();

        try {
            TradesSoldIncrementGetResponse response = getTradesIncrementResponse(
                    this.pageNo, this.pageSize, this.startDate, this.endDate, this.status);
            if (response != null && response.getTrades() != null) {
                for (Trade pTrade : response.getTrades()) {
                    tradeList.add(this.convertTaobaoTrade(pTrade));
                }

                if (pageNo == 1) {
                    int total = response.getTotalResults().intValue();
                    setPageInfo(total);
                }
            }
        } catch (Exception e) {
            log.error(getRequestString(), e);
        } finally {
            pageNo--;
        }

        return tradeList;
    }

    private TradesSoldIncrementGetResponse getTradesIncrementResponse(int pageNO,
                                                                      int pageSize, Date startCreated, Date endCreated, String status) throws Exception {
        TradesSoldIncrementGetResponse response = null;
        if (isEnableOts) {
            Map<String, String> params = new HashMap<>();
            params.put("page", String.valueOf(pageNO));
            params.put("pageSize", String.valueOf(pageSize));
            params.put("startDate", DateUtil.toDateTimeString(startCreated));
            params.put("endDate", DateUtil.toDateTimeString(endCreated));
            params.put("status", status);
            params.put("fields", TRADE_INCREMENT_FIELDS);
            params.put("type", TRADE_TYPE);
            params.put("useHasNext", pageNO == 1 ? "0" : "1");// 第1页不启用

            response = this.executeOts("getTradesIncrementResponse",
                    params, TradesSoldIncrementGetResponse.class);
        } else {
            TradesSoldIncrementGetRequest req = new TradesSoldIncrementGetRequest();
            req.setFields(TRADE_INCREMENT_FIELDS);
            req.setType(TRADE_TYPE);
            req.setStartModified(startCreated);
            req.setEndModified(endCreated);
            req.setStatus(status);
            req.setPageNo((long) pageNO);
            req.setPageSize((long) pageSize);
            req.setUseHasNext(pageNO == 1 ? false : true);//第1页不启用
            response = this.execute(req);
        }
        return response;
    }

    private AbsResponse reShipNotice(String tid, String outSid, String tmsCode,
                                     String tmsName, boolean isSplit, String subTids) {
        AbsResponse lRetBean = new AbsResponse();
        if (!StringUtils.isNumeric(tid)) {
            lRetBean.setResult(400, "来源单号为空");
            return lRetBean;
        }
        if (StringUtils.isEmpty(tmsCode) || StringUtils.isEmpty(tmsName)) {
            lRetBean.setResult(402, "快递公司为空");
            return lRetBean;
        }

        LogisticsConsignResendResponse response = null;
        try {
            RequestCheckUtils.checkNotEmpty(outSid, "tid");
            RequestCheckUtils.checkNotEmpty(outSid, "outSid");

            LogisticsConsignResendRequest req = new LogisticsConsignResendRequest();
            req.setTid(Long.valueOf(tid));
            req.setOutSid(outSid);
            req.setCompanyCode(tmsCode);
            req.setIsSplit(0L);
            if (isSplit && StringUtils.isNotEmpty(subTids)) {
                req.setIsSplit(1L);
                req.setSubTid(subTids);
            }

            response = this.executeOtsOne(req);

            Shipping ship = response.getShipping();

            if (ship != null && ship.getIsSuccess()) {
                lRetBean.setResult(0, "OK");
            } else {
                String error = getErrorMsg(response);
                lRetBean.setResult(500, convertShippingError(error) + error);
            }
//        } catch (ApiCheckException e){
//            lRetBean.setResult(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            lRetBean.setResult(503, "发生异常:" + e.getMessage());
            log.error(tid, e);
        }
        return lRetBean;
    }

    public AbsResponse shipNoticeOffline(String tid, String outSid, String expId,
                                         String expName, boolean isSplit, String subTids) {
        AbsResponse lRetBean = new AbsResponse();

        LogisticsOfflineSendResponse response = null;
        try {
            LogisticsOfflineSendRequest req = new LogisticsOfflineSendRequest();
            req.setTid(Long.valueOf(tid));
            req.setOutSid(outSid);
            req.setCompanyCode(expId);
            req.setIsSplit(0L);
            if (isSplit && StringUtils.isNotEmpty(subTids)) {
                req.setIsSplit(1L);
                req.setSubTid(subTids);
            }
            response = this.executeOtsOne(req);

            Shipping ship = response.getShipping();

            if (ship != null && ship.getIsSuccess()) {
                lRetBean.setResult(0, "OK");
            } else {
                String error = getErrorMsg(response);
                lRetBean.setResult(500, convertShippingError(error) + error);
            }
        } catch (Exception e) {
            lRetBean.setResult(503, "发生异常:" + e.getMessage());
            log.error(tid, e);
        }

        return lRetBean;
    }

    /**
     * 支持货到付款
     */
    public AbsResponse shipNoticeOnline(String tid, String outSid, String expName,
                                        String expId, boolean isSplit, String subTids) {
        AbsResponse lRetBean = new AbsResponse();
        LogisticsOnlineSendResponse response = null;
        try {
            LogisticsOnlineSendRequest req = new LogisticsOnlineSendRequest();
            req.setTid(Long.valueOf(tid));
            req.setOutSid(outSid);
            req.setCompanyCode(expId);
            req.setIsSplit(1L);
            if (isSplit && StringUtils.isNotEmpty(subTids)) {
                req.setIsSplit(0L);
                req.setSubTid(subTids);
            }
            response = this.executeOtsOne(req);
            Shipping ship = response.getShipping();

            if (ship != null && ship.getIsSuccess()) {
                lRetBean.setResult(0, "OK");
            } else {
                String error = getErrorMsg(response);
                lRetBean.setResult(500, convertShippingError(error) + error);
            }
        } catch (Exception e) {
            lRetBean.setResult(503, "发生异常:" + e.getMessage());
            log.error(tid, e);
        }

        return lRetBean;
    }

    private String convertShippingError(String errorMsg) {
        if (errorMsg == null) return "";
        if (errorMsg.contains("B04")) {
            errorMsg = "平台已经发货，无需上传发货;";
        } else if (errorMsg.contains("B141")) {
            errorMsg = "请尝试手动上传发货;";
        } else if (errorMsg.contains("P38")) {
            errorMsg = "该订单换过商品，网仓系统不能上传发货;";
        } else if (errorMsg.contains("B60")) {
            errorMsg = "运单号不符合规则或已经被使用;";
        } else if (errorMsg.contains("ORDER_NOT_FOUND_ERROR")) {
            errorMsg = "该来源单号不存在;";
        } else if (errorMsg.contains("session-not-exist")) {
            errorMsg = "授权失效;";
        } else {
            errorMsg = "";
        }
        return errorMsg;
    }





}

