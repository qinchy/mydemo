package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.utils.AbsResponse;

/**
 * 
 * 短信接口
 *
 */
public interface ISmsApi extends com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRecordAble {
	/**
	 * 发送单条短信
	 * @param mobile
	 * @param content
	 * @return
	 * @throws Exception
	 */
	public AbsResponse<String> sendSms(String mobile, String content)
			throws Exception;

	/**
	 * 发送多条短信
	 * @param mobiles
	 * @param content
	 * @return
	 * @throws Exception
	 */
	public AbsResponse<String> sendSms(String[] mobiles, String content)
			throws Exception;
}
