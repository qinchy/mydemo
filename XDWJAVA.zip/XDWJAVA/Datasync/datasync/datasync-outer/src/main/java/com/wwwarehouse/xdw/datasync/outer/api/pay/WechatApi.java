package com.wwwarehouse.xdw.datasync.outer.api.pay;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.commons.xml.XmlConverter;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IPayApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRecordAble;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.net.ssl.SSLContext;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyStore;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by xiuli.yang on 16/9/20.
 */
public class WechatApi extends BaseRequestApi implements IPayApi,IRecordAble {
	private static Logger logger = LoggerFactory.getLogger(WechatApi.class);
	// 微信支付相关
	private String TRADE_TYPE = "APP";
	private String notify_url = ConstantsOuter.NOTIFY_URL + "/payNotify/wechatpay";
	private static int connectionTimeOut = 25000;
	private static int readTimeout = 25000;
	private String CHARSET = "UTF-8";
	private String appId;
	private String partnerId;	// = "1401609202";
	private String key;			// = "Zjwckj20161021Wckj20161021201621";
	private String payAppType;			// PAY, IOSPAY

	/**
	 * 接口地址
	 */
	private enum API_URL {
		UNIFIED_ORDER("https://api.mch.weixin.qq.com/pay/unifiedorder"),
		ORDER_QUERY("https://api.mch.weixin.qq.com/pay/orderquery"),
		TRANSFERS("https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers"),
		GET_TRANSFER_INFO("https://api.mch.weixin.qq.com/mmpaymkttransfers/gettransferinfo"),
		USERINFO("https://api.weixin.qq.com/sns/userinfo"),
		AUTH("https://api.weixin.qq.com/sns/auth");

		private String url;
		private API_URL(String url) {
			this.url = url;
		}
	}

	public WechatApi(AmAppSubscriptionDTO appSuber) {
		AmAppkeyDTO amAppkey = appSuber.getApp();
		this.appId = amAppkey.getAppKey();
		this.key = amAppkey.getAppSecret();
		this.partnerId = appSuber.getPlatformUserId();
		this.CHARSET = amAppkey.getCharset();

		this.payAppType = amAppkey.getAppType();
	}

	/**
	 * 调用统一下单接口
	 * https://pay.weixin.qq.com/wiki/doc/api/app/app.php?chapter=9_1#
	 * @param tradeNo
	 * @param clientIp
	 * @param body
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public AbsResponse<Object> unifiedorder(String tradeNo, String body, String clientIp, double amount) throws Exception {
		// 支付请求参数
		AbsResponse<Object> ret = new AbsResponse<>();
		try {
			Map<String, String> uniOrderParams = this.buildUniOrderParams(clientIp, body, amount, tradeNo);
			String rspXml = this.callApi(API_URL.UNIFIED_ORDER.url, uniOrderParams);
			Map<String, String> rspMap = this.convertToMap(rspXml);
			String returnCode = rspMap.get("return_code");
			if (!"SUCCESS".equals(returnCode)) {
				ret.setResult(602017, rspMap.get("return_msg"), "", rspMap);
				return ret;
			}
			String resultCode = rspMap.get("result_code");
			if (!"SUCCESS".equals(resultCode)) {
				ret.setResult(602017, rspMap.get("err_code_des"), "", rspMap);
				return ret;
			}
			// 验证签名成功
			if (!validate(rspMap)) {
				ret.setResult(611112, "验证签名失败", "", rspMap);
				return ret;
			}
			String prepayId = rspMap.get("prepay_id");
			HashMap<String, String> clientParams = buildParamsForClient(prepayId);

			clientParams.put("registerType", "");
			ret.setResult(0, "成功", "", clientParams);
			logger.debug("weixin return:" + clientParams);
		} catch (Exception e) {
			logger.error(partnerId, e);
			ret.setResult(500, "发生异常");
		}
		return ret;
	}

	@Override
	public AbsResponse<String> buildPayUrl(String tradeNo, String title, String body, double amount) throws Exception {
		return null;
	}

	@Override
	public AbsResponse<String> buildBatchPay(String tradeNo, String receivePaymentAccount, String receiveUserName, String billMoney, String paymentRemark, String batchNo) throws Exception {
		return null;
	}

	/**
	 * 组装统一下单的参数
	 * https://pay.weixin.qq.com/wiki/doc/api/app/app.php?chapter=9_1
	 * @param clientIp
	 * @param body
	 * @param amount
	 * @param tradeNo
	 * @return
	 * @throws Exception
	 */
	private Map<String, String> buildUniOrderParams(String clientIp, String body, double amount,
													String tradeNo) throws Exception {
		String nonceStr = getRandomString(16);

		//微信以分为单位，不允许出现小数点
		double totalFee = StringUtils.comDouble(amount, 100D, '*');

		Map<String, String> contentData = new HashMap<>();
		contentData.put("notify_url", notify_url);
		contentData.put("trade_type", TRADE_TYPE);
		contentData.put("nonce_str", nonceStr);
		contentData.put("body", body);
		contentData.put("out_trade_no", tradeNo);
		contentData.put("total_fee", String.valueOf((int) totalFee));
		contentData.put("spbill_create_ip", clientIp);
		contentData.put("attach", payAppType); //重要，传送的是网仓的支付app_type:PAY, IOSPAY

		return contentData;
	}

	// 调用随机数函数生成，将得到的值转换为字符串。
	private static String getRandomString(int length) {
		String base = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(base.length());
			sb.append(base.charAt(number));
		}
		return sb.toString();
	}

	private String callApi(String apiCallUrl, Map<String, String> params) throws IOException {
		String responseString = null;
		Date reqDate = new Date();

		params.put("appid", appId);
		params.put("mch_id", partnerId);

		String sign = this.sign(params);
		params.put("sign", sign);
		try {
			String apiBody = XmlConverter.convert("xml", params, false);
			// 请求数据
			responseString = WebUtils.doPost(apiCallUrl, apiBody, CHARSET,
					connectionTimeOut, readTimeout, null);
		} catch (IOException e) {
			responseString = e.getMessage();
			throw e;
		} finally {
			appendReqAResp("WECHATPAY", reqDate, apiCallUrl, params, responseString);
		}
		return responseString;
	}

	private String sign(Map<String, String> param) throws IOException {
		// 1.通过key=value&key=value方式拼接字符串
		String query = CodecUtils.sortsEncodeParams(param, false);
		// 2.对对原始字符串进行签名
		String signString = query + "&key=" + this.key;
		byte[] bytes = CodecUtils.encryptMD5(signString);
		String sign = CodecUtils.byte2hex(bytes, true);
		return sign;
	}

	/**
	 * @description 将xml字符串转换成map
	 * @param xml
	 * @return Map
	 */
	public static Map<String, String> convertToMap(String xml) {
		Map<String, String> results = new HashMap<>();
		try {
			Element rootEle = XmlUtils.getRootElementFromString(xml);

			NodeList nodeList = rootEle.getChildNodes();
			if(nodeList != null)
				for(int i = 0; i < nodeList.getLength(); i++){
					Node node = nodeList.item(i);
					String nodeName = node.getNodeName();
					results.put(nodeName, node.getTextContent());
				}
		} catch (Exception e) {
			logger.error(xml, e);
		}
		return results;
	}

	/**
	 * 校验外部签名
	 * @param rspData
	 * @return
	 */
	public boolean validate(Map<String, String> rspData) {
		String returnSign = rspData.get("sign"); // 签名

		Map<String, String> validateData = new HashMap<>(rspData);
		validateData.remove("sign");

		try {
			String query = CodecUtils.sortsEncodeParams(validateData, false);
			String signString = query + "&key=" + this.key;

			byte[] bytes = CodecUtils.encryptMD5(signString);
			String newSign = CodecUtils.byte2hex(bytes, true);
			return newSign.equals(returnSign);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return false;
	}

	/**
	 * 组装【调起支付】的参数
	 * https://pay.weixin.qq.com/wiki/doc/api/app/app.php?chapter=9_12&index=2
	 * @param prepayId
	 * @return
	 * @throws Exception
	 */
	private HashMap<String, String> buildParamsForClient(String prepayId) throws Exception {
		String nonceStr = getRandomString(16);
		String packageValue = "Sign=WXPay";

		HashMap<String, String> params = new HashMap<>();
		params.put("appid", this.appId);
		params.put("partnerid", this.partnerId);
		params.put("package", packageValue);
		params.put("prepayid", prepayId);
		params.put("noncestr", nonceStr);
		params.put("timestamp", String.valueOf(System.currentTimeMillis() / 1000));
		params.put("sign", this.sign(params)); // 新的签名
		return params;
	}

	/**
	 * 企业付款业务
	 * https://pay.weixin.qq.com/wiki/doc/api/tools/mch_pay.php?chapter=14_2
	 */
	public AbsResponse<Object> payToPersonal(String tradeNo, String tradeTitle, String clientIp,
									 double amount, String openId, String registerType) throws Exception {
		AbsResponse<Object> ret = new AbsResponse<Object>();

		//微信以分为单位，不允许出现小数点
		amount = StringUtils.comDouble(amount, 100D, '*');
		String nonceStr = WechatApi.getRandomString(16);

		Map<String, String> params = new HashMap<>();
		params.put("mch_appid", this.appId);
		params.put("mchid", this.partnerId);
		params.put("partner_trade_no", tradeNo);
		params.put("openid", openId);
		params.put("check_name", "NO_CHECK");
		params.put("amount", String.valueOf((int) amount));
		params.put("desc", tradeTitle);
		params.put("spbill_create_ip", clientIp);
		params.put("nonce_str", nonceStr);
		params.put("sign", this.sign(params));
		String content = XmlConverter.convert("xml", params, false);

		InputStream certFileStream = getCertFileStream(registerType);//证书路径
		String rspXml = httpsPost(API_URL.TRANSFERS.url, certFileStream, this.partnerId, content);
		Map<String, String> rspMap = convertToMap(rspXml);
		String returnCode = rspMap.get("return_code");
		String resultCode = rspMap.get("result_code");

		if ("SUCCESS".equals(returnCode) && "SUCCESS".equals(resultCode)) {
			rspMap.put("prepayid", rspMap.get("payment_no"));//企业付款成功，返回的微信订单号
			rspMap.put("registerType", registerType);
			ret.setResult(0, "成功", rspXml, rspMap);
		} else {
			String errMsg = "return_msg:" + rspMap.get("return_msg") + "; err_code_des:" + rspMap.get("err_code_des");
			ret.setResult(602019, errMsg, rspXml, rspMap);
		}

		return ret;
	}

	/**
	 * 获取证书路径
	 * @param registerType
	 * @return
	 */
	private InputStream getCertFileStream(String registerType) throws IOException {
		String filePath = null;//证书路径
		switch (registerType) {
			case "GS":
				filePath = "gs_apiclient_cert.p12"; // 公司
				break;
			case "QY":
				filePath = "qy_apiclient_cert.p12"; // 企业
				break;
			default:
				break;
		}

		return WechatApi.class.getResource("/pay_assets/wechat/" + filePath).openStream();
	}

	/**
	 * 查询企业付款
	 */
	public AbsResponse getTransferInfo(String tradeNo, String registerType) throws Exception {
		AbsResponse<Object> ret = new AbsResponse<>();

		Map<String, String> params = new HashMap<>();
		params.put("appid", appId);
		params.put("mch_id", partnerId);
		params.put("partner_trade_no", tradeNo);
		params.put("nonce_str", this.getRandomString(16));
		params.put("sign", this.sign(params));

        String content = XmlConverter.convert("xml", params, false);

		InputStream certFileStream = getCertFileStream(registerType);//证书路径
		String rspXml = httpsPost(API_URL.GET_TRANSFER_INFO.url, certFileStream, partnerId, content);
		Map<String, String> rspMap = convertToMap(rspXml);
		String returnCode = rspMap.get("return_code");
		String resultCode = rspMap.get("result_code");

		if ("SUCCESS".equals(returnCode) && "SUCCESS".equals(resultCode)) {
			ret.setResult(0, "成功", "", rspMap);
		} else {
			String errMsg = "return_msg:" + rspMap.get("return_msg") + "; err_code_des:" + rspMap.get("err_code_des");

			ret.setResult(602019, errMsg, "", rspMap);
		}

		return ret;
	}

	@SuppressWarnings("deprecation")
	private String httpsPost(String apiUrl, InputStream certInstream, String mchId, String content) throws Exception {
		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		try {
			keyStore.load(certInstream, mchId.toCharArray());
		} finally {
			WebUtils.closeQuietly(certInstream);
		}

        // Trust own CA and all self-signed certs
        SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, mchId.toCharArray()).build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                sslcontext,
                new String[] { "TLSv1" },
                null,
                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
        CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		Date reqDate = new Date();
        StringBuilder respBuider = new StringBuilder();
        try {
			HttpPost httpPost = new HttpPost(apiUrl);
			HttpEntity contentE = new StringEntity(content, this.CHARSET);
			httpPost.setEntity(contentE);
			logger.info("executing request" + httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				HttpEntity entity = response.getEntity();
				logger.info("weixin httpsPost:" + response.getStatusLine());
				if (entity != null) {
					BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(entity.getContent(), this.CHARSET));
					String text;
					while ((text = bufferedReader.readLine()) != null) {
						respBuider.append(text);
					}
				}
				EntityUtils.consume(entity);
			} finally {
				response.close();
			}
		} catch (Exception e){
			respBuider.append(e.getMessage());
			throw e;
        } finally {
			try {
				appendReqAResp("WECHATPAY", reqDate, apiUrl + "?" + content, null, respBuider.toString());
			} catch (Exception e){}
			httpclient.close();
		}
        return respBuider.toString();
	}

}
