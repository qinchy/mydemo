package com.wwwarehouse.xdw.datasync.outer.api.pay;

import com.wwwarehouse.commons.utils.*;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.AlipayCore;
import com.wwwarehouse.xdw.datasync.outer.ConstantsOuter;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IPayApi;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jiejun on 16/9/20.
 */
public class AlipayApi extends BaseRequestApi implements IPayApi {
//	protected static final Logger logger = LogManager.getLogger(AlipayApi.class);

    private static final String ALIPAY_GATEWAY_NEW = "https://mapi.alipay.com/gateway.do";
    private static final String ASYNC_NOTIFY_URL = ConstantsOuter.NOTIFY_URL + "/payNotify/alipay";//异步通知接口
    private static final String WEB_NOTIFY_URL = ConstantsOuter.NOTIFY_URL + "/api/alipayNotify";
    private static final String PAY_EMAIL = "iscs2011@163.com";

    /**
     * 接口地址
     */
    private static enum API_SERVICE {
        MOBILE_PAY("mobile.securitypay.pay"),
        BATCH_NOTIFY("batch_trans_notify");

        private String value;

        private API_SERVICE(String value) {
            this.value = value;
        }
    }


    private String appId;
    private String secretKey;
    private String privateKey;
    private String input_charset = "utf-8";
    private String partner;
    private String accountName;
    private String signType;
    private String publickey;

    public AlipayApi(AmAppSubscriptionDTO appSuber) {
        AmAppkeyDTO amAppkey = appSuber.getApp();
        this.appId = amAppkey.getAppKey();
        this.secretKey = amAppkey.getAppSecret();
        this.input_charset = amAppkey.getCharset();
        this.signType = amAppkey.getSignMethod();

        this.privateKey = appSuber.getPrivateKey();
        this.publickey = appSuber.getPublicKey();
        this.partner = appSuber.getPlatformUserId();
        this.accountName = appSuber.getPlatformUserNick();
    }

    /**
     * 支付请求参数
     * <p>
     * /* //1.通过key=value&key=value方式拼接字符串
     * String signContent = AlipaySignature.getSignContent(param);
     * //2.对对原始字符串进行签名
     * String sign = AlipaySignature.rsaSign(signContent, this.privateKey, CHARSET);
     * //3.最后对请求字符串的所有一级value（biz_content作为一个value）进行encode
     * String decodedString = this.getEecodeParams(param, sign);
     * ret.setData(decodedString);
     */
    @Override
    public AbsResponse<String> buildPayUrl(String tradeNo, String title, String body,
                                           double amount) throws Exception {
        AbsResponse<String> ret = new AbsResponse<>();
        Map<String, String> param = this.getAlipayMapParams(title, body, amount, tradeNo);

        String signContent = AlipayCore.createLinkString(param);
        try {
            String sign = RSAUtil.sign(StringUtils.toBytes(signContent, input_charset), this.privateKey);
            ret.setData(this.getEecodeSignOfContent(signContent, sign));
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        return ret;
    }

    @Override
    public AbsResponse<String> buildBatchPay(String tradeNo, String receivePaymentAccount, String receiveUserName, String billMoney, String paymentRemark, String batchNo) throws Exception {
        return null;
    }

    private String getEecodeSignOfContent(String signContent, String sign) {
        String encodeValue = CodecUtils.urlEncode(sign);
        StringBuffer decodeParams = new StringBuffer(signContent);
        decodeParams.append("&sign=" + encodeValue);
        decodeParams.append("&sign_type=" + this.signType);
        return decodeParams.toString();
    }

    /**
     * 组装请求alipay的参数
     *
     * @param title
     * @param body
     * @param amount
     * @param tradeNo
     * @return
     */
    private Map<String, String> getAlipayMapParams(String title, String body, double amount, String tradeNo) {
        Map<String, String> params = new HashMap<>();
        params.put("service", API_SERVICE.MOBILE_PAY.value);
        params.put("partner", this.partner);
        params.put("input_charset", input_charset);
        params.put("sign_type", this.signType);
        params.put("notify_url", ASYNC_NOTIFY_URL);
        //sortedParams.put("app_id", this.appId);
        params.put("out_trade_no", tradeNo);
        params.put("subject", title);
        params.put("payment_type", "1");
        params.put("seller_id", this.partner);
        params.put("total_fee", String.valueOf(amount));
        params.put("body", body);
        return params;
    }


    public AbsResponse<String> buildBatchPay(Long billUkid,
                                             String receivePaymentAccount, String receiveUserName,
                                             String billMoney, String paymentRemark, String batchNo) throws Exception {
        AbsResponse<String> abs = new AbsResponse<>();
        //付款详细数据拼接，最多支持1000笔
        StringBuilder detailBuilder = new StringBuilder();
        detailBuilder.append(billUkid);
        detailBuilder.append("^" + receivePaymentAccount);
        detailBuilder.append("^" + receiveUserName);
        detailBuilder.append("^" + billMoney);
        detailBuilder.append("^" + paymentRemark);
        //付款详细数据
        String detailData = detailBuilder.toString();
        //付款总金额 参数detail_data的值中所有金额的总和
        String batchFee = billMoney.toString();
        //付款笔数 最大支持1000笔
        String batchNum = "1";

        //把请求参数打包成数组
        Map<String, String> sParaTemp = new HashMap<>();
        sParaTemp.put("service", API_SERVICE.BATCH_NOTIFY.value);
        sParaTemp.put("partner", this.partner);
        sParaTemp.put("_input_charset", this.input_charset);
        sParaTemp.put("notify_url", WEB_NOTIFY_URL);
        sParaTemp.put("email", PAY_EMAIL);
        sParaTemp.put("account_name", this.accountName);
        //付款当天日期//必填，格式：年[4位]月[2位]日[2位]，如：20100801
        sParaTemp.put("pay_date", DateUtil.format(new Date(), "yyyyMMdd"));
        sParaTemp.put("batch_no", batchNo);
        sParaTemp.put("batch_fee", batchFee);
        sParaTemp.put("batch_num", batchNum);
        sParaTemp.put("detail_data", detailData);
        String sHtmlText = buildRequest(sParaTemp, "post", "确认");
        abs.setData(sHtmlText);
        return abs;
    }

    /**
     * 建立请求，以表单HTML形式构造（默认）
     *
     * @param sParaTemp     请求参数数组
     * @param strMethod     提交方式。两个值可选：post、get
     * @param strButtonName 确认按钮显示文字
     * @return 提交表单HTML文本
     */
    private String buildRequest(Map<String, String> sParaTemp, String strMethod, String strButtonName) {
        //待请求参数数组
        Map<String, String> params = buildRequestPara(sParaTemp);

        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<form id=\"alipaysubmit\" name=\"alipaysubmit\" action=\"" + ALIPAY_GATEWAY_NEW
                + "?_input_charset=" + input_charset + "\" method=\"" + strMethod
                + "\">");

        for (String name : params.keySet()) {
            String value = params.get(name);

            sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
        }

        //submit按钮控件请不要含有name属性
        sbHtml.append("<input type=\"submit\" value=\"" + strButtonName + "\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['alipaysubmit'].submit();</script>");
        return sbHtml.toString();
    }

    /**
     * 生成要请求给支付宝的参数数组
     *
     * @param sParaTemp 请求前的参数数组
     * @return 要请求的参数数组
     */
    private Map<String, String> buildRequestPara(Map<String, String> sParaTemp) {
        //除去数组中的空值和签名参数
        Map<String, String> sPara = AlipayCore.paraFilter(sParaTemp);
        //生成签名结果
        String sign = buildSign(sPara);

        //签名结果与签名方式加入请求提交参数组中
        sPara.put("sign", sign);
        sPara.put("sign_type", this.signType);

        return sPara;
    }

    /**
     * 生成签名结果
     *
     * @param params 要签名的数组
     * @return 签名结果字符串
     */
    private String buildSign(Map<String, String> params) {
        String preStr = AlipayCore.createLinkString(params); //把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        String mysign;
        switch (this.signType) {
            case "MD5":
                try {
                    byte[] bytes = StringUtils.toBytes(preStr + this.secretKey, this.input_charset);
                    mysign = CodecUtils.encodeBase64(bytes);
                } catch (IOException e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
                break;
            case "RSA":
                try {
                    mysign = RSAUtil.sign(StringUtils.toBytes(preStr, this.input_charset), this.privateKey);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
                break;
            default:
                mysign = "";
                break;
        }
        return mysign;
    }

    /**
     * 根据反馈回来的信息，生成签名结果
     *
     * @param Params 通知返回来的参数数组
     * @param sign   比对的签名结果
     * @return 生成的签名结果
     */
    private boolean verifySign(Map<String, String> Params, String sign) {
        //过滤空值、sign与sign_type参数
        Map<String, String> sParaNew = AlipayCore.paraFilter(Params);
        //获取待签名字符串
        String preSignStr = AlipayCore.createLinkString(sParaNew);
        //获得签名验证结果
        boolean isSign = false;
        switch (this.signType) {
            case "MD5":
                try {
                    isSign = md5Verify(preSignStr, this.secretKey, sign);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
                break;
            case "RSA":
                try {
                    byte[] bytes = StringUtils.toBytes(preSignStr, this.input_charset);
                    isSign = RSAUtil.verify(bytes, sign, this.publickey);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
                break;
            default:
                break;
        }
        return isSign;
    }

    /**
     * 验证是否是支付宝发来的通知
     * <p>
     * 得到的处理结果有两种：
     * 成功时：true
     * 不成功时：报对应错误
     *
     * @param notifyId
     */
    private String verifyResponse(String notifyId) {
        Map<String, String> params = new HashMap<>();
        params.put("partner", this.partner);
        params.put("notify_id", notifyId);

        //获取远程服务器ATN结果，验证是否是支付宝服务器发来的请求
        final String service = "notify_verify";
        try {
            return callApi(service, params);
        } catch (Exception e) {
            return "";
        }
    }

    private String callApi(String service, Map<String, String> params)
            throws IOException {
        String responseString = null;
        Date reqDate = new Date();
        try {
            params.put("service", service);
            responseString = WebUtils.doGet(ALIPAY_GATEWAY_NEW, params);
        } catch (IOException e) {
            responseString = e.getMessage();
            throw e;
        } finally {
            appendReqAResp(service, reqDate, ALIPAY_GATEWAY_NEW, params, responseString);
        }

        return responseString;
    }

    //判断responsetTxt是否为true，isSign是否为true
    //responsetTxt的结果不是true，与服务器设置问题、合作身份者ID、notify_id一分钟失效有关
    //isSign不是true，与安全校验码、请求时的参数格式（如：带自定义参数等）、编码格式有关
    public boolean verify(Map<String, String> params) {
        String notifyId = params.get("notify_id");
        if (StringUtils.isEmpty(notifyId)) {
            return false;
        }

        String responseTxt = this.verifyResponse(notifyId);
        if (!"true".equals(responseTxt)) {
            return false;
        }

        String sign = params.get("sign");
        return verifySign(params, sign);
    }


    private boolean md5Verify(String text, String key, String sign) throws IOException {
        String reSign = CodecUtils.encodeMD5ToHex(text + key);
        return reSign.equals(sign);
    }
}
