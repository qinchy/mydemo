package com.wwwarehouse.xdw.datasync.outer;

import java.util.ResourceBundle;

/**
 * Created by zhigang.huang on 2017/6/8.
 */
public class ConstantsOuter {

    public static ResourceBundle rbn = ResourceBundle.getBundle("server-outer");
    public final static String authL = "-987456123";

    /**
     * 淘宝ots地址
     */
    public final static String OtsTaobaoHost = rbn.getString("ots.taobao.host");
    /**
     * 诚信通ots地址
     */
    public final static String OtsAli1688Host = rbn.getString("ots.ali1688.host");

    /**
     * 京东云鼎地址
     */
    public final static String OtsJdHost = rbn.getString("ots.jd.host");

    /**
     * 默认的字符集
     */
    public static final String DEFAULT_CHARSET = "UTF-8";

    /**
     * 授权与认证回调地址
     */
    public static final String AUTH_FEEDBACK_URL = rbn.getString("auth.feecback.url");

    /**
     * 支付异步授权与认证回调地址
     */
    public static final String NOTIFY_URL = rbn.getString("notify.url");
}
