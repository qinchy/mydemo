package com.wwwarehouse.xdw.datasync.outer.api.interfaces;

import com.wwwarehouse.commons.utils.AbsResponse;

import java.util.Date;
import java.util.List;

public interface ITradeApi extends IRecordAble {

	/**
	 * 查询订单
	 *
	 * @param tid
	 * @return
	 */
	public AbsResponse<?> catchOneTrade(String tid);

	/**
	 * 查询订单
	 *
	 * @param startTime
	 *            1 拍单时间，2 更新时间，3 付款时间
	 *
	 * @return
	 */
	public AbsResponse<List<?>> catchTrades(Date startTime, Date endTime,
											String status, boolean isFullFields);

	/**
	 * 每次查询一页数据 查询订单
	 *
	 * @param dateType
	 *            1 拍单时间，2 更新时间，3 付款时间
	 *
	 * @return
	 */
	public AbsResponse<List<?>> catchTradesPerPage(Date startTime,
												   Date endTime, String status, boolean isFullFields);


	/**
	 * 增量每次查询一页数据 查询订单
	 *
	 * @param dateType
	 *            1 拍单时间，2 更新时间，3 付款时间
	 *
	 * @return
	 */
	public AbsResponse<List<?>> catchTradesIncPerPage(Date startTime,
													  Date endTime, String status, boolean isFullFields);

	/**
	 * 订单下载时判断是否还有下一页
	 *
	 * @return
	 */
	public boolean hasNext();

	/**
	 * 抓取平台订单数量
	 * @param startTime
	 * @param endTime
	 * @param status
	 * @return
	 */
	public int catchTradeCount(Date startTime, Date endTime, String status);

	/**
	 * 更新订单备注
	 *
	 * @param tid
	 * @param memo
	 * @return
	 */
	public AbsResponse<?> updateTradeMemo(String tid, String memo);

	/**
	 * 更新订单状态
	 *
	 * @param tid
	 * @param status
	 * @return
	 */
	public AbsResponse<?> updateTradeStatus(String tid, String status);

	/**
	 * 线上发货通知
	 *
	 * @param tid
	 *            平台订单号
	 * @param tmsCode
	 *            平台运输商编码
	 * @param tmsName
	 *            平台运输商名称
	 * @param outSid
	 *            快递单号
	 * @param weight
	 *            包裹重量
	 * @param subTids
	 *            备注
	 * @return
	 */
	public AbsResponse<?> shipNotice(String tid, String tmsCode, String tmsName,
									 String outSid, Double weight, boolean isSplit, String subTids);

	/**
	 * 为已授权的用户开通消息服务
	 * @return
	 */
	public AbsResponse<?> tmcUserPermit(String topics);

	/**
	 * 取消用户的消息服务
	 * @param nick
	 * @return
	 */
	public AbsResponse<?> tmcUserCancel(String nick, String userPlatform);
}
