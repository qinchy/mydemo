package com.wwwarehouse.xdw.datasync.outer.api.hardware;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.outer.URLConnectionApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IUnifiApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lidan.wu on 2017/6/20.
 */
public class UnifiApi implements IUnifiApi {
    private static Logger logger = LogManager.getLogger(UnifiApi.class);

    private String site = "default";
    private String version = "v5";
    private String baseUrl = "https://172.16.2.38:8443";
    private boolean isLoggedin = false;
    private String cookies;

    private URLConnectionApi urlApi;


    /**
     * 请求方法集合
     */
    private enum API_METHOD {
        LOGIN("/login"),
        DO_LOGIN("/api/login"),
        LOGOUT("/logout"),
        SITES("/api/self/sites"),
        CMD_STAMGR("/api/s/%s/cmd/stamgr"),
        UPD_USER("/api/s/%s/upd/user/%s"),
        All_USER("/stat/alluser"),
        STAT_STA("/stat/sta"),
        STAT_CLIENT("/stat/client"),
        LIST_USER_GROUP("/list/usergroup"),
        STAT_HEALTH("/stat/health"),
        STAT_DASHBOARD("/stat/dashboard"),
        LIST_USER("/list/user"),
        STAT_DEVICE("/stat/device"),
        CMD_SITEMGR("/cmd/sitemgr"),
        LIST_WLAN_GROUP("/list/wlangroup"),
        STAT_SYSINFO("/stat/sysinfo"),
        SELF("/self"),
        LIST_NETWORK_CONF("/list/networkconf"),
        LIST_HOTSPO_TOP("/list/hotspotop"),
        LIST_PORTFOR_WARD("/list/portforward"),
        LIST_DYNAMIC_DNS("/list/dynamicdns"),
        LIST_PORT_CONF("/list/portconf"),
        LIST_EXTENSION("/list/extension"),
        GET_SETTINGS("/get/setting"),
        STAT_EVENT("/stat/event"),
        LIST_WLAN_CONF("/list/wlanconf"),
        LIST_ALARM("/list/alarm"),




        REST_DEVICE("/rest/device/"),
        CMD_DEVMGR("/cmd/devmgr"),
        SET_SETTING_MGMT("/set/setting/mgmt"),
        SET_SETTING_GUEST_ACCESS("/set/setting/guest_access"),
        UPD_DEVICE("/upd/device"),

        ADD_WLANCONF("/add/wlanconf"),
        UPD_WLANCONF("/upd/wlanconf"),

        DEL_WLANCONF("/del/wlanconf/"),

        CNT_ALARM("/cnt/alarm");

        API_METHOD(String subPath) {
            this.subUrl = subPath;
        }

        private String subUrl;

        public String getSubPath() {
            return subUrl;
        }
    }

    public UnifiApi(String baseUrl, String site, String version) {
        urlApi = new URLConnectionApi(baseUrl,cookies);

        if (StringUtils.isNotEmpty(baseUrl)) {
            this.baseUrl = baseUrl;
        }
        if (StringUtils.isNotEmpty(site)) {
            this.site = site;
        }
        if (StringUtils.isNotEmpty(version)) {
            this.version = version;
        }
    }


    /**
     * Login to UniFi Controller
     */
    public boolean login(String username, String password) {
        Map<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("password", password);

        this.isLoggedin = false;
        try {
            Map<String, String> resp = urlApi.callApiWithCookie(API_METHOD.DO_LOGIN.getSubPath(), params, null);

            AbsResponse<JSONObject> abs = urlApi.isOK(resp.get("response"));
            if (!abs.isSuccess()){
                this.isLoggedin = false;
                return this.isLoggedin;
            }

            this.isLoggedin = true;
            this.cookies = resp.get("Set-Cookie");
            urlApi.setCookies(cookies);
        } catch (Exception e) {
            logger.error(username, e);
            this.isLoggedin = false;
        }

        return this.isLoggedin;
    }

    public boolean logout() {
        return false;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> sites() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.SITES.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("sites", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

//    /**
//     * Logout from UniFi Controller
//     */
//    public boolean logout() {
//        if (!this.isLoggedin) return false;
//        try {
//            String respContent = this.callApi(API_METHOD.LOGOUT.getSubPath(), null, null,METHOD_POST);
//            this.isLoggedin = false;
//            this.cookies = null;
//        } catch (IOException e) {
//            logger.error(e.getMessage(), e);
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * Authorize a client device
//     * -------------------------
//     * return true on success
//     * required parameter <mac>     = client MAC address
//     * required parameter <minutes> = minutes (from now) until authorization expires
//     * optional parameter <up>      = upload speed limit in kbps
//     * optional parameter <down>    = download speed limit in kbps
//     * optional parameter <MBytes>  = data transfer limit in MB
//     * optional parameter <ap_mac>  = AP MAC address to which client is connected, should result in faster authorization
//     */
//    public boolean authorizeGuest(String mac, String minutes, String up, String down, String MBytes, String apMac) {
//        if (!this.isLoggedin) {
//            return false;
//        }
//
//        if (StringUtils.isEmpty(mac)) {
//            return false;
//        }
//
//        mac = mac.toLowerCase();
//
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd", "authorize-guest");
//        params.put("mac", mac);
//        params.put("minutes", minutes);
//        if (StringUtils.isNotEmpty(up)) {
//            params.put("up", up);
//        }
//        if (StringUtils.isNotEmpty(down)) {
//            params.put("down", down);
//        }
//        if (StringUtils.isNotEmpty(MBytes)) {
//            params.put("MBytes", MBytes);
//        }
//        if (StringUtils.isNotEmpty(apMac)) {
//            params.put("ap_mac", apMac);
//        }
//
//        /**
//         * if we have received values for up/down/MBytes we append them to the payload array to be submitted
//         */
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.CMD_STAMGR, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("authorizeGuest", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param mac
//     * @return
//     * @throws IOException
//     */
//    public boolean unauthorizeGuest(String mac){
//        if(!this.isLoggedin){
//            return  false;
//        }
//        if (StringUtils.isEmpty(mac)) {
//            return false;
//        }
//        mac = mac.toLowerCase();
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd", "unauthorize-guest");
//        params.put("mac", mac);
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.CMD_STAMGR.getSubPath(), false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("unauthorizeGuest", e);
//            isOK = false;
//        }
//        return isOK;
//
//
//    }
//
//    /**
//     * @param mac
//     * @return
//     * @throws IOException
//     */
//    public boolean reconnectSta(String mac){
//        if(!this.isLoggedin){
//            return  false;
//        }
//
//        if (StringUtils.isEmpty(mac)) {
//            return false;
//        }
//        mac = mac.toLowerCase();
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd", "kick-sta");
//        params.put("mac", mac);
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.CMD_STAMGR, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("reconnectSta", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param mac
//     * @return
//     * @throws IOException
//     */
//    public boolean blockSta(String mac){
//        if(!this.isLoggedin){
//            return  false;
//        }
//
//        if (StringUtils.isEmpty(mac)) {
//            return false;
//        }
//        mac = mac.toLowerCase();
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd", "block-sta");
//        params.put("mac", mac);
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.CMD_STAMGR, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("blockSta", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param mac
//     * @return
//     * @throws IOException
//     */
//    public boolean unblockSta(String mac){
//        if(!this.isLoggedin){
//            return  false;
//        }
//
//        if (StringUtils.isEmpty(mac)) {
//            return false;
//        }
//        mac = mac.toLowerCase();
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd", "unblock-sta");
//        params.put("mac", mac);
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.CMD_STAMGR, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("unblockSta", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param userId
//     * @param note
//     * @return
//     * @throws IOException
//     */
//    public boolean setStaNote(String userId, String note){
//
//        if(!this.isLoggedin){
//            return  false;
//        }
//
//        boolean noted = StringUtils.isEmpty(note);
//        if (StringUtils.isEmpty(note)) {
//            noted = false;
//        }
//        Map<String, String> params = new HashMap<>();
//        params.put("note", "note");
//        params.put("noted", String.valueOf(noted));
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.UPD_USER, false, this.site, userId);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("setStaNote", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param pptId
//     * @param name
//     * @return
//     * @throws IOException
//     */
//    public boolean setStaName(String pptId,String name){
//
//        if(!this.isLoggedin){
//            return  false;
//        }
//
//        Boolean noted = true;
//        if (StringUtils.isEmpty(name)) {
//            noted = false;
//        }
//        Map<String, String> params = new HashMap<>();
//        params.put("name", "name");
//        boolean isOK;
//        try {
//            String subUrl = buildUrl(API_METHOD.UPD_USER, false, this.site, pptId);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("setStaName", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param  historyhours
//     * @return
//     * @throws IOException
//     */
//    public List<Object> statAllUsers(Long  historyhours){
//
//        if(!this.isLoggedin){
//            return null;
//        }
//        if(historyhours == null){
//            historyhours = 8760L;
//        }
//        Map<String, String> params = new HashMap<>();
//        params.put("type", "all");
//        params.put("conn", "all");
//        params.put("within", historyhours.toString());
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.All_USER, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("statAllUsers", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @param  within
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listGuests(Long within){
//
//        //       if(!this.isLoggedin){
//        //           return null;
//        //       }
//        if(within == null){
//            within = 8760L;
//        }
//        Map<String, String> params = new HashMap<>();
//        params.put("within", within.toString());
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.STAT_STA, false, this.site);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("listGuests", e);
//        }
//        return listMap;
//    }


//    /**
//     * @param  clientMac
//     * @return
//     * @throws IOException
//     */
//    public List<Object> statClient(String clientMac){
//
//        if(!this.isLoggedin){
//            return null;
//        }
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.STAT_STA, false, clientMac);
//            String resp = callApi(subUrl, null, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("statClient", e);
//        }
//        return listMap;
//    }
//
//
//    /**
//     * @param  clientMac
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listClients(String clientMac){
//
//        if(!this.isLoggedin){
//            return null;
//        }
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.STAT_CLIENT.getSubPath(), false, clientMac);
//            String resp = callApi(subUrl, null, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("listClients", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @param  clientMac
//     * @return
//     * @throws IOException
//     */
//    public List<Object> statClients(String clientMac){
//
//        if(!this.isLoggedin){
//            return null;
//        }
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.All_USER.getSubPath(), false, clientMac);
//            String resp = callApi(subUrl, null, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("statClients", e);
//        }
//        return listMap;
//    }
//
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listUserGroups(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_USER_GROUP.getSubPath(),null);}
//        catch (Exception e) {
//            logger.error("listUserGroups", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @param  pptId
//     * @param  groupId
//     * @return
//     * @throws IOException
//     */
//    public boolean setUserGroups(String pptId, String groupId){
//        if(!this.isLoggedin){
//            return false;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        Map<String, String> params = new HashMap<>();
//        params.put("usergroup_id",groupId);
//        try {
//            String subUrl = buildUrl(API_METHOD.UPD_USER, false, pptId);
//            String resp = callApi(subUrl, params, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("setUserGroups", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listHealth(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.STAT_HEALTH.getSubPath(),null);}
//        catch (Exception e) {
//            logger.error("listHealth", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listDashboard(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.STAT_DASHBOARD.getSubPath(),null);}
//        catch (Exception e) {
//            logger.error("listDashboard", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public boolean listUser(){
//
//        if(!this.isLoggedin){
//            return false;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.LIST_USER, false);
//            String resp = callApi(subUrl, null, null,METHOD_POST);
//            AbsResponse<JSONObject> abs = isOK(resp);
//            isOK = abs.isSuccess();
//        } catch (Exception e) {
//            logger.error("listUser", e);
//            isOK = false;
//        }
//        return isOK;
//    }
//
//    /**
//     * @param deviceMac
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listAps(String deviceMac){
//
//        if(!this.isLoggedin){
//            return null;
//        }
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            String subUrl = buildUrl(API_METHOD.STAT_DEVICE, false, deviceMac);
//            String resp = callApi(subUrl, null, null,METHOD_POST);
//            AbsResponse<JSONObject> isOK = isOK(resp);
//            JSONObject jsonObject = isOK.getData();
//            if(isOK.isSuccess()) {
//                JSONArray jsonArray = jsonObject.getJSONArray("data");
//                if(jsonArray == null){
//                    return  null;
//                }
//                boolean isArray  = jsonArray.getClass().isArray();
//                if(isArray){
//                    for(int i = 0; i<jsonArray.size(); i++){
//                        JSONObject jsonObj  = jsonArray.getJSONObject(i);
//                        listMap.add(jsonObj);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("listAps", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listAdmins(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        Map<String, String> params = new HashMap<>();
//        params.put("cmd","get-admins");
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.CMD_SITEMGR.getSubPath(),params);}
//        catch (Exception e) {
//            logger.error("listAdmins", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listWlanGroups(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_WLAN_GROUP.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listWlanGroups", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> statSysinfo(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.STAT_SYSINFO.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("statSysinfo", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listSelf(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//
//            listMap = listProduce(API_METHOD.SELF.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listSelf", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listNetworkConf(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_NETWORK_CONF.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listNetworkConf", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listHotspotop(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_HOTSPO_TOP.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listHotspotop", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listPortforwarding(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_PORTFOR_WARD.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listPortforwarding", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listDynamicdns(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_DYNAMIC_DNS.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listDynamicdns", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listPortconf(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_PORT_CONF.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listPortconf", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listExtension(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_EXTENSION.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listExtension", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listSettings(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.GET_SETTINGS.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listSettings", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listEvents(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.STAT_EVENT.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listEvents", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listWlanconf(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_WLAN_CONF.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listWlanconf", e);
//        }
//        return listMap;
//    }
//
//    /**
//     * @return
//     * @throws IOException
//     */
//    public List<Object> listAlarms(){
//        if(!this.isLoggedin){
//            return null;
//        }
//        boolean isOK;
//        List<Object> listMap = new ArrayList<Object>();
//        try {
//            listMap = listProduce(API_METHOD.LIST_ALARM.getSubPath(),null) ;}
//        catch (Exception e) {
//            logger.error("listAlarms", e);
//        }
//        return listMap;
//    }
//
//
//
//    /**
//     * @param  key
//     * @return
//     * @throws IOException
//     */
//    private List<Object> listProduce(String key, Map<String, String> params) throws Exception {
//        if (!this.isLoggedin) {
//            return null;
//        }
//        AbsResponse<JSONObject> isOK;
//        List<Object> listMap = new ArrayList<>();
//        String subUrl = buildUrl(key, false);
//        String resp = callApi(subUrl, params, null,METHOD_POST);
//        isOK = isOK(resp);
//        JSONObject jsonObject = isOK.getData();
//        if (isOK.isSuccess()) {
//            JSONArray jsonArray = jsonObject.getJSONArray("data");
//            if (jsonArray == null) {
//                return null;
//            }
//            boolean isArray = jsonArray.getClass().isArray();
//            if (isArray) {
//                for (int i = 0; i < jsonArray.size(); i++) {
//                    JSONObject jsonObj = jsonArray.getJSONObject(i);
//                    listMap.add(jsonObj);
//                }
//            }
//        }
//
//        return listMap;
//    }


    /**
     * @return
     * @throws IOException
     */
    public List<Object> cntAlarm() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.CNT_ALARM.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("cntAlarm", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> delWlanConf() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.DEL_WLANCONF.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("delWlanConf", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> updWlanConf() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.UPD_WLANCONF.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("updWlanConf", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> addWlanConf() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.ADD_WLANCONF.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("addWlanConf", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }


    /**
     * @return
     * @throws IOException
     */
    public List<Object> updDevice() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.UPD_DEVICE.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("updDevice", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }


    /**
     * @return
     * @throws IOException
     */
    public List<Object> settingGuestAccess() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.SET_SETTING_GUEST_ACCESS.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("settingGuestAccess", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> settingMgmt() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.SET_SETTING_MGMT.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("settingMgmt", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> restDevice() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.CMD_DEVMGR.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("restDevice", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

    /**
     * @return
     * @throws IOException
     */
    public List<Object> devmgr() {
        if (!this.isLoggedin) {
            return new ArrayList<>();
        }
        Map<String, String> result ;
        List<Object> listMap = new ArrayList<>();
        try {
            result = urlApi.callGetApi(API_METHOD.REST_DEVICE.getSubPath(), null, null);
            AbsResponse<JSONObject> isOK = urlApi.isOK(result.get("response"));
            JSONObject jsonObject = isOK.getData();
            if (isOK.isSuccess()) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray == null) {
                    return null;
                }
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    listMap.add(jsonObj);
                }
            }
        } catch (Exception e) {
            logger.error("restDevice", e);
        }
        System.out.println(listMap.size());
        return listMap;
    }

}
