package com.wwwarehouse.xdw.datasync.outer.api.interfaces;


import com.wwwarehouse.commons.utils.AbsResponse;

public interface IShopApi extends IRecordAble {
	
	/**
	 * 获取店铺信息
	 * @param nick
	 * @return
	 */
	public AbsResponse<?> getShop(String nick) throws Exception;

}
