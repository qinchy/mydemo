package com.wwwarehouse.xdw.datasync.outer.api.ots;

import com.jd.open.api.sdk.JdClient;
import com.jd.open.api.sdk.JdException;
import com.jd.open.api.sdk.internal.parser.Parser;
import com.jd.open.api.sdk.internal.parser.ParserFactory;
import com.jd.open.api.sdk.internal.util.CodecUtil;
import com.jd.open.api.sdk.internal.util.HttpUtil;
import com.jd.open.api.sdk.internal.util.StringUtil;
import com.jd.open.api.sdk.request.JdRequest;
import com.jd.open.api.sdk.request.JdUploadRequest;
import com.jd.open.api.sdk.response.AbstractResponse;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class DefaultJdClient implements JdClient {
	private static final String CHARSET_UTF8 = "UTF-8";
	private static final String JSON_PARAM_KEY = "360buy_param_json";
	private Map<String, String> otsSysParams;
	private String serverUrl;
	private String accessToken;
	private int connectTimeout = 10000;
	private int readTimeout = 20000;
	private String appKey;
	private String appSecret;
	
	private String format = "json";

	public DefaultJdClient(String serverUrl, String accessToken, String appKey,
			String appSecret) {
		this.serverUrl = serverUrl;
		this.accessToken = accessToken;
		this.appKey = appKey;
		this.appSecret = appSecret;
	}

	public DefaultJdClient(String serverUrl, String accessToken, String appKey,
			String appSecret, int connectTimeout, int readTimeout) {
		this(serverUrl, accessToken, appKey, appSecret);
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
	}
	public DefaultJdClient(Map<String, String> otsSysParams, String serverUrl, String accessToken, String appKey,
			String appSecret, int connectTimeout, int readTimeout) {
		this(serverUrl, accessToken, appKey, appSecret);
		this.otsSysParams = otsSysParams;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
	}

	public <T extends AbstractResponse> T execute(JdRequest<T> request)
			throws JdException {
		try {
			String url = buildUrl(request);

			Map<String, String> params = new HashMap<>();
			String json = request.getAppJsonParams();
			params.put(JSON_PARAM_KEY, json);

			String rsp = null;
			if ((request instanceof JdUploadRequest)) {
				rsp = HttpUtil.doPost(url, params, ((JdUploadRequest) request).getFileParams(),
						this.connectTimeout, this.readTimeout);
			} else {
				rsp = HttpUtil.doPost(url, params, this.connectTimeout, this.readTimeout);
			}
			T resp = parse(rsp, request.getResponseClass());
			StringBuffer sb = new StringBuffer();
			sb.append(url).append("&").append(JSON_PARAM_KEY).append("=")
					.append(json);

			resp.setUrl(sb.toString());

			return resp;
		} catch (Exception e) {
			throw new JdException(e);
		}
	}

	private <T extends AbstractResponse> String buildUrl(JdRequest<T> request)
			throws Exception {
		Map<String, String> sysParams = request.getSysParams();

		Map<String, String> pmap = new TreeMap<>();
		pmap.put(JSON_PARAM_KEY, request.getAppJsonParams());
		sysParams.put("method", request.getApiMethod());
		sysParams.put("access_token", this.accessToken);
		sysParams.put("app_key", this.appKey);
		pmap.putAll(sysParams);

		String sign = sign(pmap, this.appSecret);

		sysParams.put("sign", sign);
		StringBuilder sb = new StringBuilder(this.serverUrl);
		if (this.serverUrl.contains("?")) {				/*iscs,地址修改*/
			sb.append("&");
		} else {
			sb.append("?");
		}
		if(this.otsSysParams != null && !this.otsSysParams.isEmpty()){
			sysParams.putAll(otsSysParams);/*iscs,添加ots授权信息*/
		}
		sb.append(HttpUtil.buildQuery(sysParams, CHARSET_UTF8));
		return sb.toString();
	}

	private <T extends AbstractResponse> T parse(String rsp,
			Class<T> responseClass) throws JdException {
		Parser parser;
		if ("json".equals(format)) {/*iscs 修改*/
			parser = ParserFactory.getJsonParser();
		} else {
			parser = ParserFactory.getXmlParser();
		}
		return parser.parse(rsp, responseClass);
	}

	private String sign(Map<String, String> pmap, String appSecret)
			throws Exception {
		StringBuilder sb = new StringBuilder(appSecret);
		for (Map.Entry<String, String> entry : pmap.entrySet()) {
			String name = (String) entry.getKey();
			String value = (String) entry.getValue();
			if (StringUtil.areNotEmpty(new String[] { name, value })) {
				sb.append(name).append(value);
			}
		}
		sb.append(appSecret);
		String result = CodecUtil.md5(sb.toString());

		return result;
	}
}
