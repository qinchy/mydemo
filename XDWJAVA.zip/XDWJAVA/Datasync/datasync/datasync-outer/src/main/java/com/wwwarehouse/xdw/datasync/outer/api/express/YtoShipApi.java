package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.BaseRequestApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaExpressCode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Element;

import java.security.MessageDigest;
import java.util.*;


/**
 * 圆通快递
 *
 * @author wangshisheng
 *         错误代码(暂用,等完善了再定义ErrorCode):
 *         101参数非法 102快递公司返回错误 103网络错误 100 其他
 */
public class YtoShipApi extends BaseRequestApi implements IShipApi {

    private static Logger log = LogManager.getLogger(YtoShipApi.class);

    //	private static final String API_URL = "http://jingang.yto56.com.cn/ordws/VipOrderServlet";
    private final static String API_URL = "http://58.32.246.70:8002";

    private static final String VERSION = "1.01";
    private final static String USER_ID = "wc3h_test_2016";
    private final static String APP_KEY = "axedpa";
    private final static String SECRET = "vjnM60";
    private final static String CHARSET = "utf-8";

    private static final String ORDER_URL = "CommonOrderModeBPlusServlet.action";
    private static final String ORD_URL = "CommonOrderServlet.action";
    private static final String OUTSID_URL = "api!synWaybill.action";

    private String customerCode;
    private String password;
    private String charset = "utf-8";
    //private String apiUrl;

    private static final String materialCodeNotCod = "DZ100301"; // 材料非货到付款
    private static final String materialCodeCod = "DZ100302";  // 材料货到付款

    /**
     * 已签收
     */
    private static final String LOGISTICS_STATUS_SIGN = "1";
    /**
     * 运输中
     */
    private static final String LOGISTICS_TRANSPORTING = "2";

    private static Map<String, String> shipStatus;
    private static Map<String, String> errorCode;

    static {
        shipStatus = new HashMap<String, String>();
        shipStatus.put("CONFIRM", "等待确认");
        shipStatus.put("ACCEPT", "接单");
        shipStatus.put("UNACCEPT", "不接单");
        shipStatus.put("GOT", "揽收成功");
        shipStatus.put("NOT_SEND", "揽收失败");
        shipStatus.put("SENT_SCAN", "派件扫描");
        shipStatus.put("TRACKING", "流转信息");
        shipStatus.put("SIGNED", "签收成功");
        shipStatus.put("FAILED", "签收失败");
        shipStatus.put("WITHDRAW", "订单已取消");

        errorCode = new HashMap<String, String>();
        errorCode.put("R01", "揽收地超服务范围");
        errorCode.put("R02", "派送地超服务范围");
        errorCode.put("R03", "揽收预约时间超范围，无法协商");
        errorCode.put("R04", "虚假揽货电话（客户电话与联系人不符）");
        errorCode.put("R05", "用户取消投递");
        errorCode.put("R06", "托寄物品为禁限寄品");
        errorCode.put("R07", "用户恶意下单");
        errorCode.put("R08", "揽收地址错误");
        errorCode.put("R09", "上门后用户不接受价格");
        errorCode.put("R10", "用户取消投递（非包装问题）");
        errorCode.put("R11", "托寄物品超规格");
        errorCode.put("R12", "用户拒绝开箱验货");
        errorCode.put("R13", "多次联系，无法联系上发货方");
        errorCode.put("R14", "用户要求延时揽收（需用户网上重新发货）");
        errorCode.put("R15", "用户包装问题，取消投递");
        errorCode.put("R16", "收件人拒收（未验货）");
        errorCode.put("R17", "收件人拒收（验货，货不对款）");
        errorCode.put("R18", "收件人拒付或仅愿意部分支付");
        errorCode.put("R19", "收件人拒收（因拖寄物品破损）");
        errorCode.put("R20", "收件人拒收（代收货款价格不对）");
        errorCode.put("R21", "超时无法投递");
        errorCode.put("R22", "托寄物品丢失");
        errorCode.put("R23", "无法联系上收件人");
        errorCode.put("R24", "错误收件人联系方式及地址");
        errorCode.put("R25", "黑名单客户");
        errorCode.put("R99", "其他原因");

        errorCode.put("S01", "非法的XML格式");
        errorCode.put("S02", "非法的数字签名");
        errorCode.put("S03", "没有剩余单号");
        errorCode.put("S04", "接口请求参数为空：logistics_interface, data_digest或clientId");
        errorCode.put("S05", "唯品会专用");
        errorCode.put("S06", "请求太快");
        errorCode.put("S07", "url解码失败");
        errorCode.put("S08", "订单号重复：订单号+客户编码+orderType全部重复则为重复");
        errorCode.put("S08", "数据库异常");

        errorCode.put("B01", "不能进行操作，当前状态是：等待确认");
        errorCode.put("B02", "不能进行操作，当前状态是：接单");
        errorCode.put("B03", "不能进行操作，当前状态是：不接单");
        errorCode.put("B04", "不能进行操作，当前状态是：揽收成功");
        errorCode.put("B05", "不能进行操作，当前状态是：揽收失败");
        errorCode.put("B06", "不能进行操作，当前状态是：签收成功");
        errorCode.put("B07", "不能进行操作，当前状态是：签收失败");
        errorCode.put("B08", "不能进行操作，当前状态是：订单已取消");
        errorCode.put("B09", "不能进行操作，运单号为空");
        errorCode.put("B10", "不能进行操作，签收信息为空(包括运单号、签收姓名、签收时间不能为空)");
        errorCode.put("B99", "非法的物流订单号");
        errorCode.put("200", "请求成功");
    };

    public YtoShipApi() {
        this.apiUrl = "http://58.32.246.71:8000/";//测试环境
        // K21000119, 面单号不够了
        this.password = "u2Z1F7Fh";
        this.customerCode = "K21000119";
//		this.password = "6owY3zeG";
//		this.customerCode = "K57100732";
    }



    //跟踪快递物流信息
    @Override
    public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {
        String requestParam = null;
        String resp = null;


        try {
            requestParam = buildFollowShipRequest(outSid);

            String ctype = "application/x-www-form-urlencoded;charset=" + CHARSET;
            resp = WebUtils.doPost(API_URL, ctype, requestParam.getBytes(), 25000, 25000);

            Element root = XmlUtils.getRootElementFromString(resp);
            String success = XmlUtils.getChildElementValue(root, "success");
            if (success != null && "false".equals(success.toLowerCase())) {
                throw new IscsException(102, XmlUtils.getChildElementValue(root, "reason"));
            }

            List<TmLogisticsTrackingOriginal> logisticsInfoList = parseResponseXml(root);

            LogisticsInformation logisticsInformation = new LogisticsInformation();
            List<LogisticsInfomationDetail> logisticsInfomationDetailList = new ArrayList<>();
            logisticsInfoList.forEach(tmLogisticsTrackingOriginal -> {
                LogisticsInfomationDetail logisticsInfomationDetail = new LogisticsInfomationDetail();
                logisticsInfomationDetail.setDescription(tmLogisticsTrackingOriginal.getLogisticsInfo());//物流信息
                logisticsInfomationDetail.setOperatingTime(tmLogisticsTrackingOriginal.getLogisticsTime());//物流时间
                logisticsInfomationDetail.setStatus(Long.parseLong(tmLogisticsTrackingOriginal.getLogisticsStatus()));//物流状态
                logisticsInfomationDetailList.add(logisticsInfomationDetail);
            });
            logisticsInformation.setInfomationDetails(logisticsInfomationDetailList);


            return logisticsInformation;
            //return new AbsResponse<>(0, "", null, logisticsInfoList);

        } catch (Exception e) {
            log.error("圆通物流跟踪处理失败, outSid:" + outSid, e);
            throw e;
        } finally {
            //TODO
            //appendReqAResp(API_URL, new Date(), requestParam, null, resp);
        }
    }


    //创建物流单,获取电子面单
    @Override
    public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {


        if (expressOrderInfo == null || StringUtils.isEmpty(expressOrderInfo.getOrderId())) {
            throw new IscsException(101, expressOrderInfo.getClass().getSimpleName() + " 为空 或者 缺少订单号");
        }

        ExpressYTOOrderInfoDTO ytoOrderInfoDTO = (ExpressYTOOrderInfoDTO) expressOrderInfo;

		/*if(order == null){
            return retBean.setResult(101, "订单为空");
		}*/


        String outSid = ytoOrderInfoDTO.getExpressId(); // 获取已经申请的快递单号(快递面单号)
        String orderId = ytoOrderInfoDTO.getOrderId(); // 自己创建的id
        boolean isCod = false;
        String codValue = "0"; // COD费用
        String totalValue = "0"; // COD费用

        // 发件人信息
        ExpressShiperDetail senderDetail = ytoOrderInfoDTO.getSendShiperDetail();//发件人
        String senderProvice = senderDetail.getProvinceStr();
        String senderCity = senderDetail.getCityStr();
        String senderCounty = senderDetail.getConuntyStr();
        String senderAddress = senderDetail.getAddress();
        // 收件人信息
        ExpressShiperDetail receiverDetail = ytoOrderInfoDTO.getReceiverShiperDetail();
        String receiverProvice = receiverDetail.getProvinceStr();
        String receiverCity = receiverDetail.getCityStr();
        String receiverCounty = receiverDetail.getConuntyStr();
        String receiverAddress = receiverDetail.getAddress();

        Element qroot = XmlUtils.createRootElement("RequestOrder");

        XmlUtils.appendElement(qroot, "clientID", this.customerCode);
        XmlUtils.appendElement(qroot, "logisticProviderID", "YTO");
        XmlUtils.appendElement(qroot, "customerId", this.customerCode);
        XmlUtils.appendElement(qroot, "txLogisticID", orderId); // 物流订单号
        XmlUtils.appendElement(qroot, "tradeNo", ""); // 业务交易号
        XmlUtils.appendElement(qroot, "mailNo", outSid);
        XmlUtils.appendElement(qroot, "type", "1"); // 订单类型.向下兼容
        XmlUtils.appendElement(qroot, "orderType", isCod ? "0" : "1"); // 订单类型(0-COD,1-普通订单,3-退货单)
        XmlUtils.appendElement(qroot, "serviceType", "0"); // 服务类型(1-上门揽收, 2-次日达 4-次晨达 8-当日达,0-自己联系)
        XmlUtils.appendElement(qroot, "flag", "0");
        XmlUtils.appendElement(qroot, "codSplitFee", "0");
        XmlUtils.appendElement(qroot, "sendStartTime", DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        XmlUtils.appendElement(qroot, "sendEndTime", DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        XmlUtils.appendElement(qroot, "goodsValue", "0"); // 商品金额，包括优惠和运费，但无服务费。
        XmlUtils.appendElement(qroot, "itemsValue", isCod ? codValue : "0"); // COD费用
        XmlUtils.appendElement(qroot, "agencyFund", isCod ? codValue : "0");
        XmlUtils.appendElement(qroot, "insuranceValue", "0"); // 保价金额
        XmlUtils.appendElement(qroot, "special", "0"); // 商品类型
        XmlUtils.appendElement(qroot, "itemsWeight", "100"); //货物总重量
        XmlUtils.appendElement(qroot, "remark", ""); // 备注
        XmlUtils.appendElement(qroot, "totalValue", totalValue); // 总费用
        // 发件人信息
        Element sender = XmlUtils.appendElement(qroot, "sender"); // 发件人信息
        XmlUtils.appendElement(sender, "name", senderDetail.getName()); // 用户姓名
        XmlUtils.appendElement(sender, "postCode", senderDetail.getPostcode()); //
        XmlUtils.appendElement(sender, "phone", senderDetail.getPhone()); //
        XmlUtils.appendElement(sender, "mobile", senderDetail.getMobile()); //
        XmlUtils.appendElement(sender, "prov", senderProvice); //
        XmlUtils.appendElement(sender, "city", senderCity + "," + senderCounty); // 用户所在市县（区）
        XmlUtils.appendElement(sender, "address", senderProvice + "," + senderCity + "," + senderCounty + senderAddress); //
        // 收件人信息
        Element receiver = XmlUtils.appendElement(qroot, "receiver");
        XmlUtils.appendElement(receiver, "name", receiverDetail.getName()); // 用户姓名
        XmlUtils.appendElement(receiver, "city", receiverCity + "," + receiverCounty); // 用户所在市县（区）
        XmlUtils.appendElement(receiver, "address", receiverProvice + "," + receiverCity + "," + receiverCounty + receiverAddress); //
        XmlUtils.appendElement(receiver, "postCode", receiverDetail.getPostcode()); //
        XmlUtils.appendElement(receiver, "phone", receiverDetail.getPhone()); //
        XmlUtils.appendElement(receiver, "mobile", receiverDetail.getMobile()); //
        XmlUtils.appendElement(receiver, "prov", receiverProvice); //
        // 商品信息
        Element items = XmlUtils.appendElement(qroot, "items");
        int qty = 0;
        for (ShipOrderItemDTO seitem : ytoOrderInfoDTO.getShipOrderItemDTOS()) {
            qty += seitem.getNumber();
            Element item = XmlUtils.appendElement(items, "item");
            XmlUtils.appendElement(item, "itemName", seitem.getName()); //
            XmlUtils.appendElement(item, "itemValue", "0"); // 商品单价
            XmlUtils.appendElement(item, "number", "" + seitem.getNumber()); //
            if (qty >= 10) { // 无需显示更多商品信息
                break;
            }
        }
        // 记录日志?

        String xmlString = XmlUtils.nodeToString(qroot);
        // 请求
        String method = null;
        //method = ORDER_URL;
        if (StringUtils.isEmpty(outSid)) {
            method = ORDER_URL;
        } else {
            method = ORD_URL;
        }
        String resp = callApi(method, xmlString);
        // 解析返回字符串
        Element root = XmlUtils.getRootElementFromString(resp);
        String success = XmlUtils.getChildElementValue(root, "success");
        String mailNo = XmlUtils.getChildElementValue(root, "mailNo");


        if ("true".equalsIgnoreCase(success)) { // 返回正确
            Element distributeInfo = XmlUtils.getChildElement(root, "distributeInfo");
            String shortAddress = XmlUtils.getChildElementValue(distributeInfo, "shortAddress");



			/*retBean.setCode(0);
			TmTmsOrderCode code = new TmTmsOrderCode();
			code.setOutSid(mailNo);
			code.setMarkDestinationCode(shortAddress);
			code.setRelatedOrderCode(orderId);
			code.setRelatedOrderUkid(Long.valueOf(orderId));
			code.setProcessStatus(1);
			retBean.setData(code);*/
        } else {
            //retBean.setCode(102);
            String reason = XmlUtils.getChildElementValue(root, "reason");
			/*if(errorCode.containsKey(reason)){
				retBean.setMsg(errorCode.get(reason));
			} else {
				retBean.setMsg(reason);
			}*/
        }

		/*if("true".equalsIgnoreCase(success)){ // 返回正确
			Element distributeInfo = XmlUtils.getChildElement(root, "distributeInfo");
			String shortAddress = XmlUtils.getChildElementValue(distributeInfo, "shortAddress");
			retBean.setCode(0);
			TmTmsOrderCode code = new TmTmsOrderCode();
			code.setOutSid(mailNo);
			code.setMarkDestinationCode(shortAddress);
			code.setRelatedOrderCode(orderId);
			code.setRelatedOrderUkid(Long.valueOf(orderId));
			code.setProcessStatus(1);
			retBean.setData(code);
		} else {
			retBean.setCode(102);
			String reason = XmlUtils.getChildElementValue(root, "reason");
			if(errorCode.containsKey(reason)){
				retBean.setMsg(errorCode.get(reason));
			} else {
				retBean.setMsg(reason);
			}
		}*/

        return null;
    }


    //批量获取物流订单
    @Override
    public List generateExpressInfos(List expressOrderInfoDTOs) throws Exception {
        //wendong.huTODO 暂时这么写
        throw new IscsException("圆通没有批量获取物流订单接口!");
    }

    //上传重量
    @Override
    public void uploadWeight(List list) throws Exception {
        //wendong.huTODO 暂时这么写
        throw new IscsException("圆通没有单独的上传重量接口!");
    }


    //取消订单
    @Override
    public void cancelExpressOrder(String orderId, String outSid) throws Exception {

        if (StringUtils.isEmpty(orderId) || StringUtils.isEmpty(outSid)) {
            throw new IscsException("圆通取消订单缺少参数orderId 或者 outSid");
        }

        Element qroot = XmlUtils.createRootElement("UpdateInfo");

        XmlUtils.appendElement(qroot, "clientID", customerCode);
        XmlUtils.appendElement(qroot, "logisticProviderID", "YTO");
        XmlUtils.appendElement(qroot, "txLogisticID", orderId);
        XmlUtils.appendElement(qroot, "infoType", "INSTRUCTION");
        XmlUtils.appendElement(qroot, "infoContent", "WITHDRAW");
        XmlUtils.appendElement(qroot, "mailNo", outSid); // 可去掉
        XmlUtils.appendElement(qroot, "remark", "订单作废");

        // 请求
        String q = XmlUtils.nodeToString(qroot);
        String resp = callApi(ORDER_URL, q);

        // 解析返回字符串
        Element root = XmlUtils.getRootElementFromString(resp);
        String success = XmlUtils.getChildElementValue(root, "success");

        if(!"true".equalsIgnoreCase(success)){
            String reason = XmlUtils.getChildElementValue(root, "reason");
            String errorMsg;
            if(errorCode.containsKey(reason)){
                errorMsg = errorCode.get(reason);
            } else {
                errorMsg = reason;
            }
            //wendong.huTODO 暂时不返回错误码
            throw new IscsException(errorMsg);
        }
    }


    private List<TmLogisticsTrackingOriginal> parseResponseXml(Element root) {

        Element resultElement = XmlUtils.getChildElement(root, "Result");
        List<Element> waybillProcessInfoList = XmlUtils.getChildElements(resultElement);
        List<TmLogisticsTrackingOriginal> logisticsTrackingList = new ArrayList<>();

        for (Element waybillElement : waybillProcessInfoList) {
            String waybillNo = XmlUtils.getChildElementValue(waybillElement, "Waybill_No");
            String uploadTime = XmlUtils.getChildElementValue(waybillElement, "Upload_Time");
            String processInfo = XmlUtils.getChildElementValue(waybillElement, "ProcessInfo");

            TmLogisticsTrackingOriginal vo = new TmLogisticsTrackingOriginal();
            vo.setLogisticsCompanyCode(BaExpressCode.YTO.getExpCode());
            vo.setLogisticsCompanyName(BaExpressCode.YTO.getExpName());
            vo.setLogisticsInfo(processInfo);
            vo.setLogisticsStatus(getLogisticsStatus(processInfo));
            vo.setOutSid(waybillNo);
            vo.setLogisticsTime(DateUtil.parse(uploadTime, "yyyy-MM-dd HH:mm:ss"));

            logisticsTrackingList.add(vo);
        }

        return logisticsTrackingList;
    }

    private String getLogisticsStatus(String processInfo) {

        if (processInfo != null && processInfo.indexOf("已签收") >= 0) {
            return LOGISTICS_STATUS_SIGN;
        }
        return LOGISTICS_TRANSPORTING;
    }

    private String buildFollowShipRequest(String outsids) throws Exception {

        String param = "<?xml version=\"1.0\"?> <ufinterface> <Result> <WaybillCode> <Number>" + outsids
                + "</Number> </WaybillCode> </Result> </ufinterface>";

        String timestamp = DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss");
        String signSecret = sign(timestamp);
        StringBuilder sb = new StringBuilder();
        sb.append("sign=").append(signSecret).append("&");
        sb.append("app_key=").append(APP_KEY).append("&");
        sb.append("format=").append("XML").append("&");
        sb.append("method=").append("yto.Marketing.WaybillTrace").append("&");
        sb.append("timestamp=").append(timestamp).append("&");
        sb.append("user_id=").append(USER_ID).append("&");
        sb.append("v=").append(VERSION).append("&");
        sb.append("param=").append(param);

        return sb.toString();
    }

    private String sign(String timestamp) throws Exception {

        StringBuilder sb = new StringBuilder();

        sb.append(SECRET);
        sb.append("app_key").append(APP_KEY);
        sb.append("format").append("XML");
        sb.append("method").append("yto.Marketing.WaybillTrace");
        sb.append("timestamp").append(timestamp);
        sb.append("user_id").append(USER_ID);
        sb.append("v").append(VERSION);

        return md5(sb.toString()).toUpperCase();
    }

    //通知接受成功
    private boolean respTmsOrderCode(String sequence) throws Exception {
        Element qroot = XmlUtils.createRootElement("MailNoRequest");
        XmlUtils.appendElement(qroot, "customerCode", customerCode);
        XmlUtils.appendElement(qroot, "sequence", sequence);
        String q = XmlUtils.nodeToString(qroot);
        // 请求
        String resp = callApi(ORDER_URL, q);
        // 解析返回字符串
        Element root = XmlUtils.getRootElementFromString(resp);
        String success = XmlUtils.getChildElementValue(root, "success");
        if ("true".equalsIgnoreCase(success)) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 获取签名
     *
     * @param
     * @return
     * @throws Exception
     */
    private String md5(String str) throws Exception {

        StringBuffer sb = new StringBuffer();

        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(str.getBytes("UTF-8"));
        byte[] data = md.digest();
        int index;
        for (byte b : data) {
            index = b;
            if (index < 0)
                index += 256;
            if (index < 16)
                sb.append("0");
            sb.append(Integer.toHexString(index));
        }
        return sb.toString();
    }

    private String callApi(String method, String xml) throws Exception {
        String responseString = null;
        Date reqDate = new Date();
        Map<String, String> params = new HashMap<>();
        String apiUrl = this.apiUrl + method;
        try {
//    		params.put("logistics_interface", lowerCase(URLEncoder.encode(xml, charset)));
//    		String dataDigestMd5 = lowerCase(URLEncoder.encode(new String(CodecUtils.encodeBase64(CodecUtils.encryptMD5((xml + password).getBytes("utf-8")))), charset));
//			params.put("data_digest", dataDigestMd5);
//    		params.put("type", "offline");
//    		params.put("clientId", this.customerCode);

            params.put("logistics_interface", xml);
            String dataDigestMd5 = new String(CodecUtils.encodeBase64(CodecUtils.encryptMD5((xml + password))));
            params.put("data_digest", dataDigestMd5);
            params.put("type", "offline");
            params.put("clientId", this.customerCode);
            if (log.isDebugEnabled()) {
                log.debug("和YTO交互, 请求数据:" + params);
            }
            responseString = WebUtils.doPost(apiUrl, params);

        } catch (Exception e) {
            log.error("callApi error", e);
            if (null == responseString) {
                responseString = e.getMessage();
            }
            throw e;
        } finally {
            //TODO
            //appendReqAResp(apiUrl, reqDate, null, params, responseString);
            if (log.isDebugEnabled()) {
                log.debug("和YTO交互, 返回数据:" + responseString);
            }
        }

        return responseString;
    }

    /**
     * 将%xx后的2字符转为小写
     *
     * @param str
     * @return
     */
    private String lowerCase(String str) {
        char[] ch = str.toCharArray();
        char chFind = '%';
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == chFind) {
                ch[(i + 1)] = String.valueOf(ch[(i + 1)]).toLowerCase()
                        .charAt(0);
                ch[(i + 2)] = String.valueOf(ch[(i + 2)]).toLowerCase()
                        .charAt(0);
                i += 2;
            }
        }
        return String.valueOf(ch);
    }


    @Override
    public void appendReqAResp(String apiMethod, Date reqDate, String reqString, Map<String, String> params, Map<String, String> headerParams, String responseString) {

    }

    @Override
    public List<AmRequestLogDTO> getAccessLogList() {
        return null;
    }
}
