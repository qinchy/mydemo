package com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums;

import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.ApiInstancer;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.instancer.impl.MapApiInstancer;

/**
 * Created by huahui.wu on 2017/6/16.
 */
public enum MapPlatform {
	IBSMAP(0L, "高德地图", new MapApiInstancer.IbsMapInstancer()); //todo 未定义平台编码

	private long id;
	private String platformName;
	private String apiCode;
	private ApiInstancer apiInstancer;

	private MapPlatform(long id, String platformName, ApiInstancer apiInstancer) {
		this.apiCode = name();
		this.id = id;
		this.platformName = platformName;
		this.apiInstancer = apiInstancer;
	}

	public boolean equalsByApiCode(String apiCode) {
		return this.apiCode.equals(apiCode);
	}

	public boolean equalsById(Long apiId) {
		return apiId != null && this.id == apiId.longValue();
	}

	public String getPlatformName() {
		return this.platformName;
	}

	public String getApiCode() {
		return this.apiCode;
	}

	public long getId() {
		return this.id;
	}

	public ApiInstancer getApiInstancer() {
		return apiInstancer;
	}

	public boolean equalsByName(String apiName) {
		return this.name().equals(apiName);
	}

	public static PayPlatform getPlatform(String apiName) {
		try {
			return PayPlatform.valueOf(PayPlatform.class, apiName);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static MapPlatform getPlatform(long id) {
		for (MapPlatform item : values()) {
			if (item.id == id)
				return item;
		}

		return null;
	}

}
