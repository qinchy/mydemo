package com.wwwarehouse.xdw.datasync.outer.api.interfaces;


import com.wwwarehouse.xdw.datasync.model.AmRequestLogDTO;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface IRecordAble {
	
	public void appendReqAResp(String apiMethod, Date reqDate, String reqString,
							   Map<String, String> params, Map<String, String> headerParams, String responseString);

	public List<AmRequestLogDTO> getAccessLogList();
	
}
