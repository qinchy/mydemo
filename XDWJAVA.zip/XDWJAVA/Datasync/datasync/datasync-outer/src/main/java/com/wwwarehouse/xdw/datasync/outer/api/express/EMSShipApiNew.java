package com.wwwarehouse.xdw.datasync.outer.api.express;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.thoughtworks.xstream.XStream;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.commons.xml.XmlConverter;
import com.wwwarehouse.commons.xml.XmlUtils;
import com.wwwarehouse.xdw.datasync.model.*;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.commons.codec.binary.Base64;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 8:36 on 2017/6/19.
 * @Modified By:
 */
public class EMSShipApiNew implements IShipApi<ExpressOrderEMSInfoDTO> {

    private static final String targetNamespace = "http://printService.webservice.bigaccount.hollycrm.com";
    private String apiUrl = "http://os.ems.com.cn:8081/zkweb/services/getPrintDatas?wsdl";
    private String charset = "utf-8";
    private String sysAccount;
    private String passWord;

    @Override
    public LogisticsInformation trackLogisticsInfo(String outSid) throws Exception {

        LogisticsInformation information = new LogisticsInformation();
        information.setOutSid(outSid);

        String responseHtml = WebUtils.doGet("http://www.ems.com.cn/apple/query/" + outSid, null);
        System.out.println(responseHtml);
        Document doc = Jsoup.parse(responseHtml);

        Elements table = doc.getElementsByTag("table");
        if (table.size() < 3) {
            return information;
        }
        Elements trs = table.get(3).getElementsByTag("tr");
        List<LogisticsInfomationDetail> list = new ArrayList<>();
        for (int i = 2; i < trs.size(); i++) {
            LogisticsInfomationDetail detail = new LogisticsInfomationDetail();
            Elements tds = trs.get(i).getElementsByTag("td");
            String operationDate = tds.get(1).text().replace(" ", " ");
            String address = StringUtils.trim(tds.get(2).text());
            String remark = StringUtils.trim(tds.get(3).text());
            detail.setOperatingTime(DateUtil.parse(operationDate, "yyyy-MM-dd HH:mm:ss"));
            detail.setAddress(address);
            detail.setDescription(remark);
            detail.setStatus(getFlowStatus(remark));
            list.add(detail);
        }
        information.setInfomationDetails(list);
        return information;
    }

    @Override
    public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
        if(!(expressOrderInfo instanceof ExpressOrderEMSInfoDTO)){
            throw new IscsException(300, "ExpressOrderEMSInfoDTO");
        }
        List<ExpressOrderEMSInfoDTO> expressOrderInfoDTOs = new ArrayList<>();
        expressOrderInfoDTOs.add((ExpressOrderEMSInfoDTO) expressOrderInfo);

        //调用批量上传方法
        List<ExpressOrderEMSInfoDTO> orderEMSInfoDTOs = generateExpressInfos(expressOrderInfoDTOs);
        if(orderEMSInfoDTOs == null || orderEMSInfoDTOs.isEmpty()){
            throw new IscsException(300, "生成物流信息失败！");
        }

        return orderEMSInfoDTOs.get(0);
    }

    @Override
    public List<ExpressOrderEMSInfoDTO> generateExpressInfos(List<ExpressOrderEMSInfoDTO> expressOrderInfoDTOs) throws Exception {
        if(expressOrderInfoDTOs == null){
            throw new IscsException(200, "传入参数为空！");
        }

        //获取快递单号
        List<String> outSids = getBillNos(expressOrderInfoDTOs.size());

        //将快递单号放入快递信息里面
        List<ExpressOrderEMSInfoDTO> orderEMSInfoDTOS = expressOrderInfoDTOs;
        for(int i = 0 ; i < expressOrderInfoDTOs.size(); i++){
            ExpressOrderEMSInfoDTO infoDTO = orderEMSInfoDTOS.get(i);
            infoDTO.setExpressId(outSids.get(i));
        }

        //将详情单打印信息更新到EMS
        AbsResponse absResponse = updatePrintEMSDatas(orderEMSInfoDTOS);

        if(absResponse.getCode() == 100){
            throw new IscsException(200, absResponse.getMsg());
        }

        return orderEMSInfoDTOS;
    }

    @Override
    public void cancelExpressOrder(String orderId, String outSid) throws Exception {
        throw new IscsException(100, "不支持取消订单！");
    }

    @Override
    public void uploadWeight(List list) throws Exception {
        throw new IscsException(100, "不支持上传重量！");
    }

    @Override
    public void appendReqAResp(String apiMethod, Date reqDate, String reqString, Map<String, String> params, Map<String, String> headerParams, String responseString) {

    }

    @Override
    public List<AmRequestLogDTO> getAccessLogList() {
        return null;
    }

    /**
    * @author:
    * @description: 获取详情单号
    * @param billNoAmount 单号的数量
    * @return List<String>  快递单号集合
    * @throws Exception
    */
    private List<String> getBillNos(Integer billNoAmount) throws Exception{
        List<String> outSids = new ArrayList<>();

        Map<String, Object> m = Maps.newHashMap();
        m.put("sysAccount", "sysAccount");// 暂时还没有真实数据，所以传个固定的
        m.put("passWord", "passWord");
        m.put("businessType", 1);
        m.put("billNoAmount", billNoAmount);
        String requestXml = XmlConverter.convert("XMLInfo", m);
        String responseXml = callEMSApi(requestXml, 3000);
        responseXml = new String(Base64.decodeBase64(responseXml), charset);
        System.out.println(responseXml);

        Element root = XmlUtils.getRootElementFromString(responseXml);
        String result = root.getElementsByTagName("result").item(0).getTextContent();
        //1标识成功，0表示失败
        if("1".equals(result)){
            NodeList billnos = root.getElementsByTagName("billno");
            for(int i = 0; i < billnos.getLength(); i++){
                outSids.add(billnos.item(i).getTextContent());
            }
        }else{
            String errorDesc = root.getElementsByTagName("errorDesc").item(0).getTextContent();
            throw new IscsException(100, errorDesc);
        }
        return outSids;
    }

    private AbsResponse updatePrintEMSDatas(List<ExpressOrderEMSInfoDTO> orderEMSInfoDTOS) throws Exception {
        AbsResponse abs = new AbsResponse();
        // 封装数据--start
        Map<String, Object> m = Maps.newHashMap();
        m.put("sysAccount", "sysAccount");// 暂时还没有真实数据，所以传个固定的
        m.put("passWord", "passWord");
        m.put("printKind", 1);
        // printDatas
        List<Map<String, Map<String, String>>> printDatal = Lists.newArrayList();
        for(ExpressOrderEMSInfoDTO infoDTO : orderEMSInfoDTOS){
            Map<String, String> printDataM = Maps.newHashMap();
            printDataM.put("billno", infoDTO.getExpressId() == null ? "" : infoDTO.getExpressId());
            printDataM.put("cargoType", infoDTO.getCargoType() == null ? "" : infoDTO.getCargoType());
            printDataM.put("businessType", infoDTO.getBusinessType() == null ? "" : infoDTO.getBusinessType());
            printDataM.put("dateType", infoDTO.getDateType() == null ? "" : infoDTO.getDateType());
            printDataM.put("weight", String.valueOf(infoDTO.getWeight()));
            printDataM.put("length", String.valueOf(infoDTO.getLength()));
            printDataM.put("insureType", infoDTO.getInsureType() == null ? "" : infoDTO.getInsureType());
            //            printDataM.put("insurance", String.valueOf(infoDTO.getInsurance()));
            //            printDataM.put("insure", String.valueOf(infoDTO.getInsure()));
            printDataM.put("fee", String.valueOf(infoDTO.getFee()));
            printDataM.put("cargoDesc", infoDTO.getCargoDesc() == null ? "" : infoDTO.getCargoDesc());
            printDataM.put("deliveryclaim", infoDTO.getDeliveryclaim() == null ? "" : infoDTO.getDeliveryclaim());
//            printDataM.put("remark", infoDTO.getRemark() == null ? "" : infoDTO.getRemark());
            printDataM.put("bigAccountDataId", infoDTO.getBigAccountDataId() == null ? "" : infoDTO.getBigAccountDataId());
            printDataM.put("customerDn", infoDTO.getOrderId() == null ? "" : infoDTO.getOrderId());
//            printDataM.put("productCode", infoDTO.getProductCode() == null ? "" : infoDTO.getProductCode());

            ExpressShiperDetail sendShiperDetail = infoDTO.getSendShiperDetail();
            printDataM.put("procdate", String.valueOf(infoDTO.getCreateDate() == null
                    ? DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss") : infoDTO.getCreateDate()));
            printDataM.put("scontactor", sendShiperDetail.getName() == null ? "" : sendShiperDetail.getName());
            printDataM.put("scustMobile", sendShiperDetail.getMobile() == null ? "" : sendShiperDetail.getMobile());
            printDataM.put("scustTelplus", sendShiperDetail.getPhone() == null ? "" : sendShiperDetail.getPhone());
            printDataM.put("scustPost", sendShiperDetail.getPostcode() == null ? "" : sendShiperDetail.getPostcode());
            printDataM.put("scustAddr", sendShiperDetail.getAddress() == null ? "" : sendShiperDetail.getAddress());
            printDataM.put("scustComp", sendShiperDetail.getCompany() == null ? "" : sendShiperDetail.getCompany());

            ExpressShiperDetail receiverShiperDetail = infoDTO.getReceiverShiperDetail();
            printDataM.put("tcontactor", receiverShiperDetail.getName() == null ? "" : receiverShiperDetail.getName());
            printDataM.put("tcustMobile", receiverShiperDetail.getMobile() == null ? "" : receiverShiperDetail.getMobile());
            printDataM.put("tcustTelplus", receiverShiperDetail.getPhone() == null ? "" : receiverShiperDetail.getPhone());
            printDataM.put("tcustPost", receiverShiperDetail.getPostcode() == null ? "" : receiverShiperDetail.getPostcode());
            printDataM.put("tcustAddr", receiverShiperDetail.getAddress() == null ? "" : receiverShiperDetail.getAddress());
            printDataM.put("tcustComp", receiverShiperDetail.getCompany() == null ? "" : receiverShiperDetail.getCompany());
            printDataM.put("tcustProvince", receiverShiperDetail.getProvince() == null ? "" : receiverShiperDetail.getProvince());
            printDataM.put("tcustCity", receiverShiperDetail.getCity() == null ? "" : receiverShiperDetail.getCity());
            printDataM.put("tcustCounty", receiverShiperDetail.getCounty() == null ? "" : receiverShiperDetail.getCounty());

            Map<String, Map<String, String>> parentM = Maps.newHashMap();
            parentM.put("printData", printDataM);
            printDatal.add(parentM);
        }
        m.put("printDatas", printDatal);
        // 封装数据--end
        String requestXml = XmlConverter.convert("XMLInfo", m);
        String responseXml = callEMSApi(requestXml, 3000);
        responseXml = new String(Base64.decodeBase64(responseXml), charset);

        //返回结果
        Element root = XmlUtils.getRootElementFromString(responseXml);
        String result = root.getElementsByTagName("result").item(0).getTextContent();
        //1为成功，0为失败
        if("1".equals(result)){
            abs.setCode(0);
        }else{
            abs.setCode(100);
            String errorDesc = root.getElementsByTagName("errorDesc").item(0).getTextContent();
            abs.setMsg(errorDesc);
        }
        return abs;
    }

    public static void main(String[] args) throws Exception{
        EMSShipApiNew api = new EMSShipApiNew();
        List<ExpressOrderEMSInfoDTO> expressOrderInfoDTOs = new ArrayList<>();
        api.generateExpressInfos(expressOrderInfoDTOs);
    }

    private String callEMSApi(String strXml, int timeOut) throws  Exception{
        Call call = (Call) new Service().createCall();
        call.setTimeout(timeOut);
        call.setTargetEndpointAddress(apiUrl);
        call.setOperationName(new QName(targetNamespace, "getBillNoBySys"));
        call.addParameter("xmlStr", XMLType.XSD_STRING, ParameterMode.IN);
        call.setReturnType(XMLType.XSD_STRING);
        String xmlStr = new String(Base64.encodeBase64(strXml.getBytes(charset)), charset);
        return call.invoke(new Object[]{xmlStr}).toString();
    }

    private Long getFlowStatus(String remark) {
        Long status = 0L;
        if (StringUtils.contains(remark, "收寄", "揽收")) {
            status = 550L;
        } else if (StringUtils.contains(remark, "离开处理中心", "到达处理中心")) {
            status = 555L;
        } else if (StringUtils.contains(remark, "到达处理中心", "离开处理中心")) {
            status = 560L;
        } else if (StringUtils.contains(remark, "安排投递", "到达处理中心", "离开处理中心")) {
            status = 565L;
        } else if (StringUtils.contains(remark, "签收", "未签收", "未妥投", "代收", "妥投")) {
            status = 600L;
        }
        return status;
    }
}
