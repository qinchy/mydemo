package com.wwwarehouse.xdw.datasync.outer.exception;

/**
 * Created by zhigang.huang on 2017/6/20.
 */

import com.wwwarehouse.commons.exception.IscsErrorCode;
import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.StringUtils;


public class ApiException extends IscsException {
    private static final long serialVersionUID = -238091758285157331L;
    private int errCode = 100;
    private String errMsg;

    public ApiException() {
    }

    public ApiException(String message, Throwable cause) {
        super(message, cause);
        this.errMsg = message;
    }

    public ApiException(String message) {
        super(message);
        this.errMsg = message;
    }

    public ApiException(Throwable cause) {
        super(cause);
    }

    public ApiException(int errCode, String errMsg) {
        super(errCode + ":" + errMsg);
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public ApiException(int errCode, String errMsg, Throwable cause) {
        super(errCode + ":" + errMsg, cause);
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public ApiException(IscsErrorCode apiErrorCode, String errorMsg) {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(apiErrorCode.getErrorText());
        if (StringUtils.isNotEmpty(errorMsg)) {
            strBuilder.append(":").append(errorMsg);
        }

        this.errCode = apiErrorCode.getErrorCode();
        this.errMsg = strBuilder.toString();
    }

    public int getErrCode() {
        return this.errCode;
    }

    public String getErrMsg() {
        return this.errMsg;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}

