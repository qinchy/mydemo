package com.wwwarehouse.xdw.datasync.constant;

/**
 * Created by shisheng.wang on 17/6/8.
 */
public class Constants {
    public static final String TOPIC_DATASYNC_RESULT = "datasync_result";
    public final static Long WCKJ = 260001L; //网仓
    public final static String payAppType = "PAY"; //支付
}
