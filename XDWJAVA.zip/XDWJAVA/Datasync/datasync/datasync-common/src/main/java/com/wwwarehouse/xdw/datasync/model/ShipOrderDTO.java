package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;
import java.util.List;

/**
 * Created by wang sir on 16/2/23.
 */
public class ShipOrderDTO extends BaseObject {
	private String orderId; // 订单号
	private String deliveryId; // 快递单号
	private String senderName; // 发件人姓名
	private String senderCompany; // 发件人公司
	private String senderCountry; // 发件人国家
	private String senderProvince; // 发件人所在省
	private String senderCity; // 发件人所在市
	private String senderCounty; // 发件人所在县
	private String senderStreet; // 发件人所在街道
	private String senderAddress; // 发件人地址
	private String senderPostcode; // 发件人邮编
	private String senderPhone; // 发件人电话
	private String senderMobile; // 发件人手机
	private String senderEmail; // 发件人电子邮箱
	private String receiverName; // 收件人姓名
	private String receiverCompany; // 收件人公司
	private String receiverCountry; // 收件人国家
	private String receiverProvince; // 收件人所在省
	private String receiverCity; // 收件人所在市
	private String receiverCounty; // 收件人所在县
	private String receiverStreet; // 收件人所在街道
	private String receiverAddress; // 收件人地址
	private String receiverPostcode; // 收件人邮编
	private String receiverPhone; // 收件人电话
	private String receiverMobile; // 收件人手机
	private String receiverEmail; // 收件人电子邮箱
	private List<ShipOrderItemDTO> shipOrderItemDTOs;

	private Double weight; // 重量
	private String size; // 尺寸
	private float payment; // 支付金额

	private boolean cod; // 是否货到付款
	private double collectionValue; // 代收货款金额
	private int packNo; // 件数
	private Date createDate; // 创建时间

	// JDShip
	private String pickMethod; // 取件方式(上门收货：1，自送：2。不填或者超出范围，默认是1)
	private String packageRequired; // 包装要求(不需包装：1，简单包装：2，特殊包装：3。不填或者超出范围，默认是
	private int guaranteeValue; // 是否保价(是：1，否：0。不填或者超出范围，默认是0)
	private Double guaranteeValueAmount; // 保价金额(保留小数点后两位)
	private int signReturn; // 签单返还(是：1，否：0。不填或者超出范围，默认是0)
	private int aging; // 时效(普通：1，工作日：2，非工作日：3，晚间：4。O2O一小时达：5。O2O定时达：6。不填或者超出范围，默认是1)
	private String orderSendTime; // 预约配送时间（格式：yyyy-MM-dd HH:mm:ss。例如：2014-09-18
									// 08:30:00）

	// EUBShip
	private int operationtype; // 业务类型（默认0，如果不填或者没有该节点就取默认值）0:e 邮宝1:e 包裹2:e
								// 特快3:e 速宝
	private String customerCode;// 使用者系统中的客户编码。
	private String remark; // 备注

	// DiSiFangShip
	private String productCode; // 产品代码
	private String cargoCode; // 货物类型
	private String senderCountryCode; // 发货人国家代码
	private String receiverCountryCode; // 收货人国家代码
	private String unitPrice; // 单价
	private String eName; // 商品英文名
	private String paymentMode; // 付款方式

	// TTKCBShipApi
	private String ecCompanyId; // 电商在天天唯一标识（天天总部对接时提供）
	private String customerId; // 网点分配的客户名称
	private int orderType; // 订单类型(1-普通订单)
	private long serviceType; // 服务类型(0-自己联系)
	private long goodsValue; // 商品价值
	// 顺丰
	/** 快件产品代码 如标准快递、电商速配等 */
	private String expressServiceCode;
	/** 付款类型，月结、现金等 */
	private String paymentType;
	/** 月结账户 */
	private String paymentAccountNo;
	/** 投递方式 送货上门, 自取等 */
	private String deliveryMode;

	private int is_gen_bill_no;// 是否要求返回顺丰运单号
	private String custid;// 顺丰月结卡号 ////
	private int pay_method;// 付款方式：1:寄方付 2:收方付 3:第三方付
	private String express_type;// 快件产品类别
	private int parcel_quantity;// 包裹数
	private Date sendstarttime;// 要求上门取件开始时间，格式：YYYY-MM-DD HH24:MM:SS
	private String order_source;// 客户订单来源（对于平台类客户，如果需要在订单中区分订单来源，则可使用此字段
	private List<ShipOrderItemDTO> cargoItems;
	// private List<ShipOrderItemDTO> addedServiceItems;
	private int dealtype;
	// private List<ShipOrderItemDTO> orderConfirmOptionItems;

	// EMS
	private String businessType;// 业务类型
	private String dateType;// 时间类型
	// private Date procdate;// 时间 公用createdate
	private String cargoType;// 内件类型
	private double insurance;// 保险金额
	private double length;// 货物长度
	private String insureType;// 所负责任
	private double insure;// 保价金额
	private double fee;// 货款金额
	// private String feeUppercase;// 大写货款金额
	private String cargoDesc;// 内件信息
	private String deliveryclaim;// 揽投员的投递要求
	private String bigAccountDataId;// 邮件数据唯一标识
	// private String blank1;// 扩展字段1
	// private String blank2;// 扩展字段2
	// private String blank3;// 扩展字段3
	// private String blank4;// 扩展字段4
	// private String blank5;// 扩展字段5
	// SaiAoDiShip
	private String payType; // 付款方式(现金、pos、支票)

	public ShipOrderDTO() {
		super();
	}

	public ShipOrderDTO(String orderId, String deliveryId, String senderName, String senderCompany,
	                    String senderProvince, String senderCity, String senderCounty, String senderAddress,
	                    String senderPostcode, String senderPhone, String senderMobile, String receiverName,
	                    String receiverCompany, String receiverProvince, String receiverCity,
	                    String receiverCounty, String receiverAddress, String receiverPostcode,
	                    String receiverPhone, String receiverMobile, List<ShipOrderItemDTO> shipOrderItemDTOs,
	                    String productCode, String cargoCode, String senderCountryCode,
	                    String receiverCountryCode, String unitPrice, String eName, String paymentMode,
	                    Double weight, String size, float payment, boolean cod, double collectionValue,
	                    int packNo, Date createDate, String pickMethod, String packageRequired,
	                    int guaranteeValue, Double guaranteeValueAmount, int signReturn, int aging,
	                    String orderSendTime) {
		super();
		this.orderId = orderId;
		this.deliveryId = deliveryId;
		this.senderName = senderName;
		this.senderCompany = senderCompany;
		this.senderProvince = senderProvince;
		this.senderCity = senderCity;
		this.senderCounty = senderCounty;
		this.senderAddress = senderAddress;
		this.senderPostcode = senderPostcode;
		this.senderPhone = senderPhone;
		this.senderMobile = senderMobile;
		this.receiverName = receiverName;
		this.receiverCompany = receiverCompany;
		this.receiverProvince = receiverProvince;
		this.receiverCity = receiverCity;
		this.receiverCounty = receiverCounty;
		this.receiverAddress = receiverAddress;
		this.receiverPostcode = receiverPostcode;
		this.receiverPhone = receiverPhone;
		this.receiverMobile = receiverMobile;
		this.shipOrderItemDTOs = shipOrderItemDTOs;
		this.productCode = productCode;
		this.cargoCode = cargoCode;
		this.senderCountryCode = senderCountryCode;
		this.receiverCountryCode = receiverCountryCode;
		this.unitPrice = unitPrice;
		this.eName = eName;
		this.paymentMode = paymentMode;
		this.weight = weight;
		this.size = size;
		this.payment = payment;
		this.cod = cod;
		this.collectionValue = collectionValue;
		this.packNo = packNo;
		this.createDate = createDate;
		this.pickMethod = pickMethod;
		this.packageRequired = packageRequired;
		this.guaranteeValue = guaranteeValue;
		this.guaranteeValueAmount = guaranteeValueAmount;
		this.signReturn = signReturn;
		this.aging = aging;
		this.orderSendTime = orderSendTime;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getSenderCompany() {
		return senderCompany;
	}

	public void setSenderCompany(String senderCompany) {
		this.senderCompany = senderCompany;
	}

	public String getSenderProvince() {
		return senderProvince;
	}

	public void setSenderProvince(String senderProvince) {
		this.senderProvince = senderProvince;
	}

	public String getSenderCity() {
		return senderCity;
	}

	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}

	public String getSenderCounty() {
		return senderCounty;
	}

	public void setSenderCounty(String senderCounty) {
		this.senderCounty = senderCounty;
	}

	public String getSenderAddress() {
		return senderAddress;
	}

	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}

	public String getSenderPostcode() {
		return senderPostcode;
	}

	public void setSenderPostcode(String senderPostcode) {
		this.senderPostcode = senderPostcode;
	}

	public String getSenderPhone() {
		return senderPhone;
	}

	public void setSenderPhone(String senderPhone) {
		this.senderPhone = senderPhone;
	}

	public String getSenderMobile() {
		return senderMobile;
	}

	public void setSenderMobile(String senderMobile) {
		this.senderMobile = senderMobile;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverCompany() {
		return receiverCompany;
	}

	public void setReceiverCompany(String receiverCompany) {
		this.receiverCompany = receiverCompany;
	}

	public String getReceiverProvince() {
		return receiverProvince;
	}

	public void setReceiverProvince(String receiverProvince) {
		this.receiverProvince = receiverProvince;
	}

	public String getReceiverCity() {
		return receiverCity;
	}

	public void setReceiverCity(String receiverCity) {
		this.receiverCity = receiverCity;
	}

	public String getReceiverCounty() {
		return receiverCounty;
	}

	public void setReceiverCounty(String receiverCounty) {
		this.receiverCounty = receiverCounty;
	}

	public String getReceiverAddress() {
		return receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public String getReceiverPostcode() {
		return receiverPostcode;
	}

	public void setReceiverPostcode(String receiverPostcode) {
		this.receiverPostcode = receiverPostcode;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}

	public String getReceiverMobile() {
		return receiverMobile;
	}

	public void setReceiverMobile(String receiverMobile) {
		this.receiverMobile = receiverMobile;
	}

	public List<ShipOrderItemDTO> getShipOrderItemDTOs() {
		return shipOrderItemDTOs;
	}

	public void setShipOrderItemDTOs(List<ShipOrderItemDTO> shipOrderItemDTOs) {
		this.shipOrderItemDTOs = shipOrderItemDTOs;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getCargoCode() {
		return cargoCode;
	}

	public void setCargoCode(String cargoCode) {
		this.cargoCode = cargoCode;
	}

	public String getSenderCountryCode() {
		return senderCountryCode;
	}

	public void setSenderCountryCode(String senderCountryCode) {
		this.senderCountryCode = senderCountryCode;
	}

	public String getReceiverCountryCode() {
		return receiverCountryCode;
	}

	public void setReceiverCountryCode(String receiverCountryCode) {
		this.receiverCountryCode = receiverCountryCode;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public float getPayment() {
		return payment;
	}

	public void setPayment(float payment) {
		this.payment = payment;
	}

	public boolean isCod() {
		return cod;
	}

	public void setCod(boolean cod) {
		this.cod = cod;
	}

	public double getCollectionValue() {
		return collectionValue;
	}

	public void setCollectionValue(double collectionValue) {
		this.collectionValue = collectionValue;
	}

	public int getPackNo() {
		return packNo;
	}

	public void setPackNo(int packNo) {
		this.packNo = packNo;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getPickMethod() {
		return pickMethod;
	}

	public void setPickMethod(String pickMethod) {
		this.pickMethod = pickMethod;
	}

	public String getPackageRequired() {
		return packageRequired;
	}

	public void setPackageRequired(String packageRequired) {
		this.packageRequired = packageRequired;
	}

	public int getGuaranteeValue() {
		return guaranteeValue;
	}

	public void setGuaranteeValue(int guaranteeValue) {
		this.guaranteeValue = guaranteeValue;
	}

	public Double getGuaranteeValueAmount() {
		return guaranteeValueAmount;
	}

	public void setGuaranteeValueAmount(Double guaranteeValueAmount) {
		this.guaranteeValueAmount = guaranteeValueAmount;
	}

	public int getSignReturn() {
		return signReturn;
	}

	public void setSignReturn(int signReturn) {
		this.signReturn = signReturn;
	}

	public int getAging() {
		return aging;
	}

	public void setAging(int aging) {
		this.aging = aging;
	}

	public String getOrderSendTime() {
		return orderSendTime;
	}

	public void setOrderSendTime(String orderSendTime) {
		this.orderSendTime = orderSendTime;
	}

	public String getSenderCountry() {
		return senderCountry;
	}

	public void setSenderCountry(String senderCountry) {
		this.senderCountry = senderCountry;
	}

	public String getSenderStreet() {
		return senderStreet;
	}

	public void setSenderStreet(String senderStreet) {
		this.senderStreet = senderStreet;
	}

	public String getReceiverCountry() {
		return receiverCountry;
	}

	public void setReceiverCountry(String receiverCountry) {
		this.receiverCountry = receiverCountry;
	}

	public String getReceiverStreet() {
		return receiverStreet;
	}

	public void setReceiverStreet(String receiverStreet) {
		this.receiverStreet = receiverStreet;
	}

	public int getOperationtype() {
		return operationtype;
	}

	public void setOperationtype(int operationtype) {
		this.operationtype = operationtype;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSenderEmail() {
		return senderEmail;
	}

	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public String getEcCompanyId() {
		return ecCompanyId;
	}

	public void setEcCompanyId(String ecCompanyId) {
		this.ecCompanyId = ecCompanyId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getOrderType() {
		return orderType;
	}

	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	public long getServiceType() {
		return serviceType;
	}

	public void setServiceType(long serviceType) {
		this.serviceType = serviceType;
	}

	public long getGoodsValue() {
		return goodsValue;
	}

	public void setGoodsValue(long goodsValue) {
		this.goodsValue = goodsValue;
	}

	/**
	 * @return the expressServiceCode
	 */
	public String getExpressServiceCode() {
		return expressServiceCode;
	}

	/**
	 * @param expressServiceCode
	 *            the expressServiceCode to set
	 */
	public void setExpressServiceCode(String expressServiceCode) {
		this.expressServiceCode = expressServiceCode;
	}

	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType
	 *            the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the deliveryMode
	 */
	public String getDeliveryMode() {
		return deliveryMode;
	}

	/**
	 * @param deliveryMode
	 *            the deliveryMode to set
	 */
	public void setDeliveryMode(String deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	/**
	 * @return the paymentAccountNo
	 */
	public String getPaymentAccountNo() {
		return paymentAccountNo;
	}

	/**
	 * @param paymentAccountNo
	 *            the paymentAccountNo to set
	 */
	public void setPaymentAccountNo(String paymentAccountNo) {
		this.paymentAccountNo = paymentAccountNo;
	}

	public int getIs_gen_bill_no() {
		return is_gen_bill_no;
	}

	public void setIs_gen_bill_no(int is_gen_bill_no) {
		this.is_gen_bill_no = is_gen_bill_no;
	}

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	public int getPay_method() {
		return pay_method;
	}

	public void setPay_method(int pay_method) {
		this.pay_method = pay_method;
	}

	public String getExpress_type() {
		return express_type;
	}

	public void setExpress_type(String express_type) {
		this.express_type = express_type;
	}

	public int getParcel_quantity() {
		return parcel_quantity;
	}

	public void setParcel_quantity(int parcel_quantity) {
		this.parcel_quantity = parcel_quantity;
	}

	public Date getSendstarttime() {
		return sendstarttime;
	}

	public void setSendstarttime(Date sendstarttime) {
		this.sendstarttime = sendstarttime;
	}

	public String getOrder_source() {
		return order_source;
	}

	public void setOrder_source(String order_source) {
		this.order_source = order_source;
	}

	public List<ShipOrderItemDTO> getCargoItems() {
		return cargoItems;
	}

	public void setCargoItems(List<ShipOrderItemDTO> cargoItems) {
		this.cargoItems = cargoItems;
	}

	// public List<ShipOrderItemDTO> getAddedServiceItems() {
	// return addedServiceItems;
	// }
	//
	// public void setAddedServiceItems(List<ShipOrderItemDTO> addedServiceItems) {
	// this.addedServiceItems = addedServiceItems;
	// }

	public int getDealtype() {
		return dealtype;
	}

	public void setDealtype(int dealtype) {
		this.dealtype = dealtype;
	}

	// public List<ShipOrderItemDTO> getOrderConfirmOptionItems() {
	// return orderConfirmOptionItems;
	// }
	//
	// public void setOrderConfirmOptionItems(List<ShipOrderItemDTO>
	// orderConfirmOptionItems) {
	// this.orderConfirmOptionItems = orderConfirmOptionItems;
	// }

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	// public Date getProcdate() {
	// return procdate;
	// }
	//
	// public void setProcdate(Date procdate) {
	// this.procdate = procdate;
	// }

	public String getCargoType() {
		return cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public double getInsurance() {
		return insurance;
	}

	public void setInsurance(double insurance) {
		this.insurance = insurance;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getInsureType() {
		return insureType;
	}

	public void setInsureType(String insureType) {
		this.insureType = insureType;
	}

	public double getInsure() {
		return insure;
	}

	public void setInsure(double insure) {
		this.insure = insure;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	// public String getFeeUppercase() {
	// return feeUppercase;
	// }
	//
	// public void setFeeUppercase(String feeUppercase) {
	// this.feeUppercase = feeUppercase;
	// }

	public String getCargoDesc() {
		return cargoDesc;
	}

	public void setCargoDesc(String cargoDesc) {
		this.cargoDesc = cargoDesc;
	}

	public String getDeliveryclaim() {
		return deliveryclaim;
	}

	public void setDeliveryclaim(String deliveryclaim) {
		this.deliveryclaim = deliveryclaim;
	}

	public String getBigAccountDataId() {
		return bigAccountDataId;
	}

	public void setBigAccountDataId(String bigAccountDataId) {
		this.bigAccountDataId = bigAccountDataId;
	}

	// public String getBlank1() {
	// return blank1;
	// }
	//
	// public void setBlank1(String blank1) {
	// this.blank1 = blank1;
	// }
	//
	// public String getBlank2() {
	// return blank2;
	// }
	//
	// public void setBlank2(String blank2) {
	// this.blank2 = blank2;
	// }
	//
	// public String getBlank3() {
	// return blank3;
	// }
	//
	// public void setBlank3(String blank3) {
	// this.blank3 = blank3;
	// }
	//
	// public String getBlank4() {
	// return blank4;
	// }
	//
	// public void setBlank4(String blank4) {
	// this.blank4 = blank4;
	// }
	//
	// public String getBlank5() {
	// return blank5;
	// }
	//
	// public void setBlank5(String blank5) {
	// this.blank5 = blank5;
	// }

}