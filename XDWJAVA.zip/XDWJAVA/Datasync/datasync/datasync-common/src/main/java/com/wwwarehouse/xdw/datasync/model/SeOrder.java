package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

/**
 * Created by xuchun on 16/2/23.
 */
public class SeOrder extends BaseObject{
    private Long id;
	private String idName;
    private String name;
    private Long userId;
    private Date createDate;
    
    public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {//
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}