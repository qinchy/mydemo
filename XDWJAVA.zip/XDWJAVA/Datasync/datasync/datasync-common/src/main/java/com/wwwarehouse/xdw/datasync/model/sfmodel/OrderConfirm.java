package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description: 订单确认
 * @Date: Created in 9:34 on 2017/6/18.
 * @Modified By:
 */
@XStreamAlias("OrderConfirm")
public class OrderConfirm extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String orderid;

    @XStreamAsAttribute()
    private String mailno;

    @XStreamAsAttribute()
    private String dealtype;

    @XStreamAlias("OrderConfirmOption")
    private OrderConfirmOption orderConfirmOption;

    public OrderConfirm(String orderid, String mailno, String dealtype, OrderConfirmOption orderConfirmOption) {
        this.orderid = orderid;
        this.mailno = mailno;
        this.dealtype = dealtype;
        this.orderConfirmOption = orderConfirmOption;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getMailno() {
        return mailno;
    }

    public void setMailno(String mailno) {
        this.mailno = mailno;
    }

    public String getDealtype() {
        return dealtype;
    }

    public void setDealtype(String dealtype) {
        this.dealtype = dealtype;
    }

    public OrderConfirmOption getOrderConfirmOption() {
        return orderConfirmOption;
    }

    public void setOrderConfirmOption(OrderConfirmOption orderConfirmOption) {
        this.orderConfirmOption = orderConfirmOption;
    }
}
