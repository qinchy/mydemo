package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.xdw.datasync.model.Item;

/**
 * Created by shisheng.wang on 17/6/6.
 */
public interface ItemService {
    Item get(long itemId);

    int add(Item item);
}
