package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

public class BaAreaWeatherDTO extends BaseObject {
    private Long areaWeatherUkid;

    private Date downTime;

    private Long cityId;

    private String basic;

    private String aqi;

    private String cond;

    private String hum;

    private String pcpn;

    private String pop;

    private String pres;

    private String vis;

    private String tmp;

    private String wind;

    private String comf;

    private String cw;

    private String drsg;

    private String flu;

    private String sport;

    private String trav;

    private String uv;

    public Long getAreaWeatherUkid() {
        return areaWeatherUkid;
    }

    public void setAreaWeatherUkid(Long areaWeatherUkid) {
        this.areaWeatherUkid = areaWeatherUkid;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }

    public String getBasic() {
        return basic;
    }

    public void setBasic(String basic) {
        this.basic = basic == null ? null : basic.trim();
    }

    public String getAqi() {
        return aqi;
    }

    public void setAqi(String aqi) {
        this.aqi = aqi == null ? null : aqi.trim();
    }

    public String getCond() {
        return cond;
    }

    public void setCond(String cond) {
        this.cond = cond == null ? null : cond.trim();
    }

    public String getHum() {
        return hum;
    }

    public void setHum(String hum) {
        this.hum = hum == null ? null : hum.trim();
    }

    public String getPcpn() {
        return pcpn;
    }

    public void setPcpn(String pcpn) {
        this.pcpn = pcpn == null ? null : pcpn.trim();
    }

    public String getPop() {
        return pop;
    }

    public void setPop(String pop) {
        this.pop = pop == null ? null : pop.trim();
    }

    public String getPres() {
        return pres;
    }

    public void setPres(String pres) {
        this.pres = pres == null ? null : pres.trim();
    }

    public String getVis() {
        return vis;
    }

    public void setVis(String vis) {
        this.vis = vis == null ? null : vis.trim();
    }

    public String getTmp() {
        return tmp;
    }

    public void setTmp(String tmp) {
        this.tmp = tmp == null ? null : tmp.trim();
    }

    public String getWind() {
        return wind;
    }

    public void setWind(String wind) {
        this.wind = wind == null ? null : wind.trim();
    }

    public String getComf() {
        return comf;
    }

    public void setComf(String comf) {
        this.comf = comf == null ? null : comf.trim();
    }

    public String getCw() {
        return cw;
    }

    public void setCw(String cw) {
        this.cw = cw == null ? null : cw.trim();
    }

    public String getDrsg() {
        return drsg;
    }

    public void setDrsg(String drsg) {
        this.drsg = drsg == null ? null : drsg.trim();
    }

    public String getFlu() {
        return flu;
    }

    public void setFlu(String flu) {
        this.flu = flu == null ? null : flu.trim();
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport == null ? null : sport.trim();
    }

    public String getTrav() {
        return trav;
    }

    public void setTrav(String trav) {
        this.trav = trav == null ? null : trav.trim();
    }

    public String getUv() {
        return uv;
    }

    public void setUv(String uv) {
        this.uv = uv == null ? null : uv.trim();
    }
}