package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

/**
 * App entity.
 * 
 * @author MyEclipse Persistence Tools
 */
public class AmAppkeyDTO extends BaseObject {
// Fields

	private Long appUkid;
	private String appName;
	private Long platformId;
	private Long ownerBuId;
	private String appType;
	private Date createTime;
	private Long createUserId;
	private Date updateTime;
	private Long updateUserId;
	private Short status;
	private String authType;
	private String apiUrl;
	private String appKey;
	private String appSecret;
	private String dataFormat;
	private String charset;
	private String signMethod;
	private Long dataEncrypt;
	private String dataEncryptType;
	private String authFilePath;
	private String whiteIp;
	private String blackIp;
	private String sysParamFormat;
	private String serviceCode;
	private String paymentAccountId;

	// Constructors

	/** default constructor */
	public AmAppkeyDTO() {
	}

	/** minimal constructor */
	public AmAppkeyDTO(Long appUkid) {
		this.appUkid = appUkid;
	}

	/** full constructor */
	public AmAppkeyDTO(Long appUkid, String appName, Long platformId, Long ownerBuId,
					String appType, Date createTime, Long createUserId,
					Date updateTime, Long updateUserId, Short status, String authType,
					String apiUrl, String appKey, String appSecret, String dataFormat,
					String charset, String signMethod, Long dataEncrypt,
					String dataEncryptType, String authFilePath, String whiteIp,
					String blackIp, String sysParamFormat) {
		this.appUkid = appUkid;
		this.appName = appName;
		this.platformId = platformId;
		this.ownerBuId = ownerBuId;
		this.appType = appType;
		this.createTime = createTime;
		this.createUserId = createUserId;
		this.updateTime = updateTime;
		this.updateUserId = updateUserId;
		this.status = status;
		this.authType = authType;
		this.apiUrl = apiUrl;
		this.appKey = appKey;
		this.appSecret = appSecret;
		this.dataFormat = dataFormat;
		this.charset = charset;
		this.signMethod = signMethod;
		this.dataEncrypt = dataEncrypt;
		this.dataEncryptType = dataEncryptType;
		this.authFilePath = authFilePath;
		this.whiteIp = whiteIp;
		this.blackIp = blackIp;
		this.sysParamFormat = sysParamFormat;
	}

	// Property accessors

	public Long getAppUkid() {
		return this.appUkid;
	}

	public void setAppUkid(Long appUkid) {
		this.appUkid = appUkid;
	}

	public String getAppName() {
		return this.appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Long getPlatformId() {
		return this.platformId;
	}

	public void setPlatformId(Long platformId) {
		this.platformId = platformId;
	}

	public Long getOwnerBuId() {
		return this.ownerBuId;
	}

	public void setOwnerBuId(Long ownerBuId) {
		this.ownerBuId = ownerBuId;
	}

	public String getAppType() {
		return this.appType;
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setupdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Short getStatus() {
		return this.status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public String getAuthType() {
		return this.authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getApiUrl() {
		return this.apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public String getAppKey() {
		return this.appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getAppSecret() {
		return this.appSecret;
	}

	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}

	public String getDataFormat() {
		return this.dataFormat;
	}

	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}

	public String getCharset() {
		return this.charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getSignMethod() {
		return this.signMethod;
	}

	public void setSignMethod(String signMethod) {
		this.signMethod = signMethod;
	}

	public Long getDataEncrypt() {
		return this.dataEncrypt;
	}

	public void setDataEncrypt(Long dataEncrypt) {
		this.dataEncrypt = dataEncrypt;
	}

	public String getDataEncryptType() {
		return this.dataEncryptType;
	}

	public void setDataEncryptType(String dataEncryptType) {
		this.dataEncryptType = dataEncryptType;
	}

	public String getAuthFilePath() {
		return this.authFilePath;
	}

	public void setAuthFilePath(String authFilePath) {
		this.authFilePath = authFilePath;
	}

	public String getWhiteIp() {
		return this.whiteIp;
	}

	public void setWhiteIp(String whiteIp) {
		this.whiteIp = whiteIp;
	}

	public String getBlackIp() {
		return this.blackIp;
	}

	public void setBlackIp(String blackIp) {
		this.blackIp = blackIp;
	}

	public String getSysParamFormat() {
		return this.sysParamFormat;
	}

	public void setSysParamFormat(String sysParamFormat) {
		this.sysParamFormat = sysParamFormat;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getPaymentAccountId() {
		return paymentAccountId;
	}

	public void setPaymentAccountId(String paymentAccountId) {
		this.paymentAccountId = paymentAccountId;
	}
}