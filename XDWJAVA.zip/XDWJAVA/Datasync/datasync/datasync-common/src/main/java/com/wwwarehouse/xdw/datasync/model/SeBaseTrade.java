package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;
import java.util.List;

public abstract class SeBaseTrade<T> extends BaseObject {
	private Long tradeUkid;
    private String orderId;//原始订单号
    private Long shopId;
    private Date downTime;
    private Date updateTime;
    private Date releaseTime;
    private Long originTradeStatus;
    private Long targetOrderUkid;
    
    private String platformOrderStatus;
    private String buyerNick;
    private Long isCod;
    private Date orderCreateTime;
    private Date orderPayTime;
	private Date consignTime;
    private Date orderModifyTime;
    private Date orderEndTime;
    
    private String receiverName;
    private String receiverMobile;
    private String receiverPhone;
	private String receiverCountry;
    private String receiverState;
    private String receiverCity;
    private String receiverTown;
    private String receiverCounty;
    private String receiverAddress;
    private String receiverZip;
    
    private String buyerMessage;
    private String sellerMemo;

	private Long platformId;
	private Long stockId;

    private List<T> itemList;

    public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String sourceOrderId) {
		this.orderId = sourceOrderId;
	}

	public List<T> getItemList() {
        return itemList;
    }

    public void setItemList(List<T> itemList) {
        this.itemList = itemList;
    }

    public Long getTradeUkid() {
        return tradeUkid;
    }

    public void setTradeUkid(Long tradeUkid) {
        this.tradeUkid = tradeUkid;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getReleaseDate() {
        return releaseTime;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseTime = releaseDate;
    }

    public Long getOriginTradeStatus() {
        return originTradeStatus;
    }

    public void setOriginTradeStatus(Long originTradeStatus) {
        this.originTradeStatus = originTradeStatus;
    }

	public Date getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(Date releaseTime) {
		this.releaseTime = releaseTime;
	}

	public Long getTargetOrderUkid() {
		return targetOrderUkid;
	}

	public void setTargetOrderUkid(Long targetOrderUkid) {
		this.targetOrderUkid = targetOrderUkid;
	}

	public String getPlatformOrderStatus() {
		return platformOrderStatus;
	}

	public void setPlatformOrderStatus(String platformOrderStatus) {
		this.platformOrderStatus = platformOrderStatus;
	}

	public String getBuyerNick() {
		return buyerNick;
	}

	public void setBuyerNick(String buyerNick) {
		this.buyerNick = buyerNick;
	}

	public Long getIsCod() {
		return isCod;
	}

	public void setIsCod(Long isCod) {
		this.isCod = isCod;
	}

	public Date getOrderCreateTime() {
		return orderCreateTime;
	}

	public void setOrderCreateTime(Date orderCreateTime) {
		this.orderCreateTime = orderCreateTime;
	}

	public Date getOrderPayTime() {
		return orderPayTime;
	}

	public void setOrderPayTime(Date orderPayTime) {
		this.orderPayTime = orderPayTime;
	}

	public Date getOrderModifyTime() {
		return orderModifyTime;
	}

	public void setOrderModifyTime(Date orderModifyTime) {
		this.orderModifyTime = orderModifyTime;
	}

	public Date getOrderEndTime() {
		return orderEndTime;
	}

	public void setOrderEndTime(Date orderEndTime) {
		this.orderEndTime = orderEndTime;
	}

	public Date getConsignTime() {
		return consignTime;
	}

	public void setConsignTime(Date consignTime) {
		this.consignTime = consignTime;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverMobile() {
		return receiverMobile;
	}

	public void setReceiverMobile(String receiverMobile) {
		this.receiverMobile = receiverMobile;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}

	public String getReceiverState() {
		return receiverState;
	}

	public void setReceiverState(String receiverState) {
		this.receiverState = receiverState;
	}

	public String getReceiverCity() {
		return receiverCity;
	}

	public void setReceiverCity(String receiverCity) {
		this.receiverCity = receiverCity;
	}

	public String getReceiverCounty() {
		return receiverCounty;
	}

	public void setReceiverCounty(String receiverCounty) {
		this.receiverCounty = receiverCounty;
	}

	public String getReceiverAddress() {
		return receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public String getReceiverCountry() {
		return receiverCountry;
	}

	public void setReceiverCountry(String receiverCountry) {
		this.receiverCountry = receiverCountry;
	}

	public String getReceiverTown() {
		return receiverTown;
	}

	public void setReceiverTown(String receiverTown) {
		this.receiverTown = receiverTown;
	}

	public String getReceiverZip() {
		return receiverZip;
	}

	public void setReceiverZip(String receiverZip) {
		this.receiverZip = receiverZip;
	}

	public String getBuyerMessage() {
		return buyerMessage;
	}

	public void setBuyerMessage(String buyerMessage) {
		this.buyerMessage = buyerMessage;
	}

	public String getSellerMemo() {
		return sellerMemo;
	}

	public void setSellerMemo(String sellerMemo) {
		this.sellerMemo = sellerMemo;
	}

	public Long getPlatformId() {
		return platformId;
	}

	public void setPlatformId(Long platformId) {
		this.platformId = platformId;
	}

	public Long getStockId() {
		return stockId;
	}

	public void setStockId(Long stockId) {
		this.stockId = stockId;
	}
}