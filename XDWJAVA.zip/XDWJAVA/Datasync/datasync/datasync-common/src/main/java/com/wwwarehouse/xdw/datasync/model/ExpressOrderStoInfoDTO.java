package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

/**
 * Created by wenquan.wu on 2017/6/17.
 */
public class ExpressOrderStoInfoDTO extends ExpressOrderInfoDTO {
    private static final long serialVersionUID = -2763898102926720695L;
    private String remark; //订单备注
    private String systemCode; //系统编号
    private String SiteCode; //网点编码
    private String OrderSource; //合作伙伴编码

    public String getSystemCode() {
        return systemCode;
    }

    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public String getSiteCode() {
        return SiteCode;
    }

    public void setSiteCode(String siteCode) {
        SiteCode = siteCode;
    }

    public String getOrderSource() {
        return OrderSource;
    }

    public void setOrderSource(String orderSource) {
        OrderSource = orderSource;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public ExpressOrderStoInfoDTO(){

    }

    public ExpressOrderStoInfoDTO(String orderId, String expressId, Long expressCode,
                                  ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size,
                                  int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
        super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment,
                createDate, isInsured, insuredValue);
    }
}
