package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

public class ExpressOrderEMSInfoDTO extends ExpressOrderInfoDTO {

	private static final long serialVersionUID = 7037167267054684137L;

	private String businessType;// 业务类型
	private String dateType;// 时间类型
	private String cargoType;// 内件类型
	private double length;// 货物长度
	private String insureType;// 所负责任
	private double fee;// 货款金额
	private String cargoDesc;// 内件信息
	private String deliveryclaim;// 揽投员的投递要求
	private String bigAccountDataId;// 邮件数据唯一标识
	private String payType; // 付款方式(现金、pos、支票)

	public ExpressOrderEMSInfoDTO(String orderId, String expressId, Long expressCode,
			ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size,
			int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
		super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment,
				createDate, isInsured, insuredValue);
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public String getCargoType() {
		return cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getInsureType() {
		return insureType;
	}

	public void setInsureType(String insureType) {
		this.insureType = insureType;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public String getCargoDesc() {
		return cargoDesc;
	}

	public void setCargoDesc(String cargoDesc) {
		this.cargoDesc = cargoDesc;
	}

	public String getDeliveryclaim() {
		return deliveryclaim;
	}

	public void setDeliveryclaim(String deliveryclaim) {
		this.deliveryclaim = deliveryclaim;
	}

	public String getBigAccountDataId() {
		return bigAccountDataId;
	}

	public void setBigAccountDataId(String bigAccountDataId) {
		this.bigAccountDataId = bigAccountDataId;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

}
