package com.wwwarehouse.xdw.datasync.model;


import java.util.Date;
import java.util.List;

public class SeBaseRefund<T> extends BaseObject {
	public Long refundUkid;
    public String refundId;//退款单单号
    public Long shopId;
    public Date downTime;
    public Date modifyTime;
    public Date releaseTime;
    public Long originRefundStatus;
    private List<T> itemList;
	/**
	 *更新时间
	 **/
	private Date updateTime;

    
    
	public String getRefundId() {
		return refundId;
	}

	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}

	public Long getOriginRefundStatus() {
		return originRefundStatus;
	}

	public void setOriginRefundStatus(Long originRefundStatus) {
		this.originRefundStatus = originRefundStatus;
	}

	public Date getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(Date releaseTime) {
		this.releaseTime = releaseTime;
	}


	public List<T> getItemList() {
        return itemList;
    }

    public void setItemList(List<T> itemList) {
        this.itemList = itemList;
    }


    public Long getRefundUkid() {
		return refundUkid;
	}

	public void setRefundUkid(Long refundUkid) {
		this.refundUkid = refundUkid;
	}

	public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Date getReleaseDate() {
        return releaseTime;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseTime = releaseDate;
    }

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
