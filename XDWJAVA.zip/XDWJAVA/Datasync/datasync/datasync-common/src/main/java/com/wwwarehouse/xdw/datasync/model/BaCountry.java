package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.Date;

public class BaCountry implements Serializable {
    private String countryId;

    private String countryNameEn;

    private String countryNameZh;

    private String countryCallingCode;

    private String timeZone;

    private Short jetLag;

    private String extraCountryId;

    private Date createTime;

    private Date updateTime;

    private Short updateUserId;

    private Short createUserId;

    private static final long serialVersionUID = 1L;

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getCountryNameEn() {
        return countryNameEn;
    }

    public void setCountryNameEn(String countryNameEn) {
        this.countryNameEn = countryNameEn;
    }

    public String getCountryNameZh() {
        return countryNameZh;
    }

    public void setCountryNameZh(String countryNameZh) {
        this.countryNameZh = countryNameZh;
    }

    public String getCountryCallingCode() {
        return countryCallingCode;
    }

    public void setCountryCallingCode(String countryCallingCode) {
        this.countryCallingCode = countryCallingCode;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Short getJetLag() {
        return jetLag;
    }

    public void setJetLag(Short jetLag) {
        this.jetLag = jetLag;
    }

    public String getExtraCountryId() {
        return extraCountryId;
    }

    public void setExtraCountryId(String extraCountryId) {
        this.extraCountryId = extraCountryId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Short getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Short updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Short getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Short createUserId) {
        this.createUserId = createUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", countryId=").append(countryId);
        sb.append(", countryNameEn=").append(countryNameEn);
        sb.append(", countryNameZh=").append(countryNameZh);
        sb.append(", countryCallingCode=").append(countryCallingCode);
        sb.append(", timeZone=").append(timeZone);
        sb.append(", jetLag=").append(jetLag);
        sb.append(", extraCountryId=").append(extraCountryId);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", createUserId=").append(createUserId);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        BaCountry other = (BaCountry) that;
        return (this.getCountryId() == null ? other.getCountryId() == null : this.getCountryId().equals(other.getCountryId()))
            && (this.getCountryNameEn() == null ? other.getCountryNameEn() == null : this.getCountryNameEn().equals(other.getCountryNameEn()))
            && (this.getCountryNameZh() == null ? other.getCountryNameZh() == null : this.getCountryNameZh().equals(other.getCountryNameZh()))
            && (this.getCountryCallingCode() == null ? other.getCountryCallingCode() == null : this.getCountryCallingCode().equals(other.getCountryCallingCode()))
            && (this.getTimeZone() == null ? other.getTimeZone() == null : this.getTimeZone().equals(other.getTimeZone()))
            && (this.getJetLag() == null ? other.getJetLag() == null : this.getJetLag().equals(other.getJetLag()))
            && (this.getExtraCountryId() == null ? other.getExtraCountryId() == null : this.getExtraCountryId().equals(other.getExtraCountryId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getCountryId() == null) ? 0 : getCountryId().hashCode());
        result = prime * result + ((getCountryNameEn() == null) ? 0 : getCountryNameEn().hashCode());
        result = prime * result + ((getCountryNameZh() == null) ? 0 : getCountryNameZh().hashCode());
        result = prime * result + ((getCountryCallingCode() == null) ? 0 : getCountryCallingCode().hashCode());
        result = prime * result + ((getTimeZone() == null) ? 0 : getTimeZone().hashCode());
        result = prime * result + ((getJetLag() == null) ? 0 : getJetLag().hashCode());
        result = prime * result + ((getExtraCountryId() == null) ? 0 : getExtraCountryId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        return result;
    }
}