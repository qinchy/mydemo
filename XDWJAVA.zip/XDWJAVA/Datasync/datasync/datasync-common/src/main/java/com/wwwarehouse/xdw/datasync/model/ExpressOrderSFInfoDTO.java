package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

public class ExpressOrderSFInfoDTO extends ExpressOrderInfoDTO {
	private static final long serialVersionUID = 8542784517005781677L;

	private String expressServiceCode;// 快件产品代码 如01标准快递、02电商速配等
	private String paymentType;// 付款类型，01月结、02现金等
	private String paymentAccountNo;// 月结账户
	private String deliveryMode;// 投递方式 01送货上门, 02自取等
	private int is_gen_bill_no;// 是否要求返回顺丰运单号
	private String custid;// 顺丰月结卡号 ////
	private int pay_method;// 付款方式：1:寄方付 2:收方付 3:第三方付
	private String express_type;// 快件产品类别
	private int parcel_quantity;// 包裹数
	private Date sendstarttime;// 要求上门取件开始时间，格式：YYYY-MM-DD HH24:MM:SS
	private String order_source;// 客户订单来源（对于平台类客户，如果需要在订单中区分订单来源，则可使用此字段
	private int dealtype;
	private String remark; // 备注


	public ExpressOrderSFInfoDTO(String orderId, String expressId, Long expressCode,
			ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size,
			int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
		super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment,
				createDate, isInsured, insuredValue);
	}

	/**
	 * 快件产品代码 如01标准快递、02电商速配等
	 * 
	 * @return
	 */
	public String getExpressServiceCode() {
		return expressServiceCode;
	}

	/**
	 * 快件产品代码 如01标准快递、02电商速配等
	 * 
	 * @param expressServiceCode
	 */
	public void setExpressServiceCode(String expressServiceCode) {
		this.expressServiceCode = expressServiceCode;
	}

	/**
	 * 付款类型，01月结、02现金等
	 * 
	 * @return
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * 付款类型，01月结、02现金等
	 * 
	 * @param paymentType
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentAccountNo() {
		return paymentAccountNo;
	}

	public void setPaymentAccountNo(String paymentAccountNo) {
		this.paymentAccountNo = paymentAccountNo;
	}

	/**
	 * 投递方式 01送货上门, 02自取等
	 * 
	 * @return
	 */
	public String getDeliveryMode() {
		return deliveryMode;
	}

	/**
	 * 投递方式 01送货上门, 02自取等
	 * 
	 * @param deliveryMode
	 */
	public void setDeliveryMode(String deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	public int getIs_gen_bill_no() {
		return is_gen_bill_no;
	}

	public void setIs_gen_bill_no(int is_gen_bill_no) {
		this.is_gen_bill_no = is_gen_bill_no;
	}

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	/**
	 * 付款方式：1:寄方付 2:收方付 3:第三方付
	 * 
	 * @return
	 */
	public int getPay_method() {
		return pay_method;
	}

	/**
	 * 付款方式：1:寄方付 2:收方付 3:第三方付
	 * 
	 * @param pay_method
	 */
	public void setPay_method(int pay_method) {
		this.pay_method = pay_method;
	}

	public String getExpress_type() {
		return express_type;
	}

	public void setExpress_type(String express_type) {
		this.express_type = express_type;
	}

	public int getParcel_quantity() {
		return parcel_quantity;
	}

	public void setParcel_quantity(int parcel_quantity) {
		this.parcel_quantity = parcel_quantity;
	}

	public Date getSendstarttime() {
		return sendstarttime;
	}

	public void setSendstarttime(Date sendstarttime) {
		this.sendstarttime = sendstarttime;
	}

	public String getOrder_source() {
		return order_source;
	}

	public void setOrder_source(String order_source) {
		this.order_source = order_source;
	}

	public int getDealtype() {
		return dealtype;
	}

	public void setDealtype(int dealtype) {
		this.dealtype = dealtype;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
