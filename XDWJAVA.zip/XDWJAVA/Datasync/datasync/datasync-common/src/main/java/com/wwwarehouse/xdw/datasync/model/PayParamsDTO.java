package com.wwwarehouse.xdw.datasync.model;

/**
 * Created by xiuli.yang on 2017/6/13.
 */
public class PayParamsDTO extends BaseObject {
    /**
     * 平台id （1310 支付宝， 1320 银联， 1330 微信）
     */
    private Long platFormId;
    private String tradeNo;
    /**
     * 微信用户端实际ip
     */
    private String clientIp;
    private String title;
    private double amount;
    /**
     * 微信注册唯一标识
     */
    private String openId;
    /**
     * 微信：公对私/私对公
     */
    private boolean isP2C;
    /**
     * 微信：应用注册类型
     */
    private String regAppType;

    public Long getPlatFormId() {
        return platFormId;
    }

    public void setPlatFormId(Long platFormId) {
        this.platFormId = platFormId;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public boolean isP2C() {
        return isP2C;
    }

    public void setIsP2C(boolean isP2C) {
        this.isP2C = isP2C;
    }

    public String getRegAppType() {
        return regAppType;
    }

    public void setRegAppType(String regAppType) {
        this.regAppType = regAppType;
    }
}
