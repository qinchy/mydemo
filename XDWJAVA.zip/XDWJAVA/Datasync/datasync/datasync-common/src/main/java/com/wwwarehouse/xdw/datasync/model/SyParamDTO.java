package com.wwwarehouse.xdw.datasync.model;

public class SyParamDTO extends BaseObject {

	public static final String L_NEED_DOWN_TRADE = "NEED_DOWN_TRADE";			//是否需要下载订单
	public static final String L_NEED_DOWN_TRADE_HIS = "NEED_DOWN_TRADE_HIS";	//是否需要下载订单
	public static final String L_NEED_DOWN_PRODUCT = "NEED_DOWN_RPODUCT";		//是否需要下载商品
	public static final String S_DOWN_TRADE_STATUS = "DOWN_TRADE_STATUS";		//下载订单的状态
	public static final String S_DOWN_TRADE_STATUS_HIS = "DOWN_TRADE_STATUS_HIS";//下载历史订单的状态
	public static final String D_LAST_TRADE = "LAST_TRADE";						//上次下载订单时间
	public static final String D_LAST_TRADE_HIS = "LAST_TRADE_HIS";				//历史下载订单时间
	public static final String L_HIS_TRADE_TIME_RANGE = "HIS_TRADE_TIME_RANGE";	//下载历史订单的往前推时间长度（天）
	public static final String L_PRODUCT_TIME_RANGE = "PRODUCT_TIME_RANGE";		//下载商品的往前推时间长度（天）
	public static final String D_LAST_TRADE_INC = "LAST_TRADE_INC";				//上次增量下载订单的时间
	public static final String D_LAST_TRADERATE = "LAST_TRADERATE";
	public static final String D_LAST_PURCHASE = "LAST_PURCHASE";
	public static final String D_LAST_REFUND = "LAST_REFUND";
	public static final String S_SHOP_SCORE_URL = "SHOP_SCORE_URL";
	public static final String L_HAS_PRESALE = "HAS_PRESALE";
	public static final String L_NOT_SHIP_NOTICE = "NOT_SHIP_NOTICE";
	public static final String L_REQUIRE_SHIP_DAY = "REQUIRE_SHIP_DAY";
	public static final String L_AUTO_ADD_RETURN = "AUTO_ADD_RETURN";
	public static final String L_FLOOR_COD_FEE = "FLOOR_COD_FEE";
	public static final String L_AUTO_ALLOCATION_RETURN = "AUTO_ALLOCATION_RETURN";
	public static final String L_DOWN_RATE_FLAG = "DOWN_RATE_FLAG";
	public static final String L_PUSH_TMC = "PUSH_TMC";
	public static final String L_END_REMOVE_ORDER_STATUS = "END_REMOVE_ORDER_STATUS";
	public static final String D_LAST_SYN_INVENTORY = "LAST_SYN_INVENTORY";
	public static final String L_SHIP_TRACK_TYPE = "SHIP_TRACK_TYPE";
	public static final String S_API_URL = "API_URL";
	
	private Long relatedId;

	private String paramName;

	private String paramValue;

	private String remark;

	public Long getRelatedId() {
		return relatedId;
	}

	public void setRelatedId(Long relatedId) {
		this.relatedId = relatedId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}