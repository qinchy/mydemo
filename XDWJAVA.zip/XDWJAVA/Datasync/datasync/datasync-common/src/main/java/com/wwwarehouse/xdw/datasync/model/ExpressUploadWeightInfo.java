package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.Date;

public class ExpressUploadWeightInfo implements Serializable {

	private static final long serialVersionUID = 276590487729652169L;

	private String expressId; // 快递单号
	private Long expressCode;
	private Double weight; // 包裹重量
	private Long packageId; // 包裹id
	private String orderId; // 订单id
	private Date scanTime; // 包裹扫描时间

	public String getExpressId() {
		return expressId;
	}

	public void setExpressId(String expressId) {
		this.expressId = expressId;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Long getPackageId() {
		return packageId;
	}

	public void setPackageId(Long packageId) {
		this.packageId = packageId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Date getScanTime() {
		return scanTime;
	}

	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}

	public Long getExpressCode() {
		return expressCode;
	}

	public void setExpressCode(Long expressCode) {
		this.expressCode = expressCode;
	}
}
