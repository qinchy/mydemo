package com.wwwarehouse.xdw.datasync.model;


import java.math.BigDecimal;
import java.util.Date;

public class SeJingdongTradeDTO extends SeBaseTrade<SeJingdongItemDTO> {
    private Long tradeUkid;

    private Long shopId;

    private Date downTime;

    private Date updateTime;

    private Date releaseTime;

    private Long originTradeStatus;

    private String orderId;

    private String orderSource;

    private String customs;

    private String customsModel;

    private String venderId;

    private String payType;

    private BigDecimal orderTotalPrice;

    private BigDecimal orderSellerPrice;

    private BigDecimal orderPayment;

    private BigDecimal freightPrice;

    private BigDecimal sellerDiscount;

    private String deliveryType;

    private String invoiceInfo;

    private String buyerMessage;

    private Date orderEndTime;

    private String receiverName;

    private String receiverPhone;

    private String receiverMobile;

    private String receiverAddress;

    private String receiverState;

    private String receiverCity;

    private String receiverCounty;

    private String balanceUsed;

    private String returnOrder;

    private String wayBill;

    private String logisticsId;

    private Date orderModifyTime;

    private String parentOrderId;

    private String orderType;

    private String storeOrder;

    private String taxPayerIdent;

    private String registeredAddress;

    private String registeredPhone;

    private String depositBank;

    private String bankAccount;

    private Long targetOrderUkid;

    private String platformOrderStatus;

    private Date orderCreateTime;

    private Date orderPayTime;

    private String buyerNick;

    private String receiverZip;

    private String sellerMemo;

    private Long isCod;

    private static final long serialVersionUID = 1L;

    public Long getTradeUkid() {
        return tradeUkid;
    }

    public void setTradeUkid(Long tradeUkid) {
        this.tradeUkid = tradeUkid;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public Long getOriginTradeStatus() {
        return originTradeStatus;
    }

    public void setOriginTradeStatus(Long originTradeStatus) {
        this.originTradeStatus = originTradeStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getCustoms() {
        return customs;
    }

    public void setCustoms(String customs) {
        this.customs = customs;
    }

    public String getCustomsModel() {
        return customsModel;
    }

    public void setCustomsModel(String customsModel) {
        this.customsModel = customsModel;
    }

    public String getVenderId() {
        return venderId;
    }

    public void setVenderId(String venderId) {
        this.venderId = venderId;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public BigDecimal getOrderTotalPrice() {
        return orderTotalPrice;
    }

    public void setOrderTotalPrice(BigDecimal orderTotalPrice) {
        this.orderTotalPrice = orderTotalPrice;
    }

    public BigDecimal getOrderSellerPrice() {
        return orderSellerPrice;
    }

    public void setOrderSellerPrice(BigDecimal orderSellerPrice) {
        this.orderSellerPrice = orderSellerPrice;
    }

    public BigDecimal getOrderPayment() {
        return orderPayment;
    }

    public void setOrderPayment(BigDecimal orderPayment) {
        this.orderPayment = orderPayment;
    }

    public BigDecimal getFreightPrice() {
        return freightPrice;
    }

    public void setFreightPrice(BigDecimal freightPrice) {
        this.freightPrice = freightPrice;
    }

    public BigDecimal getSellerDiscount() {
        return sellerDiscount;
    }

    public void setSellerDiscount(BigDecimal sellerDiscount) {
        this.sellerDiscount = sellerDiscount;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getInvoiceInfo() {
        return invoiceInfo;
    }

    public void setInvoiceInfo(String invoiceInfo) {
        this.invoiceInfo = invoiceInfo;
    }

    public String getBuyerMessage() {
        return buyerMessage;
    }

    public void setBuyerMessage(String buyerMessage) {
        this.buyerMessage = buyerMessage;
    }

    public Date getOrderEndTime() {
        return orderEndTime;
    }

    public void setOrderEndTime(Date orderEndTime) {
        this.orderEndTime = orderEndTime;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getReceiverMobile() {
        return receiverMobile;
    }

    public void setReceiverMobile(String receiverMobile) {
        this.receiverMobile = receiverMobile;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public String getReceiverState() {
        return receiverState;
    }

    public void setReceiverState(String receiverState) {
        this.receiverState = receiverState;
    }

    public String getReceiverCity() {
        return receiverCity;
    }

    public void setReceiverCity(String receiverCity) {
        this.receiverCity = receiverCity;
    }

    public String getReceiverCounty() {
        return receiverCounty;
    }

    public void setReceiverCounty(String receiverCounty) {
        this.receiverCounty = receiverCounty;
    }

    public String getBalanceUsed() {
        return balanceUsed;
    }

    public void setBalanceUsed(String balanceUsed) {
        this.balanceUsed = balanceUsed;
    }

    public String getReturnOrder() {
        return returnOrder;
    }

    public void setReturnOrder(String returnOrder) {
        this.returnOrder = returnOrder;
    }

    public String getWayBill() {
        return wayBill;
    }

    public void setWayBill(String wayBill) {
        this.wayBill = wayBill;
    }

    public String getLogisticsId() {
        return logisticsId;
    }

    public void setLogisticsId(String logisticsId) {
        this.logisticsId = logisticsId;
    }

    public Date getOrderModifyTime() {
        return orderModifyTime;
    }

    public void setOrderModifyTime(Date orderModifyTime) {
        this.orderModifyTime = orderModifyTime;
    }

    public String getParentOrderId() {
        return parentOrderId;
    }

    public void setParentOrderId(String parentOrderId) {
        this.parentOrderId = parentOrderId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getStoreOrder() {
        return storeOrder;
    }

    public void setStoreOrder(String storeOrder) {
        this.storeOrder = storeOrder;
    }

    public String getTaxPayerIdent() {
        return taxPayerIdent;
    }

    public void setTaxPayerIdent(String taxPayerIdent) {
        this.taxPayerIdent = taxPayerIdent;
    }

    public String getRegisteredAddress() {
        return registeredAddress;
    }

    public void setRegisteredAddress(String registeredAddress) {
        this.registeredAddress = registeredAddress;
    }

    public String getRegisteredPhone() {
        return registeredPhone;
    }

    public void setRegisteredPhone(String registeredPhone) {
        this.registeredPhone = registeredPhone;
    }

    public String getDepositBank() {
        return depositBank;
    }

    public void setDepositBank(String depositBank) {
        this.depositBank = depositBank;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public Long getTargetOrderUkid() {
        return targetOrderUkid;
    }

    public void setTargetOrderUkid(Long targetOrderUkid) {
        this.targetOrderUkid = targetOrderUkid;
    }

    public String getPlatformOrderStatus() {
        return platformOrderStatus;
    }

    public void setPlatformOrderStatus(String platformOrderStatus) {
        this.platformOrderStatus = platformOrderStatus;
    }

    public Date getOrderCreateTime() {
        return orderCreateTime;
    }

    public void setOrderCreateTime(Date orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }

    public Date getOrderPayTime() {
        return orderPayTime;
    }

    public void setOrderPayTime(Date orderPayTime) {
        this.orderPayTime = orderPayTime;
    }

    public String getBuyerNick() {
        return buyerNick;
    }

    public void setBuyerNick(String buyerNick) {
        this.buyerNick = buyerNick;
    }

    public String getReceiverZip() {
        return receiverZip;
    }

    public void setReceiverZip(String receiverZip) {
        this.receiverZip = receiverZip;
    }

    public String getSellerMemo() {
        return sellerMemo;
    }

    public void setSellerMemo(String sellerMemo) {
        this.sellerMemo = sellerMemo;
    }

    public Long getIsCod() {
        return isCod;
    }

    public void setIsCod(Long isCod) {
        this.isCod = isCod;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", tradeUkid=").append(tradeUkid);
        sb.append(", shopId=").append(shopId);
        sb.append(", downTime=").append(downTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", releaseTime=").append(releaseTime);
        sb.append(", originTradeStatus=").append(originTradeStatus);
        sb.append(", orderId=").append(orderId);
        sb.append(", orderSource=").append(orderSource);
        sb.append(", customs=").append(customs);
        sb.append(", customsModel=").append(customsModel);
        sb.append(", venderId=").append(venderId);
        sb.append(", payType=").append(payType);
        sb.append(", orderTotalPrice=").append(orderTotalPrice);
        sb.append(", orderSellerPrice=").append(orderSellerPrice);
        sb.append(", orderPayment=").append(orderPayment);
        sb.append(", freightPrice=").append(freightPrice);
        sb.append(", sellerDiscount=").append(sellerDiscount);
        sb.append(", deliveryType=").append(deliveryType);
        sb.append(", invoiceInfo=").append(invoiceInfo);
        sb.append(", buyerMessage=").append(buyerMessage);
        sb.append(", orderEndTime=").append(orderEndTime);
        sb.append(", receiverName=").append(receiverName);
        sb.append(", receiverPhone=").append(receiverPhone);
        sb.append(", receiverMobile=").append(receiverMobile);
        sb.append(", receiverAddress=").append(receiverAddress);
        sb.append(", receiverState=").append(receiverState);
        sb.append(", receiverCity=").append(receiverCity);
        sb.append(", receiverCounty=").append(receiverCounty);
        sb.append(", balanceUsed=").append(balanceUsed);
        sb.append(", returnOrder=").append(returnOrder);
        sb.append(", wayBill=").append(wayBill);
        sb.append(", logisticsId=").append(logisticsId);
        sb.append(", orderModifyTime=").append(orderModifyTime);
        sb.append(", parentOrderId=").append(parentOrderId);
        sb.append(", orderType=").append(orderType);
        sb.append(", storeOrder=").append(storeOrder);
        sb.append(", taxPayerIdent=").append(taxPayerIdent);
        sb.append(", registeredAddress=").append(registeredAddress);
        sb.append(", registeredPhone=").append(registeredPhone);
        sb.append(", depositBank=").append(depositBank);
        sb.append(", bankAccount=").append(bankAccount);
        sb.append(", targetOrderUkid=").append(targetOrderUkid);
        sb.append(", platformOrderStatus=").append(platformOrderStatus);
        sb.append(", orderCreateTime=").append(orderCreateTime);
        sb.append(", orderPayTime=").append(orderPayTime);
        sb.append(", buyerNick=").append(buyerNick);
        sb.append(", receiverZip=").append(receiverZip);
        sb.append(", sellerMemo=").append(sellerMemo);
        sb.append(", isCod=").append(isCod);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeJingdongTradeDTO other = (SeJingdongTradeDTO) that;
        return (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
                && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
                && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
                && (this.getReleaseTime() == null ? other.getReleaseTime() == null : this.getReleaseTime().equals(other.getReleaseTime()))
                && (this.getOriginTradeStatus() == null ? other.getOriginTradeStatus() == null : this.getOriginTradeStatus().equals(other.getOriginTradeStatus()))
                && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
                && (this.getOrderSource() == null ? other.getOrderSource() == null : this.getOrderSource().equals(other.getOrderSource()))
                && (this.getCustoms() == null ? other.getCustoms() == null : this.getCustoms().equals(other.getCustoms()))
                && (this.getCustomsModel() == null ? other.getCustomsModel() == null : this.getCustomsModel().equals(other.getCustomsModel()))
                && (this.getVenderId() == null ? other.getVenderId() == null : this.getVenderId().equals(other.getVenderId()))
                && (this.getPayType() == null ? other.getPayType() == null : this.getPayType().equals(other.getPayType()))
                && (this.getOrderTotalPrice() == null ? other.getOrderTotalPrice() == null : this.getOrderTotalPrice().equals(other.getOrderTotalPrice()))
                && (this.getOrderSellerPrice() == null ? other.getOrderSellerPrice() == null : this.getOrderSellerPrice().equals(other.getOrderSellerPrice()))
                && (this.getOrderPayment() == null ? other.getOrderPayment() == null : this.getOrderPayment().equals(other.getOrderPayment()))
                && (this.getFreightPrice() == null ? other.getFreightPrice() == null : this.getFreightPrice().equals(other.getFreightPrice()))
                && (this.getSellerDiscount() == null ? other.getSellerDiscount() == null : this.getSellerDiscount().equals(other.getSellerDiscount()))
                && (this.getDeliveryType() == null ? other.getDeliveryType() == null : this.getDeliveryType().equals(other.getDeliveryType()))
                && (this.getInvoiceInfo() == null ? other.getInvoiceInfo() == null : this.getInvoiceInfo().equals(other.getInvoiceInfo()))
                && (this.getBuyerMessage() == null ? other.getBuyerMessage() == null : this.getBuyerMessage().equals(other.getBuyerMessage()))
                && (this.getOrderEndTime() == null ? other.getOrderEndTime() == null : this.getOrderEndTime().equals(other.getOrderEndTime()))
                && (this.getReceiverName() == null ? other.getReceiverName() == null : this.getReceiverName().equals(other.getReceiverName()))
                && (this.getReceiverPhone() == null ? other.getReceiverPhone() == null : this.getReceiverPhone().equals(other.getReceiverPhone()))
                && (this.getReceiverMobile() == null ? other.getReceiverMobile() == null : this.getReceiverMobile().equals(other.getReceiverMobile()))
                && (this.getReceiverAddress() == null ? other.getReceiverAddress() == null : this.getReceiverAddress().equals(other.getReceiverAddress()))
                && (this.getReceiverState() == null ? other.getReceiverState() == null : this.getReceiverState().equals(other.getReceiverState()))
                && (this.getReceiverCity() == null ? other.getReceiverCity() == null : this.getReceiverCity().equals(other.getReceiverCity()))
                && (this.getReceiverCounty() == null ? other.getReceiverCounty() == null : this.getReceiverCounty().equals(other.getReceiverCounty()))
                && (this.getBalanceUsed() == null ? other.getBalanceUsed() == null : this.getBalanceUsed().equals(other.getBalanceUsed()))
                && (this.getReturnOrder() == null ? other.getReturnOrder() == null : this.getReturnOrder().equals(other.getReturnOrder()))
                && (this.getWayBill() == null ? other.getWayBill() == null : this.getWayBill().equals(other.getWayBill()))
                && (this.getLogisticsId() == null ? other.getLogisticsId() == null : this.getLogisticsId().equals(other.getLogisticsId()))
                && (this.getOrderModifyTime() == null ? other.getOrderModifyTime() == null : this.getOrderModifyTime().equals(other.getOrderModifyTime()))
                && (this.getParentOrderId() == null ? other.getParentOrderId() == null : this.getParentOrderId().equals(other.getParentOrderId()))
                && (this.getOrderType() == null ? other.getOrderType() == null : this.getOrderType().equals(other.getOrderType()))
                && (this.getStoreOrder() == null ? other.getStoreOrder() == null : this.getStoreOrder().equals(other.getStoreOrder()))
                && (this.getTaxPayerIdent() == null ? other.getTaxPayerIdent() == null : this.getTaxPayerIdent().equals(other.getTaxPayerIdent()))
                && (this.getRegisteredAddress() == null ? other.getRegisteredAddress() == null : this.getRegisteredAddress().equals(other.getRegisteredAddress()))
                && (this.getRegisteredPhone() == null ? other.getRegisteredPhone() == null : this.getRegisteredPhone().equals(other.getRegisteredPhone()))
                && (this.getDepositBank() == null ? other.getDepositBank() == null : this.getDepositBank().equals(other.getDepositBank()))
                && (this.getBankAccount() == null ? other.getBankAccount() == null : this.getBankAccount().equals(other.getBankAccount()))
                && (this.getTargetOrderUkid() == null ? other.getTargetOrderUkid() == null : this.getTargetOrderUkid().equals(other.getTargetOrderUkid()))
                && (this.getPlatformOrderStatus() == null ? other.getPlatformOrderStatus() == null : this.getPlatformOrderStatus().equals(other.getPlatformOrderStatus()))
                && (this.getOrderCreateTime() == null ? other.getOrderCreateTime() == null : this.getOrderCreateTime().equals(other.getOrderCreateTime()))
                && (this.getOrderPayTime() == null ? other.getOrderPayTime() == null : this.getOrderPayTime().equals(other.getOrderPayTime()))
                && (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
                && (this.getReceiverZip() == null ? other.getReceiverZip() == null : this.getReceiverZip().equals(other.getReceiverZip()))
                && (this.getSellerMemo() == null ? other.getSellerMemo() == null : this.getSellerMemo().equals(other.getSellerMemo()))
                && (this.getIsCod() == null ? other.getIsCod() == null : this.getIsCod().equals(other.getIsCod()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getReleaseTime() == null) ? 0 : getReleaseTime().hashCode());
        result = prime * result + ((getOriginTradeStatus() == null) ? 0 : getOriginTradeStatus().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getOrderSource() == null) ? 0 : getOrderSource().hashCode());
        result = prime * result + ((getCustoms() == null) ? 0 : getCustoms().hashCode());
        result = prime * result + ((getCustomsModel() == null) ? 0 : getCustomsModel().hashCode());
        result = prime * result + ((getVenderId() == null) ? 0 : getVenderId().hashCode());
        result = prime * result + ((getPayType() == null) ? 0 : getPayType().hashCode());
        result = prime * result + ((getOrderTotalPrice() == null) ? 0 : getOrderTotalPrice().hashCode());
        result = prime * result + ((getOrderSellerPrice() == null) ? 0 : getOrderSellerPrice().hashCode());
        result = prime * result + ((getOrderPayment() == null) ? 0 : getOrderPayment().hashCode());
        result = prime * result + ((getFreightPrice() == null) ? 0 : getFreightPrice().hashCode());
        result = prime * result + ((getSellerDiscount() == null) ? 0 : getSellerDiscount().hashCode());
        result = prime * result + ((getDeliveryType() == null) ? 0 : getDeliveryType().hashCode());
        result = prime * result + ((getInvoiceInfo() == null) ? 0 : getInvoiceInfo().hashCode());
        result = prime * result + ((getBuyerMessage() == null) ? 0 : getBuyerMessage().hashCode());
        result = prime * result + ((getOrderEndTime() == null) ? 0 : getOrderEndTime().hashCode());
        result = prime * result + ((getReceiverName() == null) ? 0 : getReceiverName().hashCode());
        result = prime * result + ((getReceiverPhone() == null) ? 0 : getReceiverPhone().hashCode());
        result = prime * result + ((getReceiverMobile() == null) ? 0 : getReceiverMobile().hashCode());
        result = prime * result + ((getReceiverAddress() == null) ? 0 : getReceiverAddress().hashCode());
        result = prime * result + ((getReceiverState() == null) ? 0 : getReceiverState().hashCode());
        result = prime * result + ((getReceiverCity() == null) ? 0 : getReceiverCity().hashCode());
        result = prime * result + ((getReceiverCounty() == null) ? 0 : getReceiverCounty().hashCode());
        result = prime * result + ((getBalanceUsed() == null) ? 0 : getBalanceUsed().hashCode());
        result = prime * result + ((getReturnOrder() == null) ? 0 : getReturnOrder().hashCode());
        result = prime * result + ((getWayBill() == null) ? 0 : getWayBill().hashCode());
        result = prime * result + ((getLogisticsId() == null) ? 0 : getLogisticsId().hashCode());
        result = prime * result + ((getOrderModifyTime() == null) ? 0 : getOrderModifyTime().hashCode());
        result = prime * result + ((getParentOrderId() == null) ? 0 : getParentOrderId().hashCode());
        result = prime * result + ((getOrderType() == null) ? 0 : getOrderType().hashCode());
        result = prime * result + ((getStoreOrder() == null) ? 0 : getStoreOrder().hashCode());
        result = prime * result + ((getTaxPayerIdent() == null) ? 0 : getTaxPayerIdent().hashCode());
        result = prime * result + ((getRegisteredAddress() == null) ? 0 : getRegisteredAddress().hashCode());
        result = prime * result + ((getRegisteredPhone() == null) ? 0 : getRegisteredPhone().hashCode());
        result = prime * result + ((getDepositBank() == null) ? 0 : getDepositBank().hashCode());
        result = prime * result + ((getBankAccount() == null) ? 0 : getBankAccount().hashCode());
        result = prime * result + ((getTargetOrderUkid() == null) ? 0 : getTargetOrderUkid().hashCode());
        result = prime * result + ((getPlatformOrderStatus() == null) ? 0 : getPlatformOrderStatus().hashCode());
        result = prime * result + ((getOrderCreateTime() == null) ? 0 : getOrderCreateTime().hashCode());
        result = prime * result + ((getOrderPayTime() == null) ? 0 : getOrderPayTime().hashCode());
        result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
        result = prime * result + ((getReceiverZip() == null) ? 0 : getReceiverZip().hashCode());
        result = prime * result + ((getSellerMemo() == null) ? 0 : getSellerMemo().hashCode());
        result = prime * result + ((getIsCod() == null) ? 0 : getIsCod().hashCode());
        return result;
    }
}