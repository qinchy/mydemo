package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 14:43 on 2017/6/16.
 * @Modified By:
 */
@XStreamAlias("RouteResponse")
public class RouteResponse extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String  mailno;

    @XStreamImplicit()
    private List<Route> routes = new ArrayList<>();

    public String getMailno() {
        return mailno;
    }

    public void setMailno(String mailno) {
        this.mailno = mailno;
    }

    public List<Route> getRoutes() {
        return routes;
    }

    public void setRoutes(List<Route> routes) {
        this.routes = routes;
    }

}
