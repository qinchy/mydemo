package com.wwwarehouse.xdw.datasync.model;

import sun.util.resources.cldr.ga.LocaleNames_ga;

/**
 * Created by xuchun on 16/2/23.
 */
public class ExpressOrderItemInfoDTO extends BaseObject {
	private String name;
	private double weight;
	private String remark;
	private String id;  //商品ID
	private String category; //商品品类
	private String unitprice; //单价
	private Long itemNum; //商品数量
	private String itemName; //商品名称
	private String extendFields;  //is_precious:1
	private Long insuredAmount;  //199900


	public Long getItemNum() {
		return itemNum;
	}

	public void setItemNum(Long itemNum) {
		this.itemNum = itemNum;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getExtendFields() {
		return extendFields;
	}

	public void setExtendFields(String extendFields) {
		this.extendFields = extendFields;
	}

	public Long getInsuredAmount() {
		return insuredAmount;
	}

	public void setInsuredAmount(Long insuredAmount) {
		this.insuredAmount = insuredAmount;
	}

	public String getUnitprice() {
		return unitprice;
	}

	public void setUnitprice(String unitprice) {
		this.unitprice = unitprice;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}