package com.wwwarehouse.xdw.datasync.service;

import java.util.List;

/**
 * Created by lidan.wu on  2017/6/20.
 */
public interface UnifiService {

    boolean login(String username, String password);

    boolean logout();

    /**
     * 查询连接unifi设备mac信息
     * @return
     */
    List<Object> sites();

}
