package com.wwwarehouse.xdw.datasync.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by xuchun on 16/2/26.
 */
public class SeTaobaoItemDTO extends SeBaseItem {

	private Long itemUkid;

	private Long tradeUkid;

	private Long originOrderStatus;

	private Long shopProductUkid;

	private Long productCodeUkid;

	private String productCode;

	private Date presaleDate;

	private Date downTime;

	private Date updateTime;

	private String workspaceId;

	private String itemMealName;

	private String picPath;

	private String sellerNick;

	private String buyerNick;

	private String refundStatus;

	private String productOuterId;

	private String snapshotUrl;

	private String snapshot;

	private Date timeoutActionTime;

	private Long buyerRate;

	private Long sellerRate;

	private String sellerType;

	private Long cid;

	private BigDecimal subOrderTaxFee;

	private BigDecimal subOrderTaxRate;

	private Long subOrderId;

	private String subOrderStatus;

	private String productName;

	private String type;

	private String iid;

	private BigDecimal price;

	private Long productNumId;

	private Long itemMealId;

	private String skuNumId;

	private Long qty;

	private String skuOuterId;

	private String orderFrom;

	private BigDecimal totalFee;

	private BigDecimal payment;

	private BigDecimal discountFee;

	private BigDecimal adjustFee;

	private Date modified;

	private String skuPropertiesName;

	private Long refundId;

	private Long isOversold;

	private Long isServiceOrder;

	private Date endTime;

	private Date consignTime;

	private String shippingType;

	private Long bindOid;

	private String logisticsCompany;

	private String invoiceNo;

	private Long isDaixiao;

	private BigDecimal divideOrderFee;

	private BigDecimal partMjzDiscount;

	private String ticketOuterId;

	private String ticketExpdateKey;

	private String storeCode;

	private Long isWww;

	private String tmserSpuCode;

	private String bindOids;

	private Long zhengjiStatus;

	private String mdQualification;

	private BigDecimal mdFee;

	private String customization;

	private Long updateUserId;

	private static final long serialVersionUID = 1L;

	public Long getItemUkid() {
		return itemUkid;
	}

	public void setItemUkid(Long itemUkid) {
		this.itemUkid = itemUkid;
	}

	public Long getTradeUkid() {
		return tradeUkid;
	}

	public void setTradeUkid(Long tradeUkid) {
		this.tradeUkid = tradeUkid;
	}

	public Long getOriginOrderStatus() {
		return originOrderStatus;
	}

	public void setOriginOrderStatus(Long originOrderStatus) {
		this.originOrderStatus = originOrderStatus;
	}

	public Long getShopProductUkid() {
		return shopProductUkid;
	}

	public void setShopProductUkid(Long shopProductUkid) {
		this.shopProductUkid = shopProductUkid;
	}

	public Long getProductCodeUkid() {
		return productCodeUkid;
	}

	public void setProductCodeUkid(Long productCodeUkid) {
		this.productCodeUkid = productCodeUkid;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Date getPresaleDate() {
		return presaleDate;
	}

	public void setPresaleDate(Date presaleDate) {
		this.presaleDate = presaleDate;
	}

	public Date getDownTime() {
		return downTime;
	}

	public void setDownTime(Date downTime) {
		this.downTime = downTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getWorkspaceId() {
		return workspaceId;
	}

	public void setWorkspaceId(String workspaceId) {
		this.workspaceId = workspaceId;
	}

	public String getItemMealName() {
		return itemMealName;
	}

	public void setItemMealName(String itemMealName) {
		this.itemMealName = itemMealName;
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

	public String getSellerNick() {
		return sellerNick;
	}

	public void setSellerNick(String sellerNick) {
		this.sellerNick = sellerNick;
	}

	public String getBuyerNick() {
		return buyerNick;
	}

	public void setBuyerNick(String buyerNick) {
		this.buyerNick = buyerNick;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getProductOuterId() {
		return productOuterId;
	}

	public void setProductOuterId(String productOuterId) {
		this.productOuterId = productOuterId;
	}

	public String getSnapshotUrl() {
		return snapshotUrl;
	}

	public void setSnapshotUrl(String snapshotUrl) {
		this.snapshotUrl = snapshotUrl;
	}

	public String getSnapshot() {
		return snapshot;
	}

	public void setSnapshot(String snapshot) {
		this.snapshot = snapshot;
	}

	public Date getTimeoutActionTime() {
		return timeoutActionTime;
	}

	public void setTimeoutActionTime(Date timeoutActionTime) {
		this.timeoutActionTime = timeoutActionTime;
	}

	public Long getBuyerRate() {
		return buyerRate;
	}

	public void setBuyerRate(Long buyerRate) {
		this.buyerRate = buyerRate;
	}

	public Long getSellerRate() {
		return sellerRate;
	}

	public void setSellerRate(Long sellerRate) {
		this.sellerRate = sellerRate;
	}

	public String getSellerType() {
		return sellerType;
	}

	public void setSellerType(String sellerType) {
		this.sellerType = sellerType;
	}

	public Long getCid() {
		return cid;
	}

	public void setCid(Long cid) {
		this.cid = cid;
	}

	public BigDecimal getSubOrderTaxFee() {
		return subOrderTaxFee;
	}

	public void setSubOrderTaxFee(BigDecimal subOrderTaxFee) {
		this.subOrderTaxFee = subOrderTaxFee;
	}

	public BigDecimal getSubOrderTaxRate() {
		return subOrderTaxRate;
	}

	public void setSubOrderTaxRate(BigDecimal subOrderTaxRate) {
		this.subOrderTaxRate = subOrderTaxRate;
	}

	public Long getSubOrderId() {
		return subOrderId;
	}

	public void setSubOrderId(Long subOrderId) {
		this.subOrderId = subOrderId;
	}

	public String getSubOrderStatus() {
		return subOrderStatus;
	}

	public void setSubOrderStatus(String subOrderStatus) {
		this.subOrderStatus = subOrderStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIid() {
		return iid;
	}

	public void setIid(String iid) {
		this.iid = iid;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Long getProductNumId() {
		return productNumId;
	}

	public void setProductNumId(Long productNumId) {
		this.productNumId = productNumId;
	}

	public Long getItemMealId() {
		return itemMealId;
	}

	public void setItemMealId(Long itemMealId) {
		this.itemMealId = itemMealId;
	}

	public String getSkuNumId() {
		return skuNumId;
	}

	public void setSkuNumId(String skuNumId) {
		this.skuNumId = skuNumId;
	}

	public Long getQty() {
		return qty;
	}

	public void setQty(Long qty) {
		this.qty = qty;
	}

	public String getSkuOuterId() {
		return skuOuterId;
	}

	public void setSkuOuterId(String skuOuterId) {
		this.skuOuterId = skuOuterId;
	}

	public String getOrderFrom() {
		return orderFrom;
	}

	public void setOrderFrom(String orderFrom) {
		this.orderFrom = orderFrom;
	}

	public BigDecimal getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}

	public BigDecimal getPayment() {
		return payment;
	}

	public void setPayment(BigDecimal payment) {
		this.payment = payment;
	}

	public BigDecimal getDiscountFee() {
		return discountFee;
	}

	public void setDiscountFee(BigDecimal discountFee) {
		this.discountFee = discountFee;
	}

	public BigDecimal getAdjustFee() {
		return adjustFee;
	}

	public void setAdjustFee(BigDecimal adjustFee) {
		this.adjustFee = adjustFee;
	}

	public Date getModified() {
		return modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public String getSkuPropertiesName() {
		return skuPropertiesName;
	}

	public void setSkuPropertiesName(String skuPropertiesName) {
		this.skuPropertiesName = skuPropertiesName;
	}

	public Long getRefundId() {
		return refundId;
	}

	public void setRefundId(Long refundId) {
		this.refundId = refundId;
	}

	public Long getIsOversold() {
		return isOversold;
	}

	public void setIsOversold(Long isOversold) {
		this.isOversold = isOversold;
	}

	public Long getIsServiceOrder() {
		return isServiceOrder;
	}

	public void setIsServiceOrder(Long isServiceOrder) {
		this.isServiceOrder = isServiceOrder;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getConsignTime() {
		return consignTime;
	}

	public void setConsignTime(Date consignTime) {
		this.consignTime = consignTime;
	}

	public String getShippingType() {
		return shippingType;
	}

	public void setShippingType(String shippingType) {
		this.shippingType = shippingType;
	}

	public Long getBindOid() {
		return bindOid;
	}

	public void setBindOid(Long bindOid) {
		this.bindOid = bindOid;
	}

	public String getLogisticsCompany() {
		return logisticsCompany;
	}

	public void setLogisticsCompany(String logisticsCompany) {
		this.logisticsCompany = logisticsCompany;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Long getIsDaixiao() {
		return isDaixiao;
	}

	public void setIsDaixiao(Long isDaixiao) {
		this.isDaixiao = isDaixiao;
	}

	public BigDecimal getDivideOrderFee() {
		return divideOrderFee;
	}

	public void setDivideOrderFee(BigDecimal divideOrderFee) {
		this.divideOrderFee = divideOrderFee;
	}

	public BigDecimal getPartMjzDiscount() {
		return partMjzDiscount;
	}

	public void setPartMjzDiscount(BigDecimal partMjzDiscount) {
		this.partMjzDiscount = partMjzDiscount;
	}

	public String getTicketOuterId() {
		return ticketOuterId;
	}

	public void setTicketOuterId(String ticketOuterId) {
		this.ticketOuterId = ticketOuterId;
	}

	public String getTicketExpdateKey() {
		return ticketExpdateKey;
	}

	public void setTicketExpdateKey(String ticketExpdateKey) {
		this.ticketExpdateKey = ticketExpdateKey;
	}

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	public Long getIsWww() {
		return isWww;
	}

	public void setIsWww(Long isWww) {
		this.isWww = isWww;
	}

	public String getTmserSpuCode() {
		return tmserSpuCode;
	}

	public void setTmserSpuCode(String tmserSpuCode) {
		this.tmserSpuCode = tmserSpuCode;
	}

	public String getBindOids() {
		return bindOids;
	}

	public void setBindOids(String bindOids) {
		this.bindOids = bindOids;
	}

	public Long getZhengjiStatus() {
		return zhengjiStatus;
	}

	public void setZhengjiStatus(Long zhengjiStatus) {
		this.zhengjiStatus = zhengjiStatus;
	}

	public String getMdQualification() {
		return mdQualification;
	}

	public void setMdQualification(String mdQualification) {
		this.mdQualification = mdQualification;
	}

	public BigDecimal getMdFee() {
		return mdFee;
	}

	public void setMdFee(BigDecimal mdFee) {
		this.mdFee = mdFee;
	}

	public String getCustomization() {
		return customization;
	}

	public void setCustomization(String customization) {
		this.customization = customization;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(", itemUkid=").append(itemUkid);
		sb.append(", tradeUkid=").append(tradeUkid);
		sb.append(", originOrderStatus=").append(originOrderStatus);
		sb.append(", shopProductUkid=").append(shopProductUkid);
		sb.append(", productCodeUkid=").append(productCodeUkid);
		sb.append(", productCode=").append(productCode);
		sb.append(", presaleDate=").append(presaleDate);
		sb.append(", downTime=").append(downTime);
		sb.append(", updateTime=").append(updateTime);
		sb.append(", workspaceId=").append(workspaceId);
		sb.append(", itemMealName=").append(itemMealName);
		sb.append(", picPath=").append(picPath);
		sb.append(", sellerNick=").append(sellerNick);
		sb.append(", buyerNick=").append(buyerNick);
		sb.append(", refundStatus=").append(refundStatus);
		sb.append(", productOuterId=").append(productOuterId);
		sb.append(", snapshotUrl=").append(snapshotUrl);
		sb.append(", snapshot=").append(snapshot);
		sb.append(", timeoutActionTime=").append(timeoutActionTime);
		sb.append(", buyerRate=").append(buyerRate);
		sb.append(", sellerRate=").append(sellerRate);
		sb.append(", sellerType=").append(sellerType);
		sb.append(", cid=").append(cid);
		sb.append(", subOrderTaxFee=").append(subOrderTaxFee);
		sb.append(", subOrderTaxRate=").append(subOrderTaxRate);
		sb.append(", subOrderId=").append(subOrderId);
		sb.append(", subOrderStatus=").append(subOrderStatus);
		sb.append(", productName=").append(productName);
		sb.append(", type=").append(type);
		sb.append(", iid=").append(iid);
		sb.append(", price=").append(price);
		sb.append(", productNumId=").append(productNumId);
		sb.append(", itemMealId=").append(itemMealId);
		sb.append(", skuNumId=").append(skuNumId);
		sb.append(", qty=").append(qty);
		sb.append(", skuOuterId=").append(skuOuterId);
		sb.append(", orderFrom=").append(orderFrom);
		sb.append(", totalFee=").append(totalFee);
		sb.append(", payment=").append(payment);
		sb.append(", discountFee=").append(discountFee);
		sb.append(", adjustFee=").append(adjustFee);
		sb.append(", modified=").append(modified);
		sb.append(", skuPropertiesName=").append(skuPropertiesName);
		sb.append(", refundId=").append(refundId);
		sb.append(", isOversold=").append(isOversold);
		sb.append(", isServiceOrder=").append(isServiceOrder);
		sb.append(", endTime=").append(endTime);
		sb.append(", consignTime=").append(consignTime);
		sb.append(", shippingType=").append(shippingType);
		sb.append(", bindOid=").append(bindOid);
		sb.append(", logisticsCompany=").append(logisticsCompany);
		sb.append(", invoiceNo=").append(invoiceNo);
		sb.append(", isDaixiao=").append(isDaixiao);
		sb.append(", divideOrderFee=").append(divideOrderFee);
		sb.append(", partMjzDiscount=").append(partMjzDiscount);
		sb.append(", ticketOuterId=").append(ticketOuterId);
		sb.append(", ticketExpdateKey=").append(ticketExpdateKey);
		sb.append(", storeCode=").append(storeCode);
		sb.append(", isWww=").append(isWww);
		sb.append(", tmserSpuCode=").append(tmserSpuCode);
		sb.append(", bindOids=").append(bindOids);
		sb.append(", zhengjiStatus=").append(zhengjiStatus);
		sb.append(", mdQualification=").append(mdQualification);
		sb.append(", mdFee=").append(mdFee);
		sb.append(", customization=").append(customization);
		sb.append(", updateUserId=").append(updateUserId);
		sb.append("]");
		return sb.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		SeTaobaoItemDTO other = (SeTaobaoItemDTO) that;
		return (this.getItemUkid() == null ? other.getItemUkid() == null : this.getItemUkid().equals(other.getItemUkid()))
				&& (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
				&& (this.getOriginOrderStatus() == null ? other.getOriginOrderStatus() == null : this.getOriginOrderStatus().equals(other.getOriginOrderStatus()))
				&& (this.getShopProductUkid() == null ? other.getShopProductUkid() == null : this.getShopProductUkid().equals(other.getShopProductUkid()))
				&& (this.getProductCodeUkid() == null ? other.getProductCodeUkid() == null : this.getProductCodeUkid().equals(other.getProductCodeUkid()))
				&& (this.getProductCode() == null ? other.getProductCode() == null : this.getProductCode().equals(other.getProductCode()))
				&& (this.getPresaleDate() == null ? other.getPresaleDate() == null : this.getPresaleDate().equals(other.getPresaleDate()))
				&& (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
				&& (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
				&& (this.getWorkspaceId() == null ? other.getWorkspaceId() == null : this.getWorkspaceId().equals(other.getWorkspaceId()))
				&& (this.getItemMealName() == null ? other.getItemMealName() == null : this.getItemMealName().equals(other.getItemMealName()))
				&& (this.getPicPath() == null ? other.getPicPath() == null : this.getPicPath().equals(other.getPicPath()))
				&& (this.getSellerNick() == null ? other.getSellerNick() == null : this.getSellerNick().equals(other.getSellerNick()))
				&& (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
				&& (this.getRefundStatus() == null ? other.getRefundStatus() == null : this.getRefundStatus().equals(other.getRefundStatus()))
				&& (this.getProductOuterId() == null ? other.getProductOuterId() == null : this.getProductOuterId().equals(other.getProductOuterId()))
				&& (this.getSnapshotUrl() == null ? other.getSnapshotUrl() == null : this.getSnapshotUrl().equals(other.getSnapshotUrl()))
				&& (this.getSnapshot() == null ? other.getSnapshot() == null : this.getSnapshot().equals(other.getSnapshot()))
				&& (this.getTimeoutActionTime() == null ? other.getTimeoutActionTime() == null : this.getTimeoutActionTime().equals(other.getTimeoutActionTime()))
				&& (this.getBuyerRate() == null ? other.getBuyerRate() == null : this.getBuyerRate().equals(other.getBuyerRate()))
				&& (this.getSellerRate() == null ? other.getSellerRate() == null : this.getSellerRate().equals(other.getSellerRate()))
				&& (this.getSellerType() == null ? other.getSellerType() == null : this.getSellerType().equals(other.getSellerType()))
				&& (this.getCid() == null ? other.getCid() == null : this.getCid().equals(other.getCid()))
				&& (this.getSubOrderTaxFee() == null ? other.getSubOrderTaxFee() == null : this.getSubOrderTaxFee().equals(other.getSubOrderTaxFee()))
				&& (this.getSubOrderTaxRate() == null ? other.getSubOrderTaxRate() == null : this.getSubOrderTaxRate().equals(other.getSubOrderTaxRate()))
				&& (this.getSubOrderId() == null ? other.getSubOrderId() == null : this.getSubOrderId().equals(other.getSubOrderId()))
				&& (this.getSubOrderStatus() == null ? other.getSubOrderStatus() == null : this.getSubOrderStatus().equals(other.getSubOrderStatus()))
				&& (this.getProductName() == null ? other.getProductName() == null : this.getProductName().equals(other.getProductName()))
				&& (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
				&& (this.getIid() == null ? other.getIid() == null : this.getIid().equals(other.getIid()))
				&& (this.getPrice() == null ? other.getPrice() == null : this.getPrice().equals(other.getPrice()))
				&& (this.getProductNumId() == null ? other.getProductNumId() == null : this.getProductNumId().equals(other.getProductNumId()))
				&& (this.getItemMealId() == null ? other.getItemMealId() == null : this.getItemMealId().equals(other.getItemMealId()))
				&& (this.getSkuNumId() == null ? other.getSkuNumId() == null : this.getSkuNumId().equals(other.getSkuNumId()))
				&& (this.getQty() == null ? other.getQty() == null : this.getQty().equals(other.getQty()))
				&& (this.getSkuOuterId() == null ? other.getSkuOuterId() == null : this.getSkuOuterId().equals(other.getSkuOuterId()))
				&& (this.getOrderFrom() == null ? other.getOrderFrom() == null : this.getOrderFrom().equals(other.getOrderFrom()))
				&& (this.getTotalFee() == null ? other.getTotalFee() == null : this.getTotalFee().equals(other.getTotalFee()))
				&& (this.getPayment() == null ? other.getPayment() == null : this.getPayment().equals(other.getPayment()))
				&& (this.getDiscountFee() == null ? other.getDiscountFee() == null : this.getDiscountFee().equals(other.getDiscountFee()))
				&& (this.getAdjustFee() == null ? other.getAdjustFee() == null : this.getAdjustFee().equals(other.getAdjustFee()))
				&& (this.getModified() == null ? other.getModified() == null : this.getModified().equals(other.getModified()))
				&& (this.getSkuPropertiesName() == null ? other.getSkuPropertiesName() == null : this.getSkuPropertiesName().equals(other.getSkuPropertiesName()))
				&& (this.getRefundId() == null ? other.getRefundId() == null : this.getRefundId().equals(other.getRefundId()))
				&& (this.getIsOversold() == null ? other.getIsOversold() == null : this.getIsOversold().equals(other.getIsOversold()))
				&& (this.getIsServiceOrder() == null ? other.getIsServiceOrder() == null : this.getIsServiceOrder().equals(other.getIsServiceOrder()))
				&& (this.getEndTime() == null ? other.getEndTime() == null : this.getEndTime().equals(other.getEndTime()))
				&& (this.getConsignTime() == null ? other.getConsignTime() == null : this.getConsignTime().equals(other.getConsignTime()))
				&& (this.getShippingType() == null ? other.getShippingType() == null : this.getShippingType().equals(other.getShippingType()))
				&& (this.getBindOid() == null ? other.getBindOid() == null : this.getBindOid().equals(other.getBindOid()))
				&& (this.getLogisticsCompany() == null ? other.getLogisticsCompany() == null : this.getLogisticsCompany().equals(other.getLogisticsCompany()))
				&& (this.getInvoiceNo() == null ? other.getInvoiceNo() == null : this.getInvoiceNo().equals(other.getInvoiceNo()))
				&& (this.getIsDaixiao() == null ? other.getIsDaixiao() == null : this.getIsDaixiao().equals(other.getIsDaixiao()))
				&& (this.getDivideOrderFee() == null ? other.getDivideOrderFee() == null : this.getDivideOrderFee().equals(other.getDivideOrderFee()))
				&& (this.getPartMjzDiscount() == null ? other.getPartMjzDiscount() == null : this.getPartMjzDiscount().equals(other.getPartMjzDiscount()))
				&& (this.getTicketOuterId() == null ? other.getTicketOuterId() == null : this.getTicketOuterId().equals(other.getTicketOuterId()))
				&& (this.getTicketExpdateKey() == null ? other.getTicketExpdateKey() == null : this.getTicketExpdateKey().equals(other.getTicketExpdateKey()))
				&& (this.getStoreCode() == null ? other.getStoreCode() == null : this.getStoreCode().equals(other.getStoreCode()))
				&& (this.getIsWww() == null ? other.getIsWww() == null : this.getIsWww().equals(other.getIsWww()))
				&& (this.getTmserSpuCode() == null ? other.getTmserSpuCode() == null : this.getTmserSpuCode().equals(other.getTmserSpuCode()))
				&& (this.getBindOids() == null ? other.getBindOids() == null : this.getBindOids().equals(other.getBindOids()))
				&& (this.getZhengjiStatus() == null ? other.getZhengjiStatus() == null : this.getZhengjiStatus().equals(other.getZhengjiStatus()))
				&& (this.getMdQualification() == null ? other.getMdQualification() == null : this.getMdQualification().equals(other.getMdQualification()))
				&& (this.getMdFee() == null ? other.getMdFee() == null : this.getMdFee().equals(other.getMdFee()))
				&& (this.getCustomization() == null ? other.getCustomization() == null : this.getCustomization().equals(other.getCustomization()))
				&& (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getItemUkid() == null) ? 0 : getItemUkid().hashCode());
		result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
		result = prime * result + ((getOriginOrderStatus() == null) ? 0 : getOriginOrderStatus().hashCode());
		result = prime * result + ((getShopProductUkid() == null) ? 0 : getShopProductUkid().hashCode());
		result = prime * result + ((getProductCodeUkid() == null) ? 0 : getProductCodeUkid().hashCode());
		result = prime * result + ((getProductCode() == null) ? 0 : getProductCode().hashCode());
		result = prime * result + ((getPresaleDate() == null) ? 0 : getPresaleDate().hashCode());
		result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
		result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
		result = prime * result + ((getWorkspaceId() == null) ? 0 : getWorkspaceId().hashCode());
		result = prime * result + ((getItemMealName() == null) ? 0 : getItemMealName().hashCode());
		result = prime * result + ((getPicPath() == null) ? 0 : getPicPath().hashCode());
		result = prime * result + ((getSellerNick() == null) ? 0 : getSellerNick().hashCode());
		result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
		result = prime * result + ((getRefundStatus() == null) ? 0 : getRefundStatus().hashCode());
		result = prime * result + ((getProductOuterId() == null) ? 0 : getProductOuterId().hashCode());
		result = prime * result + ((getSnapshotUrl() == null) ? 0 : getSnapshotUrl().hashCode());
		result = prime * result + ((getSnapshot() == null) ? 0 : getSnapshot().hashCode());
		result = prime * result + ((getTimeoutActionTime() == null) ? 0 : getTimeoutActionTime().hashCode());
		result = prime * result + ((getBuyerRate() == null) ? 0 : getBuyerRate().hashCode());
		result = prime * result + ((getSellerRate() == null) ? 0 : getSellerRate().hashCode());
		result = prime * result + ((getSellerType() == null) ? 0 : getSellerType().hashCode());
		result = prime * result + ((getCid() == null) ? 0 : getCid().hashCode());
		result = prime * result + ((getSubOrderTaxFee() == null) ? 0 : getSubOrderTaxFee().hashCode());
		result = prime * result + ((getSubOrderTaxRate() == null) ? 0 : getSubOrderTaxRate().hashCode());
		result = prime * result + ((getSubOrderId() == null) ? 0 : getSubOrderId().hashCode());
		result = prime * result + ((getSubOrderStatus() == null) ? 0 : getSubOrderStatus().hashCode());
		result = prime * result + ((getProductName() == null) ? 0 : getProductName().hashCode());
		result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
		result = prime * result + ((getIid() == null) ? 0 : getIid().hashCode());
		result = prime * result + ((getPrice() == null) ? 0 : getPrice().hashCode());
		result = prime * result + ((getProductNumId() == null) ? 0 : getProductNumId().hashCode());
		result = prime * result + ((getItemMealId() == null) ? 0 : getItemMealId().hashCode());
		result = prime * result + ((getSkuNumId() == null) ? 0 : getSkuNumId().hashCode());
		result = prime * result + ((getQty() == null) ? 0 : getQty().hashCode());
		result = prime * result + ((getSkuOuterId() == null) ? 0 : getSkuOuterId().hashCode());
		result = prime * result + ((getOrderFrom() == null) ? 0 : getOrderFrom().hashCode());
		result = prime * result + ((getTotalFee() == null) ? 0 : getTotalFee().hashCode());
		result = prime * result + ((getPayment() == null) ? 0 : getPayment().hashCode());
		result = prime * result + ((getDiscountFee() == null) ? 0 : getDiscountFee().hashCode());
		result = prime * result + ((getAdjustFee() == null) ? 0 : getAdjustFee().hashCode());
		result = prime * result + ((getModified() == null) ? 0 : getModified().hashCode());
		result = prime * result + ((getSkuPropertiesName() == null) ? 0 : getSkuPropertiesName().hashCode());
		result = prime * result + ((getRefundId() == null) ? 0 : getRefundId().hashCode());
		result = prime * result + ((getIsOversold() == null) ? 0 : getIsOversold().hashCode());
		result = prime * result + ((getIsServiceOrder() == null) ? 0 : getIsServiceOrder().hashCode());
		result = prime * result + ((getEndTime() == null) ? 0 : getEndTime().hashCode());
		result = prime * result + ((getConsignTime() == null) ? 0 : getConsignTime().hashCode());
		result = prime * result + ((getShippingType() == null) ? 0 : getShippingType().hashCode());
		result = prime * result + ((getBindOid() == null) ? 0 : getBindOid().hashCode());
		result = prime * result + ((getLogisticsCompany() == null) ? 0 : getLogisticsCompany().hashCode());
		result = prime * result + ((getInvoiceNo() == null) ? 0 : getInvoiceNo().hashCode());
		result = prime * result + ((getIsDaixiao() == null) ? 0 : getIsDaixiao().hashCode());
		result = prime * result + ((getDivideOrderFee() == null) ? 0 : getDivideOrderFee().hashCode());
		result = prime * result + ((getPartMjzDiscount() == null) ? 0 : getPartMjzDiscount().hashCode());
		result = prime * result + ((getTicketOuterId() == null) ? 0 : getTicketOuterId().hashCode());
		result = prime * result + ((getTicketExpdateKey() == null) ? 0 : getTicketExpdateKey().hashCode());
		result = prime * result + ((getStoreCode() == null) ? 0 : getStoreCode().hashCode());
		result = prime * result + ((getIsWww() == null) ? 0 : getIsWww().hashCode());
		result = prime * result + ((getTmserSpuCode() == null) ? 0 : getTmserSpuCode().hashCode());
		result = prime * result + ((getBindOids() == null) ? 0 : getBindOids().hashCode());
		result = prime * result + ((getZhengjiStatus() == null) ? 0 : getZhengjiStatus().hashCode());
		result = prime * result + ((getMdQualification() == null) ? 0 : getMdQualification().hashCode());
		result = prime * result + ((getMdFee() == null) ? 0 : getMdFee().hashCode());
		result = prime * result + ((getCustomization() == null) ? 0 : getCustomization().hashCode());
		result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
		return result;
	}

}
