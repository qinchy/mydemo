package com.wwwarehouse.xdw.datasync.model;

/**
 * Iscs Base Object
 */
public class BaseObject implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7533146364184225973L;

}
