package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderSFInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressShiperDetail;

import java.util.Date;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 11:30 on 2017/6/18.
 * @Modified By:
 */
@XStreamAlias("Order")
public class Order extends ToStringBaseModel{

    @XStreamAsAttribute()
    private String orderid;

    @XStreamAsAttribute()
    private String mailno;

    @XStreamAsAttribute()
    private String is_gen_bill_no;

    @XStreamAsAttribute()
    private String j_company;

    @XStreamAsAttribute()
    private String j_contact;

    @XStreamAsAttribute()
    private String j_tel;

    @XStreamAsAttribute()
    private String j_mobile;

    @XStreamAsAttribute()
    private String j_shippercode;

    @XStreamAsAttribute()
    private String j_country;

    @XStreamAsAttribute()
    private String j_province;

    @XStreamAsAttribute()
    private String j_city;

    @XStreamAsAttribute()
    private String j_county;

    @XStreamAsAttribute()
    private String j_address;

    @XStreamAsAttribute()
    private String j_post_code;

    @XStreamAsAttribute()
    private String d_company;

    @XStreamAsAttribute()
    private String d_contact;

    @XStreamAsAttribute()
    private String d_tel;

    @XStreamAsAttribute()
    private String d_mobile;

    @XStreamAsAttribute()
    private String d_deliverycode;

    @XStreamAsAttribute()
    private String d_country;

    @XStreamAsAttribute()
    private String d_province;

    @XStreamAsAttribute()
    private String d_city;

    @XStreamAsAttribute()
    private String d_county;

    @XStreamAsAttribute()
    private String d_address;

    @XStreamAsAttribute()
    private String d_post_code;

    @XStreamAsAttribute()
    private String custid;

    @XStreamAsAttribute()
    private String pay_method;

    @XStreamAsAttribute()
    private String express_type;

    @XStreamAsAttribute()
    private String parcel_quantity;

    @XStreamAsAttribute()
    private String sendstarttime;

    @XStreamAsAttribute()
    private String order_source;

    @XStreamAsAttribute()
    private String remark;

    public Order(ExpressOrderSFInfoDTO infoDTO) {
        this.orderid = infoDTO.getOrderId();
//        this.mailno = infoDTO.getExpressId();
        this.is_gen_bill_no = String.valueOf(infoDTO.getIs_gen_bill_no());
        ExpressShiperDetail sendShiperDetail = infoDTO.getSendShiperDetail();
        this.j_company = sendShiperDetail.getCompany();
        this.j_contact = sendShiperDetail.getName();
        this.j_tel = sendShiperDetail.getPhone();
        this.j_mobile = sendShiperDetail.getMobile();
//        this.j_shippercode = sendShiperDetail.get;
        this.j_country = sendShiperDetail.getCountry();
        this.j_province = sendShiperDetail.getProvince();
        this.j_city = sendShiperDetail.getCity();
        this.j_county = sendShiperDetail.getCounty();
        this.j_address =sendShiperDetail.getAddress();
        this.j_post_code = sendShiperDetail.getPostcode();
        ExpressShiperDetail receiverShiperDetail = infoDTO.getReceiverShiperDetail();
        this.d_company = receiverShiperDetail.getCompany();
        this.d_contact = receiverShiperDetail.getName();
        this.d_tel = receiverShiperDetail.getPhone();
        this.d_mobile = receiverShiperDetail.getMobile();
//        this.d_deliverycode
        this.d_country = receiverShiperDetail.getCountry();
        this.d_province = receiverShiperDetail.getProvince();
        this.d_city = receiverShiperDetail.getCity();
        this.d_county = receiverShiperDetail.getCounty();
        this.d_address = receiverShiperDetail.getAddress();
        this.d_post_code = receiverShiperDetail.getPostcode();
        this.custid = infoDTO.getCustid();
        this.pay_method = String.valueOf(infoDTO.getPay_method());
        this.express_type = infoDTO.getExpress_type();
        this.parcel_quantity = String.valueOf(infoDTO.getParcel_quantity());
        this.sendstarttime = String.valueOf(infoDTO.getSendstarttime() == null
                ? DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")
                : infoDTO.getSendstarttime());
        this.order_source = infoDTO.getOrder_source();
        this.remark = infoDTO.getRemark();
    }
}
