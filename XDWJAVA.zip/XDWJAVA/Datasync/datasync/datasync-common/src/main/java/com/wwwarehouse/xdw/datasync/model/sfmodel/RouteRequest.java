package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 13:15 on 2017/6/16.
 * @Modified By:
 */
@XStreamAlias("RouteRequest")
public class RouteRequest extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String tracking_type;

    @XStreamAsAttribute()
    private String method_type;

    @XStreamAsAttribute()
    private String tracking_number;

    public RouteRequest() {
    }

    public RouteRequest(String tracking_type, String method_type, String tracking_number) {
        this.tracking_type = tracking_type;
        this.method_type = method_type;
        this.tracking_number = tracking_number;
    }

    public String getTracking_type() {
        return tracking_type;
    }

    public void setTracking_type(String tracking_type) {
        this.tracking_type = tracking_type;
    }

    public String getMethod_type() {
        return method_type;
    }

    public void setMethod_type(String method_type) {
        this.method_type = method_type;
    }

    public String getTracking_number() {
        return tracking_number;
    }

    public void setTracking_number(String tracking_number) {
        this.tracking_number = tracking_number;
    }

}
