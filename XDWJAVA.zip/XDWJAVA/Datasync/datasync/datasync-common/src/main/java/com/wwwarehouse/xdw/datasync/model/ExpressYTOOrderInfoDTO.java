package com.wwwarehouse.xdw.datasync.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by wendong.hu on 2017/6/15.
 * 用于圆通接口
 */
public class ExpressYTOOrderInfoDTO extends ExpressOrderInfoDTO{
    public ExpressYTOOrderInfoDTO(String orderId, String expressId, Long expressCode, ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size, int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
        super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment, createDate, isInsured, insuredValue);
    }

    private List<ShipOrderItemDTO> shipOrderItemDTOS = new ArrayList<>();

    public List<ShipOrderItemDTO> getShipOrderItemDTOS() {
        return shipOrderItemDTOS;
    }

    public void setShipOrderItemDTOS(List<ShipOrderItemDTO> shipOrderItemDTOS) {
        this.shipOrderItemDTOS = shipOrderItemDTOS;
    }
}
