package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import java.util.Date;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 15:05 on 2017/6/16.
 * @Modified By:
 */
@XStreamAlias("Route")
public class Route extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String acceptTime;

    @XStreamAsAttribute()
    private String acceptAddress;

    @XStreamAsAttribute()
    private String remark;

    public String getAcceptTime() {
        return acceptTime;
    }

    public void setAcceptTime(String acceptTime) {
        this.acceptTime = acceptTime;
    }

    public String getAcceptAddress() {
        return acceptAddress;
    }

    public void setAcceptAddress(String acceptAddress) {
        this.acceptAddress = acceptAddress;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
