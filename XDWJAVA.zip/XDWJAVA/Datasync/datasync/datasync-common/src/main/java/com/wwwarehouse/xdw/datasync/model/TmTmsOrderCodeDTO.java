package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

public class TmTmsOrderCodeDTO extends BaseObject {
	
	private Long tmsOrderCodeUkid;
    private Long transporterId;
    private Long transporterUnitId;
    private Long expressServiceUkid;
    private Long sellerId;
    private Integer isCod;
    private String outSid;
    private Integer used;
    private Long seq;
    private Long relatedOrderUkid;
    private Date createTime;
    private Date useTime;
    private String expressServiceType;
    private String relatedOrderCode;
    private Long transportContractUkid;
    private Long transportContractItemUkid;
    private String markDestinationCode;
    
    /**
     * 是否已经通知平台
     */
    private Integer noticeStatus;
    /**
     * 平台处理状态
     */
    private Integer processStatus;
    
    /**
     *生成人UKID
     **/
    private Long createUserId;
    
    /**
     *更新时间
     **/
    private Date updateTime;

    /**
     *更新人UKID
     **/
    private Long updateUserId;
    
    public Long getTmsOrderCodeUkid() {
        return tmsOrderCodeUkid;
    }

    public void setTmsOrderCodeUkid(Long tmsOrderCodeUkid) {
        this.tmsOrderCodeUkid = tmsOrderCodeUkid;
    }

    public Long getTransporterId() {
        return transporterId;
    }

    public void setTransporterId(Long transporterId) {
        this.transporterId = transporterId;
    }

    public Long getTransporterUnitId() {
        return transporterUnitId;
    }

    public void setTransporterUnitId(Long transporterUnitId) {
        this.transporterUnitId = transporterUnitId;
    }

    public Long getExpressServiceUkid() {
        return expressServiceUkid;
    }

    public void setExpressServiceUkid(Long expressServiceUkid) {
        this.expressServiceUkid = expressServiceUkid;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getIsCod() {
        return isCod;
    }

    public void setIsCod(Integer isCod) {
        this.isCod = isCod;
    }

    public String getOutSid() {
        return outSid;
    }

    public void setOutSid(String outSid) {
        this.outSid = outSid == null ? null : outSid.trim();
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }

    public Long getSeq() {
        return seq;
    }

    public void setSeq(Long seq) {
        this.seq = seq;
    }

    public Long getRelatedOrderUkid() {
        return relatedOrderUkid;
    }

    public void setRelatedOrderUkid(Long relatedOrderUkid) {
        this.relatedOrderUkid = relatedOrderUkid;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUseTime() {
        return useTime;
    }

    public void setUseTime(Date useTime) {
        this.useTime = useTime;
    }

    public String getExpressServiceType() {
        return expressServiceType;
    }

    public void setExpressServiceType(String expressServiceType) {
        this.expressServiceType = expressServiceType == null ? null : expressServiceType.trim();
    }

	public String getRelatedOrderCode() {
		return relatedOrderCode;
	}

	public void setRelatedOrderCode(String relatedOrderCode) {
		this.relatedOrderCode = relatedOrderCode;
	}

	public Integer getNoticeStatus() {
		return noticeStatus;
	}

	public void setNoticeStatus(Integer noticeStatus) {
		this.noticeStatus = noticeStatus;
	}

	public Integer getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(Integer processStatus) {
		this.processStatus = processStatus;
	}

	public Long getTransportContractUkid() {
    	return transportContractUkid;
    }

	public void setTransportContractUkid(Long transportContractUkid) {
    	this.transportContractUkid = transportContractUkid;
    }

	public Long getTransportContractItemUkid() {
    	return transportContractItemUkid;
    }

	public void setTransportContractItemUkid(Long transportContractItemUkid) {
    	this.transportContractItemUkid = transportContractItemUkid;
    }

	public String getMarkDestinationCode() {
		return markDestinationCode;
	}

	public void setMarkDestinationCode(String markDestinationCode) {
		this.markDestinationCode = markDestinationCode;
	}

	public Long getCreateUserId() {
    	return createUserId;
    }

	public void setCreateUserId(Long createUserId) {
    	this.createUserId = createUserId;
    }

	public Date getUpdateTime() {
    	return updateTime;
    }

	public void setUpdateTime(Date updateTime) {
    	this.updateTime = updateTime;
    }

	public Long getUpdateUserId() {
    	return updateUserId;
    }

	public void setUpdateUserId(Long updateUserId) {
    	this.updateUserId = updateUserId;
    }
	
}