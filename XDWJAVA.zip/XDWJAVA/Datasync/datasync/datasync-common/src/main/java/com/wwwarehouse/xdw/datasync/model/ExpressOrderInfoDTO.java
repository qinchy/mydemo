package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ExpressOrderInfoDTO implements Serializable {
    private static final long serialVersionUID = -2763898102926720695L;
    private String orderId; // 订单号
    private String expressId; // 快递单号

    // 快递公司
    private Long expressCode;// 快递公司编码
    private String expressCompany;// 快递公司名称

    // 发货人的详细信息
    private ExpressShiperDetail sendShiperDetail;
    // 收货人的详细信息
    private ExpressShiperDetail receiverShiperDetail;

    // 包裹物件描述
    private double weight; // 重量
    private String size; // 尺寸
    private int packNo; // 件数

    // 货到付款
    private float payment; // 支付金额
    private boolean isCOD = false; // 是否货到付款
    private double collectionValue; // 代收货款金额

    // 保价
    private boolean isInsured = false; // 是否保价
    private double insuredValue; // 保价金额(保留小数点后两位)

    private Date createDate; // 创建时间

	private List<ExpressOrderItemInfoDTO> expressOrderItemInfoDTO;

	public List<ExpressOrderItemInfoDTO> getexpressOrderItemInfoDTOs() {
		return expressOrderItemInfoDTO;
	}
	public void setexpressOrderItemInfoDTOs(List<ExpressOrderItemInfoDTO> cargoItems) {
		this.expressOrderItemInfoDTO = cargoItems;
	}



	public ExpressOrderInfoDTO(String orderId, String expressId, Long expressCode, ExpressShiperDetail sendShiperDetail,
                               ExpressShiperDetail receiverShiperDetail, double weight, String size, int packNo, float payment,
                               Date createDate, boolean isInsured, double insuredValue) {
        this.orderId = orderId;
        this.expressId = expressId;
        this.expressCode = expressCode;
        this.sendShiperDetail = sendShiperDetail;
        this.receiverShiperDetail = receiverShiperDetail;
        this.weight = weight;
        this.size = size;
        this.packNo = packNo;
        this.payment = payment;
        this.createDate = createDate;
        this.isInsured = isInsured;
        this.insuredValue = insuredValue;

    }

    public ExpressOrderInfoDTO() {
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getExpressId() {
        return expressId;
    }

    public void setExpressId(String expressId) {
        this.expressId = expressId;
    }

    public Long getExpressCode() {
        return expressCode;
    }

    public void setExpressCode(Long expressCode) {
        this.expressCode = expressCode;
    }

    public String getExpressCompany() {
        return expressCompany;
    }

    public void setExpressCompany(String expressCompany) {
        this.expressCompany = expressCompany;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getPackNo() {
        return packNo;
    }

    public void setPackNo(int packNo) {
        this.packNo = packNo;
    }

    public float getPayment() {
        return payment;
    }

    public void setPayment(float payment) {
        this.payment = payment;
    }

    public boolean isCOD() {
        return isCOD;
    }

    public void setCOD(boolean isCOD) {
        this.isCOD = isCOD;
    }

    public double getCollectionValue() {
        return collectionValue;
    }

    public void setCollectionValue(double collectionValue) {
        this.collectionValue = collectionValue;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public boolean isInsured() {
        return isInsured;
    }

    public void setInsured(boolean isInsured) {
        this.isInsured = isInsured;
    }

    public double getInsuredValue() {
        return insuredValue;
    }

    public void setInsuredValue(double insuredValue) {
        this.insuredValue = insuredValue;
    }

    public ExpressShiperDetail getSendShiperDetail() {
        return sendShiperDetail;
    }

    public void setSendShiperDetail(ExpressShiperDetail sendShiperDetail) {
        this.sendShiperDetail = sendShiperDetail;
    }

    public ExpressShiperDetail getReceiverShiperDetail() {
        return receiverShiperDetail;
    }

    public void setReceiverShiperDetail(ExpressShiperDetail receiverShiperDetail) {
        this.receiverShiperDetail = receiverShiperDetail;
    }

}
