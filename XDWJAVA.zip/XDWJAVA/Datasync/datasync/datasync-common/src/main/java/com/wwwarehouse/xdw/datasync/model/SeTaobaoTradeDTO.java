package com.wwwarehouse.xdw.datasync.model;


import java.math.BigDecimal;
import java.util.Date;

public class SeTaobaoTradeDTO extends SeBaseTrade<SeTaobaoItemDTO> {
	private Long tradeUkid;

	private Long shopId;

	private Date downTime;

	private Date updateTime;

	private Date releaseTime;

	private Long originTradeStatus;

	private String sellerNick;

	private String picPath;

	private BigDecimal payment;

	private Long sellerRate;

	private BigDecimal postFee;

	private String receiverName;

	private String receiverState;

	private String receiverAddress;

	private String receiverZip;

	private String receiverMobile;

	private String receiverPhone;

	private Date consignTime;

	private String receiverCountry;

	private String receiverTown;

	private BigDecimal orderTaxFee;

	private Long shopPick;

	private String orderId;

	private Long num;

	private Long numIid;

	private String platformOrderStatus;

	private String title;

	private String type;

	private BigDecimal price;

	private BigDecimal discountFee;

	private BigDecimal totalFee;

	private Date orderCreateTime;

	private Date orderPayTime;

	private Date orderModifyTime;

	private Date orderEndTime;

	private Long sellerFlag;

	private String buyerNick;

	private Long hasBuyerMessage;

	private BigDecimal creditCardFee;

	private String stepTradeStatus;

	private BigDecimal stepPaidFee;

	private String markDesc;

	private String shippingType;

	private BigDecimal adjustFee;

	private String tradeFrom;

	private Long buyerRate;

	private String receiverCity;

	private String receiverCounty;

	private String rxAuditStatus;

	private Long hasPostFee;

	private BigDecimal sellerCodFee;

	private BigDecimal buyerCodFee;

	private String codStatus;

	private BigDecimal codFee;

	private Long pointFee;

	private String buyerMessage;

	private Long buyerFlag;

	private String sellerMemo;

	private String buyerArea;

	private String buyerAlipayNo;

	private String fenxiaoShopName;

	private Long fenxiaoShopId;

	private Long isScoreUpdated;

	private String serviceTags;

	private Long zhengjiStatus;

	private Long targetOrderUkid;

	private String invoiceName;

	private String invoiceType;

	private String estConTime;

	private String invoiceKind;

	private String paidCouponFee;

	private String receivedPayment;

	private String eticketServiceAddr;

	private String isShShip;

	private String o2oSnatchStatus;

	private String market;

	private String etType;

	private Long etShopId;

	private String obs;

	private Long createUserId;

	private Long updateUserId;

	private static final long serialVersionUID = 1L;

	public Long getTradeUkid() {
		return tradeUkid;
	}

	public void setTradeUkid(Long tradeUkid) {
		this.tradeUkid = tradeUkid;
	}

	public Long getShopId() {
		return shopId;
	}

	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}

	public Date getDownTime() {
		return downTime;
	}

	public void setDownTime(Date downTime) {
		this.downTime = downTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(Date releaseTime) {
		this.releaseTime = releaseTime;
	}

	public Long getOriginTradeStatus() {
		return originTradeStatus;
	}

	public void setOriginTradeStatus(Long originTradeStatus) {
		this.originTradeStatus = originTradeStatus;
	}

	public String getSellerNick() {
		return sellerNick;
	}

	public void setSellerNick(String sellerNick) {
		this.sellerNick = sellerNick;
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

	public BigDecimal getPayment() {
		return payment;
	}

	public void setPayment(BigDecimal payment) {
		this.payment = payment;
	}

	public Long getSellerRate() {
		return sellerRate;
	}

	public void setSellerRate(Long sellerRate) {
		this.sellerRate = sellerRate;
	}

	public BigDecimal getPostFee() {
		return postFee;
	}

	public void setPostFee(BigDecimal postFee) {
		this.postFee = postFee;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverState() {
		return receiverState;
	}

	public void setReceiverState(String receiverState) {
		this.receiverState = receiverState;
	}

	public String getReceiverAddress() {
		return receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public String getReceiverZip() {
		return receiverZip;
	}

	public void setReceiverZip(String receiverZip) {
		this.receiverZip = receiverZip;
	}

	public String getReceiverMobile() {
		return receiverMobile;
	}

	public void setReceiverMobile(String receiverMobile) {
		this.receiverMobile = receiverMobile;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}

	public Date getConsignTime() {
		return consignTime;
	}

	public void setConsignTime(Date consignTime) {
		this.consignTime = consignTime;
	}

	public String getReceiverCountry() {
		return receiverCountry;
	}

	public void setReceiverCountry(String receiverCountry) {
		this.receiverCountry = receiverCountry;
	}

	public String getReceiverTown() {
		return receiverTown;
	}

	public void setReceiverTown(String receiverTown) {
		this.receiverTown = receiverTown;
	}

	public BigDecimal getOrderTaxFee() {
		return orderTaxFee;
	}

	public void setOrderTaxFee(BigDecimal orderTaxFee) {
		this.orderTaxFee = orderTaxFee;
	}

	public Long getShopPick() {
		return shopPick;
	}

	public void setShopPick(Long shopPick) {
		this.shopPick = shopPick;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getNum() {
		return num;
	}

	public void setNum(Long num) {
		this.num = num;
	}

	public Long getNumIid() {
		return numIid;
	}

	public void setNumIid(Long numIid) {
		this.numIid = numIid;
	}

	public String getPlatformOrderStatus() {
		return platformOrderStatus;
	}

	public void setPlatformOrderStatus(String platformOrderStatus) {
		this.platformOrderStatus = platformOrderStatus;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getDiscountFee() {
		return discountFee;
	}

	public void setDiscountFee(BigDecimal discountFee) {
		this.discountFee = discountFee;
	}

	public BigDecimal getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}

	public Date getOrderCreateTime() {
		return orderCreateTime;
	}

	public void setOrderCreateTime(Date orderCreateTime) {
		this.orderCreateTime = orderCreateTime;
	}

	public Date getOrderPayTime() {
		return orderPayTime;
	}

	public void setOrderPayTime(Date orderPayTime) {
		this.orderPayTime = orderPayTime;
	}

	public Date getOrderModifyTime() {
		return orderModifyTime;
	}

	public void setOrderModifyTime(Date orderModifyTime) {
		this.orderModifyTime = orderModifyTime;
	}

	public Date getOrderEndTime() {
		return orderEndTime;
	}

	public void setOrderEndTime(Date orderEndTime) {
		this.orderEndTime = orderEndTime;
	}

	public Long getSellerFlag() {
		return sellerFlag;
	}

	public void setSellerFlag(Long sellerFlag) {
		this.sellerFlag = sellerFlag;
	}

	public String getBuyerNick() {
		return buyerNick;
	}

	public void setBuyerNick(String buyerNick) {
		this.buyerNick = buyerNick;
	}

	public Long getHasBuyerMessage() {
		return hasBuyerMessage;
	}

	public void setHasBuyerMessage(Long hasBuyerMessage) {
		this.hasBuyerMessage = hasBuyerMessage;
	}

	public BigDecimal getCreditCardFee() {
		return creditCardFee;
	}

	public void setCreditCardFee(BigDecimal creditCardFee) {
		this.creditCardFee = creditCardFee;
	}

	public String getStepTradeStatus() {
		return stepTradeStatus;
	}

	public void setStepTradeStatus(String stepTradeStatus) {
		this.stepTradeStatus = stepTradeStatus;
	}

	public BigDecimal getStepPaidFee() {
		return stepPaidFee;
	}

	public void setStepPaidFee(BigDecimal stepPaidFee) {
		this.stepPaidFee = stepPaidFee;
	}

	public String getMarkDesc() {
		return markDesc;
	}

	public void setMarkDesc(String markDesc) {
		this.markDesc = markDesc;
	}

	public String getShippingType() {
		return shippingType;
	}

	public void setShippingType(String shippingType) {
		this.shippingType = shippingType;
	}

	public BigDecimal getAdjustFee() {
		return adjustFee;
	}

	public void setAdjustFee(BigDecimal adjustFee) {
		this.adjustFee = adjustFee;
	}

	public String getTradeFrom() {
		return tradeFrom;
	}

	public void setTradeFrom(String tradeFrom) {
		this.tradeFrom = tradeFrom;
	}

	public Long getBuyerRate() {
		return buyerRate;
	}

	public void setBuyerRate(Long buyerRate) {
		this.buyerRate = buyerRate;
	}

	public String getReceiverCity() {
		return receiverCity;
	}

	public void setReceiverCity(String receiverCity) {
		this.receiverCity = receiverCity;
	}

	public String getReceiverCounty() {
		return receiverCounty;
	}

	public void setReceiverCounty(String receiverCounty) {
		this.receiverCounty = receiverCounty;
	}

	public String getRxAuditStatus() {
		return rxAuditStatus;
	}

	public void setRxAuditStatus(String rxAuditStatus) {
		this.rxAuditStatus = rxAuditStatus;
	}

	public Long getHasPostFee() {
		return hasPostFee;
	}

	public void setHasPostFee(Long hasPostFee) {
		this.hasPostFee = hasPostFee;
	}

	public BigDecimal getSellerCodFee() {
		return sellerCodFee;
	}

	public void setSellerCodFee(BigDecimal sellerCodFee) {
		this.sellerCodFee = sellerCodFee;
	}

	public BigDecimal getBuyerCodFee() {
		return buyerCodFee;
	}

	public void setBuyerCodFee(BigDecimal buyerCodFee) {
		this.buyerCodFee = buyerCodFee;
	}

	public String getCodStatus() {
		return codStatus;
	}

	public void setCodStatus(String codStatus) {
		this.codStatus = codStatus;
	}

	public BigDecimal getCodFee() {
		return codFee;
	}

	public void setCodFee(BigDecimal codFee) {
		this.codFee = codFee;
	}

	public Long getPointFee() {
		return pointFee;
	}

	public void setPointFee(Long pointFee) {
		this.pointFee = pointFee;
	}

	public String getBuyerMessage() {
		return buyerMessage;
	}

	public void setBuyerMessage(String buyerMessage) {
		this.buyerMessage = buyerMessage;
	}

	public Long getBuyerFlag() {
		return buyerFlag;
	}

	public void setBuyerFlag(Long buyerFlag) {
		this.buyerFlag = buyerFlag;
	}

	public String getSellerMemo() {
		return sellerMemo;
	}

	public void setSellerMemo(String sellerMemo) {
		this.sellerMemo = sellerMemo;
	}

	public String getBuyerArea() {
		return buyerArea;
	}

	public void setBuyerArea(String buyerArea) {
		this.buyerArea = buyerArea;
	}

	public String getBuyerAlipayNo() {
		return buyerAlipayNo;
	}

	public void setBuyerAlipayNo(String buyerAlipayNo) {
		this.buyerAlipayNo = buyerAlipayNo;
	}

	public String getFenxiaoShopName() {
		return fenxiaoShopName;
	}

	public void setFenxiaoShopName(String fenxiaoShopName) {
		this.fenxiaoShopName = fenxiaoShopName;
	}

	public Long getFenxiaoShopId() {
		return fenxiaoShopId;
	}

	public void setFenxiaoShopId(Long fenxiaoShopId) {
		this.fenxiaoShopId = fenxiaoShopId;
	}

	public Long getIsScoreUpdated() {
		return isScoreUpdated;
	}

	public void setIsScoreUpdated(Long isScoreUpdated) {
		this.isScoreUpdated = isScoreUpdated;
	}

	public String getServiceTags() {
		return serviceTags;
	}

	public void setServiceTags(String serviceTags) {
		this.serviceTags = serviceTags;
	}

	public Long getZhengjiStatus() {
		return zhengjiStatus;
	}

	public void setZhengjiStatus(Long zhengjiStatus) {
		this.zhengjiStatus = zhengjiStatus;
	}

	public Long getTargetOrderUkid() {
		return targetOrderUkid;
	}

	public void setTargetOrderUkid(Long targetOrderUkid) {
		this.targetOrderUkid = targetOrderUkid;
	}

	public String getInvoiceName() {
		return invoiceName;
	}

	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getEstConTime() {
		return estConTime;
	}

	public void setEstConTime(String estConTime) {
		this.estConTime = estConTime;
	}

	public String getInvoiceKind() {
		return invoiceKind;
	}

	public void setInvoiceKind(String invoiceKind) {
		this.invoiceKind = invoiceKind;
	}

	public String getPaidCouponFee() {
		return paidCouponFee;
	}

	public void setPaidCouponFee(String paidCouponFee) {
		this.paidCouponFee = paidCouponFee;
	}

	public String getReceivedPayment() {
		return receivedPayment;
	}

	public void setReceivedPayment(String receivedPayment) {
		this.receivedPayment = receivedPayment;
	}

	public String getEticketServiceAddr() {
		return eticketServiceAddr;
	}

	public void setEticketServiceAddr(String eticketServiceAddr) {
		this.eticketServiceAddr = eticketServiceAddr;
	}

	public String getIsShShip() {
		return isShShip;
	}

	public void setIsShShip(String isShShip) {
		this.isShShip = isShShip;
	}

	public String getO2oSnatchStatus() {
		return o2oSnatchStatus;
	}

	public void setO2oSnatchStatus(String o2oSnatchStatus) {
		this.o2oSnatchStatus = o2oSnatchStatus;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getEtType() {
		return etType;
	}

	public void setEtType(String etType) {
		this.etType = etType;
	}

	public Long getEtShopId() {
		return etShopId;
	}

	public void setEtShopId(Long etShopId) {
		this.etShopId = etShopId;
	}

	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(", tradeUkid=").append(tradeUkid);
		sb.append(", shopId=").append(shopId);
		sb.append(", downTime=").append(downTime);
		sb.append(", updateTime=").append(updateTime);
		sb.append(", releaseTime=").append(releaseTime);
		sb.append(", originTradeStatus=").append(originTradeStatus);
		sb.append(", sellerNick=").append(sellerNick);
		sb.append(", picPath=").append(picPath);
		sb.append(", payment=").append(payment);
		sb.append(", sellerRate=").append(sellerRate);
		sb.append(", postFee=").append(postFee);
		sb.append(", receiverName=").append(receiverName);
		sb.append(", receiverState=").append(receiverState);
		sb.append(", receiverAddress=").append(receiverAddress);
		sb.append(", receiverZip=").append(receiverZip);
		sb.append(", receiverMobile=").append(receiverMobile);
		sb.append(", receiverPhone=").append(receiverPhone);
		sb.append(", consignTime=").append(consignTime);
		sb.append(", receiverCountry=").append(receiverCountry);
		sb.append(", receiverTown=").append(receiverTown);
		sb.append(", orderTaxFee=").append(orderTaxFee);
		sb.append(", shopPick=").append(shopPick);
		sb.append(", orderId=").append(orderId);
		sb.append(", num=").append(num);
		sb.append(", numIid=").append(numIid);
		sb.append(", platformOrderStatus=").append(platformOrderStatus);
		sb.append(", title=").append(title);
		sb.append(", type=").append(type);
		sb.append(", price=").append(price);
		sb.append(", discountFee=").append(discountFee);
		sb.append(", totalFee=").append(totalFee);
		sb.append(", orderCreateTime=").append(orderCreateTime);
		sb.append(", orderPayTime=").append(orderPayTime);
		sb.append(", orderModifyTime=").append(orderModifyTime);
		sb.append(", orderEndTime=").append(orderEndTime);
		sb.append(", sellerFlag=").append(sellerFlag);
		sb.append(", buyerNick=").append(buyerNick);
		sb.append(", hasBuyerMessage=").append(hasBuyerMessage);
		sb.append(", creditCardFee=").append(creditCardFee);
		sb.append(", stepTradeStatus=").append(stepTradeStatus);
		sb.append(", stepPaidFee=").append(stepPaidFee);
		sb.append(", markDesc=").append(markDesc);
		sb.append(", shippingType=").append(shippingType);
		sb.append(", adjustFee=").append(adjustFee);
		sb.append(", tradeFrom=").append(tradeFrom);
		sb.append(", buyerRate=").append(buyerRate);
		sb.append(", receiverCity=").append(receiverCity);
		sb.append(", receiverCounty=").append(receiverCounty);
		sb.append(", rxAuditStatus=").append(rxAuditStatus);
		sb.append(", hasPostFee=").append(hasPostFee);
		sb.append(", sellerCodFee=").append(sellerCodFee);
		sb.append(", buyerCodFee=").append(buyerCodFee);
		sb.append(", codStatus=").append(codStatus);
		sb.append(", codFee=").append(codFee);
		sb.append(", pointFee=").append(pointFee);
		sb.append(", buyerMessage=").append(buyerMessage);
		sb.append(", buyerFlag=").append(buyerFlag);
		sb.append(", sellerMemo=").append(sellerMemo);
		sb.append(", buyerArea=").append(buyerArea);
		sb.append(", buyerAlipayNo=").append(buyerAlipayNo);
		sb.append(", fenxiaoShopName=").append(fenxiaoShopName);
		sb.append(", fenxiaoShopId=").append(fenxiaoShopId);
		sb.append(", isScoreUpdated=").append(isScoreUpdated);
		sb.append(", serviceTags=").append(serviceTags);
		sb.append(", zhengjiStatus=").append(zhengjiStatus);
		sb.append(", targetOrderUkid=").append(targetOrderUkid);
		sb.append(", invoiceName=").append(invoiceName);
		sb.append(", invoiceType=").append(invoiceType);
		sb.append(", estConTime=").append(estConTime);
		sb.append(", invoiceKind=").append(invoiceKind);
		sb.append(", paidCouponFee=").append(paidCouponFee);
		sb.append(", receivedPayment=").append(receivedPayment);
		sb.append(", eticketServiceAddr=").append(eticketServiceAddr);
		sb.append(", isShShip=").append(isShShip);
		sb.append(", o2oSnatchStatus=").append(o2oSnatchStatus);
		sb.append(", market=").append(market);
		sb.append(", etType=").append(etType);
		sb.append(", etShopId=").append(etShopId);
		sb.append(", obs=").append(obs);
		sb.append(", createUserId=").append(createUserId);
		sb.append(", updateUserId=").append(updateUserId);
		sb.append("]");
		return sb.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		SeTaobaoTradeDTO other = (SeTaobaoTradeDTO) that;
		return (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
				&& (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
				&& (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
				&& (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
				&& (this.getReleaseTime() == null ? other.getReleaseTime() == null : this.getReleaseTime().equals(other.getReleaseTime()))
				&& (this.getOriginTradeStatus() == null ? other.getOriginTradeStatus() == null : this.getOriginTradeStatus().equals(other.getOriginTradeStatus()))
				&& (this.getSellerNick() == null ? other.getSellerNick() == null : this.getSellerNick().equals(other.getSellerNick()))
				&& (this.getPicPath() == null ? other.getPicPath() == null : this.getPicPath().equals(other.getPicPath()))
				&& (this.getPayment() == null ? other.getPayment() == null : this.getPayment().equals(other.getPayment()))
				&& (this.getSellerRate() == null ? other.getSellerRate() == null : this.getSellerRate().equals(other.getSellerRate()))
				&& (this.getPostFee() == null ? other.getPostFee() == null : this.getPostFee().equals(other.getPostFee()))
				&& (this.getReceiverName() == null ? other.getReceiverName() == null : this.getReceiverName().equals(other.getReceiverName()))
				&& (this.getReceiverState() == null ? other.getReceiverState() == null : this.getReceiverState().equals(other.getReceiverState()))
				&& (this.getReceiverAddress() == null ? other.getReceiverAddress() == null : this.getReceiverAddress().equals(other.getReceiverAddress()))
				&& (this.getReceiverZip() == null ? other.getReceiverZip() == null : this.getReceiverZip().equals(other.getReceiverZip()))
				&& (this.getReceiverMobile() == null ? other.getReceiverMobile() == null : this.getReceiverMobile().equals(other.getReceiverMobile()))
				&& (this.getReceiverPhone() == null ? other.getReceiverPhone() == null : this.getReceiverPhone().equals(other.getReceiverPhone()))
				&& (this.getConsignTime() == null ? other.getConsignTime() == null : this.getConsignTime().equals(other.getConsignTime()))
				&& (this.getReceiverCountry() == null ? other.getReceiverCountry() == null : this.getReceiverCountry().equals(other.getReceiverCountry()))
				&& (this.getReceiverTown() == null ? other.getReceiverTown() == null : this.getReceiverTown().equals(other.getReceiverTown()))
				&& (this.getOrderTaxFee() == null ? other.getOrderTaxFee() == null : this.getOrderTaxFee().equals(other.getOrderTaxFee()))
				&& (this.getShopPick() == null ? other.getShopPick() == null : this.getShopPick().equals(other.getShopPick()))
				&& (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
				&& (this.getNum() == null ? other.getNum() == null : this.getNum().equals(other.getNum()))
				&& (this.getNumIid() == null ? other.getNumIid() == null : this.getNumIid().equals(other.getNumIid()))
				&& (this.getPlatformOrderStatus() == null ? other.getPlatformOrderStatus() == null : this.getPlatformOrderStatus().equals(other.getPlatformOrderStatus()))
				&& (this.getTitle() == null ? other.getTitle() == null : this.getTitle().equals(other.getTitle()))
				&& (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
				&& (this.getPrice() == null ? other.getPrice() == null : this.getPrice().equals(other.getPrice()))
				&& (this.getDiscountFee() == null ? other.getDiscountFee() == null : this.getDiscountFee().equals(other.getDiscountFee()))
				&& (this.getTotalFee() == null ? other.getTotalFee() == null : this.getTotalFee().equals(other.getTotalFee()))
				&& (this.getOrderCreateTime() == null ? other.getOrderCreateTime() == null : this.getOrderCreateTime().equals(other.getOrderCreateTime()))
				&& (this.getOrderPayTime() == null ? other.getOrderPayTime() == null : this.getOrderPayTime().equals(other.getOrderPayTime()))
				&& (this.getOrderModifyTime() == null ? other.getOrderModifyTime() == null : this.getOrderModifyTime().equals(other.getOrderModifyTime()))
				&& (this.getOrderEndTime() == null ? other.getOrderEndTime() == null : this.getOrderEndTime().equals(other.getOrderEndTime()))
				&& (this.getSellerFlag() == null ? other.getSellerFlag() == null : this.getSellerFlag().equals(other.getSellerFlag()))
				&& (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
				&& (this.getHasBuyerMessage() == null ? other.getHasBuyerMessage() == null : this.getHasBuyerMessage().equals(other.getHasBuyerMessage()))
				&& (this.getCreditCardFee() == null ? other.getCreditCardFee() == null : this.getCreditCardFee().equals(other.getCreditCardFee()))
				&& (this.getStepTradeStatus() == null ? other.getStepTradeStatus() == null : this.getStepTradeStatus().equals(other.getStepTradeStatus()))
				&& (this.getStepPaidFee() == null ? other.getStepPaidFee() == null : this.getStepPaidFee().equals(other.getStepPaidFee()))
				&& (this.getMarkDesc() == null ? other.getMarkDesc() == null : this.getMarkDesc().equals(other.getMarkDesc()))
				&& (this.getShippingType() == null ? other.getShippingType() == null : this.getShippingType().equals(other.getShippingType()))
				&& (this.getAdjustFee() == null ? other.getAdjustFee() == null : this.getAdjustFee().equals(other.getAdjustFee()))
				&& (this.getTradeFrom() == null ? other.getTradeFrom() == null : this.getTradeFrom().equals(other.getTradeFrom()))
				&& (this.getBuyerRate() == null ? other.getBuyerRate() == null : this.getBuyerRate().equals(other.getBuyerRate()))
				&& (this.getReceiverCity() == null ? other.getReceiverCity() == null : this.getReceiverCity().equals(other.getReceiverCity()))
				&& (this.getReceiverCounty() == null ? other.getReceiverCounty() == null : this.getReceiverCounty().equals(other.getReceiverCounty()))
				&& (this.getRxAuditStatus() == null ? other.getRxAuditStatus() == null : this.getRxAuditStatus().equals(other.getRxAuditStatus()))
				&& (this.getHasPostFee() == null ? other.getHasPostFee() == null : this.getHasPostFee().equals(other.getHasPostFee()))
				&& (this.getSellerCodFee() == null ? other.getSellerCodFee() == null : this.getSellerCodFee().equals(other.getSellerCodFee()))
				&& (this.getBuyerCodFee() == null ? other.getBuyerCodFee() == null : this.getBuyerCodFee().equals(other.getBuyerCodFee()))
				&& (this.getCodStatus() == null ? other.getCodStatus() == null : this.getCodStatus().equals(other.getCodStatus()))
				&& (this.getCodFee() == null ? other.getCodFee() == null : this.getCodFee().equals(other.getCodFee()))
				&& (this.getPointFee() == null ? other.getPointFee() == null : this.getPointFee().equals(other.getPointFee()))
				&& (this.getBuyerMessage() == null ? other.getBuyerMessage() == null : this.getBuyerMessage().equals(other.getBuyerMessage()))
				&& (this.getBuyerFlag() == null ? other.getBuyerFlag() == null : this.getBuyerFlag().equals(other.getBuyerFlag()))
				&& (this.getSellerMemo() == null ? other.getSellerMemo() == null : this.getSellerMemo().equals(other.getSellerMemo()))
				&& (this.getBuyerArea() == null ? other.getBuyerArea() == null : this.getBuyerArea().equals(other.getBuyerArea()))
				&& (this.getBuyerAlipayNo() == null ? other.getBuyerAlipayNo() == null : this.getBuyerAlipayNo().equals(other.getBuyerAlipayNo()))
				&& (this.getFenxiaoShopName() == null ? other.getFenxiaoShopName() == null : this.getFenxiaoShopName().equals(other.getFenxiaoShopName()))
				&& (this.getFenxiaoShopId() == null ? other.getFenxiaoShopId() == null : this.getFenxiaoShopId().equals(other.getFenxiaoShopId()))
				&& (this.getIsScoreUpdated() == null ? other.getIsScoreUpdated() == null : this.getIsScoreUpdated().equals(other.getIsScoreUpdated()))
				&& (this.getServiceTags() == null ? other.getServiceTags() == null : this.getServiceTags().equals(other.getServiceTags()))
				&& (this.getZhengjiStatus() == null ? other.getZhengjiStatus() == null : this.getZhengjiStatus().equals(other.getZhengjiStatus()))
				&& (this.getTargetOrderUkid() == null ? other.getTargetOrderUkid() == null : this.getTargetOrderUkid().equals(other.getTargetOrderUkid()))
				&& (this.getInvoiceName() == null ? other.getInvoiceName() == null : this.getInvoiceName().equals(other.getInvoiceName()))
				&& (this.getInvoiceType() == null ? other.getInvoiceType() == null : this.getInvoiceType().equals(other.getInvoiceType()))
				&& (this.getEstConTime() == null ? other.getEstConTime() == null : this.getEstConTime().equals(other.getEstConTime()))
				&& (this.getInvoiceKind() == null ? other.getInvoiceKind() == null : this.getInvoiceKind().equals(other.getInvoiceKind()))
				&& (this.getPaidCouponFee() == null ? other.getPaidCouponFee() == null : this.getPaidCouponFee().equals(other.getPaidCouponFee()))
				&& (this.getReceivedPayment() == null ? other.getReceivedPayment() == null : this.getReceivedPayment().equals(other.getReceivedPayment()))
				&& (this.getEticketServiceAddr() == null ? other.getEticketServiceAddr() == null : this.getEticketServiceAddr().equals(other.getEticketServiceAddr()))
				&& (this.getIsShShip() == null ? other.getIsShShip() == null : this.getIsShShip().equals(other.getIsShShip()))
				&& (this.getO2oSnatchStatus() == null ? other.getO2oSnatchStatus() == null : this.getO2oSnatchStatus().equals(other.getO2oSnatchStatus()))
				&& (this.getMarket() == null ? other.getMarket() == null : this.getMarket().equals(other.getMarket()))
				&& (this.getEtType() == null ? other.getEtType() == null : this.getEtType().equals(other.getEtType()))
				&& (this.getEtShopId() == null ? other.getEtShopId() == null : this.getEtShopId().equals(other.getEtShopId()))
				&& (this.getObs() == null ? other.getObs() == null : this.getObs().equals(other.getObs()))
				&& (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
				&& (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
		result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
		result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
		result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
		result = prime * result + ((getReleaseTime() == null) ? 0 : getReleaseTime().hashCode());
		result = prime * result + ((getOriginTradeStatus() == null) ? 0 : getOriginTradeStatus().hashCode());
		result = prime * result + ((getSellerNick() == null) ? 0 : getSellerNick().hashCode());
		result = prime * result + ((getPicPath() == null) ? 0 : getPicPath().hashCode());
		result = prime * result + ((getPayment() == null) ? 0 : getPayment().hashCode());
		result = prime * result + ((getSellerRate() == null) ? 0 : getSellerRate().hashCode());
		result = prime * result + ((getPostFee() == null) ? 0 : getPostFee().hashCode());
		result = prime * result + ((getReceiverName() == null) ? 0 : getReceiverName().hashCode());
		result = prime * result + ((getReceiverState() == null) ? 0 : getReceiverState().hashCode());
		result = prime * result + ((getReceiverAddress() == null) ? 0 : getReceiverAddress().hashCode());
		result = prime * result + ((getReceiverZip() == null) ? 0 : getReceiverZip().hashCode());
		result = prime * result + ((getReceiverMobile() == null) ? 0 : getReceiverMobile().hashCode());
		result = prime * result + ((getReceiverPhone() == null) ? 0 : getReceiverPhone().hashCode());
		result = prime * result + ((getConsignTime() == null) ? 0 : getConsignTime().hashCode());
		result = prime * result + ((getReceiverCountry() == null) ? 0 : getReceiverCountry().hashCode());
		result = prime * result + ((getReceiverTown() == null) ? 0 : getReceiverTown().hashCode());
		result = prime * result + ((getOrderTaxFee() == null) ? 0 : getOrderTaxFee().hashCode());
		result = prime * result + ((getShopPick() == null) ? 0 : getShopPick().hashCode());
		result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
		result = prime * result + ((getNum() == null) ? 0 : getNum().hashCode());
		result = prime * result + ((getNumIid() == null) ? 0 : getNumIid().hashCode());
		result = prime * result + ((getPlatformOrderStatus() == null) ? 0 : getPlatformOrderStatus().hashCode());
		result = prime * result + ((getTitle() == null) ? 0 : getTitle().hashCode());
		result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
		result = prime * result + ((getPrice() == null) ? 0 : getPrice().hashCode());
		result = prime * result + ((getDiscountFee() == null) ? 0 : getDiscountFee().hashCode());
		result = prime * result + ((getTotalFee() == null) ? 0 : getTotalFee().hashCode());
		result = prime * result + ((getOrderCreateTime() == null) ? 0 : getOrderCreateTime().hashCode());
		result = prime * result + ((getOrderPayTime() == null) ? 0 : getOrderPayTime().hashCode());
		result = prime * result + ((getOrderModifyTime() == null) ? 0 : getOrderModifyTime().hashCode());
		result = prime * result + ((getOrderEndTime() == null) ? 0 : getOrderEndTime().hashCode());
		result = prime * result + ((getSellerFlag() == null) ? 0 : getSellerFlag().hashCode());
		result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
		result = prime * result + ((getHasBuyerMessage() == null) ? 0 : getHasBuyerMessage().hashCode());
		result = prime * result + ((getCreditCardFee() == null) ? 0 : getCreditCardFee().hashCode());
		result = prime * result + ((getStepTradeStatus() == null) ? 0 : getStepTradeStatus().hashCode());
		result = prime * result + ((getStepPaidFee() == null) ? 0 : getStepPaidFee().hashCode());
		result = prime * result + ((getMarkDesc() == null) ? 0 : getMarkDesc().hashCode());
		result = prime * result + ((getShippingType() == null) ? 0 : getShippingType().hashCode());
		result = prime * result + ((getAdjustFee() == null) ? 0 : getAdjustFee().hashCode());
		result = prime * result + ((getTradeFrom() == null) ? 0 : getTradeFrom().hashCode());
		result = prime * result + ((getBuyerRate() == null) ? 0 : getBuyerRate().hashCode());
		result = prime * result + ((getReceiverCity() == null) ? 0 : getReceiverCity().hashCode());
		result = prime * result + ((getReceiverCounty() == null) ? 0 : getReceiverCounty().hashCode());
		result = prime * result + ((getRxAuditStatus() == null) ? 0 : getRxAuditStatus().hashCode());
		result = prime * result + ((getHasPostFee() == null) ? 0 : getHasPostFee().hashCode());
		result = prime * result + ((getSellerCodFee() == null) ? 0 : getSellerCodFee().hashCode());
		result = prime * result + ((getBuyerCodFee() == null) ? 0 : getBuyerCodFee().hashCode());
		result = prime * result + ((getCodStatus() == null) ? 0 : getCodStatus().hashCode());
		result = prime * result + ((getCodFee() == null) ? 0 : getCodFee().hashCode());
		result = prime * result + ((getPointFee() == null) ? 0 : getPointFee().hashCode());
		result = prime * result + ((getBuyerMessage() == null) ? 0 : getBuyerMessage().hashCode());
		result = prime * result + ((getBuyerFlag() == null) ? 0 : getBuyerFlag().hashCode());
		result = prime * result + ((getSellerMemo() == null) ? 0 : getSellerMemo().hashCode());
		result = prime * result + ((getBuyerArea() == null) ? 0 : getBuyerArea().hashCode());
		result = prime * result + ((getBuyerAlipayNo() == null) ? 0 : getBuyerAlipayNo().hashCode());
		result = prime * result + ((getFenxiaoShopName() == null) ? 0 : getFenxiaoShopName().hashCode());
		result = prime * result + ((getFenxiaoShopId() == null) ? 0 : getFenxiaoShopId().hashCode());
		result = prime * result + ((getIsScoreUpdated() == null) ? 0 : getIsScoreUpdated().hashCode());
		result = prime * result + ((getServiceTags() == null) ? 0 : getServiceTags().hashCode());
		result = prime * result + ((getZhengjiStatus() == null) ? 0 : getZhengjiStatus().hashCode());
		result = prime * result + ((getTargetOrderUkid() == null) ? 0 : getTargetOrderUkid().hashCode());
		result = prime * result + ((getInvoiceName() == null) ? 0 : getInvoiceName().hashCode());
		result = prime * result + ((getInvoiceType() == null) ? 0 : getInvoiceType().hashCode());
		result = prime * result + ((getEstConTime() == null) ? 0 : getEstConTime().hashCode());
		result = prime * result + ((getInvoiceKind() == null) ? 0 : getInvoiceKind().hashCode());
		result = prime * result + ((getPaidCouponFee() == null) ? 0 : getPaidCouponFee().hashCode());
		result = prime * result + ((getReceivedPayment() == null) ? 0 : getReceivedPayment().hashCode());
		result = prime * result + ((getEticketServiceAddr() == null) ? 0 : getEticketServiceAddr().hashCode());
		result = prime * result + ((getIsShShip() == null) ? 0 : getIsShShip().hashCode());
		result = prime * result + ((getO2oSnatchStatus() == null) ? 0 : getO2oSnatchStatus().hashCode());
		result = prime * result + ((getMarket() == null) ? 0 : getMarket().hashCode());
		result = prime * result + ((getEtType() == null) ? 0 : getEtType().hashCode());
		result = prime * result + ((getEtShopId() == null) ? 0 : getEtShopId().hashCode());
		result = prime * result + ((getObs() == null) ? 0 : getObs().hashCode());
		result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
		result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
		return result;
	}
}