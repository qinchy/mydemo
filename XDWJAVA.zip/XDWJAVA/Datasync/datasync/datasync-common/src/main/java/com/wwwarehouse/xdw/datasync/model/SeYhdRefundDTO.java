package com.wwwarehouse.xdw.datasync.model;

import java.math.BigDecimal;
import java.util.Date;

public class SeYhdRefundDTO extends SeBaseRefund<SeYhdRefundItemDTO> {
    private Long refundUkid;

    private Long shopId;

    private Date downTime;

    private Date updateTime;

    private String refundId;

    private String orderId;

    private String orderCode;

    private String refundStatus;

    private BigDecimal deliveryFee;

    private BigDecimal productAmount;

    private String contactName;

    private String contactPhone;

    private String sendBackAddress;

    private String reasonMsg;

    private String refundProblem;

    private String evidencePicUrls;

    private String buyerNick;

    private String receiverPhone;

    private String receiverAddress;

    private Date refundCreateTime;

    private String merchantMark;

    private String merchantRemark;

    private Date approveDate;

    private Date sendBackDate;

    private Date rejectDate;

    private Date cancelTime;

    private String expressName;

    private String expressNbr;

    private Long conversionStatus;

    private Long targetOrderUkid;

    private String orderStatus;

    private String iscsReceiptStatus;

    private String serviceStatus;

    private Long processStatus;

    private String subOrderId;

    private String goodStatus;

    private Long createUserId;

    private Long updateUserId;

    private static final long serialVersionUID = 1L;

    public Long getRefundUkid() {
        return refundUkid;
    }

    public void setRefundUkid(Long refundUkid) {
        this.refundUkid = refundUkid;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }

    public BigDecimal getDeliveryFee() {
        return deliveryFee;
    }

    public void setDeliveryFee(BigDecimal deliveryFee) {
        this.deliveryFee = deliveryFee;
    }

    public BigDecimal getProductAmount() {
        return productAmount;
    }

    public void setProductAmount(BigDecimal productAmount) {
        this.productAmount = productAmount;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getSendBackAddress() {
        return sendBackAddress;
    }

    public void setSendBackAddress(String sendBackAddress) {
        this.sendBackAddress = sendBackAddress;
    }

    public String getReasonMsg() {
        return reasonMsg;
    }

    public void setReasonMsg(String reasonMsg) {
        this.reasonMsg = reasonMsg;
    }

    public String getRefundProblem() {
        return refundProblem;
    }

    public void setRefundProblem(String refundProblem) {
        this.refundProblem = refundProblem;
    }

    public String getEvidencePicUrls() {
        return evidencePicUrls;
    }

    public void setEvidencePicUrls(String evidencePicUrls) {
        this.evidencePicUrls = evidencePicUrls;
    }

    public String getBuyerNick() {
        return buyerNick;
    }

    public void setBuyerNick(String buyerNick) {
        this.buyerNick = buyerNick;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public Date getRefundCreateTime() {
        return refundCreateTime;
    }

    public void setRefundCreateTime(Date refundCreateTime) {
        this.refundCreateTime = refundCreateTime;
    }

    public String getMerchantMark() {
        return merchantMark;
    }

    public void setMerchantMark(String merchantMark) {
        this.merchantMark = merchantMark;
    }

    public String getMerchantRemark() {
        return merchantRemark;
    }

    public void setMerchantRemark(String merchantRemark) {
        this.merchantRemark = merchantRemark;
    }

    public Date getApproveDate() {
        return approveDate;
    }

    public void setApproveDate(Date approveDate) {
        this.approveDate = approveDate;
    }

    public Date getSendBackDate() {
        return sendBackDate;
    }

    public void setSendBackDate(Date sendBackDate) {
        this.sendBackDate = sendBackDate;
    }

    public Date getRejectDate() {
        return rejectDate;
    }

    public void setRejectDate(Date rejectDate) {
        this.rejectDate = rejectDate;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getExpressName() {
        return expressName;
    }

    public void setExpressName(String expressName) {
        this.expressName = expressName;
    }

    public String getExpressNbr() {
        return expressNbr;
    }

    public void setExpressNbr(String expressNbr) {
        this.expressNbr = expressNbr;
    }

    public Long getConversionStatus() {
        return conversionStatus;
    }

    public void setConversionStatus(Long conversionStatus) {
        this.conversionStatus = conversionStatus;
    }

    public Long getTargetOrderUkid() {
        return targetOrderUkid;
    }

    public void setTargetOrderUkid(Long targetOrderUkid) {
        this.targetOrderUkid = targetOrderUkid;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getIscsReceiptStatus() {
        return iscsReceiptStatus;
    }

    public void setIscsReceiptStatus(String iscsReceiptStatus) {
        this.iscsReceiptStatus = iscsReceiptStatus;
    }

    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public Long getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(Long processStatus) {
        this.processStatus = processStatus;
    }

    public String getSubOrderId() {
        return subOrderId;
    }

    public void setSubOrderId(String subOrderId) {
        this.subOrderId = subOrderId;
    }

    public String getGoodStatus() {
        return goodStatus;
    }

    public void setGoodStatus(String goodStatus) {
        this.goodStatus = goodStatus;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", refundUkid=").append(refundUkid);
        sb.append(", shopId=").append(shopId);
        sb.append(", downTime=").append(downTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", refundId=").append(refundId);
        sb.append(", orderId=").append(orderId);
        sb.append(", orderCode=").append(orderCode);
        sb.append(", refundStatus=").append(refundStatus);
        sb.append(", deliveryFee=").append(deliveryFee);
        sb.append(", productAmount=").append(productAmount);
        sb.append(", contactName=").append(contactName);
        sb.append(", contactPhone=").append(contactPhone);
        sb.append(", sendBackAddress=").append(sendBackAddress);
        sb.append(", reasonMsg=").append(reasonMsg);
        sb.append(", refundProblem=").append(refundProblem);
        sb.append(", evidencePicUrls=").append(evidencePicUrls);
        sb.append(", buyerNick=").append(buyerNick);
        sb.append(", receiverPhone=").append(receiverPhone);
        sb.append(", receiverAddress=").append(receiverAddress);
        sb.append(", refundCreateTime=").append(refundCreateTime);
        sb.append(", merchantMark=").append(merchantMark);
        sb.append(", merchantRemark=").append(merchantRemark);
        sb.append(", approveDate=").append(approveDate);
        sb.append(", sendBackDate=").append(sendBackDate);
        sb.append(", rejectDate=").append(rejectDate);
        sb.append(", cancelTime=").append(cancelTime);
        sb.append(", expressName=").append(expressName);
        sb.append(", expressNbr=").append(expressNbr);
        sb.append(", conversionStatus=").append(conversionStatus);
        sb.append(", targetOrderUkid=").append(targetOrderUkid);
        sb.append(", orderStatus=").append(orderStatus);
        sb.append(", iscsReceiptStatus=").append(iscsReceiptStatus);
        sb.append(", serviceStatus=").append(serviceStatus);
        sb.append(", processStatus=").append(processStatus);
        sb.append(", subOrderId=").append(subOrderId);
        sb.append(", goodStatus=").append(goodStatus);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeYhdRefundDTO other = (SeYhdRefundDTO) that;
        return (this.getRefundUkid() == null ? other.getRefundUkid() == null : this.getRefundUkid().equals(other.getRefundUkid()))
                && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
                && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
                && (this.getRefundId() == null ? other.getRefundId() == null : this.getRefundId().equals(other.getRefundId()))
                && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
                && (this.getOrderCode() == null ? other.getOrderCode() == null : this.getOrderCode().equals(other.getOrderCode()))
                && (this.getRefundStatus() == null ? other.getRefundStatus() == null : this.getRefundStatus().equals(other.getRefundStatus()))
                && (this.getDeliveryFee() == null ? other.getDeliveryFee() == null : this.getDeliveryFee().equals(other.getDeliveryFee()))
                && (this.getProductAmount() == null ? other.getProductAmount() == null : this.getProductAmount().equals(other.getProductAmount()))
                && (this.getContactName() == null ? other.getContactName() == null : this.getContactName().equals(other.getContactName()))
                && (this.getContactPhone() == null ? other.getContactPhone() == null : this.getContactPhone().equals(other.getContactPhone()))
                && (this.getSendBackAddress() == null ? other.getSendBackAddress() == null : this.getSendBackAddress().equals(other.getSendBackAddress()))
                && (this.getReasonMsg() == null ? other.getReasonMsg() == null : this.getReasonMsg().equals(other.getReasonMsg()))
                && (this.getRefundProblem() == null ? other.getRefundProblem() == null : this.getRefundProblem().equals(other.getRefundProblem()))
                && (this.getEvidencePicUrls() == null ? other.getEvidencePicUrls() == null : this.getEvidencePicUrls().equals(other.getEvidencePicUrls()))
                && (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
                && (this.getReceiverPhone() == null ? other.getReceiverPhone() == null : this.getReceiverPhone().equals(other.getReceiverPhone()))
                && (this.getReceiverAddress() == null ? other.getReceiverAddress() == null : this.getReceiverAddress().equals(other.getReceiverAddress()))
                && (this.getRefundCreateTime() == null ? other.getRefundCreateTime() == null : this.getRefundCreateTime().equals(other.getRefundCreateTime()))
                && (this.getMerchantMark() == null ? other.getMerchantMark() == null : this.getMerchantMark().equals(other.getMerchantMark()))
                && (this.getMerchantRemark() == null ? other.getMerchantRemark() == null : this.getMerchantRemark().equals(other.getMerchantRemark()))
                && (this.getApproveDate() == null ? other.getApproveDate() == null : this.getApproveDate().equals(other.getApproveDate()))
                && (this.getSendBackDate() == null ? other.getSendBackDate() == null : this.getSendBackDate().equals(other.getSendBackDate()))
                && (this.getRejectDate() == null ? other.getRejectDate() == null : this.getRejectDate().equals(other.getRejectDate()))
                && (this.getCancelTime() == null ? other.getCancelTime() == null : this.getCancelTime().equals(other.getCancelTime()))
                && (this.getExpressName() == null ? other.getExpressName() == null : this.getExpressName().equals(other.getExpressName()))
                && (this.getExpressNbr() == null ? other.getExpressNbr() == null : this.getExpressNbr().equals(other.getExpressNbr()))
                && (this.getConversionStatus() == null ? other.getConversionStatus() == null : this.getConversionStatus().equals(other.getConversionStatus()))
                && (this.getTargetOrderUkid() == null ? other.getTargetOrderUkid() == null : this.getTargetOrderUkid().equals(other.getTargetOrderUkid()))
                && (this.getOrderStatus() == null ? other.getOrderStatus() == null : this.getOrderStatus().equals(other.getOrderStatus()))
                && (this.getIscsReceiptStatus() == null ? other.getIscsReceiptStatus() == null : this.getIscsReceiptStatus().equals(other.getIscsReceiptStatus()))
                && (this.getServiceStatus() == null ? other.getServiceStatus() == null : this.getServiceStatus().equals(other.getServiceStatus()))
                && (this.getProcessStatus() == null ? other.getProcessStatus() == null : this.getProcessStatus().equals(other.getProcessStatus()))
                && (this.getSubOrderId() == null ? other.getSubOrderId() == null : this.getSubOrderId().equals(other.getSubOrderId()))
                && (this.getGoodStatus() == null ? other.getGoodStatus() == null : this.getGoodStatus().equals(other.getGoodStatus()))
                && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
                && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getRefundUkid() == null) ? 0 : getRefundUkid().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getRefundId() == null) ? 0 : getRefundId().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getOrderCode() == null) ? 0 : getOrderCode().hashCode());
        result = prime * result + ((getRefundStatus() == null) ? 0 : getRefundStatus().hashCode());
        result = prime * result + ((getDeliveryFee() == null) ? 0 : getDeliveryFee().hashCode());
        result = prime * result + ((getProductAmount() == null) ? 0 : getProductAmount().hashCode());
        result = prime * result + ((getContactName() == null) ? 0 : getContactName().hashCode());
        result = prime * result + ((getContactPhone() == null) ? 0 : getContactPhone().hashCode());
        result = prime * result + ((getSendBackAddress() == null) ? 0 : getSendBackAddress().hashCode());
        result = prime * result + ((getReasonMsg() == null) ? 0 : getReasonMsg().hashCode());
        result = prime * result + ((getRefundProblem() == null) ? 0 : getRefundProblem().hashCode());
        result = prime * result + ((getEvidencePicUrls() == null) ? 0 : getEvidencePicUrls().hashCode());
        result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
        result = prime * result + ((getReceiverPhone() == null) ? 0 : getReceiverPhone().hashCode());
        result = prime * result + ((getReceiverAddress() == null) ? 0 : getReceiverAddress().hashCode());
        result = prime * result + ((getRefundCreateTime() == null) ? 0 : getRefundCreateTime().hashCode());
        result = prime * result + ((getMerchantMark() == null) ? 0 : getMerchantMark().hashCode());
        result = prime * result + ((getMerchantRemark() == null) ? 0 : getMerchantRemark().hashCode());
        result = prime * result + ((getApproveDate() == null) ? 0 : getApproveDate().hashCode());
        result = prime * result + ((getSendBackDate() == null) ? 0 : getSendBackDate().hashCode());
        result = prime * result + ((getRejectDate() == null) ? 0 : getRejectDate().hashCode());
        result = prime * result + ((getCancelTime() == null) ? 0 : getCancelTime().hashCode());
        result = prime * result + ((getExpressName() == null) ? 0 : getExpressName().hashCode());
        result = prime * result + ((getExpressNbr() == null) ? 0 : getExpressNbr().hashCode());
        result = prime * result + ((getConversionStatus() == null) ? 0 : getConversionStatus().hashCode());
        result = prime * result + ((getTargetOrderUkid() == null) ? 0 : getTargetOrderUkid().hashCode());
        result = prime * result + ((getOrderStatus() == null) ? 0 : getOrderStatus().hashCode());
        result = prime * result + ((getIscsReceiptStatus() == null) ? 0 : getIscsReceiptStatus().hashCode());
        result = prime * result + ((getServiceStatus() == null) ? 0 : getServiceStatus().hashCode());
        result = prime * result + ((getProcessStatus() == null) ? 0 : getProcessStatus().hashCode());
        result = prime * result + ((getSubOrderId() == null) ? 0 : getSubOrderId().hashCode());
        result = prime * result + ((getGoodStatus() == null) ? 0 : getGoodStatus().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        return result;
    }
}