package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.commons.utils.AbsResponse;

/**
 * 地图接口
 * Created by huahui.wu on 2017/6/15.
 */
public interface MapService {

	/**
	 * 地理编码 转换
	 * @param address 结构化地址信息(规则遵循：国家、省份、城市、城镇、乡村、街道、门牌号码、屋邨、大厦，如：北京市朝阳区阜通东大街6号。)
	 * @param city    指定查询的城市(无，会进行全国范围内搜索)
	 * @return location 坐标点(经度，纬度)
	 * @param mapCode
	 * @return
	 * @throws Exception
	 */
	AbsResponse<Object> geoCodeGeo(String address, String city, String location, Long mapCode) throws Exception;

	/**
	 * 路线规划
	 * @param origin 出发地
	 * @param destination 目的地
	 * @param strategy 高德 驾车模式 必填
	 * @param mode 导航模式
	 * @param region 百度 公交、步行导航时该参数必填。
	 * @return
	 * @throws Exception
	 */
	AbsResponse<Object> direction(String origin, String destination, String strategy, String mode, Long mapCode, String region) throws Exception;

	/**
	 * 关键字搜索
	 *
	 * @param city     查询城市(无 全国范围内搜索)
	 * @param keywords 查询关键字
	 * @return
	 */
	AbsResponse<Object> getLocation(String city, String keywords, Long mapCode) throws Exception;
}


