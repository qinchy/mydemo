package com.wwwarehouse.xdw.datasync.model;

import java.math.BigDecimal;
import java.util.Date;

public class SeJingdongRefundDTO extends SeBaseRefund<SeBaseItem>{
    private Long refundUkid;

    private Long shopId;

    private Date downTime;

    private String refundId;

    private String buyerNick;

    private Date checkTime;

    private Date refundCreateTime;

    private BigDecimal applyRefundSum;

    private String status;

    private String checkUsername;

    private String orderId;

    private Long saveNum;

    private Long conversionStatus;

    private String wareId;

    private String wareName;

    private String refundType;

    private String expressCode;

    private Long customerExpect;

    private Long processStatus;

    private String orderStatus;

    private String iscsReceiptStatus;

    private String serviceStatus;

    private String subOrderId;

    private String goodStatus;

    private String buyerId;

    private Long updateUserId;

    private Long createUserId;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getRefundUkid() {
        return refundUkid;
    }

    public void setRefundUkid(Long refundUkid) {
        this.refundUkid = refundUkid;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public String getBuyerNick() {
        return buyerNick;
    }

    public void setBuyerNick(String buyerNick) {
        this.buyerNick = buyerNick;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getRefundCreateTime() {
        return refundCreateTime;
    }

    public void setRefundCreateTime(Date refundCreateTime) {
        this.refundCreateTime = refundCreateTime;
    }

    public BigDecimal getApplyRefundSum() {
        return applyRefundSum;
    }

    public void setApplyRefundSum(BigDecimal applyRefundSum) {
        this.applyRefundSum = applyRefundSum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCheckUsername() {
        return checkUsername;
    }

    public void setCheckUsername(String checkUsername) {
        this.checkUsername = checkUsername;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Long getSaveNum() {
        return saveNum;
    }

    public void setSaveNum(Long saveNum) {
        this.saveNum = saveNum;
    }

    public Long getConversionStatus() {
        return conversionStatus;
    }

    public void setConversionStatus(Long conversionStatus) {
        this.conversionStatus = conversionStatus;
    }

    public String getWareId() {
        return wareId;
    }

    public void setWareId(String wareId) {
        this.wareId = wareId;
    }

    public String getWareName() {
        return wareName;
    }

    public void setWareName(String wareName) {
        this.wareName = wareName;
    }

    public String getRefundType() {
        return refundType;
    }

    public void setRefundType(String refundType) {
        this.refundType = refundType;
    }

    public String getExpressCode() {
        return expressCode;
    }

    public void setExpressCode(String expressCode) {
        this.expressCode = expressCode;
    }

    public Long getCustomerExpect() {
        return customerExpect;
    }

    public void setCustomerExpect(Long customerExpect) {
        this.customerExpect = customerExpect;
    }

    public Long getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(Long processStatus) {
        this.processStatus = processStatus;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getIscsReceiptStatus() {
        return iscsReceiptStatus;
    }

    public void setIscsReceiptStatus(String iscsReceiptStatus) {
        this.iscsReceiptStatus = iscsReceiptStatus;
    }

    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public String getSubOrderId() {
        return subOrderId;
    }

    public void setSubOrderId(String subOrderId) {
        this.subOrderId = subOrderId;
    }

    public String getGoodStatus() {
        return goodStatus;
    }

    public void setGoodStatus(String goodStatus) {
        this.goodStatus = goodStatus;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", refundUkid=").append(refundUkid);
        sb.append(", shopId=").append(shopId);
        sb.append(", downTime=").append(downTime);
        sb.append(", refundId=").append(refundId);
        sb.append(", buyerNick=").append(buyerNick);
        sb.append(", checkTime=").append(checkTime);
        sb.append(", refundCreateTime=").append(refundCreateTime);
        sb.append(", applyRefundSum=").append(applyRefundSum);
        sb.append(", status=").append(status);
        sb.append(", checkUsername=").append(checkUsername);
        sb.append(", orderId=").append(orderId);
        sb.append(", saveNum=").append(saveNum);
        sb.append(", conversionStatus=").append(conversionStatus);
        sb.append(", wareId=").append(wareId);
        sb.append(", wareName=").append(wareName);
        sb.append(", refundType=").append(refundType);
        sb.append(", expressCode=").append(expressCode);
        sb.append(", customerExpect=").append(customerExpect);
        sb.append(", processStatus=").append(processStatus);
        sb.append(", orderStatus=").append(orderStatus);
        sb.append(", iscsReceiptStatus=").append(iscsReceiptStatus);
        sb.append(", serviceStatus=").append(serviceStatus);
        sb.append(", subOrderId=").append(subOrderId);
        sb.append(", goodStatus=").append(goodStatus);
        sb.append(", buyerId=").append(buyerId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeJingdongRefundDTO other = (SeJingdongRefundDTO) that;
        return (this.getRefundUkid() == null ? other.getRefundUkid() == null : this.getRefundUkid().equals(other.getRefundUkid()))
                && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
                && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
                && (this.getRefundId() == null ? other.getRefundId() == null : this.getRefundId().equals(other.getRefundId()))
                && (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
                && (this.getCheckTime() == null ? other.getCheckTime() == null : this.getCheckTime().equals(other.getCheckTime()))
                && (this.getRefundCreateTime() == null ? other.getRefundCreateTime() == null : this.getRefundCreateTime().equals(other.getRefundCreateTime()))
                && (this.getApplyRefundSum() == null ? other.getApplyRefundSum() == null : this.getApplyRefundSum().equals(other.getApplyRefundSum()))
                && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
                && (this.getCheckUsername() == null ? other.getCheckUsername() == null : this.getCheckUsername().equals(other.getCheckUsername()))
                && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
                && (this.getSaveNum() == null ? other.getSaveNum() == null : this.getSaveNum().equals(other.getSaveNum()))
                && (this.getConversionStatus() == null ? other.getConversionStatus() == null : this.getConversionStatus().equals(other.getConversionStatus()))
                && (this.getWareId() == null ? other.getWareId() == null : this.getWareId().equals(other.getWareId()))
                && (this.getWareName() == null ? other.getWareName() == null : this.getWareName().equals(other.getWareName()))
                && (this.getRefundType() == null ? other.getRefundType() == null : this.getRefundType().equals(other.getRefundType()))
                && (this.getExpressCode() == null ? other.getExpressCode() == null : this.getExpressCode().equals(other.getExpressCode()))
                && (this.getCustomerExpect() == null ? other.getCustomerExpect() == null : this.getCustomerExpect().equals(other.getCustomerExpect()))
                && (this.getProcessStatus() == null ? other.getProcessStatus() == null : this.getProcessStatus().equals(other.getProcessStatus()))
                && (this.getOrderStatus() == null ? other.getOrderStatus() == null : this.getOrderStatus().equals(other.getOrderStatus()))
                && (this.getIscsReceiptStatus() == null ? other.getIscsReceiptStatus() == null : this.getIscsReceiptStatus().equals(other.getIscsReceiptStatus()))
                && (this.getServiceStatus() == null ? other.getServiceStatus() == null : this.getServiceStatus().equals(other.getServiceStatus()))
                && (this.getSubOrderId() == null ? other.getSubOrderId() == null : this.getSubOrderId().equals(other.getSubOrderId()))
                && (this.getGoodStatus() == null ? other.getGoodStatus() == null : this.getGoodStatus().equals(other.getGoodStatus()))
                && (this.getBuyerId() == null ? other.getBuyerId() == null : this.getBuyerId().equals(other.getBuyerId()))
                && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
                && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getRefundUkid() == null) ? 0 : getRefundUkid().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getRefundId() == null) ? 0 : getRefundId().hashCode());
        result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
        result = prime * result + ((getCheckTime() == null) ? 0 : getCheckTime().hashCode());
        result = prime * result + ((getRefundCreateTime() == null) ? 0 : getRefundCreateTime().hashCode());
        result = prime * result + ((getApplyRefundSum() == null) ? 0 : getApplyRefundSum().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCheckUsername() == null) ? 0 : getCheckUsername().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getSaveNum() == null) ? 0 : getSaveNum().hashCode());
        result = prime * result + ((getConversionStatus() == null) ? 0 : getConversionStatus().hashCode());
        result = prime * result + ((getWareId() == null) ? 0 : getWareId().hashCode());
        result = prime * result + ((getWareName() == null) ? 0 : getWareName().hashCode());
        result = prime * result + ((getRefundType() == null) ? 0 : getRefundType().hashCode());
        result = prime * result + ((getExpressCode() == null) ? 0 : getExpressCode().hashCode());
        result = prime * result + ((getCustomerExpect() == null) ? 0 : getCustomerExpect().hashCode());
        result = prime * result + ((getProcessStatus() == null) ? 0 : getProcessStatus().hashCode());
        result = prime * result + ((getOrderStatus() == null) ? 0 : getOrderStatus().hashCode());
        result = prime * result + ((getIscsReceiptStatus() == null) ? 0 : getIscsReceiptStatus().hashCode());
        result = prime * result + ((getServiceStatus() == null) ? 0 : getServiceStatus().hashCode());
        result = prime * result + ((getSubOrderId() == null) ? 0 : getSubOrderId().hashCode());
        result = prime * result + ((getGoodStatus() == null) ? 0 : getGoodStatus().hashCode());
        result = prime * result + ((getBuyerId() == null) ? 0 : getBuyerId().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}