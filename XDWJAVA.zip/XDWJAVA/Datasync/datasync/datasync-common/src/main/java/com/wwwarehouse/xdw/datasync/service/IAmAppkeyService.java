package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/19 0019.
 */
public interface IAmAppkeyService {


    /**
     * @param platformId
     * @param ownerBuId
     * @param appKey
     * @param appkeyType
     * @param status
     * @return
     */
    public List<AmAppkeyDTO> getsByType(Long platformId, Long ownerBuId, String appKey,
                                        String appkeyType, Long status);

    /**
     * 查询状态为1的数据
     *
     * @param platformId
     * @param appKey
     * @param appkeyType
     * @return
     */
    public AmAppkeyDTO getByAppkey(Long platformId, String appKey, String appkeyType);

    /**
     * 查询状态为1的数据
     *
     * @param platformId
     * @param ownerBuId
     * @param appType
     * @return
     */
    public AmAppkeyDTO getByType(Long platformId, Long ownerBuId, String appType);

    /**
     * 根据类型获取可用状态的appKeys
     *
     * @return
     */
    public List<AmAppkeyDTO> getsUsableKeys(String appType);
}
