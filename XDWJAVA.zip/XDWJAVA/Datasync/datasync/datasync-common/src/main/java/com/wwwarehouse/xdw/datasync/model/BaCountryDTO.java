package com.wwwarehouse.xdw.datasync.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.List;


/**
 * Created by jingchun.zhang on 2017/6/16.
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class BaCountryDTO extends BaseObject{
    //国家id
    private String countryId;
    //中文名称
    private String countryNameZh;
    //英文名称
    private String countryNameEn;
    //下一级行政区域列表
    private List<BaArea> nextLevelAreaList;

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getCountryNameZh() {
        return countryNameZh;
    }

    public void setCountryNameZh(String countryNameZh) {
        this.countryNameZh = countryNameZh;
    }

    public String getCountryNameEn() {
        return countryNameEn;
    }

    public void setCountryNameEn(String countryNameEn) {
        this.countryNameEn = countryNameEn;
    }

    public List<BaArea> getNextLevelAreaList() {
        return nextLevelAreaList;
    }

    public void setNextLevelAreaList(List<BaArea> nextLevelAreaList) {
        this.nextLevelAreaList = nextLevelAreaList;
    }

    @Override
    public String toString() {
        return "BaCountryDTO{" +
                "countryId='" + countryId + '\'' +
                ", countryNameZh='" + countryNameZh + '\'' +
                ", countryNameEn='" + countryNameEn + '\'' +
                ", nextLevelAreaList=" + nextLevelAreaList +
                '}';
    }
}
