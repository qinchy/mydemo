package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

public class BaShopDTO extends BaseObject {
    private Long shopId;

    private String shopName;

    private Long platformId;

    private Long sellerId;

    private String sellerNick;

    private Long createUserId;

    private Date createDate;

    private Long updateUserId;

    private Date updateDate;

    private Date shopCreated;

    private Date authExpireIn;

    private Long isAuth;

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName == null ? null : shopName.trim();
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerNick() {
        return sellerNick;
    }

    public void setSellerNick(String sellerNick) {
        this.sellerNick = sellerNick == null ? null : sellerNick.trim();
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

	public Date getShopCreated() {
		return shopCreated;
	}

	public void setShopCreated(Date shopCreated) {
		this.shopCreated = shopCreated;
	}

	public Date getAuthExpireIn() {
		return authExpireIn;
	}

	public void setAuthExpireIn(Date authExpireIn) {
		this.authExpireIn = authExpireIn;
	}

	public Long getIsAuth() {
		return isAuth;
	}

	public void setIsAuth(Long isAuth) {
		this.isAuth = isAuth;
	}
}