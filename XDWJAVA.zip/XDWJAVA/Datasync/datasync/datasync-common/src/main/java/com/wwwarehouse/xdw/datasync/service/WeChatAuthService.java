package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;

/**
 * Created by dan.han on 2017/6/13.
 */
public interface WeChatAuthService {
    /**
     *根据临时授权票据,获取access_token,授权结果信息
     * @param authCode
     * @return
     */
    public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode, AmAppkeyDTO amAppkey);

}
