package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

/**
 * SaSmsDTO entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class SaSmsDTO extends BaseObject{
    private Long smsUkid;
    private Long serviceBuId;
    private Long sendBuId;
    private String mobileNo;
    private String sendContent;
    private Long smsNum;
    private Date planSendTime;
    private Date actualSendTime;
    private Long smsStatus;
    private Date createTime;
    private Long createUserId;
    private String smsType;
    private Date cancelTime;
    private Long cancelUserId;
    private String returnText;
    private Long platformId;
    private Long smsTemplateUkid;
    private Long smsAccountUkid;
    private String relatedType;
    private Long relatedOrderUkid;

    public SaSmsDTO() {
    }

    public SaSmsDTO(Long smsUkid) {
        this.smsUkid = smsUkid;
    }

    public Long getSmsUkid() {
        return smsUkid;
    }

    public void setSmsUkid(Long smsUkid) {
        this.smsUkid = smsUkid;
    }

    public Long getServiceBuId() {
        return serviceBuId;
    }

    public void setServiceBuId(Long serviceBuId) {
        this.serviceBuId = serviceBuId;
    }

    public Long getSendBuId() {
        return sendBuId;
    }

    public void setSendBuId(Long sendBuId) {
        this.sendBuId = sendBuId;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getSendContent() {
        return sendContent;
    }

    public void setSendContent(String sendContent) {
        this.sendContent = sendContent;
    }

    public Long getSmsNum() {
        return smsNum;
    }

    public void setSmsNum(Long smsNum) {
        this.smsNum = smsNum;
    }

    public Date getPlanSendTime() {
        return planSendTime;
    }

    public void setPlanSendTime(Date planSendTime) {
        this.planSendTime = planSendTime;
    }

    public Date getActualSendTime() {
        return actualSendTime;
    }

    public void setActualSendTime(Date actualSendTime) {
        this.actualSendTime = actualSendTime;
    }

    public Long getSmsStatus() {
        return smsStatus;
    }

    public void setSmsStatus(Long smsStatus) {
        this.smsStatus = smsStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public String getSmsType() {
        return smsType;
    }

    public void setSmsType(String smsType) {
        this.smsType = smsType;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Long getCancelUserId() {
        return cancelUserId;
    }

    public void setCancelUserId(Long cancelUserId) {
        this.cancelUserId = cancelUserId;
    }

    public String getReturnText() {
        return returnText;
    }

    public void setReturnText(String returnText) {
        this.returnText = returnText;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public Long getSmsTemplateUkid() {
        return smsTemplateUkid;
    }

    public void setSmsTemplateUkid(Long smsTemplateUkid) {
        this.smsTemplateUkid = smsTemplateUkid;
    }

    public Long getSmsAccountUkid() {
        return smsAccountUkid;
    }

    public void setSmsAccountUkid(Long smsAccountUkid) {
        this.smsAccountUkid = smsAccountUkid;
    }

    public String getRelatedType() {
        return relatedType;
    }

    public void setRelatedType(String relatedType) {
        this.relatedType = relatedType;
    }

    public Long getRelatedOrderUkid() {
        return relatedOrderUkid;
    }

    public void setRelatedOrderUkid(Long relatedOrderUkid) {
        this.relatedOrderUkid = relatedOrderUkid;
    }


}