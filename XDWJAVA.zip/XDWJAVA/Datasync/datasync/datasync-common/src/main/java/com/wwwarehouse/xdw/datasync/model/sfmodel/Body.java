package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 11:09 on 2017/6/16.
 * @Modified By:
 */
public class Body<T> extends ToStringBaseModel{
    private T data;

    public Body() {
    }

    public Body(T data) {
        this.data = data;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }


    /**
     * 路由请求Body
     * */
    @XStreamAlias("Body")
    public class RouteBody extends ToStringBaseModel{
        @XStreamAlias("RouteResponse")
        private RouteResponse routeResponse;

        public RouteResponse getRouteResponse() {
            return routeResponse;
        }

        public void setRouteResponse(RouteResponse routeResponse) {
            this.routeResponse = routeResponse;
        }
    }

    /**
     * 下订单请求Body
     * */
    @XStreamAlias("Body")
    public class OrderBody extends ToStringBaseModel{
        @XStreamAlias("OrderResponse")
        private OrderResponse OrderResponse;

        public com.wwwarehouse.xdw.datasync.model.sfmodel.OrderResponse getOrderResponse() {
            return OrderResponse;
        }

        public void setOrderResponse(com.wwwarehouse.xdw.datasync.model.sfmodel.OrderResponse orderResponse) {
            OrderResponse = orderResponse;
        }
    }

    /**
     * 订单确认请求Body
     * */
    @XStreamAlias("Body")
    public class ConfirmBody extends ToStringBaseModel{
        @XStreamAlias("OrderConfirmResponse")
        private OrderConfirmResponse orderConfirmResponse;

        public OrderConfirmResponse getOrderConfirmResponse() {
            return orderConfirmResponse;
        }

        public void setOrderConfirmResponse(OrderConfirmResponse orderConfirmResponse) {
            this.orderConfirmResponse = orderConfirmResponse;
        }
    }
}
