package com.wwwarehouse.xdw.datasync.model;

/**
 * Created by huahui.wu on 2017/6/16.
 */

/**
 * 地图
 */
public class MapParamsDTO extends BaseObject{

	private String origin; //起始地

	private String destination; //目的地

	private String strategy; //驾车选择策略

	private String address; //结构化地址信息

	private String city; //指定查询的城市

	private String location; //经纬度坐标

	private String mode; //导航模式

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}




}
