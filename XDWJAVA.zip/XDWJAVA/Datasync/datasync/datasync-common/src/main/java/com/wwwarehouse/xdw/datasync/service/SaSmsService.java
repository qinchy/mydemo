package com.wwwarehouse.xdw.datasync.service;

/**
 * Created by yinsheng.wang on 2017/6/9.
 */
public interface SaSmsService {
    /**
     * 发送短信
     * @param mobile      手机号码
     * @param smsContent  发送内容
     * @param platformId  平台ID
     * @return
     * @throws Exception
     */
    String sendSms(String mobile, String smsContent,Long platformId) throws Exception;
}
