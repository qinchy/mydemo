package com.wwwarehouse.xdw.datasync.model;

/**
 * Created by xuchun on 16/2/23.
 */
public class ShipOrderItemDTO extends BaseObject {
	private String name;
	private int number;
	private double weight;
	private String remark;

	// saiaodi
	private String id;
	private String goodsid; // 商品ID
	// zto
	// sf
	// Order/Cargo

	// EUBShip 货品信息
	private String enname; // 英文名称
	private double itemValue; // 商品单价（两位小数）
	private String unit; // 单位

	//
	// sf
	// Order/Cargo
	// private double amount;//货物单价，精确到小数点后3位，跨境件报关需要填写
	// private String currency;//货物单价的币别
	// private String source_area;//原产地国别，跨境件报关需要填写
	// private String product_record_no;//货物产品国检备案编号
	// private String good_prepard_no;//商品海关备案号
	// Order/AddedService
	// private String value;//增值服务扩展属性
	// private String value1;//增值服务扩展属性
	// OrderConfirm/OrderConfirmOption
	// private String volume;
	// private String return_tracking;
	// private String express_type;
	// private String children_nos;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGoodsid() {
		return goodsid;
	}

	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getEnname() {
		return enname;
	}

	public void setEnname(String enname) {
		this.enname = enname;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public double getItemValue() {
		return itemValue;
	}

	public void setItemValue(double itemValue) {
		this.itemValue = itemValue;
	}

	// public String getMaterial() {
	// return material;
	// }
	//
	// public void setMaterial(String material) {
	// this.material = material;
	// }
	//
	// public String getSize() {
	// return size;
	// }
	//
	// public void setSize(String size) {
	// this.size = size;
	// }
	//
	// public String getUrl() {
	// return url;
	// }
	//
	// public void setUrl(String url) {
	// this.url = url;
	// }

	// public double getAmount() {
	// return amount;
	// }
	//
	// public void setAmount(double amount) {
	// this.amount = amount;
	// }
	//
	// public String getCurrency() {
	// return currency;
	// }
	//
	// public void setCurrency(String currency) {
	// this.currency = currency;
	// }
	//
	// public String getSource_area() {
	// return source_area;
	// }
	//
	// public void setSource_area(String source_area) {
	// this.source_area = source_area;
	// }
	//
	// public String getProduct_record_no() {
	// return product_record_no;
	// }
	//
	// public void setProduct_record_no(String product_record_no) {
	// this.product_record_no = product_record_no;
	// }
	//
	// public String getGood_prepard_no() {
	// return good_prepard_no;
	// }
	//
	// public void setGood_prepard_no(String good_prepard_no) {
	// this.good_prepard_no = good_prepard_no;
	// }
	//
	// public String getValue() {
	// return value;
	// }
	//
	// public void setValue(String value) {
	// this.value = value;
	// }
	//
	// public String getValue1() {
	// return value1;
	// }
	//
	// public void setValue1(String value1) {
	// this.value1 = value1;
	// }
	//
	// public String getVolume() {
	// return volume;
	// }
	//
	// public void setVolume(String volume) {
	// this.volume = volume;
	// }
	//
	// public String getReturn_tracking() {
	// return return_tracking;
	// }
	//
	// public void setReturn_tracking(String return_tracking) {
	// this.return_tracking = return_tracking;
	// }
	//
	// public String getExpress_type() {
	// return express_type;
	// }
	//
	// public void setExpress_type(String express_type) {
	// this.express_type = express_type;
	// }
	//
	// public String getChildren_nos() {
	// return children_nos;
	// }
	//
	// public void setChildren_nos(String children_nos) {
	// this.children_nos = children_nos;
	// }

}