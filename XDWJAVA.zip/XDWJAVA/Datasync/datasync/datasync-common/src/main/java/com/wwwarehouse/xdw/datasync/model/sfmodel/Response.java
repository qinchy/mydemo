package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 10:40 on 2017/6/16.
 * @Modified By:
 */
public class Response {
    /**
     * 请求路由返回
     * */
    @XStreamAlias("Response")
    public class RouteResponse extends ToStringBaseModel{
        @XStreamAsAttribute()
        private String service;

        @XStreamAlias("Head")
        private String head;

        @XStreamAlias("Body")
        private Body.RouteBody body;

        @XStreamAlias("ERROR")
        private String error;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public Body.RouteBody getBody() {
            return body;
        }

        public void setBody(Body.RouteBody body) {
            this.body = body;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }
    }

    /**
     * 下订单返回
     * */
    @XStreamAlias("Response")
    public class OrderResponse extends ToStringBaseModel{
        @XStreamAsAttribute()
        private String service;

        @XStreamAlias("Head")
        private String head;

        @XStreamAlias("Body")
        private Body.OrderBody body;

        @XStreamAlias("ERROR")
        private String error;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public Body.OrderBody getBody() {
            return body;
        }

        public void setBody(Body.OrderBody body) {
            this.body = body;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }
    }

    /**
     * 订单确认返回
     * */
    @XStreamAlias("Response")
    public class ConfirmResponse extends ToStringBaseModel{
        @XStreamAsAttribute()
        private String service;

        @XStreamAlias("Head")
        private String head;

        @XStreamAlias("Body")
        private Body.ConfirmBody body;

        @XStreamAlias("ERROR")
        private String error;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public Body.ConfirmBody getBody() {
            return body;
        }

        public void setBody(Body.ConfirmBody body) {
            this.body = body;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }
    }
}
