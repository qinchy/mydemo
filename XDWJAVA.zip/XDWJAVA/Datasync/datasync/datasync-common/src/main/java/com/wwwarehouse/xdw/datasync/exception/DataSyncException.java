package com.wwwarehouse.xdw.datasync.exception;

import com.wwwarehouse.commons.exception.ServiceException;
import com.wwwarehouse.xdw.datasync.constant.DataSyncResultConstant;

/**
 * Created by shisheng.wang on 17/6/16.
 * biz 异常.
 */
public class DataSyncException extends ServiceException {
    public DataSyncException(DataSyncResultConstant result) {
        this(result.getCode(), result.getMessage());
    }

    public DataSyncException(DataSyncResultConstant result, Throwable cause) {
        this(result.getCode(), result.getMessage(), cause);
    }

    public DataSyncException(DataSyncResultConstant result, Object... params) {
        this(result.getCode(), String.format(result.getMessage(), params));
    }

    public DataSyncException(DataSyncResultConstant result, Throwable cause, Object... params) {
        this(result.getCode(), String.format(result.getMessage(), params), cause);
    }

    public DataSyncException(int code, String message) {
        super(code, message);
    }

    public DataSyncException(int code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
