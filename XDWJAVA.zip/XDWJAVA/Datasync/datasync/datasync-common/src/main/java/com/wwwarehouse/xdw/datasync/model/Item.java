package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.Map;

/**
 * Created by shisheng.wang on 17/6/6.
 */
public class Item implements Serializable {
    private Long itemId;
    private String itemName;
    private Map<String, String> features;

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Map<String, String> getFeatures() {
        return features;
    }

    public void setFeatures(Map<String, String> features) {
        this.features = features;
    }

    @Override
    public String toString() {
        return "[Item(itemId=" + itemId + ", itemName=" + itemName + ")]";
    }
}
