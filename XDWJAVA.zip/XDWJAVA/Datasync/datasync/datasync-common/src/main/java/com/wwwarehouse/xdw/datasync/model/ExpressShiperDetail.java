package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;

/**
 * 收/发货人的详细信息
 *
 * @author haichao.wang
 */
public class ExpressShiperDetail implements Serializable {

    private static final long serialVersionUID = -6827970770236710471L;
    // 收发货人的详细信息
    private String name; // 姓名
    private String company; // 公司
    private String country; // 国家(编码)
    private String province; // 所在省(编码)
    private String provinceStr;//所在省字符串
    private String city; // 所在市(编码)
    private String cityStr;//所在市字符串
    private String county; // 所在县
    private String conuntyStr;//所在县字符串
    private String street; // 所在街道
    private String address; // 地址
    private String postcode; // 人邮编
    private String phone; // 电话
    private String mobile; // 手机
    private String email; // 人电子邮箱

    public String getProvinceStr() {
        return provinceStr;
    }

    public void setProvinceStr(String provinceStr) {
        this.provinceStr = provinceStr;
    }

    public String getCityStr() {
        return cityStr;
    }

    public void setCityStr(String cityStr) {
        this.cityStr = cityStr;
    }

    public String getConuntyStr() {
        return conuntyStr;
    }

    public void setConuntyStr(String conuntyStr) {
        this.conuntyStr = conuntyStr;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
