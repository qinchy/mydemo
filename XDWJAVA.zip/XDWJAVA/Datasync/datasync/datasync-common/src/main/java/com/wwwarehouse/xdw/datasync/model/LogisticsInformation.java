package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.List;

public class LogisticsInformation implements Serializable {

	private static final long serialVersionUID = 2488256184743050862L;
	// 起始国家
	private String startCountry;
	// 目的地国家
	private String targetCountry;
	// 快递的起始地址（地级市）
	private String startAddress;
	// 快递的目的地（地级市）
	private String targetAddress;
	// 快递公司名称
	private String expressCompany;
	// 快递单号
	private String outSid;
	// 运单目前所处状态码（ExpressStatus中定义了，暂定四个状态：待揽收，运输，派送，签收）
	private Long status;
	// 运单目前所处的状态描述
	private String statusDesc;
	// 物流详情
	private List<LogisticsInfomationDetail> infomationDetails;

	public String getStartCountry() {
		return startCountry;
	}

	public void setStartCountry(String startCountry) {
		this.startCountry = startCountry;
	}

	public String getTargetCountry() {
		return targetCountry;
	}

	public void setTargetCountry(String targetCountry) {
		this.targetCountry = targetCountry;
	}

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public String getTargetAddress() {
		return targetAddress;
	}

	public void setTargetAddress(String targetAddress) {
		this.targetAddress = targetAddress;
	}

	public String getExpressCompany() {
		return expressCompany;
	}

	public void setExpressCompany(String expressCompany) {
		this.expressCompany = expressCompany;
	}

	public String getOutSid() {
		return outSid;
	}

	public void setOutSid(String outSid) {
		this.outSid = outSid;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public List<LogisticsInfomationDetail> getInfomationDetails() {
		return infomationDetails;
	}

	public void setInfomationDetails(List<LogisticsInfomationDetail> infomationDetails) {
		this.infomationDetails = infomationDetails;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@Override
	public String toString() {
		return "LogisticsInformation [expressCompany=" + expressCompany + ", status=" + status + ", statusDesc="
				+ statusDesc + ", LogisticsInfomationDetail=" + (infomationDetails == null ? 0 : infomationDetails.size()) + "]";
	}

}
