package com.wwwarehouse.xdw.datasync.service;


import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;


/**
 * Created by chengwei on 2017/6/9 13:51.
 */
public interface PayService {

	/**
	 * 推送订单信息
	 *
	 * @param payParamsDTO
	 * @return
	 */
	AbsResponse<Object> mobilePay(PayParamsDTO payParamsDTO) throws Exception;

	/**
	 * 阿里异步通知支付结果
	 *
	 * @param request
	 */
	String aliAnalyzeData(String request) throws Exception;


	/**
	 * 银联异步通知支付结果
	 *
	 * @param request
	 * @return
	 */
	String UnionAnalyzeData(String request) throws Exception;

	/**
	 * 微信异步通知支付结果
	 * @param request
	 */
	String wechatAnalyzeData(String request) throws Exception;
}
