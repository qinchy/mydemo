package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.util.Date;

public class LogisticsInfomationDetail implements Serializable {

	private static final long serialVersionUID = 6363950967309688510L;
	// 快递条目跟踪地址
	private String address;
	// 快递信息条目发生时间
	private Date operatingTime;
	// 当前快递条目所属状态
	private Long status;
	// 当前快递条目的描述信息
	private String description;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getOperatingTime() {
		return operatingTime;
	}

	public void setOperatingTime(Date operatingTime) {
		this.operatingTime = operatingTime;
	}

}
