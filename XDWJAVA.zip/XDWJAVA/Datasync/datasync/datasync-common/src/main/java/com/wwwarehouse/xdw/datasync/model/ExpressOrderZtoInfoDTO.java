package com.wwwarehouse.xdw.datasync.model;

import javax.print.DocFlavor;
import java.util.Date;

/**
 * Created by wenquan.wu on 2017/6/15.
 */
public class ExpressOrderZtoInfoDTO extends ExpressOrderInfoDTO {
    private static final long serialVersionUID = -2763898102926720695L;
    private String partner; //商家ID(正式环境由中通合作网点提供，测试环境使用test)
    private String id;  //订单号由合作商平台产生，具有平台唯一性。
    private String typeId; //订单类型id,默认为1 如果不传或者传空自动为1
    private String orderType; //订单类型：0标准；1代收；2到付,默认为1
    private String remark; //订单备注
    private Boolean isUpdate; //是否更新
    private String siteCode; //网点编码
    private String siteName; //网点名称
    private String message; //提示信息

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public Boolean getUpdate() {
        return isUpdate;
    }

    public void setUpdate(Boolean update) {
        isUpdate = update;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTypeId() {

        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getPartner() {

        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

//    private String productCode; // 产品代码
//    private String cargoCode; // 货物类型
//    private String remark; // 备注
//    private String siteCode;
//    private String mailNo;
//    private String siteName;
//    private String orderId;
//    private Long transporterId; //运输商编码
//    private Long transporterUnitId; // 运输商位编码 暂时不知道怎么传入 先定死
//    private Long expressServiceUkid; //服务产品 暂时不知道怎么传入 先定死
//    private Integer isCod;   //是否货到付款

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ExpressOrderZtoInfoDTO(String orderId, String expressId, Long expressCode,
                                 ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size,
                                 int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
        super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment,
                createDate, isInsured, insuredValue);
    }

    public ExpressOrderZtoInfoDTO(){
    }
}
