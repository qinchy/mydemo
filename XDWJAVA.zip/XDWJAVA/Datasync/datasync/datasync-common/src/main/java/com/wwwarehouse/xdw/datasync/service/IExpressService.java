package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressUploadWeightInfo;
import com.wwwarehouse.xdw.datasync.model.LogisticsInformation;

import java.util.List;

/**
 * 快递接口
 * 
 * @author haichao.wang
 *
 */
public interface IExpressService {
	/**
	 * 跟踪快递单的物流信息
	 * 
	 * @param outSid
	 *            快递单号
	 * @param expressCode
	 *            快递公司编码
	 * @return 物流详情
	 * @throws Exception
	 */
	public AbsResponse<LogisticsInformation> trackLogisticsInfo(String outSid, Long expressCode) throws Exception;

	/**
	 * 对接生成快递单
	 * 
	 * @param expressOrderInfo
	 *            快递面单的详细信息
	 * @return 带有快递单号的详细信息
	 * @throws Exception
	 */
	public AbsResponse<ExpressOrderInfoDTO> generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception;

	/**
	 * 对接批量生成快递单
	 * 
	 * @param expressOrderInfoDTOs
	 *            快递面单的详细信息
	 * @return 带有快递单号的详细信息
	 * @throws Exception
	 */
	public <T extends ExpressOrderInfoDTO> AbsResponse<List<T>> generateExpressInfos(List<T> expressOrderInfoDTOs)
			throws Exception;

	/**
	 * 上传包裹重量列表
	 * 
	 * @param weightInfos
	 * @return
	 * @throws Exception
	 */
	public AbsResponse<String> uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception;

	/**
	 * 取消快递单
	 * 
	 * @param orderId
	 *            平台订单号
	 * @param outSid
	 *            快递单号
	 * @param expressCode
	 *            快递公司编码
	 * @return
	 * @throws Exception
	 */
	public AbsResponse<String> cancelExpressOrder(String orderId, String outSid, Long expressCode) throws Exception;

}
