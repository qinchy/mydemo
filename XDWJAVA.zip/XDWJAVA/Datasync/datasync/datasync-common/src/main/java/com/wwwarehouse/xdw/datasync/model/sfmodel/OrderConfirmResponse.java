package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 10:12 on 2017/6/18.
 * @Modified By:
 */
@XStreamAlias("OrderConfirmResponse")
public class OrderConfirmResponse extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String orderid;

    @XStreamAsAttribute()
    private String mailno;

    @XStreamAsAttribute()
    private String resStatus;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getMailno() {
        return mailno;
    }

    public void setMailno(String mailno) {
        this.mailno = mailno;
    }

    public String getResStatus() {
        return resStatus;
    }

    public void setResStatus(String resStatus) {
        this.resStatus = resStatus;
    }
}
