package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 10:51 on 2017/6/16.
 * @Modified By:
 */
@XStreamAlias("Request")
public class Request extends ToStringBaseModel{

    @XStreamAsAttribute()
    private String service;

    @XStreamAsAttribute()
    private String lang = "zh-CN";

    @XStreamAlias("Head")
    private String head;

    @XStreamAlias("Body")
    private Body body;

    public Request(){};

    public Request(String service, String head, Body body) {
        this.service = service;
        this.head = head;
        this.body = body;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public Body getBody() {
        return body;
    }

    public void setBody(Body body) {
        this.body = body;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }
}
