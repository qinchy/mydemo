package com.wwwarehouse.xdw.datasync.model;


import java.math.BigDecimal;
import java.util.Date;

/**
 * 平台子订单的基础类
 * @author 
 *
 */
public class SeBaseItem extends BaseObject {
	private Long itemUkid;
	private Long tradeUkid;
	private Long originOrderStatus;
	private Date downTime;
	private Date updateTime;
	private Long shopProductUkid;
	private Long productCodeUkid;
	private String productCode;
	private Date presaleDate;
	private Long qty;
    private BigDecimal price;
    private BigDecimal discountFee;
    private BigDecimal totalFee;
    private BigDecimal payment;
	private String workspaceId;
	
    private String subOrderStatus;
    private Long subOrderId;
	private String productName;
	private String skuName;
	private Long productNumId;
	private String productOuterId;
	private String skuNumId;
	private String skuOuterId;
	
	public Long getItemUkid() {
		return itemUkid;
	}
	public void setItemUkid(Long itemUkid) {
		this.itemUkid = itemUkid;
	}
	public Long getTradeUkid() {
		return tradeUkid;
	}
	public void setTradeUkid(Long tradeUkid) {
		this.tradeUkid = tradeUkid;
	}
	public Long getOriginOrderStatus() {
		return originOrderStatus;
	}
	public void setOriginOrderStatus(Long originOrderStatus) {
		this.originOrderStatus = originOrderStatus;
	}
	public Date getDownTime() {
		return downTime;
	}
	public void setDownTime(Date downTime) {
		this.downTime = downTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Long getShopProductUkid() {
		return shopProductUkid;
	}
	public void setShopProductUkid(Long shopProductUkid) {
		this.shopProductUkid = shopProductUkid;
	}
	public Long getProductCodeUkid() {
		return productCodeUkid;
	}
	public void setProductCodeUkid(Long productCodeUkid) {
		this.productCodeUkid = productCodeUkid;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Date getPresaleDate() {
		return presaleDate;
	}
	public void setPresaleDate(Date presaleDate) {
		this.presaleDate = presaleDate;
	}
	public Long getQty() {
		return qty;
	}
	public void setQty(Long qty) {
		this.qty = qty;
	}
	public String getWorkspaceId() {
		return workspaceId;
	}
	public void setWorkspaceId(String workspaceId) {
		this.workspaceId = workspaceId;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public BigDecimal getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}
	public BigDecimal getPayment() {
		return payment;
	}
	public void setPayment(BigDecimal payment) {
		this.payment = payment;
	}
	public BigDecimal getDiscountFee() {
		return discountFee;
	}
	public void setDiscountFee(BigDecimal discountFee) {
		this.discountFee = discountFee;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public Long getProductNumId() {
		return productNumId;
	}
	public void setProductNumId(Long productNumId) {
		this.productNumId = productNumId;
	}
	public String getProductOuterId() {
		return productOuterId;
	}
	public void setProductOuterId(String productOuterId) {
		this.productOuterId = productOuterId;
	}
	public String getSkuNumId() {
		return skuNumId;
	}
	public void setSkuNumId(String skuNumId) {
		this.skuNumId = skuNumId;
	}
	public String getSkuOuterId() {
		return skuOuterId;
	}
	public void setSkuOuterId(String skuOuterId) {
		this.skuOuterId = skuOuterId;
	}
	public Long getSubOrderId() {
		return subOrderId;
	}
	public void setSubOrderId(Long subOrderId) {
		this.subOrderId = subOrderId;
	}
	public String getSubOrderStatus() {
		return subOrderStatus;
	}
	public void setSubOrderStatus(String subOrderStatus) {
		this.subOrderStatus = subOrderStatus;
	}

}