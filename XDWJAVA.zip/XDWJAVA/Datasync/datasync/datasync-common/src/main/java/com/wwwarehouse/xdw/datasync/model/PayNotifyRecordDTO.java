package com.wwwarehouse.xdw.datasync.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by chengwei on 2017/6/12 15:57.
 */
public class PayNotifyRecordDTO implements Serializable {
	private Long payRecordUkid;

	private String outTradeNo;

	private Short platformId;

	private String resultCode;

	private String returnMsg;

	private String transactionId;

	private BigDecimal totalFee;

	private Date timeEnd;

	private String buyerId;

	private String attach;

	private String notifyMsg;

	private Short pushStatus;

	private Date createTime;

	private Long createUserId;

	private Date updateTime;

	private Long updateUserId;

	private static final long serialVersionUID = 1L;

	public Long getPayRecordUkid() {
		return payRecordUkid;
	}

	public void setPayRecordUkid(Long payRecordUkid) {
		this.payRecordUkid = payRecordUkid;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public Short getPlatformId() {
		return platformId;
	}

	public void setPlatformId(Short platformId) {
		this.platformId = platformId;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public BigDecimal getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(BigDecimal totalFee) {
		this.totalFee = totalFee;
	}

	public Date getTimeEnd() {
		return timeEnd;
	}

	public void setTimeEnd(Date timeEnd) {
		this.timeEnd = timeEnd;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

	public String getNotifyMsg() {
		return notifyMsg;
	}

	public void setNotifyMsg(String notifyMsg) {
		this.notifyMsg = notifyMsg;
	}

	public Short getPushStatus() {
		return pushStatus;
	}

	public void setPushStatus(Short pushStatus) {
		this.pushStatus = pushStatus;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(Long updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(", payRecordUkid=").append(payRecordUkid);
		sb.append(", outTradeNo=").append(outTradeNo);
		sb.append(", platformId=").append(platformId);
		sb.append(", resultCode=").append(resultCode);
		sb.append(", returnMsg=").append(returnMsg);
		sb.append(", transactionId=").append(transactionId);
		sb.append(", totalFee=").append(totalFee);
		sb.append(", timeEnd=").append(timeEnd);
		sb.append(", buyerId=").append(buyerId);
		sb.append(", attach=").append(attach);
		sb.append(", notifyMsg=").append(notifyMsg);
		sb.append(", pushStatus=").append(pushStatus);
		sb.append(", createTime=").append(createTime);
		sb.append(", createUserId=").append(createUserId);
		sb.append(", updateTime=").append(updateTime);
		sb.append(", updateUserId=").append(updateUserId);
		sb.append("]");
		return sb.toString();
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		PayNotifyRecordDTO other = (PayNotifyRecordDTO) that;
		return (this.getPayRecordUkid() == null ? other.getPayRecordUkid() == null : this.getPayRecordUkid().equals(other.getPayRecordUkid()))
				&& (this.getOutTradeNo() == null ? other.getOutTradeNo() == null : this.getOutTradeNo().equals(other.getOutTradeNo()))
				&& (this.getPlatformId() == null ? other.getPlatformId() == null : this.getPlatformId().equals(other.getPlatformId()))
				&& (this.getResultCode() == null ? other.getResultCode() == null : this.getResultCode().equals(other.getResultCode()))
				&& (this.getReturnMsg() == null ? other.getReturnMsg() == null : this.getReturnMsg().equals(other.getReturnMsg()))
				&& (this.getTransactionId() == null ? other.getTransactionId() == null : this.getTransactionId().equals(other.getTransactionId()))
				&& (this.getTotalFee() == null ? other.getTotalFee() == null : this.getTotalFee().equals(other.getTotalFee()))
				&& (this.getTimeEnd() == null ? other.getTimeEnd() == null : this.getTimeEnd().equals(other.getTimeEnd()))
				&& (this.getBuyerId() == null ? other.getBuyerId() == null : this.getBuyerId().equals(other.getBuyerId()))
				&& (this.getAttach() == null ? other.getAttach() == null : this.getAttach().equals(other.getAttach()))
				&& (this.getNotifyMsg() == null ? other.getNotifyMsg() == null : this.getNotifyMsg().equals(other.getNotifyMsg()))
				&& (this.getPushStatus() == null ? other.getPushStatus() == null : this.getPushStatus().equals(other.getPushStatus()))
				&& (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
				&& (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
				&& (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
				&& (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getPayRecordUkid() == null) ? 0 : getPayRecordUkid().hashCode());
		result = prime * result + ((getOutTradeNo() == null) ? 0 : getOutTradeNo().hashCode());
		result = prime * result + ((getPlatformId() == null) ? 0 : getPlatformId().hashCode());
		result = prime * result + ((getResultCode() == null) ? 0 : getResultCode().hashCode());
		result = prime * result + ((getReturnMsg() == null) ? 0 : getReturnMsg().hashCode());
		result = prime * result + ((getTransactionId() == null) ? 0 : getTransactionId().hashCode());
		result = prime * result + ((getTotalFee() == null) ? 0 : getTotalFee().hashCode());
		result = prime * result + ((getTimeEnd() == null) ? 0 : getTimeEnd().hashCode());
		result = prime * result + ((getBuyerId() == null) ? 0 : getBuyerId().hashCode());
		result = prime * result + ((getAttach() == null) ? 0 : getAttach().hashCode());
		result = prime * result + ((getNotifyMsg() == null) ? 0 : getNotifyMsg().hashCode());
		result = prime * result + ((getPushStatus() == null) ? 0 : getPushStatus().hashCode());
		result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
		result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
		result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
		result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
		return result;
	}
}
