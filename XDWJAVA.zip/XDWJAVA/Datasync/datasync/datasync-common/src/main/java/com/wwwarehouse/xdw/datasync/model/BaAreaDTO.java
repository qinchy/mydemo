package com.wwwarehouse.xdw.datasync.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.List;

/**
 * Created by jingchun.zhang on 2017/6/16.
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class BaAreaDTO extends BaseObject{
    //id
    private String  areaId;
    //名称
    private String areaName;
    //英文名称
    private String areaNameEn;
    //类型：省、市、区……
    private Long areaType;
    //上一级区域id
    private String parentAreaId;
    //下一级行政区域列表
    private List nextLevelAreaList;

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAreaNameEn() {
        return areaNameEn;
    }

    public void setAreaNameEn(String areaNameEn) {
        this.areaNameEn = areaNameEn;
    }

    public Long getAreaType() {
        return areaType;
    }

    public void setAreaType(Long areaType) {
        this.areaType = areaType;
    }

    public String getParentAreaId() {
        return parentAreaId;
    }

    public void setParentAreaId(String parentAreaId) {
        this.parentAreaId = parentAreaId;
    }

    public List getNextLevelAreaList() {
        return nextLevelAreaList;
    }

    public void setNextLevelAreaList(List nextLevelAreaList) {
        this.nextLevelAreaList = nextLevelAreaList;
    }

    @Override
    public String toString() {
        return "BaAreaDTO{" +
                "areaId='" + areaId + '\'' +
                ", areaName='" + areaName + '\'' +
                ", areaNameEn='" + areaNameEn + '\'' +
                ", areaType=" + areaType +
                ", parentAreaId='" + parentAreaId + '\'' +
                ", nextLevelAreaList=" + nextLevelAreaList +
                '}';
    }
}
