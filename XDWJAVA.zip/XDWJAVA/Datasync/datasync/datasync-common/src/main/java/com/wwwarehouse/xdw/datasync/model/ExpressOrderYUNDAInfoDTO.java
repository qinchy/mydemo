package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;
import java.util.List;

/**
 * Created by yejunjun on 2017/6/15.
 */
public class ExpressOrderYUNDAInfoDTO extends ExpressOrderInfoDTO {

	private List<ShipOrderItemDTO> shipOrderItemDTO;

	public List<ShipOrderItemDTO> getShipOrderItemDTO() {
		return shipOrderItemDTO;
	}

	public void setShipOrderItemDTO(List<ShipOrderItemDTO> shipOrderItemDTO) {
		this.shipOrderItemDTO = shipOrderItemDTO;
	}

	public ExpressOrderYUNDAInfoDTO(String orderId, String expressId, Long expressCode, ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size, int packNo, float payment, Date createDate, boolean isInsured, double insuredValue) {
		super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment, createDate, isInsured, insuredValue);
	}

	public ExpressOrderYUNDAInfoDTO(String orderId, String expressId, Long expressCode, ExpressShiperDetail sendShiperDetail, ExpressShiperDetail receiverShiperDetail, double weight, String size, int packNo, float payment, Date createDate, boolean isInsured, double insuredValue, List<ShipOrderItemDTO> shipOrderItemDTO) {
		super(orderId, expressId, expressCode, sendShiperDetail, receiverShiperDetail, weight, size, packNo, payment, createDate, isInsured, insuredValue);
		this.shipOrderItemDTO = shipOrderItemDTO;
	}

	public ExpressOrderYUNDAInfoDTO() {

	}


}
