package com.wwwarehouse.xdw.datasync.model;

/**
 * Created by zhigang.huang on 2017/6/7.
 */

import java.util.Date;


public class AmRequestLogDTO {

    private Long logUkid;

    private Long relatedBuId;
    private String requestIp;
    private String methodName;
    private String paramString;
    private String headerParams;
    private String responseContent;
    private Date requestDate;
    private Date responseDate;
    private String doResult;

    private Long timeRange;

    private Long pageNum;
    private String orderStatus;
    private Date startDate;
    private Date endDate;

    private Long needDown;
    private Long sn;



    public AmRequestLogDTO(){

    }

    public AmRequestLogDTO(Long relatedBuId, Date requestDate, Date responseDate,
                        String paramString, String responseContent, String methodName, String requestIp) {
        this(relatedBuId, null, null, null, requestDate, responseDate,
                paramString, responseContent, null, methodName, requestIp, null);
    }

    public AmRequestLogDTO(Long relatedBuId, Date startDate, Date endDate,
                        String orderStatus, Date requestDate, Date responseDate,
                        String paramString, String responseContent, Long pageNum,
                        String methodName, String requestIp, String headerParams) {
        this.relatedBuId = relatedBuId;
        this.paramString = paramString;
        this.responseContent = responseContent;
        this.requestDate = requestDate;
        this.responseDate = responseDate;
        this.methodName = methodName;
        this.requestIp = requestIp;
        this.headerParams = headerParams;
        if (requestDate == null || responseDate == null) {
            this.timeRange = -1L;
        } else {
            this.timeRange = responseDate.getTime() - requestDate.getTime();
        }

        this.pageNum = pageNum;
        this.startDate = startDate;
        this.endDate = endDate;
        this.orderStatus = orderStatus;
    }


    public Long getLogUkid() {
        return logUkid;
    }

    public void setLogUkid(Long logUkid) {
        this.logUkid = logUkid;
    }

    public Long getRelatedBuId() {
        return relatedBuId;
    }

    public void setRelatedBuId(Long relatedBuId) {
        this.relatedBuId = relatedBuId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus == null ? null : orderStatus.trim();
    }

    public String getParamString() {
        return paramString;
    }

    public void setParamString(String paramString) {
        this.paramString = paramString == null ? null : paramString.trim();
    }

    public String getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent == null ? null : responseContent.trim();
    }

    public Long getPageNum() {
        return pageNum;
    }

    public void setPageNum(Long pageNum) {
        this.pageNum = pageNum;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public Long getTimeRange() {
        return timeRange;
    }

    public void setTimeRange(Long timeRange) {
        this.timeRange = timeRange;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName == null ? null : methodName.trim();
    }

    public Long getNeedDown() {
        return needDown;
    }

    public void setNeedDown(Long needDown) {
        this.needDown = needDown;
    }

    public Long getSn() {
        return sn;
    }

    public void setSn(Long sn) {
        this.sn = sn;
    }


    public String getRequestIp() {
        return requestIp;
    }


    public void setRequestIp(String requestIp) {
        this.requestIp = requestIp;
    }

    public String getHeaderParams() {
        return headerParams;
    }

    public void setHeaderParams(String headerParams) {
        this.headerParams = headerParams;
    }

    public String getDoResult() {
        return doResult;
    }

    public void setDoResult(String doResult) {
        this.doResult = doResult;
    }
}
