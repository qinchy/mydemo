package com.wwwarehouse.xdw.datasync.model.sfmodel;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * @Author: SunKuo
 * @Description: 使用反射机制是重写toString方法
 * @Date: Created in 9:37 on 2017/6/18.
 * @Modified By:
 */
public class ToStringBaseModel {

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
