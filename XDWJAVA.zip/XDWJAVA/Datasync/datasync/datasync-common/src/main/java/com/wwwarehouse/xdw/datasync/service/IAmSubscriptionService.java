package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/19 0019.
 */
public interface IAmSubscriptionService {
    public AmAppSubscriptionDTO get(Long subscriptionUkid);
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long suberBuId, String appType);

    public AmAppSubscriptionDTO getSubscription(Long platformId, Long appOwnerId, Long suberBuId,
                                                String appType);

    /**
     * 封闭订购对象：设置amAppkey与platformId
     * setApp();
     * setPlatformId();
     *
     *
     * @param subscription
     * @param app
     * @return
     */
    public AmAppSubscriptionDTO packageAppSub(AmAppSubscriptionDTO subscription, AmAppkeyDTO app);

    /**
     * 根据appUkid获取list
     *
     * @param appUkid
     * @return
     */
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, Long suberBuId, Long status);

    public List<AmAppSubscriptionDTO> getsByBuid(Long suberBuId, Long status);

    public int insertSubscription(AmAppSubscriptionDTO subscription);

    public List<AmAppSubscriptionDTO> getsNeedRefresh();

    public int updateAuthBuId(AmAppSubscriptionDTO subscription);

    public int updateSubscription(AmAppSubscriptionDTO subscription);

    public int update(AmAppSubscriptionDTO subscription);

    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, int shardingCount, int shardingItem);
}
