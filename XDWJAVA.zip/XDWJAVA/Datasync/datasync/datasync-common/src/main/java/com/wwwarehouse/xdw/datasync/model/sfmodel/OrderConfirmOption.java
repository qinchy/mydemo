package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 9:34 on 2017/6/18.
 * @Modified By:
 */
@XStreamAlias("OrderConfirmOption")
public class OrderConfirmOption extends ToStringBaseModel{

    @XStreamAsAttribute()
    private String weight;

    @XStreamAsAttribute()
    private String volume;

    public OrderConfirmOption(String weight) {
        this.weight = weight;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }
}
