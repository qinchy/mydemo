package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;

import java.util.List;

/**
 * Created by jingchun.zhang on 2017/6/16.
 */
public interface BaAreaService {

    /**
     * 获取地区库信息
     * @return
     * @throws Exception
     */
    List<BaAreaDTO> listAllBaAreas() throws Exception;

    /**
     * 获取对应地区及其下一级别地区数据
     * @param areaId
     * @param areaName
     * @return
     * @throws Exception
     */
    AbsResponse<BaAreaDTO> getBaArea(String areaId, String areaName) throws Exception;
}
