package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 12:40 on 2017/6/18.
 * @Modified By:
 */
@XStreamAlias("OrderResponse")
public class OrderResponse extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String orderid;

    @XStreamAsAttribute()
    private String mailno;

    @XStreamAsAttribute()
    private String origincode;

    @XStreamAsAttribute()
    private String destcode;

    @XStreamAsAttribute()
    private String filterResult;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getMailno() {
        return mailno;
    }

    public void setMailno(String mailno) {
        this.mailno = mailno;
    }

    public String getOrigincode() {
        return origincode;
    }

    public void setOrigincode(String origincode) {
        this.origincode = origincode;
    }

    public String getDestcode() {
        return destcode;
    }

    public void setDestcode(String destcode) {
        this.destcode = destcode;
    }

    public String getFilterResult() {
        return filterResult;
    }

    public void setFilterResult(String filterResult) {
        this.filterResult = filterResult;
    }
}
