package com.wwwarehouse.xdw.datasync.model.sfmodel;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @Author: SunKuo
 * @Description:
 * @Date: Created in 11:12 on 2017/6/16.
 * @Modified By:
 */
@XStreamAlias("OrderSearch")
public class OrderSearch extends ToStringBaseModel{
    @XStreamAsAttribute()
    private String orderid;

    public OrderSearch(){

    }

    public OrderSearch(String orderid) {
        this.orderid = orderid;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

}
