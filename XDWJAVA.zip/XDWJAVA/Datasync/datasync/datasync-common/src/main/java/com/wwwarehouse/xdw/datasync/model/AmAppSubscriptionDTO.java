package com.wwwarehouse.xdw.datasync.model;

import java.util.Date;

/**
 * AppSubscription entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class AmAppSubscriptionDTO extends BaseObject {

	// Fields

	private Long subscriptionUkid;
	private Long appUkid;
	private Long subscriptionBuId;
	private Date subscriptionDate;
	private String platformUserId;
	private String platformUserNick;
	private String targetAppKey;
	private String accessToken;
	private String refreshToken;
	private Date lastAuthTime;
	private Long expiresIn;
	private Long reExpiresIn;
	private Long r1ExpiresIn;
	private Long r2ExpiresIn;
	private Long w1ExpiresIn;
	private Long w2ExpiresIn;
	private String publicKey;
	private String privateKey;
	private String publicKeyOut;
	private String dataEncryptType;
	private String dataEncryptKey;
	private String dataEncryptPwd;
	private Long status;

	private Long platformId;


	private AmAppkeyDTO app;

	public AmAppkeyDTO getApp() {
		return app;
	}

	public void setApp(AmAppkeyDTO app) {
		this.app = app;
	}
	// Constructors

	/** default constructor */
	public AmAppSubscriptionDTO() {
	}

	/** minimal constructor */
	public AmAppSubscriptionDTO(Long subscriptionUkid) {
		this.subscriptionUkid = subscriptionUkid;
	}

	/** full constructor */
	public AmAppSubscriptionDTO(Long subscriptionUkid, Long appUkid,
	                            Long subscriptionBuId, Date subscriptionDate,
	                            String platformUserId, String platformUserNick,
	                            String targetAppKey, String accessToken, String refreshToken,
	                            Date LastAuthTime, Long expiresIn, Long reExpiresIn, Long r1ExpiresIn,
	                            Long r2ExpiresIn, Long w1ExpiresIn, Long w2ExpiresIn,
	                            String publicKey, String privateKey, String publicKeyOut,
	                            String dataEncryptType, String dataEncryptKey, String dataEncryptPwd) {
		this.subscriptionUkid = subscriptionUkid;
		this.appUkid = appUkid;
		this.subscriptionBuId = subscriptionBuId;
		this.subscriptionDate = subscriptionDate;
		this.platformUserId = platformUserId;
		this.platformUserNick = platformUserNick;
		this.targetAppKey = targetAppKey;
		this.accessToken = accessToken;
		this.refreshToken = refreshToken;
		this.lastAuthTime = LastAuthTime;
		this.expiresIn = expiresIn;
		this.reExpiresIn = reExpiresIn;
		this.r1ExpiresIn = r1ExpiresIn;
		this.r2ExpiresIn = r2ExpiresIn;
		this.w1ExpiresIn = w1ExpiresIn;
		this.w2ExpiresIn = w2ExpiresIn;
		this.publicKey = publicKey;
		this.privateKey = privateKey;
		this.publicKeyOut = publicKeyOut;
		this.dataEncryptType = dataEncryptType;
		this.dataEncryptKey = dataEncryptKey;
		this.dataEncryptPwd = dataEncryptPwd;
	}

	// Property accessors

	public Long getSubscriptionUkid() {
		return this.subscriptionUkid;
	}

	public void setSubscriptionUkid(Long subscriptionUkid) {
		this.subscriptionUkid = subscriptionUkid;
	}

	public Long getAppUkid() {
		return this.appUkid;
	}

	public void setAppUkid(Long appUkid) {
		this.appUkid = appUkid;
	}

	public Long getSubscriptionBuId() {
		return this.subscriptionBuId;
	}

	public void setSubscriptionBuId(Long subscriptionBuId) {
		this.subscriptionBuId = subscriptionBuId;
	}

	public Date getSubscriptionDate() {
		return this.subscriptionDate;
	}

	public void setSubscriptionDate(Date subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	public String getPlatformUserId() {
		return this.platformUserId;
	}

	public void setPlatformUserId(String platformUserId) {
		this.platformUserId = platformUserId;
	}

	public String getPlatformUserNick() {
		return this.platformUserNick;
	}

	public void setPlatformUserNick(String platformUserNick) {
		this.platformUserNick = platformUserNick;
	}

	public String getTargetAppKey() {
		return this.targetAppKey;
	}

	public void setTargetAppKey(String targetAppKey) {
		this.targetAppKey = targetAppKey;
	}

	public String getAccessToken() {
		return this.accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return this.refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public Date getLastAuthTime() {
		return this.lastAuthTime;
	}

	public void setLastAuthTime(Date lastAuthTime) {
		this.lastAuthTime = lastAuthTime;
	}

	public Long getExpiresIn() {
		return this.expiresIn;
	}

	public void setExpiresIn(Long expiresIn) {
		this.expiresIn = expiresIn;
	}

	public Long getReExpiresIn() {
		return this.reExpiresIn;
	}

	public void setReExpiresIn(Long reExpiresIn) {
		this.reExpiresIn = reExpiresIn;
	}

	public Long getR1ExpiresIn() {
		return this.r1ExpiresIn;
	}

	public void setR1ExpiresIn(Long r1ExpiresIn) {
		this.r1ExpiresIn = r1ExpiresIn;
	}

	public Long getR2ExpiresIn() {
		return this.r2ExpiresIn;
	}

	public void setR2ExpiresIn(Long r2ExpiresIn) {
		this.r2ExpiresIn = r2ExpiresIn;
	}

	public Long getW1ExpiresIn() {
		return this.w1ExpiresIn;
	}

	public void setW1ExpiresIn(Long w1ExpiresIn) {
		this.w1ExpiresIn = w1ExpiresIn;
	}

	public Long getW2ExpiresIn() {
		return this.w2ExpiresIn;
	}

	public void setW2ExpiresIn(Long w2ExpiresIn) {
		this.w2ExpiresIn = w2ExpiresIn;
	}

	public String getPublicKey() {
		return this.publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getPrivateKey() {
		return this.privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKeyOut() {
		return this.publicKeyOut;
	}

	public void setPublicKeyOut(String publicKeyOut) {
		this.publicKeyOut = publicKeyOut;
	}

	public String getDataEncryptType() {
		return this.dataEncryptType;
	}

	public void setDataEncryptType(String dataEncryptType) {
		this.dataEncryptType = dataEncryptType;
	}

	public String getDataEncryptKey() {
		return this.dataEncryptKey;
	}

	public void setDataEncryptKey(String dataEncryptKey) {
		this.dataEncryptKey = dataEncryptKey;
	}

	public String getDataEncryptPwd() {
		return this.dataEncryptPwd;
	}

	public void setDataEncryptPwd(String dataEncryptPwd) {
		this.dataEncryptPwd = dataEncryptPwd;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public Long getPlatformId() {
		return platformId;
	}

	public void setPlatformId(Long platformId) {
		this.platformId = platformId;
	}

}