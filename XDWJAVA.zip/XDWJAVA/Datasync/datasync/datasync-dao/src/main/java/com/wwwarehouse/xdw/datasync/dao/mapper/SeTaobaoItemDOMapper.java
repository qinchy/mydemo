package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDOExample;
import java.util.List;

import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import org.apache.ibatis.annotations.Param;

public interface SeTaobaoItemDOMapper {
    long countByExample(SeTaobaoItemDOExample example);

    int deleteByExample(SeTaobaoItemDOExample example);

    int deleteByPrimaryKey(Long itemUkid);

    int insert(SeTaobaoItemDO record);

    int insertSelective(SeTaobaoItemDO record);

    List<SeTaobaoItemDO> selectByExample(SeTaobaoItemDOExample example);

    SeTaobaoItemDO selectByPrimaryKey(Long itemUkid);

    int updateByExampleSelective(@Param("record") SeTaobaoItemDO record, @Param("example") SeTaobaoItemDOExample example);

    int updateByExample(@Param("record") SeTaobaoItemDO record, @Param("example") SeTaobaoItemDOExample example);

    int updateByPrimaryKeySelective(SeTaobaoItemDO record);

    int updateByPrimaryKey(SeTaobaoItemDO record);

    List<SeTaobaoItemDO> getsByTradeUkid(Long tradeUkid);

    int updateOriginStatus(SeTaobaoItemDO oItem);

    List<Long> getsItemByProduct(@Param("productNumId") String productNumId, @Param("skuNumId")String skuNumId, @Param("shopId") Long shopId);

}