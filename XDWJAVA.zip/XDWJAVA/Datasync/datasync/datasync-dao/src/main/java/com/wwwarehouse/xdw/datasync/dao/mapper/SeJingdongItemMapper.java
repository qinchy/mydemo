package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeJingdongItemMapper {
    long countByExample(SeJingdongItemExample example);

    int deleteByExample(SeJingdongItemExample example);

    int deleteByPrimaryKey(Long itemUkid);

    int insert(SeJingdongItemDO record);

    int insertSelective(SeJingdongItemDO record);

    List<SeJingdongItemDO> selectByExample(SeJingdongItemExample example);

    SeJingdongItemDO selectByPrimaryKey(Long itemUkid);

    int updateByExampleSelective(@Param("record") SeJingdongItemDO record, @Param("example") SeJingdongItemExample example);

    int updateByExample(@Param("record") SeJingdongItemDO record, @Param("example") SeJingdongItemExample example);

    int updateByPrimaryKeySelective(SeJingdongItemDO record);

    int updateByPrimaryKey(SeJingdongItemDO record);
}