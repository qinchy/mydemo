package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AmAppSubscriptionExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public AmAppSubscriptionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSubscriptionUkidIsNull() {
            addCriterion("SUBSCRIPTION_UKID is null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidIsNotNull() {
            addCriterion("SUBSCRIPTION_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_UKID =", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidNotEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_UKID <>", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidGreaterThan(Long value) {
            addCriterion("SUBSCRIPTION_UKID >", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_UKID >=", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidLessThan(Long value) {
            addCriterion("SUBSCRIPTION_UKID <", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidLessThanOrEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_UKID <=", value, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidIn(List<Long> values) {
            addCriterion("SUBSCRIPTION_UKID in", values, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidNotIn(List<Long> values) {
            addCriterion("SUBSCRIPTION_UKID not in", values, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidBetween(Long value1, Long value2) {
            addCriterion("SUBSCRIPTION_UKID between", value1, value2, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionUkidNotBetween(Long value1, Long value2) {
            addCriterion("SUBSCRIPTION_UKID not between", value1, value2, "subscriptionUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidIsNull() {
            addCriterion("APP_UKID is null");
            return (Criteria) this;
        }

        public Criteria andAppUkidIsNotNull() {
            addCriterion("APP_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andAppUkidEqualTo(Long value) {
            addCriterion("APP_UKID =", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotEqualTo(Long value) {
            addCriterion("APP_UKID <>", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThan(Long value) {
            addCriterion("APP_UKID >", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("APP_UKID >=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThan(Long value) {
            addCriterion("APP_UKID <", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThanOrEqualTo(Long value) {
            addCriterion("APP_UKID <=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidIn(List<Long> values) {
            addCriterion("APP_UKID in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotIn(List<Long> values) {
            addCriterion("APP_UKID not in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidBetween(Long value1, Long value2) {
            addCriterion("APP_UKID between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotBetween(Long value1, Long value2) {
            addCriterion("APP_UKID not between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdIsNull() {
            addCriterion("SUBSCRIPTION_BU_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdIsNotNull() {
            addCriterion("SUBSCRIPTION_BU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID =", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdNotEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID <>", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdGreaterThan(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID >", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID >=", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdLessThan(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID <", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdLessThanOrEqualTo(Long value) {
            addCriterion("SUBSCRIPTION_BU_ID <=", value, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdIn(List<Long> values) {
            addCriterion("SUBSCRIPTION_BU_ID in", values, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdNotIn(List<Long> values) {
            addCriterion("SUBSCRIPTION_BU_ID not in", values, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdBetween(Long value1, Long value2) {
            addCriterion("SUBSCRIPTION_BU_ID between", value1, value2, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionBuIdNotBetween(Long value1, Long value2) {
            addCriterion("SUBSCRIPTION_BU_ID not between", value1, value2, "subscriptionBuId");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateIsNull() {
            addCriterion("SUBSCRIPTION_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateIsNotNull() {
            addCriterion("SUBSCRIPTION_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateEqualTo(Date value) {
            addCriterion("SUBSCRIPTION_DATE =", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateNotEqualTo(Date value) {
            addCriterion("SUBSCRIPTION_DATE <>", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateGreaterThan(Date value) {
            addCriterion("SUBSCRIPTION_DATE >", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateGreaterThanOrEqualTo(Date value) {
            addCriterion("SUBSCRIPTION_DATE >=", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateLessThan(Date value) {
            addCriterion("SUBSCRIPTION_DATE <", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateLessThanOrEqualTo(Date value) {
            addCriterion("SUBSCRIPTION_DATE <=", value, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateIn(List<Date> values) {
            addCriterion("SUBSCRIPTION_DATE in", values, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateNotIn(List<Date> values) {
            addCriterion("SUBSCRIPTION_DATE not in", values, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateBetween(Date value1, Date value2) {
            addCriterion("SUBSCRIPTION_DATE between", value1, value2, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andSubscriptionDateNotBetween(Date value1, Date value2) {
            addCriterion("SUBSCRIPTION_DATE not between", value1, value2, "subscriptionDate");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIsNull() {
            addCriterion("PLATFORM_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIsNotNull() {
            addCriterion("PLATFORM_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID =", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID <>", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdGreaterThan(String value) {
            addCriterion("PLATFORM_USER_ID >", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID >=", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLessThan(String value) {
            addCriterion("PLATFORM_USER_ID <", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID <=", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLike(String value) {
            addCriterion("PLATFORM_USER_ID like", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotLike(String value) {
            addCriterion("PLATFORM_USER_ID not like", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIn(List<String> values) {
            addCriterion("PLATFORM_USER_ID in", values, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotIn(List<String> values) {
            addCriterion("PLATFORM_USER_ID not in", values, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_ID between", value1, value2, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_ID not between", value1, value2, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIsNull() {
            addCriterion("PLATFORM_USER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIsNotNull() {
            addCriterion("PLATFORM_USER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK =", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK <>", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickGreaterThan(String value) {
            addCriterion("PLATFORM_USER_NICK >", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK >=", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLessThan(String value) {
            addCriterion("PLATFORM_USER_NICK <", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK <=", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLike(String value) {
            addCriterion("PLATFORM_USER_NICK like", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotLike(String value) {
            addCriterion("PLATFORM_USER_NICK not like", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIn(List<String> values) {
            addCriterion("PLATFORM_USER_NICK in", values, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotIn(List<String> values) {
            addCriterion("PLATFORM_USER_NICK not in", values, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_NICK between", value1, value2, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_NICK not between", value1, value2, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyIsNull() {
            addCriterion("TARGET_APP_KEY is null");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyIsNotNull() {
            addCriterion("TARGET_APP_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyEqualTo(String value) {
            addCriterion("TARGET_APP_KEY =", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyNotEqualTo(String value) {
            addCriterion("TARGET_APP_KEY <>", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyGreaterThan(String value) {
            addCriterion("TARGET_APP_KEY >", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("TARGET_APP_KEY >=", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyLessThan(String value) {
            addCriterion("TARGET_APP_KEY <", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyLessThanOrEqualTo(String value) {
            addCriterion("TARGET_APP_KEY <=", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyLike(String value) {
            addCriterion("TARGET_APP_KEY like", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyNotLike(String value) {
            addCriterion("TARGET_APP_KEY not like", value, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyIn(List<String> values) {
            addCriterion("TARGET_APP_KEY in", values, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyNotIn(List<String> values) {
            addCriterion("TARGET_APP_KEY not in", values, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyBetween(String value1, String value2) {
            addCriterion("TARGET_APP_KEY between", value1, value2, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andTargetAppKeyNotBetween(String value1, String value2) {
            addCriterion("TARGET_APP_KEY not between", value1, value2, "targetAppKey");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIsNull() {
            addCriterion("ACCESS_TOKEN is null");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIsNotNull() {
            addCriterion("ACCESS_TOKEN is not null");
            return (Criteria) this;
        }

        public Criteria andAccessTokenEqualTo(String value) {
            addCriterion("ACCESS_TOKEN =", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotEqualTo(String value) {
            addCriterion("ACCESS_TOKEN <>", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenGreaterThan(String value) {
            addCriterion("ACCESS_TOKEN >", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenGreaterThanOrEqualTo(String value) {
            addCriterion("ACCESS_TOKEN >=", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLessThan(String value) {
            addCriterion("ACCESS_TOKEN <", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLessThanOrEqualTo(String value) {
            addCriterion("ACCESS_TOKEN <=", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLike(String value) {
            addCriterion("ACCESS_TOKEN like", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotLike(String value) {
            addCriterion("ACCESS_TOKEN not like", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIn(List<String> values) {
            addCriterion("ACCESS_TOKEN in", values, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotIn(List<String> values) {
            addCriterion("ACCESS_TOKEN not in", values, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenBetween(String value1, String value2) {
            addCriterion("ACCESS_TOKEN between", value1, value2, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotBetween(String value1, String value2) {
            addCriterion("ACCESS_TOKEN not between", value1, value2, "accessToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIsNull() {
            addCriterion("REFRESH_TOKEN is null");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIsNotNull() {
            addCriterion("REFRESH_TOKEN is not null");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenEqualTo(String value) {
            addCriterion("REFRESH_TOKEN =", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotEqualTo(String value) {
            addCriterion("REFRESH_TOKEN <>", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenGreaterThan(String value) {
            addCriterion("REFRESH_TOKEN >", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenGreaterThanOrEqualTo(String value) {
            addCriterion("REFRESH_TOKEN >=", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLessThan(String value) {
            addCriterion("REFRESH_TOKEN <", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLessThanOrEqualTo(String value) {
            addCriterion("REFRESH_TOKEN <=", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLike(String value) {
            addCriterion("REFRESH_TOKEN like", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotLike(String value) {
            addCriterion("REFRESH_TOKEN not like", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIn(List<String> values) {
            addCriterion("REFRESH_TOKEN in", values, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotIn(List<String> values) {
            addCriterion("REFRESH_TOKEN not in", values, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenBetween(String value1, String value2) {
            addCriterion("REFRESH_TOKEN between", value1, value2, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotBetween(String value1, String value2) {
            addCriterion("REFRESH_TOKEN not between", value1, value2, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeIsNull() {
            addCriterion("LAST_AUTH_TIME is null");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeIsNotNull() {
            addCriterion("LAST_AUTH_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeEqualTo(Date value) {
            addCriterion("LAST_AUTH_TIME =", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeNotEqualTo(Date value) {
            addCriterion("LAST_AUTH_TIME <>", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeGreaterThan(Date value) {
            addCriterion("LAST_AUTH_TIME >", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("LAST_AUTH_TIME >=", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeLessThan(Date value) {
            addCriterion("LAST_AUTH_TIME <", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeLessThanOrEqualTo(Date value) {
            addCriterion("LAST_AUTH_TIME <=", value, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeIn(List<Date> values) {
            addCriterion("LAST_AUTH_TIME in", values, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeNotIn(List<Date> values) {
            addCriterion("LAST_AUTH_TIME not in", values, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeBetween(Date value1, Date value2) {
            addCriterion("LAST_AUTH_TIME between", value1, value2, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andLastAuthTimeNotBetween(Date value1, Date value2) {
            addCriterion("LAST_AUTH_TIME not between", value1, value2, "lastAuthTime");
            return (Criteria) this;
        }

        public Criteria andExpiresInIsNull() {
            addCriterion("EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andExpiresInIsNotNull() {
            addCriterion("EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andExpiresInEqualTo(Long value) {
            addCriterion("EXPIRES_IN =", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotEqualTo(Long value) {
            addCriterion("EXPIRES_IN <>", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInGreaterThan(Long value) {
            addCriterion("EXPIRES_IN >", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("EXPIRES_IN >=", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInLessThan(Long value) {
            addCriterion("EXPIRES_IN <", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("EXPIRES_IN <=", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInIn(List<Long> values) {
            addCriterion("EXPIRES_IN in", values, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotIn(List<Long> values) {
            addCriterion("EXPIRES_IN not in", values, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInBetween(Long value1, Long value2) {
            addCriterion("EXPIRES_IN between", value1, value2, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("EXPIRES_IN not between", value1, value2, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIsNull() {
            addCriterion("RE_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIsNotNull() {
            addCriterion("RE_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andReExpiresInEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN =", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN <>", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInGreaterThan(Long value) {
            addCriterion("RE_EXPIRES_IN >", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN >=", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInLessThan(Long value) {
            addCriterion("RE_EXPIRES_IN <", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN <=", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIn(List<Long> values) {
            addCriterion("RE_EXPIRES_IN in", values, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotIn(List<Long> values) {
            addCriterion("RE_EXPIRES_IN not in", values, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInBetween(Long value1, Long value2) {
            addCriterion("RE_EXPIRES_IN between", value1, value2, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("RE_EXPIRES_IN not between", value1, value2, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIsNull() {
            addCriterion("R1_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIsNotNull() {
            addCriterion("R1_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN =", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN <>", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInGreaterThan(Long value) {
            addCriterion("R1_EXPIRES_IN >", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN >=", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInLessThan(Long value) {
            addCriterion("R1_EXPIRES_IN <", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN <=", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIn(List<Long> values) {
            addCriterion("R1_EXPIRES_IN in", values, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotIn(List<Long> values) {
            addCriterion("R1_EXPIRES_IN not in", values, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInBetween(Long value1, Long value2) {
            addCriterion("R1_EXPIRES_IN between", value1, value2, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("R1_EXPIRES_IN not between", value1, value2, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIsNull() {
            addCriterion("R2_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIsNotNull() {
            addCriterion("R2_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN =", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN <>", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInGreaterThan(Long value) {
            addCriterion("R2_EXPIRES_IN >", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN >=", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInLessThan(Long value) {
            addCriterion("R2_EXPIRES_IN <", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN <=", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIn(List<Long> values) {
            addCriterion("R2_EXPIRES_IN in", values, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotIn(List<Long> values) {
            addCriterion("R2_EXPIRES_IN not in", values, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInBetween(Long value1, Long value2) {
            addCriterion("R2_EXPIRES_IN between", value1, value2, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("R2_EXPIRES_IN not between", value1, value2, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIsNull() {
            addCriterion("W1_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIsNotNull() {
            addCriterion("W1_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN =", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN <>", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInGreaterThan(Long value) {
            addCriterion("W1_EXPIRES_IN >", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN >=", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInLessThan(Long value) {
            addCriterion("W1_EXPIRES_IN <", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN <=", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIn(List<Long> values) {
            addCriterion("W1_EXPIRES_IN in", values, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotIn(List<Long> values) {
            addCriterion("W1_EXPIRES_IN not in", values, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInBetween(Long value1, Long value2) {
            addCriterion("W1_EXPIRES_IN between", value1, value2, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("W1_EXPIRES_IN not between", value1, value2, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIsNull() {
            addCriterion("W2_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIsNotNull() {
            addCriterion("W2_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN =", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN <>", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInGreaterThan(Long value) {
            addCriterion("W2_EXPIRES_IN >", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN >=", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInLessThan(Long value) {
            addCriterion("W2_EXPIRES_IN <", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN <=", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIn(List<Long> values) {
            addCriterion("W2_EXPIRES_IN in", values, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotIn(List<Long> values) {
            addCriterion("W2_EXPIRES_IN not in", values, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInBetween(Long value1, Long value2) {
            addCriterion("W2_EXPIRES_IN between", value1, value2, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("W2_EXPIRES_IN not between", value1, value2, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIsNull() {
            addCriterion("PUBLIC_KEY is null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIsNotNull() {
            addCriterion("PUBLIC_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyEqualTo(String value) {
            addCriterion("PUBLIC_KEY =", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotEqualTo(String value) {
            addCriterion("PUBLIC_KEY <>", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyGreaterThan(String value) {
            addCriterion("PUBLIC_KEY >", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyGreaterThanOrEqualTo(String value) {
            addCriterion("PUBLIC_KEY >=", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLessThan(String value) {
            addCriterion("PUBLIC_KEY <", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLessThanOrEqualTo(String value) {
            addCriterion("PUBLIC_KEY <=", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLike(String value) {
            addCriterion("PUBLIC_KEY like", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotLike(String value) {
            addCriterion("PUBLIC_KEY not like", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIn(List<String> values) {
            addCriterion("PUBLIC_KEY in", values, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotIn(List<String> values) {
            addCriterion("PUBLIC_KEY not in", values, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyBetween(String value1, String value2) {
            addCriterion("PUBLIC_KEY between", value1, value2, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotBetween(String value1, String value2) {
            addCriterion("PUBLIC_KEY not between", value1, value2, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyIsNull() {
            addCriterion("PRIVATE_KEY is null");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyIsNotNull() {
            addCriterion("PRIVATE_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyEqualTo(String value) {
            addCriterion("PRIVATE_KEY =", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyNotEqualTo(String value) {
            addCriterion("PRIVATE_KEY <>", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyGreaterThan(String value) {
            addCriterion("PRIVATE_KEY >", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyGreaterThanOrEqualTo(String value) {
            addCriterion("PRIVATE_KEY >=", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyLessThan(String value) {
            addCriterion("PRIVATE_KEY <", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyLessThanOrEqualTo(String value) {
            addCriterion("PRIVATE_KEY <=", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyLike(String value) {
            addCriterion("PRIVATE_KEY like", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyNotLike(String value) {
            addCriterion("PRIVATE_KEY not like", value, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyIn(List<String> values) {
            addCriterion("PRIVATE_KEY in", values, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyNotIn(List<String> values) {
            addCriterion("PRIVATE_KEY not in", values, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyBetween(String value1, String value2) {
            addCriterion("PRIVATE_KEY between", value1, value2, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPrivateKeyNotBetween(String value1, String value2) {
            addCriterion("PRIVATE_KEY not between", value1, value2, "privateKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutIsNull() {
            addCriterion("PUBLIC_KEY_OUT is null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutIsNotNull() {
            addCriterion("PUBLIC_KEY_OUT is not null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutEqualTo(String value) {
            addCriterion("PUBLIC_KEY_OUT =", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutNotEqualTo(String value) {
            addCriterion("PUBLIC_KEY_OUT <>", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutGreaterThan(String value) {
            addCriterion("PUBLIC_KEY_OUT >", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutGreaterThanOrEqualTo(String value) {
            addCriterion("PUBLIC_KEY_OUT >=", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutLessThan(String value) {
            addCriterion("PUBLIC_KEY_OUT <", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutLessThanOrEqualTo(String value) {
            addCriterion("PUBLIC_KEY_OUT <=", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutLike(String value) {
            addCriterion("PUBLIC_KEY_OUT like", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutNotLike(String value) {
            addCriterion("PUBLIC_KEY_OUT not like", value, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutIn(List<String> values) {
            addCriterion("PUBLIC_KEY_OUT in", values, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutNotIn(List<String> values) {
            addCriterion("PUBLIC_KEY_OUT not in", values, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutBetween(String value1, String value2) {
            addCriterion("PUBLIC_KEY_OUT between", value1, value2, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andPublicKeyOutNotBetween(String value1, String value2) {
            addCriterion("PUBLIC_KEY_OUT not between", value1, value2, "publicKeyOut");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIsNull() {
            addCriterion("DATA_ENCRYPT_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIsNotNull() {
            addCriterion("DATA_ENCRYPT_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE =", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <>", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeGreaterThan(String value) {
            addCriterion("DATA_ENCRYPT_TYPE >", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE >=", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLessThan(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLessThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <=", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLike(String value) {
            addCriterion("DATA_ENCRYPT_TYPE like", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotLike(String value) {
            addCriterion("DATA_ENCRYPT_TYPE not like", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_TYPE in", values, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_TYPE not in", values, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_TYPE between", value1, value2, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_TYPE not between", value1, value2, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyIsNull() {
            addCriterion("DATA_ENCRYPT_KEY is null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyIsNotNull() {
            addCriterion("DATA_ENCRYPT_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_KEY =", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyNotEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_KEY <>", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyGreaterThan(String value) {
            addCriterion("DATA_ENCRYPT_KEY >", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_KEY >=", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyLessThan(String value) {
            addCriterion("DATA_ENCRYPT_KEY <", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyLessThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_KEY <=", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyLike(String value) {
            addCriterion("DATA_ENCRYPT_KEY like", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyNotLike(String value) {
            addCriterion("DATA_ENCRYPT_KEY not like", value, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_KEY in", values, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyNotIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_KEY not in", values, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_KEY between", value1, value2, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptKeyNotBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_KEY not between", value1, value2, "dataEncryptKey");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdIsNull() {
            addCriterion("DATA_ENCRYPT_PWD is null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdIsNotNull() {
            addCriterion("DATA_ENCRYPT_PWD is not null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_PWD =", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdNotEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_PWD <>", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdGreaterThan(String value) {
            addCriterion("DATA_ENCRYPT_PWD >", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_PWD >=", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdLessThan(String value) {
            addCriterion("DATA_ENCRYPT_PWD <", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdLessThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_PWD <=", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdLike(String value) {
            addCriterion("DATA_ENCRYPT_PWD like", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdNotLike(String value) {
            addCriterion("DATA_ENCRYPT_PWD not like", value, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_PWD in", values, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdNotIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_PWD not in", values, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_PWD between", value1, value2, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andDataEncryptPwdNotBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_PWD not between", value1, value2, "dataEncryptPwd");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Long value) {
            addCriterion("STATUS =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Long value) {
            addCriterion("STATUS <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Long value) {
            addCriterion("STATUS >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("STATUS >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Long value) {
            addCriterion("STATUS <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Long value) {
            addCriterion("STATUS <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Long> values) {
            addCriterion("STATUS in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Long> values) {
            addCriterion("STATUS not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Long value1, Long value2) {
            addCriterion("STATUS between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Long value1, Long value2) {
            addCriterion("STATUS not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}