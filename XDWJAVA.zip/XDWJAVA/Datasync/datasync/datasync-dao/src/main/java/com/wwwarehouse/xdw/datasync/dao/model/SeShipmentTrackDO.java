package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

public class SeShipmentTrackDO {

	private Long trackUkid;
	private Long shipmentOrderUkid;
	private Date dateUpdated;
	private Date operationDate;
	private String operationRemark;
	private String operationAddress;
	private Long flowStatus;
	
	public Long getTrackUkid() {
		return trackUkid;
	}
	public void setTrackUkid(Long trackUkid) {
		this.trackUkid = trackUkid;
	}
	public Long getShipmentOrderUkid() {
		return shipmentOrderUkid;
	}
	public void setShipmentOrderUkid(Long shipmentOrderUkid) {
		this.shipmentOrderUkid = shipmentOrderUkid;
	}
	public Date getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(Date dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public Date getOperationDate() {
		return operationDate;
	}
	public void setOperationDate(Date operationDate) {
		this.operationDate = operationDate;
	}
	public String getOperationRemark() {
		return operationRemark;
	}
	public void setOperationRemark(String operationRemark) {
		this.operationRemark = operationRemark;
	}
	public String getOperationAddress() {
		return operationAddress;
	}
	public void setOperationAddress(String operationAddress) {
		this.operationAddress = operationAddress;
	}
	public Long getFlowStatus() {
		return flowStatus;
	}
	public void setFlowStatus(Long flowStatus) {
		this.flowStatus = flowStatus;
	}
}
