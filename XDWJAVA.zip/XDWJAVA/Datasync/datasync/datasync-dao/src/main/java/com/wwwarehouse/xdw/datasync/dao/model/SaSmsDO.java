package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.Date;

public class SaSmsDO implements Serializable {
    private Long smsUkid;

    private Long serviceBuId;

    private Long sendBuId;

    private Long platformId;

    private String mobileNo;

    private Long smsNum;

    private Short smsStatus;

    private String smsType;

    private Date createTime;

    private Long createUserId;

    private Date planSendTime;

    private Date actualSendTime;

    private Date cancelTime;

    private Long cancelUserId;

    private String returnText;

    private Long smsTemplateUkid;

    private Long smsAccountUkid;

    private String relatedType;

    private Long relatedOrderUkid;

    private String sendContent;

    private static final long serialVersionUID = 1L;

    public Long getSmsUkid() {
        return smsUkid;
    }

    public void setSmsUkid(Long smsUkid) {
        this.smsUkid = smsUkid;
    }

    public Long getServiceBuId() {
        return serviceBuId;
    }

    public void setServiceBuId(Long serviceBuId) {
        this.serviceBuId = serviceBuId;
    }

    public Long getSendBuId() {
        return sendBuId;
    }

    public void setSendBuId(Long sendBuId) {
        this.sendBuId = sendBuId;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public Long getSmsNum() {
        return smsNum;
    }

    public void setSmsNum(Long smsNum) {
        this.smsNum = smsNum;
    }

    public Short getSmsStatus() {
        return smsStatus;
    }

    public void setSmsStatus(Short smsStatus) {
        this.smsStatus = smsStatus;
    }

    public String getSmsType() {
        return smsType;
    }

    public void setSmsType(String smsType) {
        this.smsType = smsType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getPlanSendTime() {
        return planSendTime;
    }

    public void setPlanSendTime(Date planSendTime) {
        this.planSendTime = planSendTime;
    }

    public Date getActualSendTime() {
        return actualSendTime;
    }

    public void setActualSendTime(Date actualSendTime) {
        this.actualSendTime = actualSendTime;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Long getCancelUserId() {
        return cancelUserId;
    }

    public void setCancelUserId(Long cancelUserId) {
        this.cancelUserId = cancelUserId;
    }

    public String getReturnText() {
        return returnText;
    }

    public void setReturnText(String returnText) {
        this.returnText = returnText;
    }

    public Long getSmsTemplateUkid() {
        return smsTemplateUkid;
    }

    public void setSmsTemplateUkid(Long smsTemplateUkid) {
        this.smsTemplateUkid = smsTemplateUkid;
    }

    public Long getSmsAccountUkid() {
        return smsAccountUkid;
    }

    public void setSmsAccountUkid(Long smsAccountUkid) {
        this.smsAccountUkid = smsAccountUkid;
    }

    public String getRelatedType() {
        return relatedType;
    }

    public void setRelatedType(String relatedType) {
        this.relatedType = relatedType;
    }

    public Long getRelatedOrderUkid() {
        return relatedOrderUkid;
    }

    public void setRelatedOrderUkid(Long relatedOrderUkid) {
        this.relatedOrderUkid = relatedOrderUkid;
    }

    public String getSendContent() {
        return sendContent;
    }

    public void setSendContent(String sendContent) {
        this.sendContent = sendContent;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", smsUkid=").append(smsUkid);
        sb.append(", serviceBuId=").append(serviceBuId);
        sb.append(", sendBuId=").append(sendBuId);
        sb.append(", platformId=").append(platformId);
        sb.append(", mobileNo=").append(mobileNo);
        sb.append(", smsNum=").append(smsNum);
        sb.append(", smsStatus=").append(smsStatus);
        sb.append(", smsType=").append(smsType);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", planSendTime=").append(planSendTime);
        sb.append(", actualSendTime=").append(actualSendTime);
        sb.append(", cancelTime=").append(cancelTime);
        sb.append(", cancelUserId=").append(cancelUserId);
        sb.append(", returnText=").append(returnText);
        sb.append(", smsTemplateUkid=").append(smsTemplateUkid);
        sb.append(", smsAccountUkid=").append(smsAccountUkid);
        sb.append(", relatedType=").append(relatedType);
        sb.append(", relatedOrderUkid=").append(relatedOrderUkid);
        sb.append(", sendContent=").append(sendContent);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SaSmsDO other = (SaSmsDO) that;
        return (this.getSmsUkid() == null ? other.getSmsUkid() == null : this.getSmsUkid().equals(other.getSmsUkid()))
            && (this.getServiceBuId() == null ? other.getServiceBuId() == null : this.getServiceBuId().equals(other.getServiceBuId()))
            && (this.getSendBuId() == null ? other.getSendBuId() == null : this.getSendBuId().equals(other.getSendBuId()))
            && (this.getPlatformId() == null ? other.getPlatformId() == null : this.getPlatformId().equals(other.getPlatformId()))
            && (this.getMobileNo() == null ? other.getMobileNo() == null : this.getMobileNo().equals(other.getMobileNo()))
            && (this.getSmsNum() == null ? other.getSmsNum() == null : this.getSmsNum().equals(other.getSmsNum()))
            && (this.getSmsStatus() == null ? other.getSmsStatus() == null : this.getSmsStatus().equals(other.getSmsStatus()))
            && (this.getSmsType() == null ? other.getSmsType() == null : this.getSmsType().equals(other.getSmsType()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getPlanSendTime() == null ? other.getPlanSendTime() == null : this.getPlanSendTime().equals(other.getPlanSendTime()))
            && (this.getActualSendTime() == null ? other.getActualSendTime() == null : this.getActualSendTime().equals(other.getActualSendTime()))
            && (this.getCancelTime() == null ? other.getCancelTime() == null : this.getCancelTime().equals(other.getCancelTime()))
            && (this.getCancelUserId() == null ? other.getCancelUserId() == null : this.getCancelUserId().equals(other.getCancelUserId()))
            && (this.getReturnText() == null ? other.getReturnText() == null : this.getReturnText().equals(other.getReturnText()))
            && (this.getSmsTemplateUkid() == null ? other.getSmsTemplateUkid() == null : this.getSmsTemplateUkid().equals(other.getSmsTemplateUkid()))
            && (this.getSmsAccountUkid() == null ? other.getSmsAccountUkid() == null : this.getSmsAccountUkid().equals(other.getSmsAccountUkid()))
            && (this.getRelatedType() == null ? other.getRelatedType() == null : this.getRelatedType().equals(other.getRelatedType()))
            && (this.getRelatedOrderUkid() == null ? other.getRelatedOrderUkid() == null : this.getRelatedOrderUkid().equals(other.getRelatedOrderUkid()))
            && (this.getSendContent() == null ? other.getSendContent() == null : this.getSendContent().equals(other.getSendContent()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getSmsUkid() == null) ? 0 : getSmsUkid().hashCode());
        result = prime * result + ((getServiceBuId() == null) ? 0 : getServiceBuId().hashCode());
        result = prime * result + ((getSendBuId() == null) ? 0 : getSendBuId().hashCode());
        result = prime * result + ((getPlatformId() == null) ? 0 : getPlatformId().hashCode());
        result = prime * result + ((getMobileNo() == null) ? 0 : getMobileNo().hashCode());
        result = prime * result + ((getSmsNum() == null) ? 0 : getSmsNum().hashCode());
        result = prime * result + ((getSmsStatus() == null) ? 0 : getSmsStatus().hashCode());
        result = prime * result + ((getSmsType() == null) ? 0 : getSmsType().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getPlanSendTime() == null) ? 0 : getPlanSendTime().hashCode());
        result = prime * result + ((getActualSendTime() == null) ? 0 : getActualSendTime().hashCode());
        result = prime * result + ((getCancelTime() == null) ? 0 : getCancelTime().hashCode());
        result = prime * result + ((getCancelUserId() == null) ? 0 : getCancelUserId().hashCode());
        result = prime * result + ((getReturnText() == null) ? 0 : getReturnText().hashCode());
        result = prime * result + ((getSmsTemplateUkid() == null) ? 0 : getSmsTemplateUkid().hashCode());
        result = prime * result + ((getSmsAccountUkid() == null) ? 0 : getSmsAccountUkid().hashCode());
        result = prime * result + ((getRelatedType() == null) ? 0 : getRelatedType().hashCode());
        result = prime * result + ((getRelatedOrderUkid() == null) ? 0 : getRelatedOrderUkid().hashCode());
        result = prime * result + ((getSendContent() == null) ? 0 : getSendContent().hashCode());
        return result;
    }
}