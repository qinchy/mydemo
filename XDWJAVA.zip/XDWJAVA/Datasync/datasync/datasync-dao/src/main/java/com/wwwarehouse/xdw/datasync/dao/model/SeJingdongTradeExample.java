package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeJingdongTradeExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeJingdongTradeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Long value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Long value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Long value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Long value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Long> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Long> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Long value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Long value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Long value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Long value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Long> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Long> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNull() {
            addCriterion("RELEASE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNotNull() {
            addCriterion("RELEASE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeEqualTo(Date value) {
            addCriterion("RELEASE_TIME =", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotEqualTo(Date value) {
            addCriterion("RELEASE_TIME <>", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThan(Date value) {
            addCriterion("RELEASE_TIME >", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME >=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThan(Date value) {
            addCriterion("RELEASE_TIME <", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME <=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIn(List<Date> values) {
            addCriterion("RELEASE_TIME in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotIn(List<Date> values) {
            addCriterion("RELEASE_TIME not in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME not between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNull() {
            addCriterion("ORIGIN_TRADE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNotNull() {
            addCriterion("ORIGIN_TRADE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS =", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <>", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThan(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS >", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS >=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThan(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIn(List<Long> values) {
            addCriterion("ORIGIN_TRADE_STATUS in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotIn(List<Long> values) {
            addCriterion("ORIGIN_TRADE_STATUS not in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_TRADE_STATUS between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_TRADE_STATUS not between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderSourceIsNull() {
            addCriterion("ORDER_SOURCE is null");
            return (Criteria) this;
        }

        public Criteria andOrderSourceIsNotNull() {
            addCriterion("ORDER_SOURCE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderSourceEqualTo(String value) {
            addCriterion("ORDER_SOURCE =", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceNotEqualTo(String value) {
            addCriterion("ORDER_SOURCE <>", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceGreaterThan(String value) {
            addCriterion("ORDER_SOURCE >", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_SOURCE >=", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceLessThan(String value) {
            addCriterion("ORDER_SOURCE <", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceLessThanOrEqualTo(String value) {
            addCriterion("ORDER_SOURCE <=", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceLike(String value) {
            addCriterion("ORDER_SOURCE like", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceNotLike(String value) {
            addCriterion("ORDER_SOURCE not like", value, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceIn(List<String> values) {
            addCriterion("ORDER_SOURCE in", values, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceNotIn(List<String> values) {
            addCriterion("ORDER_SOURCE not in", values, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceBetween(String value1, String value2) {
            addCriterion("ORDER_SOURCE between", value1, value2, "orderSource");
            return (Criteria) this;
        }

        public Criteria andOrderSourceNotBetween(String value1, String value2) {
            addCriterion("ORDER_SOURCE not between", value1, value2, "orderSource");
            return (Criteria) this;
        }

        public Criteria andCustomsIsNull() {
            addCriterion("CUSTOMS is null");
            return (Criteria) this;
        }

        public Criteria andCustomsIsNotNull() {
            addCriterion("CUSTOMS is not null");
            return (Criteria) this;
        }

        public Criteria andCustomsEqualTo(String value) {
            addCriterion("CUSTOMS =", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsNotEqualTo(String value) {
            addCriterion("CUSTOMS <>", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsGreaterThan(String value) {
            addCriterion("CUSTOMS >", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsGreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMS >=", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsLessThan(String value) {
            addCriterion("CUSTOMS <", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsLessThanOrEqualTo(String value) {
            addCriterion("CUSTOMS <=", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsLike(String value) {
            addCriterion("CUSTOMS like", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsNotLike(String value) {
            addCriterion("CUSTOMS not like", value, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsIn(List<String> values) {
            addCriterion("CUSTOMS in", values, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsNotIn(List<String> values) {
            addCriterion("CUSTOMS not in", values, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsBetween(String value1, String value2) {
            addCriterion("CUSTOMS between", value1, value2, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsNotBetween(String value1, String value2) {
            addCriterion("CUSTOMS not between", value1, value2, "customs");
            return (Criteria) this;
        }

        public Criteria andCustomsModelIsNull() {
            addCriterion("CUSTOMS_MODEL is null");
            return (Criteria) this;
        }

        public Criteria andCustomsModelIsNotNull() {
            addCriterion("CUSTOMS_MODEL is not null");
            return (Criteria) this;
        }

        public Criteria andCustomsModelEqualTo(String value) {
            addCriterion("CUSTOMS_MODEL =", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelNotEqualTo(String value) {
            addCriterion("CUSTOMS_MODEL <>", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelGreaterThan(String value) {
            addCriterion("CUSTOMS_MODEL >", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelGreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMS_MODEL >=", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelLessThan(String value) {
            addCriterion("CUSTOMS_MODEL <", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelLessThanOrEqualTo(String value) {
            addCriterion("CUSTOMS_MODEL <=", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelLike(String value) {
            addCriterion("CUSTOMS_MODEL like", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelNotLike(String value) {
            addCriterion("CUSTOMS_MODEL not like", value, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelIn(List<String> values) {
            addCriterion("CUSTOMS_MODEL in", values, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelNotIn(List<String> values) {
            addCriterion("CUSTOMS_MODEL not in", values, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelBetween(String value1, String value2) {
            addCriterion("CUSTOMS_MODEL between", value1, value2, "customsModel");
            return (Criteria) this;
        }

        public Criteria andCustomsModelNotBetween(String value1, String value2) {
            addCriterion("CUSTOMS_MODEL not between", value1, value2, "customsModel");
            return (Criteria) this;
        }

        public Criteria andVenderIdIsNull() {
            addCriterion("VENDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andVenderIdIsNotNull() {
            addCriterion("VENDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andVenderIdEqualTo(String value) {
            addCriterion("VENDER_ID =", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdNotEqualTo(String value) {
            addCriterion("VENDER_ID <>", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdGreaterThan(String value) {
            addCriterion("VENDER_ID >", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdGreaterThanOrEqualTo(String value) {
            addCriterion("VENDER_ID >=", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdLessThan(String value) {
            addCriterion("VENDER_ID <", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdLessThanOrEqualTo(String value) {
            addCriterion("VENDER_ID <=", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdLike(String value) {
            addCriterion("VENDER_ID like", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdNotLike(String value) {
            addCriterion("VENDER_ID not like", value, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdIn(List<String> values) {
            addCriterion("VENDER_ID in", values, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdNotIn(List<String> values) {
            addCriterion("VENDER_ID not in", values, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdBetween(String value1, String value2) {
            addCriterion("VENDER_ID between", value1, value2, "venderId");
            return (Criteria) this;
        }

        public Criteria andVenderIdNotBetween(String value1, String value2) {
            addCriterion("VENDER_ID not between", value1, value2, "venderId");
            return (Criteria) this;
        }

        public Criteria andPayTypeIsNull() {
            addCriterion("PAY_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andPayTypeIsNotNull() {
            addCriterion("PAY_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andPayTypeEqualTo(String value) {
            addCriterion("PAY_TYPE =", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeNotEqualTo(String value) {
            addCriterion("PAY_TYPE <>", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeGreaterThan(String value) {
            addCriterion("PAY_TYPE >", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeGreaterThanOrEqualTo(String value) {
            addCriterion("PAY_TYPE >=", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeLessThan(String value) {
            addCriterion("PAY_TYPE <", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeLessThanOrEqualTo(String value) {
            addCriterion("PAY_TYPE <=", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeLike(String value) {
            addCriterion("PAY_TYPE like", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeNotLike(String value) {
            addCriterion("PAY_TYPE not like", value, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeIn(List<String> values) {
            addCriterion("PAY_TYPE in", values, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeNotIn(List<String> values) {
            addCriterion("PAY_TYPE not in", values, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeBetween(String value1, String value2) {
            addCriterion("PAY_TYPE between", value1, value2, "payType");
            return (Criteria) this;
        }

        public Criteria andPayTypeNotBetween(String value1, String value2) {
            addCriterion("PAY_TYPE not between", value1, value2, "payType");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceIsNull() {
            addCriterion("ORDER_TOTAL_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceIsNotNull() {
            addCriterion("ORDER_TOTAL_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceEqualTo(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE =", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE <>", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceGreaterThan(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE >", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE >=", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceLessThan(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE <", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_TOTAL_PRICE <=", value, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceIn(List<BigDecimal> values) {
            addCriterion("ORDER_TOTAL_PRICE in", values, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_TOTAL_PRICE not in", values, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_TOTAL_PRICE between", value1, value2, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderTotalPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_TOTAL_PRICE not between", value1, value2, "orderTotalPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceIsNull() {
            addCriterion("ORDER_SELLER_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceIsNotNull() {
            addCriterion("ORDER_SELLER_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceEqualTo(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE =", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE <>", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceGreaterThan(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE >", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE >=", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceLessThan(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE <", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_SELLER_PRICE <=", value, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceIn(List<BigDecimal> values) {
            addCriterion("ORDER_SELLER_PRICE in", values, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_SELLER_PRICE not in", values, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_SELLER_PRICE between", value1, value2, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderSellerPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_SELLER_PRICE not between", value1, value2, "orderSellerPrice");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentIsNull() {
            addCriterion("ORDER_PAYMENT is null");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentIsNotNull() {
            addCriterion("ORDER_PAYMENT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentEqualTo(BigDecimal value) {
            addCriterion("ORDER_PAYMENT =", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_PAYMENT <>", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentGreaterThan(BigDecimal value) {
            addCriterion("ORDER_PAYMENT >", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PAYMENT >=", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentLessThan(BigDecimal value) {
            addCriterion("ORDER_PAYMENT <", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PAYMENT <=", value, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentIn(List<BigDecimal> values) {
            addCriterion("ORDER_PAYMENT in", values, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_PAYMENT not in", values, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PAYMENT between", value1, value2, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andOrderPaymentNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PAYMENT not between", value1, value2, "orderPayment");
            return (Criteria) this;
        }

        public Criteria andFreightPriceIsNull() {
            addCriterion("FREIGHT_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andFreightPriceIsNotNull() {
            addCriterion("FREIGHT_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andFreightPriceEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_PRICE =", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceNotEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_PRICE <>", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceGreaterThan(BigDecimal value) {
            addCriterion("FREIGHT_PRICE >", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_PRICE >=", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceLessThan(BigDecimal value) {
            addCriterion("FREIGHT_PRICE <", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_PRICE <=", value, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceIn(List<BigDecimal> values) {
            addCriterion("FREIGHT_PRICE in", values, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceNotIn(List<BigDecimal> values) {
            addCriterion("FREIGHT_PRICE not in", values, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FREIGHT_PRICE between", value1, value2, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andFreightPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FREIGHT_PRICE not between", value1, value2, "freightPrice");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountIsNull() {
            addCriterion("SELLER_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountIsNotNull() {
            addCriterion("SELLER_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountEqualTo(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT =", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountNotEqualTo(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT <>", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountGreaterThan(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT >", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT >=", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountLessThan(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT <", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SELLER_DISCOUNT <=", value, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountIn(List<BigDecimal> values) {
            addCriterion("SELLER_DISCOUNT in", values, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountNotIn(List<BigDecimal> values) {
            addCriterion("SELLER_DISCOUNT not in", values, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELLER_DISCOUNT between", value1, value2, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andSellerDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELLER_DISCOUNT not between", value1, value2, "sellerDiscount");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeIsNull() {
            addCriterion("DELIVERY_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeIsNotNull() {
            addCriterion("DELIVERY_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeEqualTo(String value) {
            addCriterion("DELIVERY_TYPE =", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeNotEqualTo(String value) {
            addCriterion("DELIVERY_TYPE <>", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeGreaterThan(String value) {
            addCriterion("DELIVERY_TYPE >", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeGreaterThanOrEqualTo(String value) {
            addCriterion("DELIVERY_TYPE >=", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeLessThan(String value) {
            addCriterion("DELIVERY_TYPE <", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeLessThanOrEqualTo(String value) {
            addCriterion("DELIVERY_TYPE <=", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeLike(String value) {
            addCriterion("DELIVERY_TYPE like", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeNotLike(String value) {
            addCriterion("DELIVERY_TYPE not like", value, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeIn(List<String> values) {
            addCriterion("DELIVERY_TYPE in", values, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeNotIn(List<String> values) {
            addCriterion("DELIVERY_TYPE not in", values, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeBetween(String value1, String value2) {
            addCriterion("DELIVERY_TYPE between", value1, value2, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andDeliveryTypeNotBetween(String value1, String value2) {
            addCriterion("DELIVERY_TYPE not between", value1, value2, "deliveryType");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoIsNull() {
            addCriterion("INVOICE_INFO is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoIsNotNull() {
            addCriterion("INVOICE_INFO is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoEqualTo(String value) {
            addCriterion("INVOICE_INFO =", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoNotEqualTo(String value) {
            addCriterion("INVOICE_INFO <>", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoGreaterThan(String value) {
            addCriterion("INVOICE_INFO >", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_INFO >=", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoLessThan(String value) {
            addCriterion("INVOICE_INFO <", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_INFO <=", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoLike(String value) {
            addCriterion("INVOICE_INFO like", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoNotLike(String value) {
            addCriterion("INVOICE_INFO not like", value, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoIn(List<String> values) {
            addCriterion("INVOICE_INFO in", values, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoNotIn(List<String> values) {
            addCriterion("INVOICE_INFO not in", values, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoBetween(String value1, String value2) {
            addCriterion("INVOICE_INFO between", value1, value2, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andInvoiceInfoNotBetween(String value1, String value2) {
            addCriterion("INVOICE_INFO not between", value1, value2, "invoiceInfo");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNull() {
            addCriterion("BUYER_MESSAGE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNotNull() {
            addCriterion("BUYER_MESSAGE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageEqualTo(String value) {
            addCriterion("BUYER_MESSAGE =", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <>", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThan(String value) {
            addCriterion("BUYER_MESSAGE >", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE >=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThan(String value) {
            addCriterion("BUYER_MESSAGE <", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLike(String value) {
            addCriterion("BUYER_MESSAGE like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotLike(String value) {
            addCriterion("BUYER_MESSAGE not like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIn(List<String> values) {
            addCriterion("BUYER_MESSAGE in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotIn(List<String> values) {
            addCriterion("BUYER_MESSAGE not in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE not between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIsNull() {
            addCriterion("ORDER_END_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIsNotNull() {
            addCriterion("ORDER_END_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeEqualTo(Date value) {
            addCriterion("ORDER_END_TIME =", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotEqualTo(Date value) {
            addCriterion("ORDER_END_TIME <>", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeGreaterThan(Date value) {
            addCriterion("ORDER_END_TIME >", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_END_TIME >=", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeLessThan(Date value) {
            addCriterion("ORDER_END_TIME <", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_END_TIME <=", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIn(List<Date> values) {
            addCriterion("ORDER_END_TIME in", values, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotIn(List<Date> values) {
            addCriterion("ORDER_END_TIME not in", values, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_END_TIME between", value1, value2, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_END_TIME not between", value1, value2, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNull() {
            addCriterion("RECEIVER_NAME is null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNotNull() {
            addCriterion("RECEIVER_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameEqualTo(String value) {
            addCriterion("RECEIVER_NAME =", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotEqualTo(String value) {
            addCriterion("RECEIVER_NAME <>", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThan(String value) {
            addCriterion("RECEIVER_NAME >", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME >=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThan(String value) {
            addCriterion("RECEIVER_NAME <", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME <=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLike(String value) {
            addCriterion("RECEIVER_NAME like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotLike(String value) {
            addCriterion("RECEIVER_NAME not like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIn(List<String> values) {
            addCriterion("RECEIVER_NAME in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotIn(List<String> values) {
            addCriterion("RECEIVER_NAME not in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME not between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNull() {
            addCriterion("RECEIVER_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNotNull() {
            addCriterion("RECEIVER_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneEqualTo(String value) {
            addCriterion("RECEIVER_PHONE =", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <>", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThan(String value) {
            addCriterion("RECEIVER_PHONE >", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE >=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThan(String value) {
            addCriterion("RECEIVER_PHONE <", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLike(String value) {
            addCriterion("RECEIVER_PHONE like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotLike(String value) {
            addCriterion("RECEIVER_PHONE not like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIn(List<String> values) {
            addCriterion("RECEIVER_PHONE in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotIn(List<String> values) {
            addCriterion("RECEIVER_PHONE not in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE not between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNull() {
            addCriterion("RECEIVER_MOBILE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNotNull() {
            addCriterion("RECEIVER_MOBILE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE =", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <>", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThan(String value) {
            addCriterion("RECEIVER_MOBILE >", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE >=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThan(String value) {
            addCriterion("RECEIVER_MOBILE <", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLike(String value) {
            addCriterion("RECEIVER_MOBILE like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotLike(String value) {
            addCriterion("RECEIVER_MOBILE not like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE not in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE not between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNull() {
            addCriterion("RECEIVER_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNotNull() {
            addCriterion("RECEIVER_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS =", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <>", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThan(String value) {
            addCriterion("RECEIVER_ADDRESS >", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS >=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThan(String value) {
            addCriterion("RECEIVER_ADDRESS <", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLike(String value) {
            addCriterion("RECEIVER_ADDRESS like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotLike(String value) {
            addCriterion("RECEIVER_ADDRESS not like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS not in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS not between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNull() {
            addCriterion("RECEIVER_STATE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNotNull() {
            addCriterion("RECEIVER_STATE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateEqualTo(String value) {
            addCriterion("RECEIVER_STATE =", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotEqualTo(String value) {
            addCriterion("RECEIVER_STATE <>", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThan(String value) {
            addCriterion("RECEIVER_STATE >", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE >=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThan(String value) {
            addCriterion("RECEIVER_STATE <", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE <=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLike(String value) {
            addCriterion("RECEIVER_STATE like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotLike(String value) {
            addCriterion("RECEIVER_STATE not like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIn(List<String> values) {
            addCriterion("RECEIVER_STATE in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotIn(List<String> values) {
            addCriterion("RECEIVER_STATE not in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE not between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNull() {
            addCriterion("RECEIVER_CITY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNotNull() {
            addCriterion("RECEIVER_CITY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityEqualTo(String value) {
            addCriterion("RECEIVER_CITY =", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotEqualTo(String value) {
            addCriterion("RECEIVER_CITY <>", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThan(String value) {
            addCriterion("RECEIVER_CITY >", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY >=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThan(String value) {
            addCriterion("RECEIVER_CITY <", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY <=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLike(String value) {
            addCriterion("RECEIVER_CITY like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotLike(String value) {
            addCriterion("RECEIVER_CITY not like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIn(List<String> values) {
            addCriterion("RECEIVER_CITY in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotIn(List<String> values) {
            addCriterion("RECEIVER_CITY not in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY not between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNull() {
            addCriterion("RECEIVER_COUNTY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNotNull() {
            addCriterion("RECEIVER_COUNTY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY =", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <>", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThan(String value) {
            addCriterion("RECEIVER_COUNTY >", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY >=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThan(String value) {
            addCriterion("RECEIVER_COUNTY <", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLike(String value) {
            addCriterion("RECEIVER_COUNTY like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotLike(String value) {
            addCriterion("RECEIVER_COUNTY not like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY not in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY not between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedIsNull() {
            addCriterion("BALANCE_USED is null");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedIsNotNull() {
            addCriterion("BALANCE_USED is not null");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedEqualTo(String value) {
            addCriterion("BALANCE_USED =", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedNotEqualTo(String value) {
            addCriterion("BALANCE_USED <>", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedGreaterThan(String value) {
            addCriterion("BALANCE_USED >", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedGreaterThanOrEqualTo(String value) {
            addCriterion("BALANCE_USED >=", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedLessThan(String value) {
            addCriterion("BALANCE_USED <", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedLessThanOrEqualTo(String value) {
            addCriterion("BALANCE_USED <=", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedLike(String value) {
            addCriterion("BALANCE_USED like", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedNotLike(String value) {
            addCriterion("BALANCE_USED not like", value, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedIn(List<String> values) {
            addCriterion("BALANCE_USED in", values, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedNotIn(List<String> values) {
            addCriterion("BALANCE_USED not in", values, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedBetween(String value1, String value2) {
            addCriterion("BALANCE_USED between", value1, value2, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andBalanceUsedNotBetween(String value1, String value2) {
            addCriterion("BALANCE_USED not between", value1, value2, "balanceUsed");
            return (Criteria) this;
        }

        public Criteria andReturnOrderIsNull() {
            addCriterion("RETURN_ORDER is null");
            return (Criteria) this;
        }

        public Criteria andReturnOrderIsNotNull() {
            addCriterion("RETURN_ORDER is not null");
            return (Criteria) this;
        }

        public Criteria andReturnOrderEqualTo(String value) {
            addCriterion("RETURN_ORDER =", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderNotEqualTo(String value) {
            addCriterion("RETURN_ORDER <>", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderGreaterThan(String value) {
            addCriterion("RETURN_ORDER >", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderGreaterThanOrEqualTo(String value) {
            addCriterion("RETURN_ORDER >=", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderLessThan(String value) {
            addCriterion("RETURN_ORDER <", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderLessThanOrEqualTo(String value) {
            addCriterion("RETURN_ORDER <=", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderLike(String value) {
            addCriterion("RETURN_ORDER like", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderNotLike(String value) {
            addCriterion("RETURN_ORDER not like", value, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderIn(List<String> values) {
            addCriterion("RETURN_ORDER in", values, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderNotIn(List<String> values) {
            addCriterion("RETURN_ORDER not in", values, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderBetween(String value1, String value2) {
            addCriterion("RETURN_ORDER between", value1, value2, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andReturnOrderNotBetween(String value1, String value2) {
            addCriterion("RETURN_ORDER not between", value1, value2, "returnOrder");
            return (Criteria) this;
        }

        public Criteria andWayBillIsNull() {
            addCriterion("WAY_BILL is null");
            return (Criteria) this;
        }

        public Criteria andWayBillIsNotNull() {
            addCriterion("WAY_BILL is not null");
            return (Criteria) this;
        }

        public Criteria andWayBillEqualTo(String value) {
            addCriterion("WAY_BILL =", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillNotEqualTo(String value) {
            addCriterion("WAY_BILL <>", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillGreaterThan(String value) {
            addCriterion("WAY_BILL >", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillGreaterThanOrEqualTo(String value) {
            addCriterion("WAY_BILL >=", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillLessThan(String value) {
            addCriterion("WAY_BILL <", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillLessThanOrEqualTo(String value) {
            addCriterion("WAY_BILL <=", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillLike(String value) {
            addCriterion("WAY_BILL like", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillNotLike(String value) {
            addCriterion("WAY_BILL not like", value, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillIn(List<String> values) {
            addCriterion("WAY_BILL in", values, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillNotIn(List<String> values) {
            addCriterion("WAY_BILL not in", values, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillBetween(String value1, String value2) {
            addCriterion("WAY_BILL between", value1, value2, "wayBill");
            return (Criteria) this;
        }

        public Criteria andWayBillNotBetween(String value1, String value2) {
            addCriterion("WAY_BILL not between", value1, value2, "wayBill");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdIsNull() {
            addCriterion("LOGISTICS_ID is null");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdIsNotNull() {
            addCriterion("LOGISTICS_ID is not null");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdEqualTo(String value) {
            addCriterion("LOGISTICS_ID =", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdNotEqualTo(String value) {
            addCriterion("LOGISTICS_ID <>", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdGreaterThan(String value) {
            addCriterion("LOGISTICS_ID >", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdGreaterThanOrEqualTo(String value) {
            addCriterion("LOGISTICS_ID >=", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdLessThan(String value) {
            addCriterion("LOGISTICS_ID <", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdLessThanOrEqualTo(String value) {
            addCriterion("LOGISTICS_ID <=", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdLike(String value) {
            addCriterion("LOGISTICS_ID like", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdNotLike(String value) {
            addCriterion("LOGISTICS_ID not like", value, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdIn(List<String> values) {
            addCriterion("LOGISTICS_ID in", values, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdNotIn(List<String> values) {
            addCriterion("LOGISTICS_ID not in", values, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdBetween(String value1, String value2) {
            addCriterion("LOGISTICS_ID between", value1, value2, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andLogisticsIdNotBetween(String value1, String value2) {
            addCriterion("LOGISTICS_ID not between", value1, value2, "logisticsId");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNull() {
            addCriterion("ORDER_MODIFY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNotNull() {
            addCriterion("ORDER_MODIFY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME =", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <>", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME >", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME >=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME <", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME not in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME not between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdIsNull() {
            addCriterion("PARENT_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdIsNotNull() {
            addCriterion("PARENT_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdEqualTo(String value) {
            addCriterion("PARENT_ORDER_ID =", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdNotEqualTo(String value) {
            addCriterion("PARENT_ORDER_ID <>", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdGreaterThan(String value) {
            addCriterion("PARENT_ORDER_ID >", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("PARENT_ORDER_ID >=", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdLessThan(String value) {
            addCriterion("PARENT_ORDER_ID <", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdLessThanOrEqualTo(String value) {
            addCriterion("PARENT_ORDER_ID <=", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdLike(String value) {
            addCriterion("PARENT_ORDER_ID like", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdNotLike(String value) {
            addCriterion("PARENT_ORDER_ID not like", value, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdIn(List<String> values) {
            addCriterion("PARENT_ORDER_ID in", values, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdNotIn(List<String> values) {
            addCriterion("PARENT_ORDER_ID not in", values, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdBetween(String value1, String value2) {
            addCriterion("PARENT_ORDER_ID between", value1, value2, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andParentOrderIdNotBetween(String value1, String value2) {
            addCriterion("PARENT_ORDER_ID not between", value1, value2, "parentOrderId");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNull() {
            addCriterion("ORDER_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIsNotNull() {
            addCriterion("ORDER_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderTypeEqualTo(String value) {
            addCriterion("ORDER_TYPE =", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotEqualTo(String value) {
            addCriterion("ORDER_TYPE <>", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThan(String value) {
            addCriterion("ORDER_TYPE >", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_TYPE >=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThan(String value) {
            addCriterion("ORDER_TYPE <", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLessThanOrEqualTo(String value) {
            addCriterion("ORDER_TYPE <=", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeLike(String value) {
            addCriterion("ORDER_TYPE like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotLike(String value) {
            addCriterion("ORDER_TYPE not like", value, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeIn(List<String> values) {
            addCriterion("ORDER_TYPE in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotIn(List<String> values) {
            addCriterion("ORDER_TYPE not in", values, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeBetween(String value1, String value2) {
            addCriterion("ORDER_TYPE between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andOrderTypeNotBetween(String value1, String value2) {
            addCriterion("ORDER_TYPE not between", value1, value2, "orderType");
            return (Criteria) this;
        }

        public Criteria andStoreOrderIsNull() {
            addCriterion("STORE_ORDER is null");
            return (Criteria) this;
        }

        public Criteria andStoreOrderIsNotNull() {
            addCriterion("STORE_ORDER is not null");
            return (Criteria) this;
        }

        public Criteria andStoreOrderEqualTo(String value) {
            addCriterion("STORE_ORDER =", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderNotEqualTo(String value) {
            addCriterion("STORE_ORDER <>", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderGreaterThan(String value) {
            addCriterion("STORE_ORDER >", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderGreaterThanOrEqualTo(String value) {
            addCriterion("STORE_ORDER >=", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderLessThan(String value) {
            addCriterion("STORE_ORDER <", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderLessThanOrEqualTo(String value) {
            addCriterion("STORE_ORDER <=", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderLike(String value) {
            addCriterion("STORE_ORDER like", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderNotLike(String value) {
            addCriterion("STORE_ORDER not like", value, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderIn(List<String> values) {
            addCriterion("STORE_ORDER in", values, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderNotIn(List<String> values) {
            addCriterion("STORE_ORDER not in", values, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderBetween(String value1, String value2) {
            addCriterion("STORE_ORDER between", value1, value2, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andStoreOrderNotBetween(String value1, String value2) {
            addCriterion("STORE_ORDER not between", value1, value2, "storeOrder");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentIsNull() {
            addCriterion("TAX_PAYER_IDENT is null");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentIsNotNull() {
            addCriterion("TAX_PAYER_IDENT is not null");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentEqualTo(String value) {
            addCriterion("TAX_PAYER_IDENT =", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentNotEqualTo(String value) {
            addCriterion("TAX_PAYER_IDENT <>", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentGreaterThan(String value) {
            addCriterion("TAX_PAYER_IDENT >", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentGreaterThanOrEqualTo(String value) {
            addCriterion("TAX_PAYER_IDENT >=", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentLessThan(String value) {
            addCriterion("TAX_PAYER_IDENT <", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentLessThanOrEqualTo(String value) {
            addCriterion("TAX_PAYER_IDENT <=", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentLike(String value) {
            addCriterion("TAX_PAYER_IDENT like", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentNotLike(String value) {
            addCriterion("TAX_PAYER_IDENT not like", value, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentIn(List<String> values) {
            addCriterion("TAX_PAYER_IDENT in", values, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentNotIn(List<String> values) {
            addCriterion("TAX_PAYER_IDENT not in", values, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentBetween(String value1, String value2) {
            addCriterion("TAX_PAYER_IDENT between", value1, value2, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andTaxPayerIdentNotBetween(String value1, String value2) {
            addCriterion("TAX_PAYER_IDENT not between", value1, value2, "taxPayerIdent");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressIsNull() {
            addCriterion("REGISTERED_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressIsNotNull() {
            addCriterion("REGISTERED_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressEqualTo(String value) {
            addCriterion("REGISTERED_ADDRESS =", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressNotEqualTo(String value) {
            addCriterion("REGISTERED_ADDRESS <>", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressGreaterThan(String value) {
            addCriterion("REGISTERED_ADDRESS >", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressGreaterThanOrEqualTo(String value) {
            addCriterion("REGISTERED_ADDRESS >=", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressLessThan(String value) {
            addCriterion("REGISTERED_ADDRESS <", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressLessThanOrEqualTo(String value) {
            addCriterion("REGISTERED_ADDRESS <=", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressLike(String value) {
            addCriterion("REGISTERED_ADDRESS like", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressNotLike(String value) {
            addCriterion("REGISTERED_ADDRESS not like", value, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressIn(List<String> values) {
            addCriterion("REGISTERED_ADDRESS in", values, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressNotIn(List<String> values) {
            addCriterion("REGISTERED_ADDRESS not in", values, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressBetween(String value1, String value2) {
            addCriterion("REGISTERED_ADDRESS between", value1, value2, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredAddressNotBetween(String value1, String value2) {
            addCriterion("REGISTERED_ADDRESS not between", value1, value2, "registeredAddress");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneIsNull() {
            addCriterion("REGISTERED_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneIsNotNull() {
            addCriterion("REGISTERED_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneEqualTo(String value) {
            addCriterion("REGISTERED_PHONE =", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneNotEqualTo(String value) {
            addCriterion("REGISTERED_PHONE <>", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneGreaterThan(String value) {
            addCriterion("REGISTERED_PHONE >", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("REGISTERED_PHONE >=", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneLessThan(String value) {
            addCriterion("REGISTERED_PHONE <", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneLessThanOrEqualTo(String value) {
            addCriterion("REGISTERED_PHONE <=", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneLike(String value) {
            addCriterion("REGISTERED_PHONE like", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneNotLike(String value) {
            addCriterion("REGISTERED_PHONE not like", value, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneIn(List<String> values) {
            addCriterion("REGISTERED_PHONE in", values, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneNotIn(List<String> values) {
            addCriterion("REGISTERED_PHONE not in", values, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneBetween(String value1, String value2) {
            addCriterion("REGISTERED_PHONE between", value1, value2, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andRegisteredPhoneNotBetween(String value1, String value2) {
            addCriterion("REGISTERED_PHONE not between", value1, value2, "registeredPhone");
            return (Criteria) this;
        }

        public Criteria andDepositBankIsNull() {
            addCriterion("DEPOSIT_BANK is null");
            return (Criteria) this;
        }

        public Criteria andDepositBankIsNotNull() {
            addCriterion("DEPOSIT_BANK is not null");
            return (Criteria) this;
        }

        public Criteria andDepositBankEqualTo(String value) {
            addCriterion("DEPOSIT_BANK =", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankNotEqualTo(String value) {
            addCriterion("DEPOSIT_BANK <>", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankGreaterThan(String value) {
            addCriterion("DEPOSIT_BANK >", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankGreaterThanOrEqualTo(String value) {
            addCriterion("DEPOSIT_BANK >=", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankLessThan(String value) {
            addCriterion("DEPOSIT_BANK <", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankLessThanOrEqualTo(String value) {
            addCriterion("DEPOSIT_BANK <=", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankLike(String value) {
            addCriterion("DEPOSIT_BANK like", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankNotLike(String value) {
            addCriterion("DEPOSIT_BANK not like", value, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankIn(List<String> values) {
            addCriterion("DEPOSIT_BANK in", values, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankNotIn(List<String> values) {
            addCriterion("DEPOSIT_BANK not in", values, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankBetween(String value1, String value2) {
            addCriterion("DEPOSIT_BANK between", value1, value2, "depositBank");
            return (Criteria) this;
        }

        public Criteria andDepositBankNotBetween(String value1, String value2) {
            addCriterion("DEPOSIT_BANK not between", value1, value2, "depositBank");
            return (Criteria) this;
        }

        public Criteria andBankAccountIsNull() {
            addCriterion("BANK_ACCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andBankAccountIsNotNull() {
            addCriterion("BANK_ACCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andBankAccountEqualTo(String value) {
            addCriterion("BANK_ACCOUNT =", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountNotEqualTo(String value) {
            addCriterion("BANK_ACCOUNT <>", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountGreaterThan(String value) {
            addCriterion("BANK_ACCOUNT >", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountGreaterThanOrEqualTo(String value) {
            addCriterion("BANK_ACCOUNT >=", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountLessThan(String value) {
            addCriterion("BANK_ACCOUNT <", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountLessThanOrEqualTo(String value) {
            addCriterion("BANK_ACCOUNT <=", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountLike(String value) {
            addCriterion("BANK_ACCOUNT like", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountNotLike(String value) {
            addCriterion("BANK_ACCOUNT not like", value, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountIn(List<String> values) {
            addCriterion("BANK_ACCOUNT in", values, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountNotIn(List<String> values) {
            addCriterion("BANK_ACCOUNT not in", values, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountBetween(String value1, String value2) {
            addCriterion("BANK_ACCOUNT between", value1, value2, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andBankAccountNotBetween(String value1, String value2) {
            addCriterion("BANK_ACCOUNT not between", value1, value2, "bankAccount");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNull() {
            addCriterion("TARGET_ORDER_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNotNull() {
            addCriterion("TARGET_ORDER_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID =", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <>", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThan(Long value) {
            addCriterion("TARGET_ORDER_UKID >", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID >=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThan(Long value) {
            addCriterion("TARGET_ORDER_UKID <", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID not in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID not between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNull() {
            addCriterion("PLATFORM_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNotNull() {
            addCriterion("PLATFORM_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS =", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <>", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS not like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS not in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS not between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNull() {
            addCriterion("ORDER_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNotNull() {
            addCriterion("ORDER_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME =", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <>", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThan(Date value) {
            addCriterion("ORDER_CREATE_TIME >", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME >=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThan(Date value) {
            addCriterion("ORDER_CREATE_TIME <", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME not in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME not between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNull() {
            addCriterion("ORDER_PAY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNotNull() {
            addCriterion("ORDER_PAY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME =", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <>", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThan(Date value) {
            addCriterion("ORDER_PAY_TIME >", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME >=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThan(Date value) {
            addCriterion("ORDER_PAY_TIME <", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME not in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME not between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNull() {
            addCriterion("RECEIVER_ZIP is null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNotNull() {
            addCriterion("RECEIVER_ZIP is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipEqualTo(String value) {
            addCriterion("RECEIVER_ZIP =", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <>", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThan(String value) {
            addCriterion("RECEIVER_ZIP >", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP >=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThan(String value) {
            addCriterion("RECEIVER_ZIP <", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLike(String value) {
            addCriterion("RECEIVER_ZIP like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotLike(String value) {
            addCriterion("RECEIVER_ZIP not like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIn(List<String> values) {
            addCriterion("RECEIVER_ZIP in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotIn(List<String> values) {
            addCriterion("RECEIVER_ZIP not in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP not between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNull() {
            addCriterion("SELLER_MEMO is null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNotNull() {
            addCriterion("SELLER_MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoEqualTo(String value) {
            addCriterion("SELLER_MEMO =", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotEqualTo(String value) {
            addCriterion("SELLER_MEMO <>", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThan(String value) {
            addCriterion("SELLER_MEMO >", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO >=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThan(String value) {
            addCriterion("SELLER_MEMO <", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO <=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLike(String value) {
            addCriterion("SELLER_MEMO like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotLike(String value) {
            addCriterion("SELLER_MEMO not like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIn(List<String> values) {
            addCriterion("SELLER_MEMO in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotIn(List<String> values) {
            addCriterion("SELLER_MEMO not in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO not between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andIsCodIsNull() {
            addCriterion("IS_COD is null");
            return (Criteria) this;
        }

        public Criteria andIsCodIsNotNull() {
            addCriterion("IS_COD is not null");
            return (Criteria) this;
        }

        public Criteria andIsCodEqualTo(Long value) {
            addCriterion("IS_COD =", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodNotEqualTo(Long value) {
            addCriterion("IS_COD <>", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodGreaterThan(Long value) {
            addCriterion("IS_COD >", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodGreaterThanOrEqualTo(Long value) {
            addCriterion("IS_COD >=", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodLessThan(Long value) {
            addCriterion("IS_COD <", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodLessThanOrEqualTo(Long value) {
            addCriterion("IS_COD <=", value, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodIn(List<Long> values) {
            addCriterion("IS_COD in", values, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodNotIn(List<Long> values) {
            addCriterion("IS_COD not in", values, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodBetween(Long value1, Long value2) {
            addCriterion("IS_COD between", value1, value2, "isCod");
            return (Criteria) this;
        }

        public Criteria andIsCodNotBetween(Long value1, Long value2) {
            addCriterion("IS_COD not between", value1, value2, "isCod");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}