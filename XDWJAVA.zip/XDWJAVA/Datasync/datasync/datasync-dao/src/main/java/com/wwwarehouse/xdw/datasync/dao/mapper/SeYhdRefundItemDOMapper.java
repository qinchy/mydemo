package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeYhdRefundItemDOMapper {
    long countByExample(SeYhdRefundItemDOExample example);

    int deleteByExample(SeYhdRefundItemDOExample example);

    int deleteByPrimaryKey(Short refundItemUkid);

    int insert(SeYhdRefundItemDO record);

    int insertSelective(SeYhdRefundItemDO record);

    List<SeYhdRefundItemDO> selectByExample(SeYhdRefundItemDOExample example);

    SeYhdRefundItemDO selectByPrimaryKey(Short refundItemUkid);

    int updateByExampleSelective(@Param("record") SeYhdRefundItemDO record, @Param("example") SeYhdRefundItemDOExample example);

    int updateByExample(@Param("record") SeYhdRefundItemDO record, @Param("example") SeYhdRefundItemDOExample example);

    int updateByPrimaryKeySelective(SeYhdRefundItemDO record);

    int updateByPrimaryKey(SeYhdRefundItemDO record);
}