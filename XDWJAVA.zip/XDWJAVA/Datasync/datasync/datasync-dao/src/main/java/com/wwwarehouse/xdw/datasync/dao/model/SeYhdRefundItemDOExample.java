package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeYhdRefundItemDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeYhdRefundItemDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRefundItemUkidIsNull() {
            addCriterion("REFUND_ITEM_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidIsNotNull() {
            addCriterion("REFUND_ITEM_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidEqualTo(Long value) {
            addCriterion("REFUND_ITEM_UKID =", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidNotEqualTo(Long value) {
            addCriterion("REFUND_ITEM_UKID <>", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidGreaterThan(Long value) {
            addCriterion("REFUND_ITEM_UKID >", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("REFUND_ITEM_UKID >=", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidLessThan(Long value) {
            addCriterion("REFUND_ITEM_UKID <", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidLessThanOrEqualTo(Long value) {
            addCriterion("REFUND_ITEM_UKID <=", value, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidIn(List<Long> values) {
            addCriterion("REFUND_ITEM_UKID in", values, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidNotIn(List<Long> values) {
            addCriterion("REFUND_ITEM_UKID not in", values, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidBetween(Long value1, Long value2) {
            addCriterion("REFUND_ITEM_UKID between", value1, value2, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundItemUkidNotBetween(Long value1, Long value2) {
            addCriterion("REFUND_ITEM_UKID not between", value1, value2, "refundItemUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIsNull() {
            addCriterion("REFUND_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIsNotNull() {
            addCriterion("REFUND_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidEqualTo(Long value) {
            addCriterion("REFUND_UKID =", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotEqualTo(Long value) {
            addCriterion("REFUND_UKID <>", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThan(Long value) {
            addCriterion("REFUND_UKID >", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID >=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThan(Long value) {
            addCriterion("REFUND_UKID <", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID <=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIn(List<Long> values) {
            addCriterion("REFUND_UKID in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotIn(List<Long> values) {
            addCriterion("REFUND_UKID not in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID not between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNull() {
            addCriterion("PRODUCT_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNotNull() {
            addCriterion("PRODUCT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductIdEqualTo(String value) {
            addCriterion("PRODUCT_ID =", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotEqualTo(String value) {
            addCriterion("PRODUCT_ID <>", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThan(String value) {
            addCriterion("PRODUCT_ID >", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_ID >=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThan(String value) {
            addCriterion("PRODUCT_ID <", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_ID <=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLike(String value) {
            addCriterion("PRODUCT_ID like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotLike(String value) {
            addCriterion("PRODUCT_ID not like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdIn(List<String> values) {
            addCriterion("PRODUCT_ID in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotIn(List<String> values) {
            addCriterion("PRODUCT_ID not in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdBetween(String value1, String value2) {
            addCriterion("PRODUCT_ID between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_ID not between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductCnameIsNull() {
            addCriterion("PRODUCT_CNAME is null");
            return (Criteria) this;
        }

        public Criteria andProductCnameIsNotNull() {
            addCriterion("PRODUCT_CNAME is not null");
            return (Criteria) this;
        }

        public Criteria andProductCnameEqualTo(String value) {
            addCriterion("PRODUCT_CNAME =", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotEqualTo(String value) {
            addCriterion("PRODUCT_CNAME <>", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameGreaterThan(String value) {
            addCriterion("PRODUCT_CNAME >", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CNAME >=", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLessThan(String value) {
            addCriterion("PRODUCT_CNAME <", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CNAME <=", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLike(String value) {
            addCriterion("PRODUCT_CNAME like", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotLike(String value) {
            addCriterion("PRODUCT_CNAME not like", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameIn(List<String> values) {
            addCriterion("PRODUCT_CNAME in", values, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotIn(List<String> values) {
            addCriterion("PRODUCT_CNAME not in", values, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameBetween(String value1, String value2) {
            addCriterion("PRODUCT_CNAME between", value1, value2, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CNAME not between", value1, value2, "productCname");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIsNull() {
            addCriterion("ORDER_ITEM_NUM is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIsNotNull() {
            addCriterion("ORDER_ITEM_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM =", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM <>", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumGreaterThan(Long value) {
            addCriterion("ORDER_ITEM_NUM >", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM >=", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumLessThan(Long value) {
            addCriterion("ORDER_ITEM_NUM <", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM <=", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIn(List<Long> values) {
            addCriterion("ORDER_ITEM_NUM in", values, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotIn(List<Long> values) {
            addCriterion("ORDER_ITEM_NUM not in", values, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_NUM between", value1, value2, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_NUM not between", value1, value2, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIsNull() {
            addCriterion("ORDER_ITEM_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIsNotNull() {
            addCriterion("ORDER_ITEM_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE =", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <>", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceGreaterThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE >", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE >=", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceLessThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <=", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_PRICE in", values, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_PRICE not in", values, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_PRICE between", value1, value2, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_PRICE not between", value1, value2, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumIsNull() {
            addCriterion("PRODUCT_REFUND_NUM is null");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumIsNotNull() {
            addCriterion("PRODUCT_REFUND_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumEqualTo(Long value) {
            addCriterion("PRODUCT_REFUND_NUM =", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumNotEqualTo(Long value) {
            addCriterion("PRODUCT_REFUND_NUM <>", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumGreaterThan(Long value) {
            addCriterion("PRODUCT_REFUND_NUM >", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumGreaterThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_REFUND_NUM >=", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumLessThan(Long value) {
            addCriterion("PRODUCT_REFUND_NUM <", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumLessThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_REFUND_NUM <=", value, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumIn(List<Long> values) {
            addCriterion("PRODUCT_REFUND_NUM in", values, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumNotIn(List<Long> values) {
            addCriterion("PRODUCT_REFUND_NUM not in", values, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_REFUND_NUM between", value1, value2, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andProductRefundNumNotBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_REFUND_NUM not between", value1, value2, "productRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumIsNull() {
            addCriterion("ORIGINAL_REFUND_NUM is null");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumIsNotNull() {
            addCriterion("ORIGINAL_REFUND_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumEqualTo(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM =", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumNotEqualTo(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM <>", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumGreaterThan(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM >", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumGreaterThanOrEqualTo(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM >=", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumLessThan(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM <", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumLessThanOrEqualTo(Long value) {
            addCriterion("ORIGINAL_REFUND_NUM <=", value, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumIn(List<Long> values) {
            addCriterion("ORIGINAL_REFUND_NUM in", values, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumNotIn(List<Long> values) {
            addCriterion("ORIGINAL_REFUND_NUM not in", values, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumBetween(Long value1, Long value2) {
            addCriterion("ORIGINAL_REFUND_NUM between", value1, value2, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOriginalRefundNumNotBetween(Long value1, Long value2) {
            addCriterion("ORIGINAL_REFUND_NUM not between", value1, value2, "originalRefundNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdIsNull() {
            addCriterion("ORDER_ITEM_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdIsNotNull() {
            addCriterion("ORDER_ITEM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdEqualTo(Long value) {
            addCriterion("ORDER_ITEM_ID =", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdNotEqualTo(Long value) {
            addCriterion("ORDER_ITEM_ID <>", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdGreaterThan(Long value) {
            addCriterion("ORDER_ITEM_ID >", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_ID >=", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdLessThan(Long value) {
            addCriterion("ORDER_ITEM_ID <", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_ID <=", value, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdIn(List<Long> values) {
            addCriterion("ORDER_ITEM_ID in", values, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdNotIn(List<Long> values) {
            addCriterion("ORDER_ITEM_ID not in", values, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_ID between", value1, value2, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andOrderItemIdNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_ID not between", value1, value2, "orderItemId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}