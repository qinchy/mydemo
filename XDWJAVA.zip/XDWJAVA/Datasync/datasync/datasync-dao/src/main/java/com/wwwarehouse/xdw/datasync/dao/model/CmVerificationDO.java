package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

/**
 * Created by yinsheng.wang on 2017/6/9.
 */
public class CmVerificationDO {
    /**
     *主键
     **/
    private Long verificationUkid;

    /**
     *用户Id
     **/
    private Long userId;

    /**
     *手机号码
     **/
    private String mobile;

    /**
     *验证码
     **/
    private String verificationCode;

    /**
     *状态（0：失效，1：有效）
     **/
    private Long status;

    /**
     *业务类型（注册；绑定银行卡）
     **/
    private String businessType;

    /**
     *有效时长（秒）
     **/
    private Long validTime;

    /**
     *完成时间
     **/
    private Date finishTime;

    /**
     *创建人
     **/
    private Long createUserId;

    /**
     *更新人
     **/
    private Long updateUserId;

    /**
     *创建时间
     **/
    private Date createTime;

    /**
     *更新时间
     **/
    private Date updateTime;

    public Long getVerificationUkid() {
        return verificationUkid;
    }

    public void setVerificationUkid(Long verificationUkid) {
        this.verificationUkid = verificationUkid;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode == null ? null : verificationCode.trim();
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType == null ? null : businessType.trim();
    }

    public Long getValidTime() {
        return validTime;
    }

    public void setValidTime(Long validTime) {
        this.validTime = validTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
