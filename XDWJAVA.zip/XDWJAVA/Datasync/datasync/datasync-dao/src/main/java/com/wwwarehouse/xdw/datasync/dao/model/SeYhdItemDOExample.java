package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeYhdItemDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeYhdItemDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andItemUkidIsNull() {
            addCriterion("ITEM_UKID is null");
            return (Criteria) this;
        }

        public Criteria andItemUkidIsNotNull() {
            addCriterion("ITEM_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andItemUkidEqualTo(Long value) {
            addCriterion("ITEM_UKID =", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotEqualTo(Long value) {
            addCriterion("ITEM_UKID <>", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThan(Long value) {
            addCriterion("ITEM_UKID >", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("ITEM_UKID >=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThan(Long value) {
            addCriterion("ITEM_UKID <", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThanOrEqualTo(Long value) {
            addCriterion("ITEM_UKID <=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidIn(List<Long> values) {
            addCriterion("ITEM_UKID in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotIn(List<Long> values) {
            addCriterion("ITEM_UKID not in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidBetween(Long value1, Long value2) {
            addCriterion("ITEM_UKID between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotBetween(Long value1, Long value2) {
            addCriterion("ITEM_UKID not between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Long value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Long value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Long value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Long value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Long> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Long> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNull() {
            addCriterion("ORIGIN_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNotNull() {
            addCriterion("ORIGIN_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS =", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <>", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThan(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS >", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS >=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThan(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIn(List<Long> values) {
            addCriterion("ORIGIN_ORDER_STATUS in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotIn(List<Long> values) {
            addCriterion("ORIGIN_ORDER_STATUS not in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_ORDER_STATUS between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_ORDER_STATUS not between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNull() {
            addCriterion("SHOP_PRODUCT_UKID is null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNotNull() {
            addCriterion("SHOP_PRODUCT_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID =", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <>", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThan(Long value) {
            addCriterion("SHOP_PRODUCT_UKID >", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID >=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThan(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIn(List<Long> values) {
            addCriterion("SHOP_PRODUCT_UKID in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotIn(List<Long> values) {
            addCriterion("SHOP_PRODUCT_UKID not in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidBetween(Long value1, Long value2) {
            addCriterion("SHOP_PRODUCT_UKID between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_PRODUCT_UKID not between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNull() {
            addCriterion("PRODUCT_CODE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNotNull() {
            addCriterion("PRODUCT_CODE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID =", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID <>", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThan(Long value) {
            addCriterion("PRODUCT_CODE_UKID >", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID >=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThan(Long value) {
            addCriterion("PRODUCT_CODE_UKID <", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID <=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIn(List<Long> values) {
            addCriterion("PRODUCT_CODE_UKID in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotIn(List<Long> values) {
            addCriterion("PRODUCT_CODE_UKID not in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_CODE_UKID between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_CODE_UKID not between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("PRODUCT_CODE is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("PRODUCT_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("PRODUCT_CODE =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("PRODUCT_CODE <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("PRODUCT_CODE >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("PRODUCT_CODE <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("PRODUCT_CODE like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("PRODUCT_CODE not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("PRODUCT_CODE in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("PRODUCT_CODE not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNull() {
            addCriterion("PRESALE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNotNull() {
            addCriterion("PRESALE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateEqualTo(Date value) {
            addCriterion("PRESALE_DATE =", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotEqualTo(Date value) {
            addCriterion("PRESALE_DATE <>", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThan(Date value) {
            addCriterion("PRESALE_DATE >", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE >=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThan(Date value) {
            addCriterion("PRESALE_DATE <", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE <=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIn(List<Date> values) {
            addCriterion("PRESALE_DATE in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotIn(List<Date> values) {
            addCriterion("PRESALE_DATE not in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE not between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNull() {
            addCriterion("WORKSPACE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNotNull() {
            addCriterion("WORKSPACE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdEqualTo(String value) {
            addCriterion("WORKSPACE_ID =", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotEqualTo(String value) {
            addCriterion("WORKSPACE_ID <>", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThan(String value) {
            addCriterion("WORKSPACE_ID >", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID >=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThan(String value) {
            addCriterion("WORKSPACE_ID <", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID <=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLike(String value) {
            addCriterion("WORKSPACE_ID like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotLike(String value) {
            addCriterion("WORKSPACE_ID not like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIn(List<String> values) {
            addCriterion("WORKSPACE_ID in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotIn(List<String> values) {
            addCriterion("WORKSPACE_ID not in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID not between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(Long value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(Long value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(Long value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(Long value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<Long> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<Long> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(Long value1, Long value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andProductCnameIsNull() {
            addCriterion("PRODUCT_CNAME is null");
            return (Criteria) this;
        }

        public Criteria andProductCnameIsNotNull() {
            addCriterion("PRODUCT_CNAME is not null");
            return (Criteria) this;
        }

        public Criteria andProductCnameEqualTo(String value) {
            addCriterion("PRODUCT_CNAME =", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotEqualTo(String value) {
            addCriterion("PRODUCT_CNAME <>", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameGreaterThan(String value) {
            addCriterion("PRODUCT_CNAME >", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CNAME >=", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLessThan(String value) {
            addCriterion("PRODUCT_CNAME <", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CNAME <=", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameLike(String value) {
            addCriterion("PRODUCT_CNAME like", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotLike(String value) {
            addCriterion("PRODUCT_CNAME not like", value, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameIn(List<String> values) {
            addCriterion("PRODUCT_CNAME in", values, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotIn(List<String> values) {
            addCriterion("PRODUCT_CNAME not in", values, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameBetween(String value1, String value2) {
            addCriterion("PRODUCT_CNAME between", value1, value2, "productCname");
            return (Criteria) this;
        }

        public Criteria andProductCnameNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CNAME not between", value1, value2, "productCname");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountIsNull() {
            addCriterion("ORDER_ITEM_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountIsNotNull() {
            addCriterion("ORDER_ITEM_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT =", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT <>", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountGreaterThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT >", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT >=", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountLessThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT <", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_AMOUNT <=", value, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_AMOUNT in", values, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_AMOUNT not in", values, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_AMOUNT between", value1, value2, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_AMOUNT not between", value1, value2, "orderItemAmount");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIsNull() {
            addCriterion("ORDER_ITEM_NUM is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIsNotNull() {
            addCriterion("ORDER_ITEM_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM =", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM <>", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumGreaterThan(Long value) {
            addCriterion("ORDER_ITEM_NUM >", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM >=", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumLessThan(Long value) {
            addCriterion("ORDER_ITEM_NUM <", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_ITEM_NUM <=", value, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumIn(List<Long> values) {
            addCriterion("ORDER_ITEM_NUM in", values, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotIn(List<Long> values) {
            addCriterion("ORDER_ITEM_NUM not in", values, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_NUM between", value1, value2, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemNumNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_ITEM_NUM not between", value1, value2, "orderItemNum");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIsNull() {
            addCriterion("ORDER_ITEM_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIsNotNull() {
            addCriterion("ORDER_ITEM_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE =", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <>", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceGreaterThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE >", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE >=", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceLessThan(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_ITEM_PRICE <=", value, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_PRICE in", values, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_ITEM_PRICE not in", values, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_PRICE between", value1, value2, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOrderItemPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_ITEM_PRICE not between", value1, value2, "orderItemPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceIsNull() {
            addCriterion("ORIGINAL_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceIsNotNull() {
            addCriterion("ORIGINAL_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceEqualTo(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE =", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceNotEqualTo(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE <>", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceGreaterThan(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE >", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE >=", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceLessThan(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE <", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORIGINAL_PRICE <=", value, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceIn(List<BigDecimal> values) {
            addCriterion("ORIGINAL_PRICE in", values, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceNotIn(List<BigDecimal> values) {
            addCriterion("ORIGINAL_PRICE not in", values, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORIGINAL_PRICE between", value1, value2, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andOriginalPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORIGINAL_PRICE not between", value1, value2, "originalPrice");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNull() {
            addCriterion("PRODUCT_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNotNull() {
            addCriterion("PRODUCT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductIdEqualTo(Long value) {
            addCriterion("PRODUCT_ID =", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotEqualTo(Long value) {
            addCriterion("PRODUCT_ID <>", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThan(Long value) {
            addCriterion("PRODUCT_ID >", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_ID >=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThan(Long value) {
            addCriterion("PRODUCT_ID <", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_ID <=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdIn(List<Long> values) {
            addCriterion("PRODUCT_ID in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotIn(List<Long> values) {
            addCriterion("PRODUCT_ID not in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_ID between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_ID not between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andGroupFlagIsNull() {
            addCriterion("GROUP_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andGroupFlagIsNotNull() {
            addCriterion("GROUP_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andGroupFlagEqualTo(Long value) {
            addCriterion("GROUP_FLAG =", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagNotEqualTo(Long value) {
            addCriterion("GROUP_FLAG <>", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagGreaterThan(Long value) {
            addCriterion("GROUP_FLAG >", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagGreaterThanOrEqualTo(Long value) {
            addCriterion("GROUP_FLAG >=", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagLessThan(Long value) {
            addCriterion("GROUP_FLAG <", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagLessThanOrEqualTo(Long value) {
            addCriterion("GROUP_FLAG <=", value, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagIn(List<Long> values) {
            addCriterion("GROUP_FLAG in", values, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagNotIn(List<Long> values) {
            addCriterion("GROUP_FLAG not in", values, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagBetween(Long value1, Long value2) {
            addCriterion("GROUP_FLAG between", value1, value2, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andGroupFlagNotBetween(Long value1, Long value2) {
            addCriterion("GROUP_FLAG not between", value1, value2, "groupFlag");
            return (Criteria) this;
        }

        public Criteria andMerchantIdIsNull() {
            addCriterion("MERCHANT_ID is null");
            return (Criteria) this;
        }

        public Criteria andMerchantIdIsNotNull() {
            addCriterion("MERCHANT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantIdEqualTo(Long value) {
            addCriterion("MERCHANT_ID =", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotEqualTo(Long value) {
            addCriterion("MERCHANT_ID <>", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdGreaterThan(Long value) {
            addCriterion("MERCHANT_ID >", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdGreaterThanOrEqualTo(Long value) {
            addCriterion("MERCHANT_ID >=", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdLessThan(Long value) {
            addCriterion("MERCHANT_ID <", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdLessThanOrEqualTo(Long value) {
            addCriterion("MERCHANT_ID <=", value, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdIn(List<Long> values) {
            addCriterion("MERCHANT_ID in", values, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotIn(List<Long> values) {
            addCriterion("MERCHANT_ID not in", values, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdBetween(Long value1, Long value2) {
            addCriterion("MERCHANT_ID between", value1, value2, "merchantId");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotBetween(Long value1, Long value2) {
            addCriterion("MERCHANT_ID not between", value1, value2, "merchantId");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateIsNull() {
            addCriterion("PROCESS_FINISH_DATE is null");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateIsNotNull() {
            addCriterion("PROCESS_FINISH_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateEqualTo(Date value) {
            addCriterion("PROCESS_FINISH_DATE =", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateNotEqualTo(Date value) {
            addCriterion("PROCESS_FINISH_DATE <>", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateGreaterThan(Date value) {
            addCriterion("PROCESS_FINISH_DATE >", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateGreaterThanOrEqualTo(Date value) {
            addCriterion("PROCESS_FINISH_DATE >=", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateLessThan(Date value) {
            addCriterion("PROCESS_FINISH_DATE <", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateLessThanOrEqualTo(Date value) {
            addCriterion("PROCESS_FINISH_DATE <=", value, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateIn(List<Date> values) {
            addCriterion("PROCESS_FINISH_DATE in", values, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateNotIn(List<Date> values) {
            addCriterion("PROCESS_FINISH_DATE not in", values, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateBetween(Date value1, Date value2) {
            addCriterion("PROCESS_FINISH_DATE between", value1, value2, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andProcessFinishDateNotBetween(Date value1, Date value2) {
            addCriterion("PROCESS_FINISH_DATE not between", value1, value2, "processFinishDate");
            return (Criteria) this;
        }

        public Criteria andOuterIdIsNull() {
            addCriterion("OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOuterIdIsNotNull() {
            addCriterion("OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOuterIdEqualTo(String value) {
            addCriterion("OUTER_ID =", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotEqualTo(String value) {
            addCriterion("OUTER_ID <>", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdGreaterThan(String value) {
            addCriterion("OUTER_ID >", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("OUTER_ID >=", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLessThan(String value) {
            addCriterion("OUTER_ID <", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLessThanOrEqualTo(String value) {
            addCriterion("OUTER_ID <=", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLike(String value) {
            addCriterion("OUTER_ID like", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotLike(String value) {
            addCriterion("OUTER_ID not like", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdIn(List<String> values) {
            addCriterion("OUTER_ID in", values, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotIn(List<String> values) {
            addCriterion("OUTER_ID not in", values, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdBetween(String value1, String value2) {
            addCriterion("OUTER_ID between", value1, value2, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotBetween(String value1, String value2) {
            addCriterion("OUTER_ID not between", value1, value2, "outerId");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountIsNull() {
            addCriterion("DELIVERY_FEE_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountIsNotNull() {
            addCriterion("DELIVERY_FEE_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT =", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountNotEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT <>", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountGreaterThan(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT >", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT >=", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountLessThan(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT <", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE_AMOUNT <=", value, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountIn(List<BigDecimal> values) {
            addCriterion("DELIVERY_FEE_AMOUNT in", values, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountNotIn(List<BigDecimal> values) {
            addCriterion("DELIVERY_FEE_AMOUNT not in", values, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DELIVERY_FEE_AMOUNT between", value1, value2, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DELIVERY_FEE_AMOUNT not between", value1, value2, "deliveryFeeAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountIsNull() {
            addCriterion("PROMOTION_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountIsNotNull() {
            addCriterion("PROMOTION_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountEqualTo(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT =", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountNotEqualTo(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT <>", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountGreaterThan(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT >", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT >=", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountLessThan(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT <", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PROMOTION_AMOUNT <=", value, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountIn(List<BigDecimal> values) {
            addCriterion("PROMOTION_AMOUNT in", values, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountNotIn(List<BigDecimal> values) {
            addCriterion("PROMOTION_AMOUNT not in", values, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PROMOTION_AMOUNT between", value1, value2, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andPromotionAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PROMOTION_AMOUNT not between", value1, value2, "promotionAmount");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantIsNull() {
            addCriterion("COUPON_AMOUNT_MERCHANT is null");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantIsNotNull() {
            addCriterion("COUPON_AMOUNT_MERCHANT is not null");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantEqualTo(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT =", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantNotEqualTo(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT <>", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantGreaterThan(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT >", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT >=", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantLessThan(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT <", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantLessThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_AMOUNT_MERCHANT <=", value, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantIn(List<BigDecimal> values) {
            addCriterion("COUPON_AMOUNT_MERCHANT in", values, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantNotIn(List<BigDecimal> values) {
            addCriterion("COUPON_AMOUNT_MERCHANT not in", values, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_AMOUNT_MERCHANT between", value1, value2, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponAmountMerchantNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_AMOUNT_MERCHANT not between", value1, value2, "couponAmountMerchant");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountIsNull() {
            addCriterion("COUPON_PLATFORM_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountIsNotNull() {
            addCriterion("COUPON_PLATFORM_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountEqualTo(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT =", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountNotEqualTo(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT <>", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountGreaterThan(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT >", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT >=", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountLessThan(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT <", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_PLATFORM_DISCOUNT <=", value, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountIn(List<BigDecimal> values) {
            addCriterion("COUPON_PLATFORM_DISCOUNT in", values, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountNotIn(List<BigDecimal> values) {
            addCriterion("COUPON_PLATFORM_DISCOUNT not in", values, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_PLATFORM_DISCOUNT between", value1, value2, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andCouponPlatformDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_PLATFORM_DISCOUNT not between", value1, value2, "couponPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountIsNull() {
            addCriterion("SUBSIDY_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountIsNotNull() {
            addCriterion("SUBSIDY_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountEqualTo(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT =", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountNotEqualTo(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT <>", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountGreaterThan(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT >", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT >=", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountLessThan(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT <", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SUBSIDY_AMOUNT <=", value, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountIn(List<BigDecimal> values) {
            addCriterion("SUBSIDY_AMOUNT in", values, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountNotIn(List<BigDecimal> values) {
            addCriterion("SUBSIDY_AMOUNT not in", values, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUBSIDY_AMOUNT between", value1, value2, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andSubsidyAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUBSIDY_AMOUNT not between", value1, value2, "subsidyAmount");
            return (Criteria) this;
        }

        public Criteria andProductDepositIsNull() {
            addCriterion("PRODUCT_DEPOSIT is null");
            return (Criteria) this;
        }

        public Criteria andProductDepositIsNotNull() {
            addCriterion("PRODUCT_DEPOSIT is not null");
            return (Criteria) this;
        }

        public Criteria andProductDepositEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT =", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositNotEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT <>", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositGreaterThan(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT >", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT >=", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositLessThan(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT <", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_DEPOSIT <=", value, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_DEPOSIT in", values, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositNotIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_DEPOSIT not in", values, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_DEPOSIT between", value1, value2, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andProductDepositNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_DEPOSIT not between", value1, value2, "productDeposit");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountIsNull() {
            addCriterion("DISCOUNT_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountIsNotNull() {
            addCriterion("DISCOUNT_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT =", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountNotEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT <>", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountGreaterThan(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT >", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT >=", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountLessThan(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT <", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_AMOUNT <=", value, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_AMOUNT in", values, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountNotIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_AMOUNT not in", values, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_AMOUNT between", value1, value2, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andDiscountAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_AMOUNT not between", value1, value2, "discountAmount");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNull() {
            addCriterion("SUB_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNotNull() {
            addCriterion("SUB_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdEqualTo(Long value) {
            addCriterion("SUB_ORDER_ID =", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotEqualTo(Long value) {
            addCriterion("SUB_ORDER_ID <>", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThan(Long value) {
            addCriterion("SUB_ORDER_ID >", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SUB_ORDER_ID >=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThan(Long value) {
            addCriterion("SUB_ORDER_ID <", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThanOrEqualTo(Long value) {
            addCriterion("SUB_ORDER_ID <=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIn(List<Long> values) {
            addCriterion("SUB_ORDER_ID in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotIn(List<Long> values) {
            addCriterion("SUB_ORDER_ID not in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdBetween(Long value1, Long value2) {
            addCriterion("SUB_ORDER_ID between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotBetween(Long value1, Long value2) {
            addCriterion("SUB_ORDER_ID not between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}