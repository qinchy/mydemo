package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

public class ImPlatformCategory extends BaseObject {

    private Long platformCategoryUkid;

    private Long platformId;

    private String categoryId;

    private String categoryName;

    private String parentId;

    private Long hasChild;

    private Date createTime;

    private Long createUserId;

    /**
    *����ʱ��
    **/
    private Date updateTime;

    private Long updateUserId;

    public Long getPlatformCategoryUkid() {
        return platformCategoryUkid;
    }

    public void setPlatformCategoryUkid(Long platformCategoryUkid) {
        this.platformCategoryUkid = platformCategoryUkid;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId == null ? null : categoryId.trim();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName == null ? null : categoryName.trim();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    public Long getHasChild() {
        return hasChild;
    }

    public void setHasChild(Long hasChild) {
        this.hasChild = hasChild;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }
}