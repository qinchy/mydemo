package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeTaobaoItemDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeTaobaoItemDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andItemUkidIsNull() {
            addCriterion("ITEM_UKID is null");
            return (Criteria) this;
        }

        public Criteria andItemUkidIsNotNull() {
            addCriterion("ITEM_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andItemUkidEqualTo(Short value) {
            addCriterion("ITEM_UKID =", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotEqualTo(Short value) {
            addCriterion("ITEM_UKID <>", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThan(Short value) {
            addCriterion("ITEM_UKID >", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("ITEM_UKID >=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThan(Short value) {
            addCriterion("ITEM_UKID <", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThanOrEqualTo(Short value) {
            addCriterion("ITEM_UKID <=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidIn(List<Short> values) {
            addCriterion("ITEM_UKID in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotIn(List<Short> values) {
            addCriterion("ITEM_UKID not in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidBetween(Short value1, Short value2) {
            addCriterion("ITEM_UKID between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotBetween(Short value1, Short value2) {
            addCriterion("ITEM_UKID not between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Short value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Short value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Short value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Short value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Short value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Short> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Short> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Short value1, Short value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Short value1, Short value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNull() {
            addCriterion("ORIGIN_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNotNull() {
            addCriterion("ORIGIN_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusEqualTo(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS =", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotEqualTo(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS <>", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThan(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS >", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS >=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThan(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS <", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThanOrEqualTo(Short value) {
            addCriterion("ORIGIN_ORDER_STATUS <=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIn(List<Short> values) {
            addCriterion("ORIGIN_ORDER_STATUS in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotIn(List<Short> values) {
            addCriterion("ORIGIN_ORDER_STATUS not in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusBetween(Short value1, Short value2) {
            addCriterion("ORIGIN_ORDER_STATUS between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotBetween(Short value1, Short value2) {
            addCriterion("ORIGIN_ORDER_STATUS not between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNull() {
            addCriterion("SHOP_PRODUCT_UKID is null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNotNull() {
            addCriterion("SHOP_PRODUCT_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidEqualTo(Short value) {
            addCriterion("SHOP_PRODUCT_UKID =", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotEqualTo(Short value) {
            addCriterion("SHOP_PRODUCT_UKID <>", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThan(Short value) {
            addCriterion("SHOP_PRODUCT_UKID >", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("SHOP_PRODUCT_UKID >=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThan(Short value) {
            addCriterion("SHOP_PRODUCT_UKID <", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThanOrEqualTo(Short value) {
            addCriterion("SHOP_PRODUCT_UKID <=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIn(List<Short> values) {
            addCriterion("SHOP_PRODUCT_UKID in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotIn(List<Short> values) {
            addCriterion("SHOP_PRODUCT_UKID not in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidBetween(Short value1, Short value2) {
            addCriterion("SHOP_PRODUCT_UKID between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotBetween(Short value1, Short value2) {
            addCriterion("SHOP_PRODUCT_UKID not between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNull() {
            addCriterion("PRODUCT_CODE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNotNull() {
            addCriterion("PRODUCT_CODE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidEqualTo(Short value) {
            addCriterion("PRODUCT_CODE_UKID =", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotEqualTo(Short value) {
            addCriterion("PRODUCT_CODE_UKID <>", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThan(Short value) {
            addCriterion("PRODUCT_CODE_UKID >", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("PRODUCT_CODE_UKID >=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThan(Short value) {
            addCriterion("PRODUCT_CODE_UKID <", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThanOrEqualTo(Short value) {
            addCriterion("PRODUCT_CODE_UKID <=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIn(List<Short> values) {
            addCriterion("PRODUCT_CODE_UKID in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotIn(List<Short> values) {
            addCriterion("PRODUCT_CODE_UKID not in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidBetween(Short value1, Short value2) {
            addCriterion("PRODUCT_CODE_UKID between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotBetween(Short value1, Short value2) {
            addCriterion("PRODUCT_CODE_UKID not between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("PRODUCT_CODE is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("PRODUCT_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("PRODUCT_CODE =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("PRODUCT_CODE <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("PRODUCT_CODE >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("PRODUCT_CODE <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("PRODUCT_CODE like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("PRODUCT_CODE not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("PRODUCT_CODE in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("PRODUCT_CODE not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNull() {
            addCriterion("PRESALE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNotNull() {
            addCriterion("PRESALE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateEqualTo(Date value) {
            addCriterion("PRESALE_DATE =", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotEqualTo(Date value) {
            addCriterion("PRESALE_DATE <>", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThan(Date value) {
            addCriterion("PRESALE_DATE >", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE >=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThan(Date value) {
            addCriterion("PRESALE_DATE <", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE <=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIn(List<Date> values) {
            addCriterion("PRESALE_DATE in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotIn(List<Date> values) {
            addCriterion("PRESALE_DATE not in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE not between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNull() {
            addCriterion("WORKSPACE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNotNull() {
            addCriterion("WORKSPACE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdEqualTo(String value) {
            addCriterion("WORKSPACE_ID =", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotEqualTo(String value) {
            addCriterion("WORKSPACE_ID <>", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThan(String value) {
            addCriterion("WORKSPACE_ID >", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID >=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThan(String value) {
            addCriterion("WORKSPACE_ID <", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID <=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLike(String value) {
            addCriterion("WORKSPACE_ID like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotLike(String value) {
            addCriterion("WORKSPACE_ID not like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIn(List<String> values) {
            addCriterion("WORKSPACE_ID in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotIn(List<String> values) {
            addCriterion("WORKSPACE_ID not in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID not between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andItemMealNameIsNull() {
            addCriterion("ITEM_MEAL_NAME is null");
            return (Criteria) this;
        }

        public Criteria andItemMealNameIsNotNull() {
            addCriterion("ITEM_MEAL_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andItemMealNameEqualTo(String value) {
            addCriterion("ITEM_MEAL_NAME =", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameNotEqualTo(String value) {
            addCriterion("ITEM_MEAL_NAME <>", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameGreaterThan(String value) {
            addCriterion("ITEM_MEAL_NAME >", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameGreaterThanOrEqualTo(String value) {
            addCriterion("ITEM_MEAL_NAME >=", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameLessThan(String value) {
            addCriterion("ITEM_MEAL_NAME <", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameLessThanOrEqualTo(String value) {
            addCriterion("ITEM_MEAL_NAME <=", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameLike(String value) {
            addCriterion("ITEM_MEAL_NAME like", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameNotLike(String value) {
            addCriterion("ITEM_MEAL_NAME not like", value, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameIn(List<String> values) {
            addCriterion("ITEM_MEAL_NAME in", values, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameNotIn(List<String> values) {
            addCriterion("ITEM_MEAL_NAME not in", values, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameBetween(String value1, String value2) {
            addCriterion("ITEM_MEAL_NAME between", value1, value2, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andItemMealNameNotBetween(String value1, String value2) {
            addCriterion("ITEM_MEAL_NAME not between", value1, value2, "itemMealName");
            return (Criteria) this;
        }

        public Criteria andPicPathIsNull() {
            addCriterion("PIC_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPicPathIsNotNull() {
            addCriterion("PIC_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPicPathEqualTo(String value) {
            addCriterion("PIC_PATH =", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotEqualTo(String value) {
            addCriterion("PIC_PATH <>", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathGreaterThan(String value) {
            addCriterion("PIC_PATH >", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathGreaterThanOrEqualTo(String value) {
            addCriterion("PIC_PATH >=", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLessThan(String value) {
            addCriterion("PIC_PATH <", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLessThanOrEqualTo(String value) {
            addCriterion("PIC_PATH <=", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLike(String value) {
            addCriterion("PIC_PATH like", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotLike(String value) {
            addCriterion("PIC_PATH not like", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathIn(List<String> values) {
            addCriterion("PIC_PATH in", values, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotIn(List<String> values) {
            addCriterion("PIC_PATH not in", values, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathBetween(String value1, String value2) {
            addCriterion("PIC_PATH between", value1, value2, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotBetween(String value1, String value2) {
            addCriterion("PIC_PATH not between", value1, value2, "picPath");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNull() {
            addCriterion("SELLER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNotNull() {
            addCriterion("SELLER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andSellerNickEqualTo(String value) {
            addCriterion("SELLER_NICK =", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotEqualTo(String value) {
            addCriterion("SELLER_NICK <>", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThan(String value) {
            addCriterion("SELLER_NICK >", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK >=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThan(String value) {
            addCriterion("SELLER_NICK <", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK <=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLike(String value) {
            addCriterion("SELLER_NICK like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotLike(String value) {
            addCriterion("SELLER_NICK not like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickIn(List<String> values) {
            addCriterion("SELLER_NICK in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotIn(List<String> values) {
            addCriterion("SELLER_NICK not in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickBetween(String value1, String value2) {
            addCriterion("SELLER_NICK between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotBetween(String value1, String value2) {
            addCriterion("SELLER_NICK not between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIsNull() {
            addCriterion("REFUND_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIsNotNull() {
            addCriterion("REFUND_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andRefundStatusEqualTo(String value) {
            addCriterion("REFUND_STATUS =", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotEqualTo(String value) {
            addCriterion("REFUND_STATUS <>", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusGreaterThan(String value) {
            addCriterion("REFUND_STATUS >", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_STATUS >=", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLessThan(String value) {
            addCriterion("REFUND_STATUS <", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLessThanOrEqualTo(String value) {
            addCriterion("REFUND_STATUS <=", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLike(String value) {
            addCriterion("REFUND_STATUS like", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotLike(String value) {
            addCriterion("REFUND_STATUS not like", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIn(List<String> values) {
            addCriterion("REFUND_STATUS in", values, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotIn(List<String> values) {
            addCriterion("REFUND_STATUS not in", values, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusBetween(String value1, String value2) {
            addCriterion("REFUND_STATUS between", value1, value2, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotBetween(String value1, String value2) {
            addCriterion("REFUND_STATUS not between", value1, value2, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIsNull() {
            addCriterion("PRODUCT_OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIsNotNull() {
            addCriterion("PRODUCT_OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID =", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID <>", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdGreaterThan(String value) {
            addCriterion("PRODUCT_OUTER_ID >", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID >=", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLessThan(String value) {
            addCriterion("PRODUCT_OUTER_ID <", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID <=", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLike(String value) {
            addCriterion("PRODUCT_OUTER_ID like", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotLike(String value) {
            addCriterion("PRODUCT_OUTER_ID not like", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIn(List<String> values) {
            addCriterion("PRODUCT_OUTER_ID in", values, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotIn(List<String> values) {
            addCriterion("PRODUCT_OUTER_ID not in", values, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdBetween(String value1, String value2) {
            addCriterion("PRODUCT_OUTER_ID between", value1, value2, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_OUTER_ID not between", value1, value2, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlIsNull() {
            addCriterion("SNAPSHOT_URL is null");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlIsNotNull() {
            addCriterion("SNAPSHOT_URL is not null");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlEqualTo(String value) {
            addCriterion("SNAPSHOT_URL =", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlNotEqualTo(String value) {
            addCriterion("SNAPSHOT_URL <>", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlGreaterThan(String value) {
            addCriterion("SNAPSHOT_URL >", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlGreaterThanOrEqualTo(String value) {
            addCriterion("SNAPSHOT_URL >=", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlLessThan(String value) {
            addCriterion("SNAPSHOT_URL <", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlLessThanOrEqualTo(String value) {
            addCriterion("SNAPSHOT_URL <=", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlLike(String value) {
            addCriterion("SNAPSHOT_URL like", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlNotLike(String value) {
            addCriterion("SNAPSHOT_URL not like", value, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlIn(List<String> values) {
            addCriterion("SNAPSHOT_URL in", values, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlNotIn(List<String> values) {
            addCriterion("SNAPSHOT_URL not in", values, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlBetween(String value1, String value2) {
            addCriterion("SNAPSHOT_URL between", value1, value2, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotUrlNotBetween(String value1, String value2) {
            addCriterion("SNAPSHOT_URL not between", value1, value2, "snapshotUrl");
            return (Criteria) this;
        }

        public Criteria andSnapshotIsNull() {
            addCriterion("SNAPSHOT is null");
            return (Criteria) this;
        }

        public Criteria andSnapshotIsNotNull() {
            addCriterion("SNAPSHOT is not null");
            return (Criteria) this;
        }

        public Criteria andSnapshotEqualTo(String value) {
            addCriterion("SNAPSHOT =", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotNotEqualTo(String value) {
            addCriterion("SNAPSHOT <>", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotGreaterThan(String value) {
            addCriterion("SNAPSHOT >", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotGreaterThanOrEqualTo(String value) {
            addCriterion("SNAPSHOT >=", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotLessThan(String value) {
            addCriterion("SNAPSHOT <", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotLessThanOrEqualTo(String value) {
            addCriterion("SNAPSHOT <=", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotLike(String value) {
            addCriterion("SNAPSHOT like", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotNotLike(String value) {
            addCriterion("SNAPSHOT not like", value, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotIn(List<String> values) {
            addCriterion("SNAPSHOT in", values, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotNotIn(List<String> values) {
            addCriterion("SNAPSHOT not in", values, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotBetween(String value1, String value2) {
            addCriterion("SNAPSHOT between", value1, value2, "snapshot");
            return (Criteria) this;
        }

        public Criteria andSnapshotNotBetween(String value1, String value2) {
            addCriterion("SNAPSHOT not between", value1, value2, "snapshot");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeIsNull() {
            addCriterion("TIMEOUT_ACTION_TIME is null");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeIsNotNull() {
            addCriterion("TIMEOUT_ACTION_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeEqualTo(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME =", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeNotEqualTo(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME <>", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeGreaterThan(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME >", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME >=", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeLessThan(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME <", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeLessThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_ACTION_TIME <=", value, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeIn(List<Date> values) {
            addCriterion("TIMEOUT_ACTION_TIME in", values, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeNotIn(List<Date> values) {
            addCriterion("TIMEOUT_ACTION_TIME not in", values, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_ACTION_TIME between", value1, value2, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andTimeoutActionTimeNotBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_ACTION_TIME not between", value1, value2, "timeoutActionTime");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIsNull() {
            addCriterion("BUYER_RATE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIsNotNull() {
            addCriterion("BUYER_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerRateEqualTo(Short value) {
            addCriterion("BUYER_RATE =", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotEqualTo(Short value) {
            addCriterion("BUYER_RATE <>", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateGreaterThan(Short value) {
            addCriterion("BUYER_RATE >", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateGreaterThanOrEqualTo(Short value) {
            addCriterion("BUYER_RATE >=", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateLessThan(Short value) {
            addCriterion("BUYER_RATE <", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateLessThanOrEqualTo(Short value) {
            addCriterion("BUYER_RATE <=", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIn(List<Short> values) {
            addCriterion("BUYER_RATE in", values, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotIn(List<Short> values) {
            addCriterion("BUYER_RATE not in", values, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateBetween(Short value1, Short value2) {
            addCriterion("BUYER_RATE between", value1, value2, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotBetween(Short value1, Short value2) {
            addCriterion("BUYER_RATE not between", value1, value2, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateIsNull() {
            addCriterion("SELLER_RATE is null");
            return (Criteria) this;
        }

        public Criteria andSellerRateIsNotNull() {
            addCriterion("SELLER_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andSellerRateEqualTo(Short value) {
            addCriterion("SELLER_RATE =", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotEqualTo(Short value) {
            addCriterion("SELLER_RATE <>", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateGreaterThan(Short value) {
            addCriterion("SELLER_RATE >", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateGreaterThanOrEqualTo(Short value) {
            addCriterion("SELLER_RATE >=", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateLessThan(Short value) {
            addCriterion("SELLER_RATE <", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateLessThanOrEqualTo(Short value) {
            addCriterion("SELLER_RATE <=", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateIn(List<Short> values) {
            addCriterion("SELLER_RATE in", values, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotIn(List<Short> values) {
            addCriterion("SELLER_RATE not in", values, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateBetween(Short value1, Short value2) {
            addCriterion("SELLER_RATE between", value1, value2, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotBetween(Short value1, Short value2) {
            addCriterion("SELLER_RATE not between", value1, value2, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerTypeIsNull() {
            addCriterion("SELLER_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andSellerTypeIsNotNull() {
            addCriterion("SELLER_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andSellerTypeEqualTo(String value) {
            addCriterion("SELLER_TYPE =", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeNotEqualTo(String value) {
            addCriterion("SELLER_TYPE <>", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeGreaterThan(String value) {
            addCriterion("SELLER_TYPE >", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_TYPE >=", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeLessThan(String value) {
            addCriterion("SELLER_TYPE <", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeLessThanOrEqualTo(String value) {
            addCriterion("SELLER_TYPE <=", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeLike(String value) {
            addCriterion("SELLER_TYPE like", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeNotLike(String value) {
            addCriterion("SELLER_TYPE not like", value, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeIn(List<String> values) {
            addCriterion("SELLER_TYPE in", values, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeNotIn(List<String> values) {
            addCriterion("SELLER_TYPE not in", values, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeBetween(String value1, String value2) {
            addCriterion("SELLER_TYPE between", value1, value2, "sellerType");
            return (Criteria) this;
        }

        public Criteria andSellerTypeNotBetween(String value1, String value2) {
            addCriterion("SELLER_TYPE not between", value1, value2, "sellerType");
            return (Criteria) this;
        }

        public Criteria andCidIsNull() {
            addCriterion("CID is null");
            return (Criteria) this;
        }

        public Criteria andCidIsNotNull() {
            addCriterion("CID is not null");
            return (Criteria) this;
        }

        public Criteria andCidEqualTo(Short value) {
            addCriterion("CID =", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotEqualTo(Short value) {
            addCriterion("CID <>", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidGreaterThan(Short value) {
            addCriterion("CID >", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidGreaterThanOrEqualTo(Short value) {
            addCriterion("CID >=", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidLessThan(Short value) {
            addCriterion("CID <", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidLessThanOrEqualTo(Short value) {
            addCriterion("CID <=", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidIn(List<Short> values) {
            addCriterion("CID in", values, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotIn(List<Short> values) {
            addCriterion("CID not in", values, "cid");
            return (Criteria) this;
        }

        public Criteria andCidBetween(Short value1, Short value2) {
            addCriterion("CID between", value1, value2, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotBetween(Short value1, Short value2) {
            addCriterion("CID not between", value1, value2, "cid");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeIsNull() {
            addCriterion("SUB_ORDER_TAX_FEE is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeIsNotNull() {
            addCriterion("SUB_ORDER_TAX_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE =", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeNotEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE <>", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeGreaterThan(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE >", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE >=", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeLessThan(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE <", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_FEE <=", value, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeIn(List<BigDecimal> values) {
            addCriterion("SUB_ORDER_TAX_FEE in", values, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeNotIn(List<BigDecimal> values) {
            addCriterion("SUB_ORDER_TAX_FEE not in", values, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUB_ORDER_TAX_FEE between", value1, value2, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUB_ORDER_TAX_FEE not between", value1, value2, "subOrderTaxFee");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateIsNull() {
            addCriterion("SUB_ORDER_TAX_RATE is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateIsNotNull() {
            addCriterion("SUB_ORDER_TAX_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE =", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateNotEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE <>", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateGreaterThan(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE >", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE >=", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateLessThan(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE <", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SUB_ORDER_TAX_RATE <=", value, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateIn(List<BigDecimal> values) {
            addCriterion("SUB_ORDER_TAX_RATE in", values, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateNotIn(List<BigDecimal> values) {
            addCriterion("SUB_ORDER_TAX_RATE not in", values, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUB_ORDER_TAX_RATE between", value1, value2, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderTaxRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SUB_ORDER_TAX_RATE not between", value1, value2, "subOrderTaxRate");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNull() {
            addCriterion("SUB_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNotNull() {
            addCriterion("SUB_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdEqualTo(Short value) {
            addCriterion("SUB_ORDER_ID =", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotEqualTo(Short value) {
            addCriterion("SUB_ORDER_ID <>", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThan(Short value) {
            addCriterion("SUB_ORDER_ID >", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThanOrEqualTo(Short value) {
            addCriterion("SUB_ORDER_ID >=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThan(Short value) {
            addCriterion("SUB_ORDER_ID <", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThanOrEqualTo(Short value) {
            addCriterion("SUB_ORDER_ID <=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIn(List<Short> values) {
            addCriterion("SUB_ORDER_ID in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotIn(List<Short> values) {
            addCriterion("SUB_ORDER_ID not in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdBetween(Short value1, Short value2) {
            addCriterion("SUB_ORDER_ID between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotBetween(Short value1, Short value2) {
            addCriterion("SUB_ORDER_ID not between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusIsNull() {
            addCriterion("SUB_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusIsNotNull() {
            addCriterion("SUB_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusEqualTo(String value) {
            addCriterion("SUB_ORDER_STATUS =", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusNotEqualTo(String value) {
            addCriterion("SUB_ORDER_STATUS <>", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusGreaterThan(String value) {
            addCriterion("SUB_ORDER_STATUS >", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_STATUS >=", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusLessThan(String value) {
            addCriterion("SUB_ORDER_STATUS <", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_STATUS <=", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusLike(String value) {
            addCriterion("SUB_ORDER_STATUS like", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusNotLike(String value) {
            addCriterion("SUB_ORDER_STATUS not like", value, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusIn(List<String> values) {
            addCriterion("SUB_ORDER_STATUS in", values, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusNotIn(List<String> values) {
            addCriterion("SUB_ORDER_STATUS not in", values, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_STATUS between", value1, value2, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderStatusNotBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_STATUS not between", value1, value2, "subOrderStatus");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNull() {
            addCriterion("PRODUCT_NAME is null");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNotNull() {
            addCriterion("PRODUCT_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andProductNameEqualTo(String value) {
            addCriterion("PRODUCT_NAME =", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotEqualTo(String value) {
            addCriterion("PRODUCT_NAME <>", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThan(String value) {
            addCriterion("PRODUCT_NAME >", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NAME >=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThan(String value) {
            addCriterion("PRODUCT_NAME <", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NAME <=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLike(String value) {
            addCriterion("PRODUCT_NAME like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotLike(String value) {
            addCriterion("PRODUCT_NAME not like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameIn(List<String> values) {
            addCriterion("PRODUCT_NAME in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotIn(List<String> values) {
            addCriterion("PRODUCT_NAME not in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameBetween(String value1, String value2) {
            addCriterion("PRODUCT_NAME between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_NAME not between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("TYPE =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("TYPE <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("TYPE >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TYPE >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("TYPE <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("TYPE <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("TYPE like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("TYPE not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("TYPE in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("TYPE not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("TYPE between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("TYPE not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andIidIsNull() {
            addCriterion("IID is null");
            return (Criteria) this;
        }

        public Criteria andIidIsNotNull() {
            addCriterion("IID is not null");
            return (Criteria) this;
        }

        public Criteria andIidEqualTo(String value) {
            addCriterion("IID =", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidNotEqualTo(String value) {
            addCriterion("IID <>", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidGreaterThan(String value) {
            addCriterion("IID >", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidGreaterThanOrEqualTo(String value) {
            addCriterion("IID >=", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidLessThan(String value) {
            addCriterion("IID <", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidLessThanOrEqualTo(String value) {
            addCriterion("IID <=", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidLike(String value) {
            addCriterion("IID like", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidNotLike(String value) {
            addCriterion("IID not like", value, "iid");
            return (Criteria) this;
        }

        public Criteria andIidIn(List<String> values) {
            addCriterion("IID in", values, "iid");
            return (Criteria) this;
        }

        public Criteria andIidNotIn(List<String> values) {
            addCriterion("IID not in", values, "iid");
            return (Criteria) this;
        }

        public Criteria andIidBetween(String value1, String value2) {
            addCriterion("IID between", value1, value2, "iid");
            return (Criteria) this;
        }

        public Criteria andIidNotBetween(String value1, String value2) {
            addCriterion("IID not between", value1, value2, "iid");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("PRICE is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(BigDecimal value) {
            addCriterion("PRICE =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(BigDecimal value) {
            addCriterion("PRICE <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(BigDecimal value) {
            addCriterion("PRICE >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(BigDecimal value) {
            addCriterion("PRICE <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<BigDecimal> values) {
            addCriterion("PRICE in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<BigDecimal> values) {
            addCriterion("PRICE not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE not between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIsNull() {
            addCriterion("PRODUCT_NUM_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIsNotNull() {
            addCriterion("PRODUCT_NUM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductNumIdEqualTo(Short value) {
            addCriterion("PRODUCT_NUM_ID =", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotEqualTo(Short value) {
            addCriterion("PRODUCT_NUM_ID <>", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdGreaterThan(Short value) {
            addCriterion("PRODUCT_NUM_ID >", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdGreaterThanOrEqualTo(Short value) {
            addCriterion("PRODUCT_NUM_ID >=", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdLessThan(Short value) {
            addCriterion("PRODUCT_NUM_ID <", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdLessThanOrEqualTo(Short value) {
            addCriterion("PRODUCT_NUM_ID <=", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIn(List<Short> values) {
            addCriterion("PRODUCT_NUM_ID in", values, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotIn(List<Short> values) {
            addCriterion("PRODUCT_NUM_ID not in", values, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdBetween(Short value1, Short value2) {
            addCriterion("PRODUCT_NUM_ID between", value1, value2, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotBetween(Short value1, Short value2) {
            addCriterion("PRODUCT_NUM_ID not between", value1, value2, "productNumId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdIsNull() {
            addCriterion("ITEM_MEAL_ID is null");
            return (Criteria) this;
        }

        public Criteria andItemMealIdIsNotNull() {
            addCriterion("ITEM_MEAL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andItemMealIdEqualTo(Short value) {
            addCriterion("ITEM_MEAL_ID =", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdNotEqualTo(Short value) {
            addCriterion("ITEM_MEAL_ID <>", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdGreaterThan(Short value) {
            addCriterion("ITEM_MEAL_ID >", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdGreaterThanOrEqualTo(Short value) {
            addCriterion("ITEM_MEAL_ID >=", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdLessThan(Short value) {
            addCriterion("ITEM_MEAL_ID <", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdLessThanOrEqualTo(Short value) {
            addCriterion("ITEM_MEAL_ID <=", value, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdIn(List<Short> values) {
            addCriterion("ITEM_MEAL_ID in", values, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdNotIn(List<Short> values) {
            addCriterion("ITEM_MEAL_ID not in", values, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdBetween(Short value1, Short value2) {
            addCriterion("ITEM_MEAL_ID between", value1, value2, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andItemMealIdNotBetween(Short value1, Short value2) {
            addCriterion("ITEM_MEAL_ID not between", value1, value2, "itemMealId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIsNull() {
            addCriterion("SKU_NUM_ID is null");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIsNotNull() {
            addCriterion("SKU_NUM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdEqualTo(String value) {
            addCriterion("SKU_NUM_ID =", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotEqualTo(String value) {
            addCriterion("SKU_NUM_ID <>", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdGreaterThan(String value) {
            addCriterion("SKU_NUM_ID >", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_NUM_ID >=", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLessThan(String value) {
            addCriterion("SKU_NUM_ID <", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLessThanOrEqualTo(String value) {
            addCriterion("SKU_NUM_ID <=", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLike(String value) {
            addCriterion("SKU_NUM_ID like", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotLike(String value) {
            addCriterion("SKU_NUM_ID not like", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIn(List<String> values) {
            addCriterion("SKU_NUM_ID in", values, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotIn(List<String> values) {
            addCriterion("SKU_NUM_ID not in", values, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdBetween(String value1, String value2) {
            addCriterion("SKU_NUM_ID between", value1, value2, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotBetween(String value1, String value2) {
            addCriterion("SKU_NUM_ID not between", value1, value2, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andQtyIsNull() {
            addCriterion("QTY is null");
            return (Criteria) this;
        }

        public Criteria andQtyIsNotNull() {
            addCriterion("QTY is not null");
            return (Criteria) this;
        }

        public Criteria andQtyEqualTo(Short value) {
            addCriterion("QTY =", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyNotEqualTo(Short value) {
            addCriterion("QTY <>", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyGreaterThan(Short value) {
            addCriterion("QTY >", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyGreaterThanOrEqualTo(Short value) {
            addCriterion("QTY >=", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyLessThan(Short value) {
            addCriterion("QTY <", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyLessThanOrEqualTo(Short value) {
            addCriterion("QTY <=", value, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyIn(List<Short> values) {
            addCriterion("QTY in", values, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyNotIn(List<Short> values) {
            addCriterion("QTY not in", values, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyBetween(Short value1, Short value2) {
            addCriterion("QTY between", value1, value2, "qty");
            return (Criteria) this;
        }

        public Criteria andQtyNotBetween(Short value1, Short value2) {
            addCriterion("QTY not between", value1, value2, "qty");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIsNull() {
            addCriterion("SKU_OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIsNotNull() {
            addCriterion("SKU_OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdEqualTo(String value) {
            addCriterion("SKU_OUTER_ID =", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotEqualTo(String value) {
            addCriterion("SKU_OUTER_ID <>", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdGreaterThan(String value) {
            addCriterion("SKU_OUTER_ID >", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_OUTER_ID >=", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLessThan(String value) {
            addCriterion("SKU_OUTER_ID <", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLessThanOrEqualTo(String value) {
            addCriterion("SKU_OUTER_ID <=", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLike(String value) {
            addCriterion("SKU_OUTER_ID like", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotLike(String value) {
            addCriterion("SKU_OUTER_ID not like", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIn(List<String> values) {
            addCriterion("SKU_OUTER_ID in", values, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotIn(List<String> values) {
            addCriterion("SKU_OUTER_ID not in", values, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdBetween(String value1, String value2) {
            addCriterion("SKU_OUTER_ID between", value1, value2, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotBetween(String value1, String value2) {
            addCriterion("SKU_OUTER_ID not between", value1, value2, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andOrderFromIsNull() {
            addCriterion("ORDER_FROM is null");
            return (Criteria) this;
        }

        public Criteria andOrderFromIsNotNull() {
            addCriterion("ORDER_FROM is not null");
            return (Criteria) this;
        }

        public Criteria andOrderFromEqualTo(String value) {
            addCriterion("ORDER_FROM =", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromNotEqualTo(String value) {
            addCriterion("ORDER_FROM <>", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromGreaterThan(String value) {
            addCriterion("ORDER_FROM >", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_FROM >=", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromLessThan(String value) {
            addCriterion("ORDER_FROM <", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromLessThanOrEqualTo(String value) {
            addCriterion("ORDER_FROM <=", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromLike(String value) {
            addCriterion("ORDER_FROM like", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromNotLike(String value) {
            addCriterion("ORDER_FROM not like", value, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromIn(List<String> values) {
            addCriterion("ORDER_FROM in", values, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromNotIn(List<String> values) {
            addCriterion("ORDER_FROM not in", values, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromBetween(String value1, String value2) {
            addCriterion("ORDER_FROM between", value1, value2, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andOrderFromNotBetween(String value1, String value2) {
            addCriterion("ORDER_FROM not between", value1, value2, "orderFrom");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNull() {
            addCriterion("TOTAL_FEE is null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNotNull() {
            addCriterion("TOTAL_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE =", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <>", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThan(BigDecimal value) {
            addCriterion("TOTAL_FEE >", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE >=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThan(BigDecimal value) {
            addCriterion("TOTAL_FEE <", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE not in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE not between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNull() {
            addCriterion("PAYMENT is null");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNotNull() {
            addCriterion("PAYMENT is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentEqualTo(BigDecimal value) {
            addCriterion("PAYMENT =", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <>", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThan(BigDecimal value) {
            addCriterion("PAYMENT >", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT >=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThan(BigDecimal value) {
            addCriterion("PAYMENT <", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentIn(List<BigDecimal> values) {
            addCriterion("PAYMENT in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotIn(List<BigDecimal> values) {
            addCriterion("PAYMENT not in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT not between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIsNull() {
            addCriterion("DISCOUNT_FEE is null");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIsNotNull() {
            addCriterion("DISCOUNT_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE =", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <>", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeGreaterThan(BigDecimal value) {
            addCriterion("DISCOUNT_FEE >", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE >=", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeLessThan(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <=", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_FEE in", values, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_FEE not in", values, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_FEE between", value1, value2, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_FEE not between", value1, value2, "discountFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIsNull() {
            addCriterion("ADJUST_FEE is null");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIsNotNull() {
            addCriterion("ADJUST_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE =", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE <>", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeGreaterThan(BigDecimal value) {
            addCriterion("ADJUST_FEE >", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE >=", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeLessThan(BigDecimal value) {
            addCriterion("ADJUST_FEE <", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE <=", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIn(List<BigDecimal> values) {
            addCriterion("ADJUST_FEE in", values, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotIn(List<BigDecimal> values) {
            addCriterion("ADJUST_FEE not in", values, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ADJUST_FEE between", value1, value2, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ADJUST_FEE not between", value1, value2, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andModifiedIsNull() {
            addCriterion("MODIFIED is null");
            return (Criteria) this;
        }

        public Criteria andModifiedIsNotNull() {
            addCriterion("MODIFIED is not null");
            return (Criteria) this;
        }

        public Criteria andModifiedEqualTo(Date value) {
            addCriterion("MODIFIED =", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotEqualTo(Date value) {
            addCriterion("MODIFIED <>", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedGreaterThan(Date value) {
            addCriterion("MODIFIED >", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFIED >=", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedLessThan(Date value) {
            addCriterion("MODIFIED <", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedLessThanOrEqualTo(Date value) {
            addCriterion("MODIFIED <=", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedIn(List<Date> values) {
            addCriterion("MODIFIED in", values, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotIn(List<Date> values) {
            addCriterion("MODIFIED not in", values, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedBetween(Date value1, Date value2) {
            addCriterion("MODIFIED between", value1, value2, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotBetween(Date value1, Date value2) {
            addCriterion("MODIFIED not between", value1, value2, "modified");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameIsNull() {
            addCriterion("SKU_PROPERTIES_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameIsNotNull() {
            addCriterion("SKU_PROPERTIES_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameEqualTo(String value) {
            addCriterion("SKU_PROPERTIES_NAME =", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameNotEqualTo(String value) {
            addCriterion("SKU_PROPERTIES_NAME <>", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameGreaterThan(String value) {
            addCriterion("SKU_PROPERTIES_NAME >", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_PROPERTIES_NAME >=", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameLessThan(String value) {
            addCriterion("SKU_PROPERTIES_NAME <", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameLessThanOrEqualTo(String value) {
            addCriterion("SKU_PROPERTIES_NAME <=", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameLike(String value) {
            addCriterion("SKU_PROPERTIES_NAME like", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameNotLike(String value) {
            addCriterion("SKU_PROPERTIES_NAME not like", value, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameIn(List<String> values) {
            addCriterion("SKU_PROPERTIES_NAME in", values, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameNotIn(List<String> values) {
            addCriterion("SKU_PROPERTIES_NAME not in", values, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameBetween(String value1, String value2) {
            addCriterion("SKU_PROPERTIES_NAME between", value1, value2, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andSkuPropertiesNameNotBetween(String value1, String value2) {
            addCriterion("SKU_PROPERTIES_NAME not between", value1, value2, "skuPropertiesName");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNull() {
            addCriterion("REFUND_ID is null");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNotNull() {
            addCriterion("REFUND_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundIdEqualTo(Short value) {
            addCriterion("REFUND_ID =", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotEqualTo(Short value) {
            addCriterion("REFUND_ID <>", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThan(Short value) {
            addCriterion("REFUND_ID >", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThanOrEqualTo(Short value) {
            addCriterion("REFUND_ID >=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThan(Short value) {
            addCriterion("REFUND_ID <", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThanOrEqualTo(Short value) {
            addCriterion("REFUND_ID <=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdIn(List<Short> values) {
            addCriterion("REFUND_ID in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotIn(List<Short> values) {
            addCriterion("REFUND_ID not in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdBetween(Short value1, Short value2) {
            addCriterion("REFUND_ID between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotBetween(Short value1, Short value2) {
            addCriterion("REFUND_ID not between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andIsOversoldIsNull() {
            addCriterion("IS_OVERSOLD is null");
            return (Criteria) this;
        }

        public Criteria andIsOversoldIsNotNull() {
            addCriterion("IS_OVERSOLD is not null");
            return (Criteria) this;
        }

        public Criteria andIsOversoldEqualTo(Short value) {
            addCriterion("IS_OVERSOLD =", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldNotEqualTo(Short value) {
            addCriterion("IS_OVERSOLD <>", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldGreaterThan(Short value) {
            addCriterion("IS_OVERSOLD >", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldGreaterThanOrEqualTo(Short value) {
            addCriterion("IS_OVERSOLD >=", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldLessThan(Short value) {
            addCriterion("IS_OVERSOLD <", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldLessThanOrEqualTo(Short value) {
            addCriterion("IS_OVERSOLD <=", value, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldIn(List<Short> values) {
            addCriterion("IS_OVERSOLD in", values, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldNotIn(List<Short> values) {
            addCriterion("IS_OVERSOLD not in", values, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldBetween(Short value1, Short value2) {
            addCriterion("IS_OVERSOLD between", value1, value2, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsOversoldNotBetween(Short value1, Short value2) {
            addCriterion("IS_OVERSOLD not between", value1, value2, "isOversold");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderIsNull() {
            addCriterion("IS_SERVICE_ORDER is null");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderIsNotNull() {
            addCriterion("IS_SERVICE_ORDER is not null");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderEqualTo(Short value) {
            addCriterion("IS_SERVICE_ORDER =", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderNotEqualTo(Short value) {
            addCriterion("IS_SERVICE_ORDER <>", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderGreaterThan(Short value) {
            addCriterion("IS_SERVICE_ORDER >", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderGreaterThanOrEqualTo(Short value) {
            addCriterion("IS_SERVICE_ORDER >=", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderLessThan(Short value) {
            addCriterion("IS_SERVICE_ORDER <", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderLessThanOrEqualTo(Short value) {
            addCriterion("IS_SERVICE_ORDER <=", value, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderIn(List<Short> values) {
            addCriterion("IS_SERVICE_ORDER in", values, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderNotIn(List<Short> values) {
            addCriterion("IS_SERVICE_ORDER not in", values, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderBetween(Short value1, Short value2) {
            addCriterion("IS_SERVICE_ORDER between", value1, value2, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andIsServiceOrderNotBetween(Short value1, Short value2) {
            addCriterion("IS_SERVICE_ORDER not between", value1, value2, "isServiceOrder");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNull() {
            addCriterion("END_TIME is null");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNotNull() {
            addCriterion("END_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andEndTimeEqualTo(Date value) {
            addCriterion("END_TIME =", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotEqualTo(Date value) {
            addCriterion("END_TIME <>", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThan(Date value) {
            addCriterion("END_TIME >", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("END_TIME >=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThan(Date value) {
            addCriterion("END_TIME <", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("END_TIME <=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIn(List<Date> values) {
            addCriterion("END_TIME in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotIn(List<Date> values) {
            addCriterion("END_TIME not in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeBetween(Date value1, Date value2) {
            addCriterion("END_TIME between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("END_TIME not between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNull() {
            addCriterion("CONSIGN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNotNull() {
            addCriterion("CONSIGN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeEqualTo(Date value) {
            addCriterion("CONSIGN_TIME =", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <>", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThan(Date value) {
            addCriterion("CONSIGN_TIME >", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME >=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThan(Date value) {
            addCriterion("CONSIGN_TIME <", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIn(List<Date> values) {
            addCriterion("CONSIGN_TIME in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotIn(List<Date> values) {
            addCriterion("CONSIGN_TIME not in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME not between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNull() {
            addCriterion("SHIPPING_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNotNull() {
            addCriterion("SHIPPING_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeEqualTo(String value) {
            addCriterion("SHIPPING_TYPE =", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <>", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThan(String value) {
            addCriterion("SHIPPING_TYPE >", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE >=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThan(String value) {
            addCriterion("SHIPPING_TYPE <", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLike(String value) {
            addCriterion("SHIPPING_TYPE like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotLike(String value) {
            addCriterion("SHIPPING_TYPE not like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIn(List<String> values) {
            addCriterion("SHIPPING_TYPE in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotIn(List<String> values) {
            addCriterion("SHIPPING_TYPE not in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE not between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andBindOidIsNull() {
            addCriterion("BIND_OID is null");
            return (Criteria) this;
        }

        public Criteria andBindOidIsNotNull() {
            addCriterion("BIND_OID is not null");
            return (Criteria) this;
        }

        public Criteria andBindOidEqualTo(Short value) {
            addCriterion("BIND_OID =", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidNotEqualTo(Short value) {
            addCriterion("BIND_OID <>", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidGreaterThan(Short value) {
            addCriterion("BIND_OID >", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidGreaterThanOrEqualTo(Short value) {
            addCriterion("BIND_OID >=", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidLessThan(Short value) {
            addCriterion("BIND_OID <", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidLessThanOrEqualTo(Short value) {
            addCriterion("BIND_OID <=", value, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidIn(List<Short> values) {
            addCriterion("BIND_OID in", values, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidNotIn(List<Short> values) {
            addCriterion("BIND_OID not in", values, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidBetween(Short value1, Short value2) {
            addCriterion("BIND_OID between", value1, value2, "bindOid");
            return (Criteria) this;
        }

        public Criteria andBindOidNotBetween(Short value1, Short value2) {
            addCriterion("BIND_OID not between", value1, value2, "bindOid");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyIsNull() {
            addCriterion("LOGISTICS_COMPANY is null");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyIsNotNull() {
            addCriterion("LOGISTICS_COMPANY is not null");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyEqualTo(String value) {
            addCriterion("LOGISTICS_COMPANY =", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyNotEqualTo(String value) {
            addCriterion("LOGISTICS_COMPANY <>", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyGreaterThan(String value) {
            addCriterion("LOGISTICS_COMPANY >", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyGreaterThanOrEqualTo(String value) {
            addCriterion("LOGISTICS_COMPANY >=", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyLessThan(String value) {
            addCriterion("LOGISTICS_COMPANY <", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyLessThanOrEqualTo(String value) {
            addCriterion("LOGISTICS_COMPANY <=", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyLike(String value) {
            addCriterion("LOGISTICS_COMPANY like", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyNotLike(String value) {
            addCriterion("LOGISTICS_COMPANY not like", value, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyIn(List<String> values) {
            addCriterion("LOGISTICS_COMPANY in", values, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyNotIn(List<String> values) {
            addCriterion("LOGISTICS_COMPANY not in", values, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyBetween(String value1, String value2) {
            addCriterion("LOGISTICS_COMPANY between", value1, value2, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andLogisticsCompanyNotBetween(String value1, String value2) {
            addCriterion("LOGISTICS_COMPANY not between", value1, value2, "logisticsCompany");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoIsNull() {
            addCriterion("INVOICE_NO is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoIsNotNull() {
            addCriterion("INVOICE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoEqualTo(String value) {
            addCriterion("INVOICE_NO =", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoNotEqualTo(String value) {
            addCriterion("INVOICE_NO <>", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoGreaterThan(String value) {
            addCriterion("INVOICE_NO >", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_NO >=", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoLessThan(String value) {
            addCriterion("INVOICE_NO <", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_NO <=", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoLike(String value) {
            addCriterion("INVOICE_NO like", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoNotLike(String value) {
            addCriterion("INVOICE_NO not like", value, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoIn(List<String> values) {
            addCriterion("INVOICE_NO in", values, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoNotIn(List<String> values) {
            addCriterion("INVOICE_NO not in", values, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoBetween(String value1, String value2) {
            addCriterion("INVOICE_NO between", value1, value2, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andInvoiceNoNotBetween(String value1, String value2) {
            addCriterion("INVOICE_NO not between", value1, value2, "invoiceNo");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoIsNull() {
            addCriterion("IS_DAIXIAO is null");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoIsNotNull() {
            addCriterion("IS_DAIXIAO is not null");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoEqualTo(Short value) {
            addCriterion("IS_DAIXIAO =", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoNotEqualTo(Short value) {
            addCriterion("IS_DAIXIAO <>", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoGreaterThan(Short value) {
            addCriterion("IS_DAIXIAO >", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoGreaterThanOrEqualTo(Short value) {
            addCriterion("IS_DAIXIAO >=", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoLessThan(Short value) {
            addCriterion("IS_DAIXIAO <", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoLessThanOrEqualTo(Short value) {
            addCriterion("IS_DAIXIAO <=", value, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoIn(List<Short> values) {
            addCriterion("IS_DAIXIAO in", values, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoNotIn(List<Short> values) {
            addCriterion("IS_DAIXIAO not in", values, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoBetween(Short value1, Short value2) {
            addCriterion("IS_DAIXIAO between", value1, value2, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andIsDaixiaoNotBetween(Short value1, Short value2) {
            addCriterion("IS_DAIXIAO not between", value1, value2, "isDaixiao");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeIsNull() {
            addCriterion("DIVIDE_ORDER_FEE is null");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeIsNotNull() {
            addCriterion("DIVIDE_ORDER_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeEqualTo(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE =", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeNotEqualTo(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE <>", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeGreaterThan(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE >", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE >=", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeLessThan(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE <", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DIVIDE_ORDER_FEE <=", value, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeIn(List<BigDecimal> values) {
            addCriterion("DIVIDE_ORDER_FEE in", values, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeNotIn(List<BigDecimal> values) {
            addCriterion("DIVIDE_ORDER_FEE not in", values, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DIVIDE_ORDER_FEE between", value1, value2, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andDivideOrderFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DIVIDE_ORDER_FEE not between", value1, value2, "divideOrderFee");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountIsNull() {
            addCriterion("PART_MJZ_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountIsNotNull() {
            addCriterion("PART_MJZ_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountEqualTo(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT =", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountNotEqualTo(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT <>", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountGreaterThan(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT >", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT >=", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountLessThan(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT <", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PART_MJZ_DISCOUNT <=", value, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountIn(List<BigDecimal> values) {
            addCriterion("PART_MJZ_DISCOUNT in", values, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountNotIn(List<BigDecimal> values) {
            addCriterion("PART_MJZ_DISCOUNT not in", values, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PART_MJZ_DISCOUNT between", value1, value2, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andPartMjzDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PART_MJZ_DISCOUNT not between", value1, value2, "partMjzDiscount");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdIsNull() {
            addCriterion("TICKET_OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdIsNotNull() {
            addCriterion("TICKET_OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdEqualTo(String value) {
            addCriterion("TICKET_OUTER_ID =", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdNotEqualTo(String value) {
            addCriterion("TICKET_OUTER_ID <>", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdGreaterThan(String value) {
            addCriterion("TICKET_OUTER_ID >", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("TICKET_OUTER_ID >=", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdLessThan(String value) {
            addCriterion("TICKET_OUTER_ID <", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdLessThanOrEqualTo(String value) {
            addCriterion("TICKET_OUTER_ID <=", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdLike(String value) {
            addCriterion("TICKET_OUTER_ID like", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdNotLike(String value) {
            addCriterion("TICKET_OUTER_ID not like", value, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdIn(List<String> values) {
            addCriterion("TICKET_OUTER_ID in", values, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdNotIn(List<String> values) {
            addCriterion("TICKET_OUTER_ID not in", values, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdBetween(String value1, String value2) {
            addCriterion("TICKET_OUTER_ID between", value1, value2, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketOuterIdNotBetween(String value1, String value2) {
            addCriterion("TICKET_OUTER_ID not between", value1, value2, "ticketOuterId");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyIsNull() {
            addCriterion("TICKET_EXPDATE_KEY is null");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyIsNotNull() {
            addCriterion("TICKET_EXPDATE_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyEqualTo(String value) {
            addCriterion("TICKET_EXPDATE_KEY =", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyNotEqualTo(String value) {
            addCriterion("TICKET_EXPDATE_KEY <>", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyGreaterThan(String value) {
            addCriterion("TICKET_EXPDATE_KEY >", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyGreaterThanOrEqualTo(String value) {
            addCriterion("TICKET_EXPDATE_KEY >=", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyLessThan(String value) {
            addCriterion("TICKET_EXPDATE_KEY <", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyLessThanOrEqualTo(String value) {
            addCriterion("TICKET_EXPDATE_KEY <=", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyLike(String value) {
            addCriterion("TICKET_EXPDATE_KEY like", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyNotLike(String value) {
            addCriterion("TICKET_EXPDATE_KEY not like", value, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyIn(List<String> values) {
            addCriterion("TICKET_EXPDATE_KEY in", values, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyNotIn(List<String> values) {
            addCriterion("TICKET_EXPDATE_KEY not in", values, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyBetween(String value1, String value2) {
            addCriterion("TICKET_EXPDATE_KEY between", value1, value2, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andTicketExpdateKeyNotBetween(String value1, String value2) {
            addCriterion("TICKET_EXPDATE_KEY not between", value1, value2, "ticketExpdateKey");
            return (Criteria) this;
        }

        public Criteria andStoreCodeIsNull() {
            addCriterion("STORE_CODE is null");
            return (Criteria) this;
        }

        public Criteria andStoreCodeIsNotNull() {
            addCriterion("STORE_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andStoreCodeEqualTo(String value) {
            addCriterion("STORE_CODE =", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeNotEqualTo(String value) {
            addCriterion("STORE_CODE <>", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeGreaterThan(String value) {
            addCriterion("STORE_CODE >", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeGreaterThanOrEqualTo(String value) {
            addCriterion("STORE_CODE >=", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeLessThan(String value) {
            addCriterion("STORE_CODE <", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeLessThanOrEqualTo(String value) {
            addCriterion("STORE_CODE <=", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeLike(String value) {
            addCriterion("STORE_CODE like", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeNotLike(String value) {
            addCriterion("STORE_CODE not like", value, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeIn(List<String> values) {
            addCriterion("STORE_CODE in", values, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeNotIn(List<String> values) {
            addCriterion("STORE_CODE not in", values, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeBetween(String value1, String value2) {
            addCriterion("STORE_CODE between", value1, value2, "storeCode");
            return (Criteria) this;
        }

        public Criteria andStoreCodeNotBetween(String value1, String value2) {
            addCriterion("STORE_CODE not between", value1, value2, "storeCode");
            return (Criteria) this;
        }

        public Criteria andIsWwwIsNull() {
            addCriterion("IS_WWW is null");
            return (Criteria) this;
        }

        public Criteria andIsWwwIsNotNull() {
            addCriterion("IS_WWW is not null");
            return (Criteria) this;
        }

        public Criteria andIsWwwEqualTo(Short value) {
            addCriterion("IS_WWW =", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwNotEqualTo(Short value) {
            addCriterion("IS_WWW <>", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwGreaterThan(Short value) {
            addCriterion("IS_WWW >", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwGreaterThanOrEqualTo(Short value) {
            addCriterion("IS_WWW >=", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwLessThan(Short value) {
            addCriterion("IS_WWW <", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwLessThanOrEqualTo(Short value) {
            addCriterion("IS_WWW <=", value, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwIn(List<Short> values) {
            addCriterion("IS_WWW in", values, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwNotIn(List<Short> values) {
            addCriterion("IS_WWW not in", values, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwBetween(Short value1, Short value2) {
            addCriterion("IS_WWW between", value1, value2, "isWww");
            return (Criteria) this;
        }

        public Criteria andIsWwwNotBetween(Short value1, Short value2) {
            addCriterion("IS_WWW not between", value1, value2, "isWww");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeIsNull() {
            addCriterion("TMSER_SPU_CODE is null");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeIsNotNull() {
            addCriterion("TMSER_SPU_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeEqualTo(String value) {
            addCriterion("TMSER_SPU_CODE =", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeNotEqualTo(String value) {
            addCriterion("TMSER_SPU_CODE <>", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeGreaterThan(String value) {
            addCriterion("TMSER_SPU_CODE >", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeGreaterThanOrEqualTo(String value) {
            addCriterion("TMSER_SPU_CODE >=", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeLessThan(String value) {
            addCriterion("TMSER_SPU_CODE <", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeLessThanOrEqualTo(String value) {
            addCriterion("TMSER_SPU_CODE <=", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeLike(String value) {
            addCriterion("TMSER_SPU_CODE like", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeNotLike(String value) {
            addCriterion("TMSER_SPU_CODE not like", value, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeIn(List<String> values) {
            addCriterion("TMSER_SPU_CODE in", values, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeNotIn(List<String> values) {
            addCriterion("TMSER_SPU_CODE not in", values, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeBetween(String value1, String value2) {
            addCriterion("TMSER_SPU_CODE between", value1, value2, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andTmserSpuCodeNotBetween(String value1, String value2) {
            addCriterion("TMSER_SPU_CODE not between", value1, value2, "tmserSpuCode");
            return (Criteria) this;
        }

        public Criteria andBindOidsIsNull() {
            addCriterion("BIND_OIDS is null");
            return (Criteria) this;
        }

        public Criteria andBindOidsIsNotNull() {
            addCriterion("BIND_OIDS is not null");
            return (Criteria) this;
        }

        public Criteria andBindOidsEqualTo(String value) {
            addCriterion("BIND_OIDS =", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsNotEqualTo(String value) {
            addCriterion("BIND_OIDS <>", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsGreaterThan(String value) {
            addCriterion("BIND_OIDS >", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsGreaterThanOrEqualTo(String value) {
            addCriterion("BIND_OIDS >=", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsLessThan(String value) {
            addCriterion("BIND_OIDS <", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsLessThanOrEqualTo(String value) {
            addCriterion("BIND_OIDS <=", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsLike(String value) {
            addCriterion("BIND_OIDS like", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsNotLike(String value) {
            addCriterion("BIND_OIDS not like", value, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsIn(List<String> values) {
            addCriterion("BIND_OIDS in", values, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsNotIn(List<String> values) {
            addCriterion("BIND_OIDS not in", values, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsBetween(String value1, String value2) {
            addCriterion("BIND_OIDS between", value1, value2, "bindOids");
            return (Criteria) this;
        }

        public Criteria andBindOidsNotBetween(String value1, String value2) {
            addCriterion("BIND_OIDS not between", value1, value2, "bindOids");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIsNull() {
            addCriterion("ZHENGJI_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIsNotNull() {
            addCriterion("ZHENGJI_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS =", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS <>", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusGreaterThan(Short value) {
            addCriterion("ZHENGJI_STATUS >", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS >=", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusLessThan(Short value) {
            addCriterion("ZHENGJI_STATUS <", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusLessThanOrEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS <=", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIn(List<Short> values) {
            addCriterion("ZHENGJI_STATUS in", values, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotIn(List<Short> values) {
            addCriterion("ZHENGJI_STATUS not in", values, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusBetween(Short value1, Short value2) {
            addCriterion("ZHENGJI_STATUS between", value1, value2, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotBetween(Short value1, Short value2) {
            addCriterion("ZHENGJI_STATUS not between", value1, value2, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andMdQualificationIsNull() {
            addCriterion("MD_QUALIFICATION is null");
            return (Criteria) this;
        }

        public Criteria andMdQualificationIsNotNull() {
            addCriterion("MD_QUALIFICATION is not null");
            return (Criteria) this;
        }

        public Criteria andMdQualificationEqualTo(String value) {
            addCriterion("MD_QUALIFICATION =", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationNotEqualTo(String value) {
            addCriterion("MD_QUALIFICATION <>", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationGreaterThan(String value) {
            addCriterion("MD_QUALIFICATION >", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationGreaterThanOrEqualTo(String value) {
            addCriterion("MD_QUALIFICATION >=", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationLessThan(String value) {
            addCriterion("MD_QUALIFICATION <", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationLessThanOrEqualTo(String value) {
            addCriterion("MD_QUALIFICATION <=", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationLike(String value) {
            addCriterion("MD_QUALIFICATION like", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationNotLike(String value) {
            addCriterion("MD_QUALIFICATION not like", value, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationIn(List<String> values) {
            addCriterion("MD_QUALIFICATION in", values, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationNotIn(List<String> values) {
            addCriterion("MD_QUALIFICATION not in", values, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationBetween(String value1, String value2) {
            addCriterion("MD_QUALIFICATION between", value1, value2, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdQualificationNotBetween(String value1, String value2) {
            addCriterion("MD_QUALIFICATION not between", value1, value2, "mdQualification");
            return (Criteria) this;
        }

        public Criteria andMdFeeIsNull() {
            addCriterion("MD_FEE is null");
            return (Criteria) this;
        }

        public Criteria andMdFeeIsNotNull() {
            addCriterion("MD_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andMdFeeEqualTo(BigDecimal value) {
            addCriterion("MD_FEE =", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeNotEqualTo(BigDecimal value) {
            addCriterion("MD_FEE <>", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeGreaterThan(BigDecimal value) {
            addCriterion("MD_FEE >", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("MD_FEE >=", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeLessThan(BigDecimal value) {
            addCriterion("MD_FEE <", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("MD_FEE <=", value, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeIn(List<BigDecimal> values) {
            addCriterion("MD_FEE in", values, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeNotIn(List<BigDecimal> values) {
            addCriterion("MD_FEE not in", values, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MD_FEE between", value1, value2, "mdFee");
            return (Criteria) this;
        }

        public Criteria andMdFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("MD_FEE not between", value1, value2, "mdFee");
            return (Criteria) this;
        }

        public Criteria andCustomizationIsNull() {
            addCriterion("CUSTOMIZATION is null");
            return (Criteria) this;
        }

        public Criteria andCustomizationIsNotNull() {
            addCriterion("CUSTOMIZATION is not null");
            return (Criteria) this;
        }

        public Criteria andCustomizationEqualTo(String value) {
            addCriterion("CUSTOMIZATION =", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationNotEqualTo(String value) {
            addCriterion("CUSTOMIZATION <>", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationGreaterThan(String value) {
            addCriterion("CUSTOMIZATION >", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationGreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMIZATION >=", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationLessThan(String value) {
            addCriterion("CUSTOMIZATION <", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationLessThanOrEqualTo(String value) {
            addCriterion("CUSTOMIZATION <=", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationLike(String value) {
            addCriterion("CUSTOMIZATION like", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationNotLike(String value) {
            addCriterion("CUSTOMIZATION not like", value, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationIn(List<String> values) {
            addCriterion("CUSTOMIZATION in", values, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationNotIn(List<String> values) {
            addCriterion("CUSTOMIZATION not in", values, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationBetween(String value1, String value2) {
            addCriterion("CUSTOMIZATION between", value1, value2, "customization");
            return (Criteria) this;
        }

        public Criteria andCustomizationNotBetween(String value1, String value2) {
            addCriterion("CUSTOMIZATION not between", value1, value2, "customization");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Short value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Short value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}