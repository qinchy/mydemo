package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.ItemDO;

/**
 * Created by shisheng.wang on 17/6/6.
 */
public interface ItemMapper {
    ItemDO selectByPrimaryKey(Long itemId);

    int insert(ItemDO itemDO);
}
