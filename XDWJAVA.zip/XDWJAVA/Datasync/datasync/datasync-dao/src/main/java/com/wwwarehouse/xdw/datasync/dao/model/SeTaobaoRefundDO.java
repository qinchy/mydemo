package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SeTaobaoRefundDO implements Serializable {
    private Long refundUkid;

    private String refundId;

    private Long shopId;

    private Date downTime;

    private String shippingType;

    private String orderId;

    private String subOrderId;

    private String alipayNo;

    private BigDecimal totalFee;

    private String buyerNick;

    private String sellerNick;

    private Date refundCreateTime;

    private Date modified;

    private String orderStatus;

    private String status;

    private String goodStatus;

    private Long hasGoodReturn;

    private BigDecimal refundFee;

    private BigDecimal payment;

    private String reason;

    private String reasonDesc;

    private String title;

    private BigDecimal price;

    private Long num;

    private Date goodReturnTime;

    private String companyName;

    private String sid;

    private String address;

    private Long numIid;

    private Long csStatus;

    private Long advanceStatus;

    private BigDecimal splitTaobaoFee;

    private BigDecimal splitSellerFee;

    private Long remindType;

    private Long existTimeout;

    private Date timeout;

    private String refundPhase;

    private Long refundVersion;

    private String sku;

    private String attribute;

    private String outerId;

    private String operationContraint;

    private String iscsReceiptStatus;

    private String serviceStatus;

    private Long processStatus;

    private Long createUserId;

    private Long updateUserId;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getRefundUkid() {
        return refundUkid;
    }

    public void setRefundUkid(Long refundUkid) {
        this.refundUkid = refundUkid;
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public String getShippingType() {
        return shippingType;
    }

    public void setShippingType(String shippingType) {
        this.shippingType = shippingType;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getSubOrderId() {
        return subOrderId;
    }

    public void setSubOrderId(String subOrderId) {
        this.subOrderId = subOrderId;
    }

    public String getAlipayNo() {
        return alipayNo;
    }

    public void setAlipayNo(String alipayNo) {
        this.alipayNo = alipayNo;
    }

    public BigDecimal getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(BigDecimal totalFee) {
        this.totalFee = totalFee;
    }

    public String getBuyerNick() {
        return buyerNick;
    }

    public void setBuyerNick(String buyerNick) {
        this.buyerNick = buyerNick;
    }

    public String getSellerNick() {
        return sellerNick;
    }

    public void setSellerNick(String sellerNick) {
        this.sellerNick = sellerNick;
    }

    public Date getRefundCreateTime() {
        return refundCreateTime;
    }

    public void setRefundCreateTime(Date refundCreateTime) {
        this.refundCreateTime = refundCreateTime;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGoodStatus() {
        return goodStatus;
    }

    public void setGoodStatus(String goodStatus) {
        this.goodStatus = goodStatus;
    }

    public Long getHasGoodReturn() {
        return hasGoodReturn;
    }

    public void setHasGoodReturn(Long hasGoodReturn) {
        this.hasGoodReturn = hasGoodReturn;
    }

    public BigDecimal getRefundFee() {
        return refundFee;
    }

    public void setRefundFee(BigDecimal refundFee) {
        this.refundFee = refundFee;
    }

    public BigDecimal getPayment() {
        return payment;
    }

    public void setPayment(BigDecimal payment) {
        this.payment = payment;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReasonDesc() {
        return reasonDesc;
    }

    public void setReasonDesc(String reasonDesc) {
        this.reasonDesc = reasonDesc;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Long getNum() {
        return num;
    }

    public void setNum(Long num) {
        this.num = num;
    }

    public Date getGoodReturnTime() {
        return goodReturnTime;
    }

    public void setGoodReturnTime(Date goodReturnTime) {
        this.goodReturnTime = goodReturnTime;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getNumIid() {
        return numIid;
    }

    public void setNumIid(Long numIid) {
        this.numIid = numIid;
    }

    public Long getCsStatus() {
        return csStatus;
    }

    public void setCsStatus(Long csStatus) {
        this.csStatus = csStatus;
    }

    public Long getAdvanceStatus() {
        return advanceStatus;
    }

    public void setAdvanceStatus(Long advanceStatus) {
        this.advanceStatus = advanceStatus;
    }

    public BigDecimal getSplitTaobaoFee() {
        return splitTaobaoFee;
    }

    public void setSplitTaobaoFee(BigDecimal splitTaobaoFee) {
        this.splitTaobaoFee = splitTaobaoFee;
    }

    public BigDecimal getSplitSellerFee() {
        return splitSellerFee;
    }

    public void setSplitSellerFee(BigDecimal splitSellerFee) {
        this.splitSellerFee = splitSellerFee;
    }

    public Long getRemindType() {
        return remindType;
    }

    public void setRemindType(Long remindType) {
        this.remindType = remindType;
    }

    public Long getExistTimeout() {
        return existTimeout;
    }

    public void setExistTimeout(Long existTimeout) {
        this.existTimeout = existTimeout;
    }

    public Date getTimeout() {
        return timeout;
    }

    public void setTimeout(Date timeout) {
        this.timeout = timeout;
    }

    public String getRefundPhase() {
        return refundPhase;
    }

    public void setRefundPhase(String refundPhase) {
        this.refundPhase = refundPhase;
    }

    public Long getRefundVersion() {
        return refundVersion;
    }

    public void setRefundVersion(Long refundVersion) {
        this.refundVersion = refundVersion;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getOuterId() {
        return outerId;
    }

    public void setOuterId(String outerId) {
        this.outerId = outerId;
    }

    public String getOperationContraint() {
        return operationContraint;
    }

    public void setOperationContraint(String operationContraint) {
        this.operationContraint = operationContraint;
    }

    public String getIscsReceiptStatus() {
        return iscsReceiptStatus;
    }

    public void setIscsReceiptStatus(String iscsReceiptStatus) {
        this.iscsReceiptStatus = iscsReceiptStatus;
    }

    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public Long getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(Long processStatus) {
        this.processStatus = processStatus;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", refundUkid=").append(refundUkid);
        sb.append(", refundId=").append(refundId);
        sb.append(", shopId=").append(shopId);
        sb.append(", downTime=").append(downTime);
        sb.append(", shippingType=").append(shippingType);
        sb.append(", orderId=").append(orderId);
        sb.append(", subOrderId=").append(subOrderId);
        sb.append(", alipayNo=").append(alipayNo);
        sb.append(", totalFee=").append(totalFee);
        sb.append(", buyerNick=").append(buyerNick);
        sb.append(", sellerNick=").append(sellerNick);
        sb.append(", refundCreateTime=").append(refundCreateTime);
        sb.append(", modified=").append(modified);
        sb.append(", orderStatus=").append(orderStatus);
        sb.append(", status=").append(status);
        sb.append(", goodStatus=").append(goodStatus);
        sb.append(", hasGoodReturn=").append(hasGoodReturn);
        sb.append(", refundFee=").append(refundFee);
        sb.append(", payment=").append(payment);
        sb.append(", reason=").append(reason);
        sb.append(", reasonDesc=").append(reasonDesc);
        sb.append(", title=").append(title);
        sb.append(", price=").append(price);
        sb.append(", num=").append(num);
        sb.append(", goodReturnTime=").append(goodReturnTime);
        sb.append(", companyName=").append(companyName);
        sb.append(", sid=").append(sid);
        sb.append(", address=").append(address);
        sb.append(", numIid=").append(numIid);
        sb.append(", csStatus=").append(csStatus);
        sb.append(", advanceStatus=").append(advanceStatus);
        sb.append(", splitTaobaoFee=").append(splitTaobaoFee);
        sb.append(", splitSellerFee=").append(splitSellerFee);
        sb.append(", remindType=").append(remindType);
        sb.append(", existTimeout=").append(existTimeout);
        sb.append(", timeout=").append(timeout);
        sb.append(", refundPhase=").append(refundPhase);
        sb.append(", refundVersion=").append(refundVersion);
        sb.append(", sku=").append(sku);
        sb.append(", attribute=").append(attribute);
        sb.append(", outerId=").append(outerId);
        sb.append(", operationContraint=").append(operationContraint);
        sb.append(", iscsReceiptStatus=").append(iscsReceiptStatus);
        sb.append(", serviceStatus=").append(serviceStatus);
        sb.append(", processStatus=").append(processStatus);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeTaobaoRefundDO other = (SeTaobaoRefundDO) that;
        return (this.getRefundUkid() == null ? other.getRefundUkid() == null : this.getRefundUkid().equals(other.getRefundUkid()))
            && (this.getRefundId() == null ? other.getRefundId() == null : this.getRefundId().equals(other.getRefundId()))
            && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
            && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
            && (this.getShippingType() == null ? other.getShippingType() == null : this.getShippingType().equals(other.getShippingType()))
            && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
            && (this.getSubOrderId() == null ? other.getSubOrderId() == null : this.getSubOrderId().equals(other.getSubOrderId()))
            && (this.getAlipayNo() == null ? other.getAlipayNo() == null : this.getAlipayNo().equals(other.getAlipayNo()))
            && (this.getTotalFee() == null ? other.getTotalFee() == null : this.getTotalFee().equals(other.getTotalFee()))
            && (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
            && (this.getSellerNick() == null ? other.getSellerNick() == null : this.getSellerNick().equals(other.getSellerNick()))
            && (this.getRefundCreateTime() == null ? other.getRefundCreateTime() == null : this.getRefundCreateTime().equals(other.getRefundCreateTime()))
            && (this.getModified() == null ? other.getModified() == null : this.getModified().equals(other.getModified()))
            && (this.getOrderStatus() == null ? other.getOrderStatus() == null : this.getOrderStatus().equals(other.getOrderStatus()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getGoodStatus() == null ? other.getGoodStatus() == null : this.getGoodStatus().equals(other.getGoodStatus()))
            && (this.getHasGoodReturn() == null ? other.getHasGoodReturn() == null : this.getHasGoodReturn().equals(other.getHasGoodReturn()))
            && (this.getRefundFee() == null ? other.getRefundFee() == null : this.getRefundFee().equals(other.getRefundFee()))
            && (this.getPayment() == null ? other.getPayment() == null : this.getPayment().equals(other.getPayment()))
            && (this.getReason() == null ? other.getReason() == null : this.getReason().equals(other.getReason()))
            && (this.getReasonDesc() == null ? other.getReasonDesc() == null : this.getReasonDesc().equals(other.getReasonDesc()))
            && (this.getTitle() == null ? other.getTitle() == null : this.getTitle().equals(other.getTitle()))
            && (this.getPrice() == null ? other.getPrice() == null : this.getPrice().equals(other.getPrice()))
            && (this.getNum() == null ? other.getNum() == null : this.getNum().equals(other.getNum()))
            && (this.getGoodReturnTime() == null ? other.getGoodReturnTime() == null : this.getGoodReturnTime().equals(other.getGoodReturnTime()))
            && (this.getCompanyName() == null ? other.getCompanyName() == null : this.getCompanyName().equals(other.getCompanyName()))
            && (this.getSid() == null ? other.getSid() == null : this.getSid().equals(other.getSid()))
            && (this.getAddress() == null ? other.getAddress() == null : this.getAddress().equals(other.getAddress()))
            && (this.getNumIid() == null ? other.getNumIid() == null : this.getNumIid().equals(other.getNumIid()))
            && (this.getCsStatus() == null ? other.getCsStatus() == null : this.getCsStatus().equals(other.getCsStatus()))
            && (this.getAdvanceStatus() == null ? other.getAdvanceStatus() == null : this.getAdvanceStatus().equals(other.getAdvanceStatus()))
            && (this.getSplitTaobaoFee() == null ? other.getSplitTaobaoFee() == null : this.getSplitTaobaoFee().equals(other.getSplitTaobaoFee()))
            && (this.getSplitSellerFee() == null ? other.getSplitSellerFee() == null : this.getSplitSellerFee().equals(other.getSplitSellerFee()))
            && (this.getRemindType() == null ? other.getRemindType() == null : this.getRemindType().equals(other.getRemindType()))
            && (this.getExistTimeout() == null ? other.getExistTimeout() == null : this.getExistTimeout().equals(other.getExistTimeout()))
            && (this.getTimeout() == null ? other.getTimeout() == null : this.getTimeout().equals(other.getTimeout()))
            && (this.getRefundPhase() == null ? other.getRefundPhase() == null : this.getRefundPhase().equals(other.getRefundPhase()))
            && (this.getRefundVersion() == null ? other.getRefundVersion() == null : this.getRefundVersion().equals(other.getRefundVersion()))
            && (this.getSku() == null ? other.getSku() == null : this.getSku().equals(other.getSku()))
            && (this.getAttribute() == null ? other.getAttribute() == null : this.getAttribute().equals(other.getAttribute()))
            && (this.getOuterId() == null ? other.getOuterId() == null : this.getOuterId().equals(other.getOuterId()))
            && (this.getOperationContraint() == null ? other.getOperationContraint() == null : this.getOperationContraint().equals(other.getOperationContraint()))
            && (this.getIscsReceiptStatus() == null ? other.getIscsReceiptStatus() == null : this.getIscsReceiptStatus().equals(other.getIscsReceiptStatus()))
            && (this.getServiceStatus() == null ? other.getServiceStatus() == null : this.getServiceStatus().equals(other.getServiceStatus()))
            && (this.getProcessStatus() == null ? other.getProcessStatus() == null : this.getProcessStatus().equals(other.getProcessStatus()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getRefundUkid() == null) ? 0 : getRefundUkid().hashCode());
        result = prime * result + ((getRefundId() == null) ? 0 : getRefundId().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getShippingType() == null) ? 0 : getShippingType().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getSubOrderId() == null) ? 0 : getSubOrderId().hashCode());
        result = prime * result + ((getAlipayNo() == null) ? 0 : getAlipayNo().hashCode());
        result = prime * result + ((getTotalFee() == null) ? 0 : getTotalFee().hashCode());
        result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
        result = prime * result + ((getSellerNick() == null) ? 0 : getSellerNick().hashCode());
        result = prime * result + ((getRefundCreateTime() == null) ? 0 : getRefundCreateTime().hashCode());
        result = prime * result + ((getModified() == null) ? 0 : getModified().hashCode());
        result = prime * result + ((getOrderStatus() == null) ? 0 : getOrderStatus().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getGoodStatus() == null) ? 0 : getGoodStatus().hashCode());
        result = prime * result + ((getHasGoodReturn() == null) ? 0 : getHasGoodReturn().hashCode());
        result = prime * result + ((getRefundFee() == null) ? 0 : getRefundFee().hashCode());
        result = prime * result + ((getPayment() == null) ? 0 : getPayment().hashCode());
        result = prime * result + ((getReason() == null) ? 0 : getReason().hashCode());
        result = prime * result + ((getReasonDesc() == null) ? 0 : getReasonDesc().hashCode());
        result = prime * result + ((getTitle() == null) ? 0 : getTitle().hashCode());
        result = prime * result + ((getPrice() == null) ? 0 : getPrice().hashCode());
        result = prime * result + ((getNum() == null) ? 0 : getNum().hashCode());
        result = prime * result + ((getGoodReturnTime() == null) ? 0 : getGoodReturnTime().hashCode());
        result = prime * result + ((getCompanyName() == null) ? 0 : getCompanyName().hashCode());
        result = prime * result + ((getSid() == null) ? 0 : getSid().hashCode());
        result = prime * result + ((getAddress() == null) ? 0 : getAddress().hashCode());
        result = prime * result + ((getNumIid() == null) ? 0 : getNumIid().hashCode());
        result = prime * result + ((getCsStatus() == null) ? 0 : getCsStatus().hashCode());
        result = prime * result + ((getAdvanceStatus() == null) ? 0 : getAdvanceStatus().hashCode());
        result = prime * result + ((getSplitTaobaoFee() == null) ? 0 : getSplitTaobaoFee().hashCode());
        result = prime * result + ((getSplitSellerFee() == null) ? 0 : getSplitSellerFee().hashCode());
        result = prime * result + ((getRemindType() == null) ? 0 : getRemindType().hashCode());
        result = prime * result + ((getExistTimeout() == null) ? 0 : getExistTimeout().hashCode());
        result = prime * result + ((getTimeout() == null) ? 0 : getTimeout().hashCode());
        result = prime * result + ((getRefundPhase() == null) ? 0 : getRefundPhase().hashCode());
        result = prime * result + ((getRefundVersion() == null) ? 0 : getRefundVersion().hashCode());
        result = prime * result + ((getSku() == null) ? 0 : getSku().hashCode());
        result = prime * result + ((getAttribute() == null) ? 0 : getAttribute().hashCode());
        result = prime * result + ((getOuterId() == null) ? 0 : getOuterId().hashCode());
        result = prime * result + ((getOperationContraint() == null) ? 0 : getOperationContraint().hashCode());
        result = prime * result + ((getIscsReceiptStatus() == null) ? 0 : getIscsReceiptStatus().hashCode());
        result = prime * result + ((getServiceStatus() == null) ? 0 : getServiceStatus().hashCode());
        result = prime * result + ((getProcessStatus() == null) ? 0 : getProcessStatus().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}