package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDOExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SeYhdRefundDOMapper {
    long countByExample(SeYhdRefundDOExample example);

    int deleteByExample(SeYhdRefundDOExample example);

    int deleteByPrimaryKey(Short refundUkid);

    int insert(SeYhdRefundDO record);

    int insertSelective(SeYhdRefundDO record);

    List<SeYhdRefundDO> selectByExample(SeYhdRefundDOExample example);

    SeYhdRefundDO selectByPrimaryKey(Short refundUkid);

    int updateByExampleSelective(@Param("record") SeYhdRefundDO record, @Param("example") SeYhdRefundDOExample example);

    int updateByExample(@Param("record") SeYhdRefundDO record, @Param("example") SeYhdRefundDOExample example);

    int updateByPrimaryKeySelective(SeYhdRefundDO record);

    int updateByPrimaryKey(SeYhdRefundDO record);

    SeYhdRefundDO getRefund(String refundCode);

    int updateProcessStatus(SeYhdRefundDO o) throws Exception;

    int updateRefundStatus(SeYhdRefundDO o) throws Exception;
}