package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AmAuthRecordDOMapper {
    long countByExample(AmAuthRecordDOExample example);

    int deleteByExample(AmAuthRecordDOExample example);

    int deleteByPrimaryKey(Long authRecordUkid);

    int insert(AmAuthRecordDO record);

    int insertSelective(AmAuthRecordDO record);

    List<AmAuthRecordDO> selectByExample(AmAuthRecordDOExample example);

    AmAuthRecordDO selectByPrimaryKey(Long authRecordUkid);

    int updateByExampleSelective(@Param("record") AmAuthRecordDO record, @Param("example") AmAuthRecordDOExample example);

    int updateByExample(@Param("record") AmAuthRecordDO record, @Param("example") AmAuthRecordDOExample example);

    int updateByPrimaryKeySelective(AmAuthRecordDO record);

    int updateByPrimaryKey(AmAuthRecordDO record);
}