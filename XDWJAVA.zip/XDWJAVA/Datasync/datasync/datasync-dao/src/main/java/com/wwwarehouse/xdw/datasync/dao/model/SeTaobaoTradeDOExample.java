package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeTaobaoTradeDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeTaobaoTradeDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Short value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Short value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Short value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Short value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Short value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Short> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Short> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Short value1, Short value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Short value1, Short value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Short value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Short value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Short value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Short value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Short value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Short value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Short> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Short> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Short value1, Short value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Short value1, Short value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNull() {
            addCriterion("RELEASE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNotNull() {
            addCriterion("RELEASE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeEqualTo(Date value) {
            addCriterion("RELEASE_TIME =", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotEqualTo(Date value) {
            addCriterion("RELEASE_TIME <>", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThan(Date value) {
            addCriterion("RELEASE_TIME >", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME >=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThan(Date value) {
            addCriterion("RELEASE_TIME <", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME <=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIn(List<Date> values) {
            addCriterion("RELEASE_TIME in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotIn(List<Date> values) {
            addCriterion("RELEASE_TIME not in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME not between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNull() {
            addCriterion("ORIGIN_TRADE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNotNull() {
            addCriterion("ORIGIN_TRADE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusEqualTo(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS =", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotEqualTo(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS <>", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThan(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS >", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS >=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThan(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS <", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThanOrEqualTo(Short value) {
            addCriterion("ORIGIN_TRADE_STATUS <=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIn(List<Short> values) {
            addCriterion("ORIGIN_TRADE_STATUS in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotIn(List<Short> values) {
            addCriterion("ORIGIN_TRADE_STATUS not in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusBetween(Short value1, Short value2) {
            addCriterion("ORIGIN_TRADE_STATUS between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotBetween(Short value1, Short value2) {
            addCriterion("ORIGIN_TRADE_STATUS not between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNull() {
            addCriterion("SELLER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNotNull() {
            addCriterion("SELLER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andSellerNickEqualTo(String value) {
            addCriterion("SELLER_NICK =", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotEqualTo(String value) {
            addCriterion("SELLER_NICK <>", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThan(String value) {
            addCriterion("SELLER_NICK >", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK >=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThan(String value) {
            addCriterion("SELLER_NICK <", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK <=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLike(String value) {
            addCriterion("SELLER_NICK like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotLike(String value) {
            addCriterion("SELLER_NICK not like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickIn(List<String> values) {
            addCriterion("SELLER_NICK in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotIn(List<String> values) {
            addCriterion("SELLER_NICK not in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickBetween(String value1, String value2) {
            addCriterion("SELLER_NICK between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotBetween(String value1, String value2) {
            addCriterion("SELLER_NICK not between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andPicPathIsNull() {
            addCriterion("PIC_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPicPathIsNotNull() {
            addCriterion("PIC_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPicPathEqualTo(String value) {
            addCriterion("PIC_PATH =", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotEqualTo(String value) {
            addCriterion("PIC_PATH <>", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathGreaterThan(String value) {
            addCriterion("PIC_PATH >", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathGreaterThanOrEqualTo(String value) {
            addCriterion("PIC_PATH >=", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLessThan(String value) {
            addCriterion("PIC_PATH <", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLessThanOrEqualTo(String value) {
            addCriterion("PIC_PATH <=", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathLike(String value) {
            addCriterion("PIC_PATH like", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotLike(String value) {
            addCriterion("PIC_PATH not like", value, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathIn(List<String> values) {
            addCriterion("PIC_PATH in", values, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotIn(List<String> values) {
            addCriterion("PIC_PATH not in", values, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathBetween(String value1, String value2) {
            addCriterion("PIC_PATH between", value1, value2, "picPath");
            return (Criteria) this;
        }

        public Criteria andPicPathNotBetween(String value1, String value2) {
            addCriterion("PIC_PATH not between", value1, value2, "picPath");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNull() {
            addCriterion("PAYMENT is null");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNotNull() {
            addCriterion("PAYMENT is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentEqualTo(BigDecimal value) {
            addCriterion("PAYMENT =", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <>", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThan(BigDecimal value) {
            addCriterion("PAYMENT >", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT >=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThan(BigDecimal value) {
            addCriterion("PAYMENT <", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentIn(List<BigDecimal> values) {
            addCriterion("PAYMENT in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotIn(List<BigDecimal> values) {
            addCriterion("PAYMENT not in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT not between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andSellerRateIsNull() {
            addCriterion("SELLER_RATE is null");
            return (Criteria) this;
        }

        public Criteria andSellerRateIsNotNull() {
            addCriterion("SELLER_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andSellerRateEqualTo(Short value) {
            addCriterion("SELLER_RATE =", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotEqualTo(Short value) {
            addCriterion("SELLER_RATE <>", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateGreaterThan(Short value) {
            addCriterion("SELLER_RATE >", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateGreaterThanOrEqualTo(Short value) {
            addCriterion("SELLER_RATE >=", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateLessThan(Short value) {
            addCriterion("SELLER_RATE <", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateLessThanOrEqualTo(Short value) {
            addCriterion("SELLER_RATE <=", value, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateIn(List<Short> values) {
            addCriterion("SELLER_RATE in", values, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotIn(List<Short> values) {
            addCriterion("SELLER_RATE not in", values, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateBetween(Short value1, Short value2) {
            addCriterion("SELLER_RATE between", value1, value2, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andSellerRateNotBetween(Short value1, Short value2) {
            addCriterion("SELLER_RATE not between", value1, value2, "sellerRate");
            return (Criteria) this;
        }

        public Criteria andPostFeeIsNull() {
            addCriterion("POST_FEE is null");
            return (Criteria) this;
        }

        public Criteria andPostFeeIsNotNull() {
            addCriterion("POST_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andPostFeeEqualTo(BigDecimal value) {
            addCriterion("POST_FEE =", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeNotEqualTo(BigDecimal value) {
            addCriterion("POST_FEE <>", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeGreaterThan(BigDecimal value) {
            addCriterion("POST_FEE >", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("POST_FEE >=", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeLessThan(BigDecimal value) {
            addCriterion("POST_FEE <", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("POST_FEE <=", value, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeIn(List<BigDecimal> values) {
            addCriterion("POST_FEE in", values, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeNotIn(List<BigDecimal> values) {
            addCriterion("POST_FEE not in", values, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("POST_FEE between", value1, value2, "postFee");
            return (Criteria) this;
        }

        public Criteria andPostFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("POST_FEE not between", value1, value2, "postFee");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNull() {
            addCriterion("RECEIVER_NAME is null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNotNull() {
            addCriterion("RECEIVER_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameEqualTo(String value) {
            addCriterion("RECEIVER_NAME =", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotEqualTo(String value) {
            addCriterion("RECEIVER_NAME <>", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThan(String value) {
            addCriterion("RECEIVER_NAME >", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME >=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThan(String value) {
            addCriterion("RECEIVER_NAME <", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME <=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLike(String value) {
            addCriterion("RECEIVER_NAME like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotLike(String value) {
            addCriterion("RECEIVER_NAME not like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIn(List<String> values) {
            addCriterion("RECEIVER_NAME in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotIn(List<String> values) {
            addCriterion("RECEIVER_NAME not in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME not between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNull() {
            addCriterion("RECEIVER_STATE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNotNull() {
            addCriterion("RECEIVER_STATE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateEqualTo(String value) {
            addCriterion("RECEIVER_STATE =", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotEqualTo(String value) {
            addCriterion("RECEIVER_STATE <>", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThan(String value) {
            addCriterion("RECEIVER_STATE >", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE >=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThan(String value) {
            addCriterion("RECEIVER_STATE <", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE <=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLike(String value) {
            addCriterion("RECEIVER_STATE like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotLike(String value) {
            addCriterion("RECEIVER_STATE not like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIn(List<String> values) {
            addCriterion("RECEIVER_STATE in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotIn(List<String> values) {
            addCriterion("RECEIVER_STATE not in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE not between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNull() {
            addCriterion("RECEIVER_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNotNull() {
            addCriterion("RECEIVER_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS =", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <>", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThan(String value) {
            addCriterion("RECEIVER_ADDRESS >", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS >=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThan(String value) {
            addCriterion("RECEIVER_ADDRESS <", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLike(String value) {
            addCriterion("RECEIVER_ADDRESS like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotLike(String value) {
            addCriterion("RECEIVER_ADDRESS not like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS not in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS not between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNull() {
            addCriterion("RECEIVER_ZIP is null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNotNull() {
            addCriterion("RECEIVER_ZIP is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipEqualTo(String value) {
            addCriterion("RECEIVER_ZIP =", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <>", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThan(String value) {
            addCriterion("RECEIVER_ZIP >", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP >=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThan(String value) {
            addCriterion("RECEIVER_ZIP <", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLike(String value) {
            addCriterion("RECEIVER_ZIP like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotLike(String value) {
            addCriterion("RECEIVER_ZIP not like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIn(List<String> values) {
            addCriterion("RECEIVER_ZIP in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotIn(List<String> values) {
            addCriterion("RECEIVER_ZIP not in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP not between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNull() {
            addCriterion("RECEIVER_MOBILE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNotNull() {
            addCriterion("RECEIVER_MOBILE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE =", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <>", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThan(String value) {
            addCriterion("RECEIVER_MOBILE >", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE >=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThan(String value) {
            addCriterion("RECEIVER_MOBILE <", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLike(String value) {
            addCriterion("RECEIVER_MOBILE like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotLike(String value) {
            addCriterion("RECEIVER_MOBILE not like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE not in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE not between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNull() {
            addCriterion("RECEIVER_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNotNull() {
            addCriterion("RECEIVER_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneEqualTo(String value) {
            addCriterion("RECEIVER_PHONE =", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <>", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThan(String value) {
            addCriterion("RECEIVER_PHONE >", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE >=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThan(String value) {
            addCriterion("RECEIVER_PHONE <", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLike(String value) {
            addCriterion("RECEIVER_PHONE like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotLike(String value) {
            addCriterion("RECEIVER_PHONE not like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIn(List<String> values) {
            addCriterion("RECEIVER_PHONE in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotIn(List<String> values) {
            addCriterion("RECEIVER_PHONE not in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE not between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNull() {
            addCriterion("CONSIGN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNotNull() {
            addCriterion("CONSIGN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeEqualTo(Date value) {
            addCriterion("CONSIGN_TIME =", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <>", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThan(Date value) {
            addCriterion("CONSIGN_TIME >", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME >=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThan(Date value) {
            addCriterion("CONSIGN_TIME <", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIn(List<Date> values) {
            addCriterion("CONSIGN_TIME in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotIn(List<Date> values) {
            addCriterion("CONSIGN_TIME not in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME not between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryIsNull() {
            addCriterion("RECEIVER_COUNTRY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryIsNotNull() {
            addCriterion("RECEIVER_COUNTRY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryEqualTo(String value) {
            addCriterion("RECEIVER_COUNTRY =", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryNotEqualTo(String value) {
            addCriterion("RECEIVER_COUNTRY <>", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryGreaterThan(String value) {
            addCriterion("RECEIVER_COUNTRY >", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTRY >=", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryLessThan(String value) {
            addCriterion("RECEIVER_COUNTRY <", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTRY <=", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryLike(String value) {
            addCriterion("RECEIVER_COUNTRY like", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryNotLike(String value) {
            addCriterion("RECEIVER_COUNTRY not like", value, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryIn(List<String> values) {
            addCriterion("RECEIVER_COUNTRY in", values, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryNotIn(List<String> values) {
            addCriterion("RECEIVER_COUNTRY not in", values, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTRY between", value1, value2, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverCountryNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTRY not between", value1, value2, "receiverCountry");
            return (Criteria) this;
        }

        public Criteria andReceiverTownIsNull() {
            addCriterion("RECEIVER_TOWN is null");
            return (Criteria) this;
        }

        public Criteria andReceiverTownIsNotNull() {
            addCriterion("RECEIVER_TOWN is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverTownEqualTo(String value) {
            addCriterion("RECEIVER_TOWN =", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownNotEqualTo(String value) {
            addCriterion("RECEIVER_TOWN <>", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownGreaterThan(String value) {
            addCriterion("RECEIVER_TOWN >", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_TOWN >=", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownLessThan(String value) {
            addCriterion("RECEIVER_TOWN <", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_TOWN <=", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownLike(String value) {
            addCriterion("RECEIVER_TOWN like", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownNotLike(String value) {
            addCriterion("RECEIVER_TOWN not like", value, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownIn(List<String> values) {
            addCriterion("RECEIVER_TOWN in", values, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownNotIn(List<String> values) {
            addCriterion("RECEIVER_TOWN not in", values, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownBetween(String value1, String value2) {
            addCriterion("RECEIVER_TOWN between", value1, value2, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andReceiverTownNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_TOWN not between", value1, value2, "receiverTown");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeIsNull() {
            addCriterion("ORDER_TAX_FEE is null");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeIsNotNull() {
            addCriterion("ORDER_TAX_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeEqualTo(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE =", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE <>", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeGreaterThan(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE >", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE >=", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeLessThan(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE <", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_TAX_FEE <=", value, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeIn(List<BigDecimal> values) {
            addCriterion("ORDER_TAX_FEE in", values, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_TAX_FEE not in", values, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_TAX_FEE between", value1, value2, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andOrderTaxFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_TAX_FEE not between", value1, value2, "orderTaxFee");
            return (Criteria) this;
        }

        public Criteria andShopPickIsNull() {
            addCriterion("SHOP_PICK is null");
            return (Criteria) this;
        }

        public Criteria andShopPickIsNotNull() {
            addCriterion("SHOP_PICK is not null");
            return (Criteria) this;
        }

        public Criteria andShopPickEqualTo(Short value) {
            addCriterion("SHOP_PICK =", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickNotEqualTo(Short value) {
            addCriterion("SHOP_PICK <>", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickGreaterThan(Short value) {
            addCriterion("SHOP_PICK >", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickGreaterThanOrEqualTo(Short value) {
            addCriterion("SHOP_PICK >=", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickLessThan(Short value) {
            addCriterion("SHOP_PICK <", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickLessThanOrEqualTo(Short value) {
            addCriterion("SHOP_PICK <=", value, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickIn(List<Short> values) {
            addCriterion("SHOP_PICK in", values, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickNotIn(List<Short> values) {
            addCriterion("SHOP_PICK not in", values, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickBetween(Short value1, Short value2) {
            addCriterion("SHOP_PICK between", value1, value2, "shopPick");
            return (Criteria) this;
        }

        public Criteria andShopPickNotBetween(Short value1, Short value2) {
            addCriterion("SHOP_PICK not between", value1, value2, "shopPick");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andNumIsNull() {
            addCriterion("NUM is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("NUM is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(Short value) {
            addCriterion("NUM =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(Short value) {
            addCriterion("NUM <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(Short value) {
            addCriterion("NUM >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(Short value) {
            addCriterion("NUM >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(Short value) {
            addCriterion("NUM <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(Short value) {
            addCriterion("NUM <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<Short> values) {
            addCriterion("NUM in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<Short> values) {
            addCriterion("NUM not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(Short value1, Short value2) {
            addCriterion("NUM between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(Short value1, Short value2) {
            addCriterion("NUM not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumIidIsNull() {
            addCriterion("NUM_IID is null");
            return (Criteria) this;
        }

        public Criteria andNumIidIsNotNull() {
            addCriterion("NUM_IID is not null");
            return (Criteria) this;
        }

        public Criteria andNumIidEqualTo(Short value) {
            addCriterion("NUM_IID =", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotEqualTo(Short value) {
            addCriterion("NUM_IID <>", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidGreaterThan(Short value) {
            addCriterion("NUM_IID >", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidGreaterThanOrEqualTo(Short value) {
            addCriterion("NUM_IID >=", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidLessThan(Short value) {
            addCriterion("NUM_IID <", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidLessThanOrEqualTo(Short value) {
            addCriterion("NUM_IID <=", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidIn(List<Short> values) {
            addCriterion("NUM_IID in", values, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotIn(List<Short> values) {
            addCriterion("NUM_IID not in", values, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidBetween(Short value1, Short value2) {
            addCriterion("NUM_IID between", value1, value2, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotBetween(Short value1, Short value2) {
            addCriterion("NUM_IID not between", value1, value2, "numIid");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNull() {
            addCriterion("PLATFORM_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNotNull() {
            addCriterion("PLATFORM_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS =", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <>", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS not like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS not in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS not between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andTitleIsNull() {
            addCriterion("TITLE is null");
            return (Criteria) this;
        }

        public Criteria andTitleIsNotNull() {
            addCriterion("TITLE is not null");
            return (Criteria) this;
        }

        public Criteria andTitleEqualTo(String value) {
            addCriterion("TITLE =", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotEqualTo(String value) {
            addCriterion("TITLE <>", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThan(String value) {
            addCriterion("TITLE >", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThanOrEqualTo(String value) {
            addCriterion("TITLE >=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThan(String value) {
            addCriterion("TITLE <", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThanOrEqualTo(String value) {
            addCriterion("TITLE <=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLike(String value) {
            addCriterion("TITLE like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotLike(String value) {
            addCriterion("TITLE not like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleIn(List<String> values) {
            addCriterion("TITLE in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotIn(List<String> values) {
            addCriterion("TITLE not in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleBetween(String value1, String value2) {
            addCriterion("TITLE between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotBetween(String value1, String value2) {
            addCriterion("TITLE not between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("TYPE =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("TYPE <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("TYPE >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TYPE >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("TYPE <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("TYPE <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("TYPE like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("TYPE not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("TYPE in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("TYPE not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("TYPE between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("TYPE not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("PRICE is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(BigDecimal value) {
            addCriterion("PRICE =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(BigDecimal value) {
            addCriterion("PRICE <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(BigDecimal value) {
            addCriterion("PRICE >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(BigDecimal value) {
            addCriterion("PRICE <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<BigDecimal> values) {
            addCriterion("PRICE in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<BigDecimal> values) {
            addCriterion("PRICE not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE not between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIsNull() {
            addCriterion("DISCOUNT_FEE is null");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIsNotNull() {
            addCriterion("DISCOUNT_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE =", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <>", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeGreaterThan(BigDecimal value) {
            addCriterion("DISCOUNT_FEE >", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE >=", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeLessThan(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DISCOUNT_FEE <=", value, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_FEE in", values, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotIn(List<BigDecimal> values) {
            addCriterion("DISCOUNT_FEE not in", values, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_FEE between", value1, value2, "discountFee");
            return (Criteria) this;
        }

        public Criteria andDiscountFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DISCOUNT_FEE not between", value1, value2, "discountFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNull() {
            addCriterion("TOTAL_FEE is null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNotNull() {
            addCriterion("TOTAL_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE =", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <>", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThan(BigDecimal value) {
            addCriterion("TOTAL_FEE >", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE >=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThan(BigDecimal value) {
            addCriterion("TOTAL_FEE <", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE not in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE not between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNull() {
            addCriterion("ORDER_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNotNull() {
            addCriterion("ORDER_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME =", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <>", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThan(Date value) {
            addCriterion("ORDER_CREATE_TIME >", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME >=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThan(Date value) {
            addCriterion("ORDER_CREATE_TIME <", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME not in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME not between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNull() {
            addCriterion("ORDER_PAY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNotNull() {
            addCriterion("ORDER_PAY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME =", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <>", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThan(Date value) {
            addCriterion("ORDER_PAY_TIME >", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME >=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThan(Date value) {
            addCriterion("ORDER_PAY_TIME <", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME not in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME not between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNull() {
            addCriterion("ORDER_MODIFY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNotNull() {
            addCriterion("ORDER_MODIFY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME =", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <>", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME >", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME >=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME <", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME not in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME not between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIsNull() {
            addCriterion("ORDER_END_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIsNotNull() {
            addCriterion("ORDER_END_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeEqualTo(Date value) {
            addCriterion("ORDER_END_TIME =", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotEqualTo(Date value) {
            addCriterion("ORDER_END_TIME <>", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeGreaterThan(Date value) {
            addCriterion("ORDER_END_TIME >", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_END_TIME >=", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeLessThan(Date value) {
            addCriterion("ORDER_END_TIME <", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_END_TIME <=", value, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeIn(List<Date> values) {
            addCriterion("ORDER_END_TIME in", values, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotIn(List<Date> values) {
            addCriterion("ORDER_END_TIME not in", values, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_END_TIME between", value1, value2, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andOrderEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_END_TIME not between", value1, value2, "orderEndTime");
            return (Criteria) this;
        }

        public Criteria andSellerFlagIsNull() {
            addCriterion("SELLER_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andSellerFlagIsNotNull() {
            addCriterion("SELLER_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andSellerFlagEqualTo(Short value) {
            addCriterion("SELLER_FLAG =", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagNotEqualTo(Short value) {
            addCriterion("SELLER_FLAG <>", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagGreaterThan(Short value) {
            addCriterion("SELLER_FLAG >", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagGreaterThanOrEqualTo(Short value) {
            addCriterion("SELLER_FLAG >=", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagLessThan(Short value) {
            addCriterion("SELLER_FLAG <", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagLessThanOrEqualTo(Short value) {
            addCriterion("SELLER_FLAG <=", value, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagIn(List<Short> values) {
            addCriterion("SELLER_FLAG in", values, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagNotIn(List<Short> values) {
            addCriterion("SELLER_FLAG not in", values, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagBetween(Short value1, Short value2) {
            addCriterion("SELLER_FLAG between", value1, value2, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerFlagNotBetween(Short value1, Short value2) {
            addCriterion("SELLER_FLAG not between", value1, value2, "sellerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageIsNull() {
            addCriterion("HAS_BUYER_MESSAGE is null");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageIsNotNull() {
            addCriterion("HAS_BUYER_MESSAGE is not null");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageEqualTo(Short value) {
            addCriterion("HAS_BUYER_MESSAGE =", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageNotEqualTo(Short value) {
            addCriterion("HAS_BUYER_MESSAGE <>", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageGreaterThan(Short value) {
            addCriterion("HAS_BUYER_MESSAGE >", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageGreaterThanOrEqualTo(Short value) {
            addCriterion("HAS_BUYER_MESSAGE >=", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageLessThan(Short value) {
            addCriterion("HAS_BUYER_MESSAGE <", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageLessThanOrEqualTo(Short value) {
            addCriterion("HAS_BUYER_MESSAGE <=", value, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageIn(List<Short> values) {
            addCriterion("HAS_BUYER_MESSAGE in", values, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageNotIn(List<Short> values) {
            addCriterion("HAS_BUYER_MESSAGE not in", values, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageBetween(Short value1, Short value2) {
            addCriterion("HAS_BUYER_MESSAGE between", value1, value2, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andHasBuyerMessageNotBetween(Short value1, Short value2) {
            addCriterion("HAS_BUYER_MESSAGE not between", value1, value2, "hasBuyerMessage");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeIsNull() {
            addCriterion("CREDIT_CARD_FEE is null");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeIsNotNull() {
            addCriterion("CREDIT_CARD_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeEqualTo(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE =", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeNotEqualTo(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE <>", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeGreaterThan(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE >", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE >=", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeLessThan(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE <", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("CREDIT_CARD_FEE <=", value, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeIn(List<BigDecimal> values) {
            addCriterion("CREDIT_CARD_FEE in", values, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeNotIn(List<BigDecimal> values) {
            addCriterion("CREDIT_CARD_FEE not in", values, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CREDIT_CARD_FEE between", value1, value2, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andCreditCardFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CREDIT_CARD_FEE not between", value1, value2, "creditCardFee");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusIsNull() {
            addCriterion("STEP_TRADE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusIsNotNull() {
            addCriterion("STEP_TRADE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusEqualTo(String value) {
            addCriterion("STEP_TRADE_STATUS =", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusNotEqualTo(String value) {
            addCriterion("STEP_TRADE_STATUS <>", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusGreaterThan(String value) {
            addCriterion("STEP_TRADE_STATUS >", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusGreaterThanOrEqualTo(String value) {
            addCriterion("STEP_TRADE_STATUS >=", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusLessThan(String value) {
            addCriterion("STEP_TRADE_STATUS <", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusLessThanOrEqualTo(String value) {
            addCriterion("STEP_TRADE_STATUS <=", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusLike(String value) {
            addCriterion("STEP_TRADE_STATUS like", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusNotLike(String value) {
            addCriterion("STEP_TRADE_STATUS not like", value, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusIn(List<String> values) {
            addCriterion("STEP_TRADE_STATUS in", values, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusNotIn(List<String> values) {
            addCriterion("STEP_TRADE_STATUS not in", values, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusBetween(String value1, String value2) {
            addCriterion("STEP_TRADE_STATUS between", value1, value2, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepTradeStatusNotBetween(String value1, String value2) {
            addCriterion("STEP_TRADE_STATUS not between", value1, value2, "stepTradeStatus");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeIsNull() {
            addCriterion("STEP_PAID_FEE is null");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeIsNotNull() {
            addCriterion("STEP_PAID_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeEqualTo(BigDecimal value) {
            addCriterion("STEP_PAID_FEE =", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeNotEqualTo(BigDecimal value) {
            addCriterion("STEP_PAID_FEE <>", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeGreaterThan(BigDecimal value) {
            addCriterion("STEP_PAID_FEE >", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("STEP_PAID_FEE >=", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeLessThan(BigDecimal value) {
            addCriterion("STEP_PAID_FEE <", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("STEP_PAID_FEE <=", value, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeIn(List<BigDecimal> values) {
            addCriterion("STEP_PAID_FEE in", values, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeNotIn(List<BigDecimal> values) {
            addCriterion("STEP_PAID_FEE not in", values, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("STEP_PAID_FEE between", value1, value2, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andStepPaidFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("STEP_PAID_FEE not between", value1, value2, "stepPaidFee");
            return (Criteria) this;
        }

        public Criteria andMarkDescIsNull() {
            addCriterion("MARK_DESC is null");
            return (Criteria) this;
        }

        public Criteria andMarkDescIsNotNull() {
            addCriterion("MARK_DESC is not null");
            return (Criteria) this;
        }

        public Criteria andMarkDescEqualTo(String value) {
            addCriterion("MARK_DESC =", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescNotEqualTo(String value) {
            addCriterion("MARK_DESC <>", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescGreaterThan(String value) {
            addCriterion("MARK_DESC >", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescGreaterThanOrEqualTo(String value) {
            addCriterion("MARK_DESC >=", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescLessThan(String value) {
            addCriterion("MARK_DESC <", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescLessThanOrEqualTo(String value) {
            addCriterion("MARK_DESC <=", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescLike(String value) {
            addCriterion("MARK_DESC like", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescNotLike(String value) {
            addCriterion("MARK_DESC not like", value, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescIn(List<String> values) {
            addCriterion("MARK_DESC in", values, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescNotIn(List<String> values) {
            addCriterion("MARK_DESC not in", values, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescBetween(String value1, String value2) {
            addCriterion("MARK_DESC between", value1, value2, "markDesc");
            return (Criteria) this;
        }

        public Criteria andMarkDescNotBetween(String value1, String value2) {
            addCriterion("MARK_DESC not between", value1, value2, "markDesc");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNull() {
            addCriterion("SHIPPING_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNotNull() {
            addCriterion("SHIPPING_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeEqualTo(String value) {
            addCriterion("SHIPPING_TYPE =", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <>", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThan(String value) {
            addCriterion("SHIPPING_TYPE >", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE >=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThan(String value) {
            addCriterion("SHIPPING_TYPE <", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLike(String value) {
            addCriterion("SHIPPING_TYPE like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotLike(String value) {
            addCriterion("SHIPPING_TYPE not like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIn(List<String> values) {
            addCriterion("SHIPPING_TYPE in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotIn(List<String> values) {
            addCriterion("SHIPPING_TYPE not in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE not between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIsNull() {
            addCriterion("ADJUST_FEE is null");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIsNotNull() {
            addCriterion("ADJUST_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE =", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE <>", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeGreaterThan(BigDecimal value) {
            addCriterion("ADJUST_FEE >", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE >=", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeLessThan(BigDecimal value) {
            addCriterion("ADJUST_FEE <", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ADJUST_FEE <=", value, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeIn(List<BigDecimal> values) {
            addCriterion("ADJUST_FEE in", values, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotIn(List<BigDecimal> values) {
            addCriterion("ADJUST_FEE not in", values, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ADJUST_FEE between", value1, value2, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andAdjustFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ADJUST_FEE not between", value1, value2, "adjustFee");
            return (Criteria) this;
        }

        public Criteria andTradeFromIsNull() {
            addCriterion("TRADE_FROM is null");
            return (Criteria) this;
        }

        public Criteria andTradeFromIsNotNull() {
            addCriterion("TRADE_FROM is not null");
            return (Criteria) this;
        }

        public Criteria andTradeFromEqualTo(String value) {
            addCriterion("TRADE_FROM =", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromNotEqualTo(String value) {
            addCriterion("TRADE_FROM <>", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromGreaterThan(String value) {
            addCriterion("TRADE_FROM >", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromGreaterThanOrEqualTo(String value) {
            addCriterion("TRADE_FROM >=", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromLessThan(String value) {
            addCriterion("TRADE_FROM <", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromLessThanOrEqualTo(String value) {
            addCriterion("TRADE_FROM <=", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromLike(String value) {
            addCriterion("TRADE_FROM like", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromNotLike(String value) {
            addCriterion("TRADE_FROM not like", value, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromIn(List<String> values) {
            addCriterion("TRADE_FROM in", values, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromNotIn(List<String> values) {
            addCriterion("TRADE_FROM not in", values, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromBetween(String value1, String value2) {
            addCriterion("TRADE_FROM between", value1, value2, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andTradeFromNotBetween(String value1, String value2) {
            addCriterion("TRADE_FROM not between", value1, value2, "tradeFrom");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIsNull() {
            addCriterion("BUYER_RATE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIsNotNull() {
            addCriterion("BUYER_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerRateEqualTo(Short value) {
            addCriterion("BUYER_RATE =", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotEqualTo(Short value) {
            addCriterion("BUYER_RATE <>", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateGreaterThan(Short value) {
            addCriterion("BUYER_RATE >", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateGreaterThanOrEqualTo(Short value) {
            addCriterion("BUYER_RATE >=", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateLessThan(Short value) {
            addCriterion("BUYER_RATE <", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateLessThanOrEqualTo(Short value) {
            addCriterion("BUYER_RATE <=", value, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateIn(List<Short> values) {
            addCriterion("BUYER_RATE in", values, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotIn(List<Short> values) {
            addCriterion("BUYER_RATE not in", values, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateBetween(Short value1, Short value2) {
            addCriterion("BUYER_RATE between", value1, value2, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andBuyerRateNotBetween(Short value1, Short value2) {
            addCriterion("BUYER_RATE not between", value1, value2, "buyerRate");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNull() {
            addCriterion("RECEIVER_CITY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNotNull() {
            addCriterion("RECEIVER_CITY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityEqualTo(String value) {
            addCriterion("RECEIVER_CITY =", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotEqualTo(String value) {
            addCriterion("RECEIVER_CITY <>", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThan(String value) {
            addCriterion("RECEIVER_CITY >", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY >=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThan(String value) {
            addCriterion("RECEIVER_CITY <", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY <=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLike(String value) {
            addCriterion("RECEIVER_CITY like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotLike(String value) {
            addCriterion("RECEIVER_CITY not like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIn(List<String> values) {
            addCriterion("RECEIVER_CITY in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotIn(List<String> values) {
            addCriterion("RECEIVER_CITY not in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY not between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNull() {
            addCriterion("RECEIVER_COUNTY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNotNull() {
            addCriterion("RECEIVER_COUNTY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY =", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <>", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThan(String value) {
            addCriterion("RECEIVER_COUNTY >", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY >=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThan(String value) {
            addCriterion("RECEIVER_COUNTY <", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLike(String value) {
            addCriterion("RECEIVER_COUNTY like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotLike(String value) {
            addCriterion("RECEIVER_COUNTY not like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY not in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY not between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusIsNull() {
            addCriterion("RX_AUDIT_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusIsNotNull() {
            addCriterion("RX_AUDIT_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusEqualTo(String value) {
            addCriterion("RX_AUDIT_STATUS =", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusNotEqualTo(String value) {
            addCriterion("RX_AUDIT_STATUS <>", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusGreaterThan(String value) {
            addCriterion("RX_AUDIT_STATUS >", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusGreaterThanOrEqualTo(String value) {
            addCriterion("RX_AUDIT_STATUS >=", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusLessThan(String value) {
            addCriterion("RX_AUDIT_STATUS <", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusLessThanOrEqualTo(String value) {
            addCriterion("RX_AUDIT_STATUS <=", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusLike(String value) {
            addCriterion("RX_AUDIT_STATUS like", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusNotLike(String value) {
            addCriterion("RX_AUDIT_STATUS not like", value, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusIn(List<String> values) {
            addCriterion("RX_AUDIT_STATUS in", values, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusNotIn(List<String> values) {
            addCriterion("RX_AUDIT_STATUS not in", values, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusBetween(String value1, String value2) {
            addCriterion("RX_AUDIT_STATUS between", value1, value2, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andRxAuditStatusNotBetween(String value1, String value2) {
            addCriterion("RX_AUDIT_STATUS not between", value1, value2, "rxAuditStatus");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeIsNull() {
            addCriterion("HAS_POST_FEE is null");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeIsNotNull() {
            addCriterion("HAS_POST_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeEqualTo(Short value) {
            addCriterion("HAS_POST_FEE =", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeNotEqualTo(Short value) {
            addCriterion("HAS_POST_FEE <>", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeGreaterThan(Short value) {
            addCriterion("HAS_POST_FEE >", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeGreaterThanOrEqualTo(Short value) {
            addCriterion("HAS_POST_FEE >=", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeLessThan(Short value) {
            addCriterion("HAS_POST_FEE <", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeLessThanOrEqualTo(Short value) {
            addCriterion("HAS_POST_FEE <=", value, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeIn(List<Short> values) {
            addCriterion("HAS_POST_FEE in", values, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeNotIn(List<Short> values) {
            addCriterion("HAS_POST_FEE not in", values, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeBetween(Short value1, Short value2) {
            addCriterion("HAS_POST_FEE between", value1, value2, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andHasPostFeeNotBetween(Short value1, Short value2) {
            addCriterion("HAS_POST_FEE not between", value1, value2, "hasPostFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeIsNull() {
            addCriterion("SELLER_COD_FEE is null");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeIsNotNull() {
            addCriterion("SELLER_COD_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeEqualTo(BigDecimal value) {
            addCriterion("SELLER_COD_FEE =", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeNotEqualTo(BigDecimal value) {
            addCriterion("SELLER_COD_FEE <>", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeGreaterThan(BigDecimal value) {
            addCriterion("SELLER_COD_FEE >", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SELLER_COD_FEE >=", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeLessThan(BigDecimal value) {
            addCriterion("SELLER_COD_FEE <", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SELLER_COD_FEE <=", value, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeIn(List<BigDecimal> values) {
            addCriterion("SELLER_COD_FEE in", values, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeNotIn(List<BigDecimal> values) {
            addCriterion("SELLER_COD_FEE not in", values, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELLER_COD_FEE between", value1, value2, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andSellerCodFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELLER_COD_FEE not between", value1, value2, "sellerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeIsNull() {
            addCriterion("BUYER_COD_FEE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeIsNotNull() {
            addCriterion("BUYER_COD_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeEqualTo(BigDecimal value) {
            addCriterion("BUYER_COD_FEE =", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeNotEqualTo(BigDecimal value) {
            addCriterion("BUYER_COD_FEE <>", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeGreaterThan(BigDecimal value) {
            addCriterion("BUYER_COD_FEE >", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("BUYER_COD_FEE >=", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeLessThan(BigDecimal value) {
            addCriterion("BUYER_COD_FEE <", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("BUYER_COD_FEE <=", value, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeIn(List<BigDecimal> values) {
            addCriterion("BUYER_COD_FEE in", values, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeNotIn(List<BigDecimal> values) {
            addCriterion("BUYER_COD_FEE not in", values, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("BUYER_COD_FEE between", value1, value2, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andBuyerCodFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("BUYER_COD_FEE not between", value1, value2, "buyerCodFee");
            return (Criteria) this;
        }

        public Criteria andCodStatusIsNull() {
            addCriterion("COD_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andCodStatusIsNotNull() {
            addCriterion("COD_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andCodStatusEqualTo(String value) {
            addCriterion("COD_STATUS =", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusNotEqualTo(String value) {
            addCriterion("COD_STATUS <>", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusGreaterThan(String value) {
            addCriterion("COD_STATUS >", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusGreaterThanOrEqualTo(String value) {
            addCriterion("COD_STATUS >=", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusLessThan(String value) {
            addCriterion("COD_STATUS <", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusLessThanOrEqualTo(String value) {
            addCriterion("COD_STATUS <=", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusLike(String value) {
            addCriterion("COD_STATUS like", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusNotLike(String value) {
            addCriterion("COD_STATUS not like", value, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusIn(List<String> values) {
            addCriterion("COD_STATUS in", values, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusNotIn(List<String> values) {
            addCriterion("COD_STATUS not in", values, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusBetween(String value1, String value2) {
            addCriterion("COD_STATUS between", value1, value2, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodStatusNotBetween(String value1, String value2) {
            addCriterion("COD_STATUS not between", value1, value2, "codStatus");
            return (Criteria) this;
        }

        public Criteria andCodFeeIsNull() {
            addCriterion("COD_FEE is null");
            return (Criteria) this;
        }

        public Criteria andCodFeeIsNotNull() {
            addCriterion("COD_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andCodFeeEqualTo(BigDecimal value) {
            addCriterion("COD_FEE =", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeNotEqualTo(BigDecimal value) {
            addCriterion("COD_FEE <>", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeGreaterThan(BigDecimal value) {
            addCriterion("COD_FEE >", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("COD_FEE >=", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeLessThan(BigDecimal value) {
            addCriterion("COD_FEE <", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("COD_FEE <=", value, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeIn(List<BigDecimal> values) {
            addCriterion("COD_FEE in", values, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeNotIn(List<BigDecimal> values) {
            addCriterion("COD_FEE not in", values, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COD_FEE between", value1, value2, "codFee");
            return (Criteria) this;
        }

        public Criteria andCodFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COD_FEE not between", value1, value2, "codFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeIsNull() {
            addCriterion("POINT_FEE is null");
            return (Criteria) this;
        }

        public Criteria andPointFeeIsNotNull() {
            addCriterion("POINT_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andPointFeeEqualTo(Short value) {
            addCriterion("POINT_FEE =", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeNotEqualTo(Short value) {
            addCriterion("POINT_FEE <>", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeGreaterThan(Short value) {
            addCriterion("POINT_FEE >", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeGreaterThanOrEqualTo(Short value) {
            addCriterion("POINT_FEE >=", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeLessThan(Short value) {
            addCriterion("POINT_FEE <", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeLessThanOrEqualTo(Short value) {
            addCriterion("POINT_FEE <=", value, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeIn(List<Short> values) {
            addCriterion("POINT_FEE in", values, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeNotIn(List<Short> values) {
            addCriterion("POINT_FEE not in", values, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeBetween(Short value1, Short value2) {
            addCriterion("POINT_FEE between", value1, value2, "pointFee");
            return (Criteria) this;
        }

        public Criteria andPointFeeNotBetween(Short value1, Short value2) {
            addCriterion("POINT_FEE not between", value1, value2, "pointFee");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNull() {
            addCriterion("BUYER_MESSAGE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNotNull() {
            addCriterion("BUYER_MESSAGE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageEqualTo(String value) {
            addCriterion("BUYER_MESSAGE =", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <>", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThan(String value) {
            addCriterion("BUYER_MESSAGE >", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE >=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThan(String value) {
            addCriterion("BUYER_MESSAGE <", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLike(String value) {
            addCriterion("BUYER_MESSAGE like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotLike(String value) {
            addCriterion("BUYER_MESSAGE not like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIn(List<String> values) {
            addCriterion("BUYER_MESSAGE in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotIn(List<String> values) {
            addCriterion("BUYER_MESSAGE not in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE not between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagIsNull() {
            addCriterion("BUYER_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagIsNotNull() {
            addCriterion("BUYER_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagEqualTo(Short value) {
            addCriterion("BUYER_FLAG =", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagNotEqualTo(Short value) {
            addCriterion("BUYER_FLAG <>", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagGreaterThan(Short value) {
            addCriterion("BUYER_FLAG >", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagGreaterThanOrEqualTo(Short value) {
            addCriterion("BUYER_FLAG >=", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagLessThan(Short value) {
            addCriterion("BUYER_FLAG <", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagLessThanOrEqualTo(Short value) {
            addCriterion("BUYER_FLAG <=", value, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagIn(List<Short> values) {
            addCriterion("BUYER_FLAG in", values, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagNotIn(List<Short> values) {
            addCriterion("BUYER_FLAG not in", values, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagBetween(Short value1, Short value2) {
            addCriterion("BUYER_FLAG between", value1, value2, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andBuyerFlagNotBetween(Short value1, Short value2) {
            addCriterion("BUYER_FLAG not between", value1, value2, "buyerFlag");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNull() {
            addCriterion("SELLER_MEMO is null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNotNull() {
            addCriterion("SELLER_MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoEqualTo(String value) {
            addCriterion("SELLER_MEMO =", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotEqualTo(String value) {
            addCriterion("SELLER_MEMO <>", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThan(String value) {
            addCriterion("SELLER_MEMO >", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO >=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThan(String value) {
            addCriterion("SELLER_MEMO <", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO <=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLike(String value) {
            addCriterion("SELLER_MEMO like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotLike(String value) {
            addCriterion("SELLER_MEMO not like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIn(List<String> values) {
            addCriterion("SELLER_MEMO in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotIn(List<String> values) {
            addCriterion("SELLER_MEMO not in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO not between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaIsNull() {
            addCriterion("BUYER_AREA is null");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaIsNotNull() {
            addCriterion("BUYER_AREA is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaEqualTo(String value) {
            addCriterion("BUYER_AREA =", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaNotEqualTo(String value) {
            addCriterion("BUYER_AREA <>", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaGreaterThan(String value) {
            addCriterion("BUYER_AREA >", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_AREA >=", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaLessThan(String value) {
            addCriterion("BUYER_AREA <", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaLessThanOrEqualTo(String value) {
            addCriterion("BUYER_AREA <=", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaLike(String value) {
            addCriterion("BUYER_AREA like", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaNotLike(String value) {
            addCriterion("BUYER_AREA not like", value, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaIn(List<String> values) {
            addCriterion("BUYER_AREA in", values, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaNotIn(List<String> values) {
            addCriterion("BUYER_AREA not in", values, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaBetween(String value1, String value2) {
            addCriterion("BUYER_AREA between", value1, value2, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAreaNotBetween(String value1, String value2) {
            addCriterion("BUYER_AREA not between", value1, value2, "buyerArea");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoIsNull() {
            addCriterion("BUYER_ALIPAY_NO is null");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoIsNotNull() {
            addCriterion("BUYER_ALIPAY_NO is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoEqualTo(String value) {
            addCriterion("BUYER_ALIPAY_NO =", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoNotEqualTo(String value) {
            addCriterion("BUYER_ALIPAY_NO <>", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoGreaterThan(String value) {
            addCriterion("BUYER_ALIPAY_NO >", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_ALIPAY_NO >=", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoLessThan(String value) {
            addCriterion("BUYER_ALIPAY_NO <", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoLessThanOrEqualTo(String value) {
            addCriterion("BUYER_ALIPAY_NO <=", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoLike(String value) {
            addCriterion("BUYER_ALIPAY_NO like", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoNotLike(String value) {
            addCriterion("BUYER_ALIPAY_NO not like", value, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoIn(List<String> values) {
            addCriterion("BUYER_ALIPAY_NO in", values, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoNotIn(List<String> values) {
            addCriterion("BUYER_ALIPAY_NO not in", values, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoBetween(String value1, String value2) {
            addCriterion("BUYER_ALIPAY_NO between", value1, value2, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andBuyerAlipayNoNotBetween(String value1, String value2) {
            addCriterion("BUYER_ALIPAY_NO not between", value1, value2, "buyerAlipayNo");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameIsNull() {
            addCriterion("FENXIAO_SHOP_NAME is null");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameIsNotNull() {
            addCriterion("FENXIAO_SHOP_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameEqualTo(String value) {
            addCriterion("FENXIAO_SHOP_NAME =", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameNotEqualTo(String value) {
            addCriterion("FENXIAO_SHOP_NAME <>", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameGreaterThan(String value) {
            addCriterion("FENXIAO_SHOP_NAME >", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameGreaterThanOrEqualTo(String value) {
            addCriterion("FENXIAO_SHOP_NAME >=", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameLessThan(String value) {
            addCriterion("FENXIAO_SHOP_NAME <", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameLessThanOrEqualTo(String value) {
            addCriterion("FENXIAO_SHOP_NAME <=", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameLike(String value) {
            addCriterion("FENXIAO_SHOP_NAME like", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameNotLike(String value) {
            addCriterion("FENXIAO_SHOP_NAME not like", value, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameIn(List<String> values) {
            addCriterion("FENXIAO_SHOP_NAME in", values, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameNotIn(List<String> values) {
            addCriterion("FENXIAO_SHOP_NAME not in", values, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameBetween(String value1, String value2) {
            addCriterion("FENXIAO_SHOP_NAME between", value1, value2, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopNameNotBetween(String value1, String value2) {
            addCriterion("FENXIAO_SHOP_NAME not between", value1, value2, "fenxiaoShopName");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdIsNull() {
            addCriterion("FENXIAO_SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdIsNotNull() {
            addCriterion("FENXIAO_SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdEqualTo(Short value) {
            addCriterion("FENXIAO_SHOP_ID =", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdNotEqualTo(Short value) {
            addCriterion("FENXIAO_SHOP_ID <>", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdGreaterThan(Short value) {
            addCriterion("FENXIAO_SHOP_ID >", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdGreaterThanOrEqualTo(Short value) {
            addCriterion("FENXIAO_SHOP_ID >=", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdLessThan(Short value) {
            addCriterion("FENXIAO_SHOP_ID <", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdLessThanOrEqualTo(Short value) {
            addCriterion("FENXIAO_SHOP_ID <=", value, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdIn(List<Short> values) {
            addCriterion("FENXIAO_SHOP_ID in", values, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdNotIn(List<Short> values) {
            addCriterion("FENXIAO_SHOP_ID not in", values, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdBetween(Short value1, Short value2) {
            addCriterion("FENXIAO_SHOP_ID between", value1, value2, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andFenxiaoShopIdNotBetween(Short value1, Short value2) {
            addCriterion("FENXIAO_SHOP_ID not between", value1, value2, "fenxiaoShopId");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedIsNull() {
            addCriterion("IS_SCORE_UPDATED is null");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedIsNotNull() {
            addCriterion("IS_SCORE_UPDATED is not null");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedEqualTo(Short value) {
            addCriterion("IS_SCORE_UPDATED =", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedNotEqualTo(Short value) {
            addCriterion("IS_SCORE_UPDATED <>", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedGreaterThan(Short value) {
            addCriterion("IS_SCORE_UPDATED >", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedGreaterThanOrEqualTo(Short value) {
            addCriterion("IS_SCORE_UPDATED >=", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedLessThan(Short value) {
            addCriterion("IS_SCORE_UPDATED <", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedLessThanOrEqualTo(Short value) {
            addCriterion("IS_SCORE_UPDATED <=", value, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedIn(List<Short> values) {
            addCriterion("IS_SCORE_UPDATED in", values, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedNotIn(List<Short> values) {
            addCriterion("IS_SCORE_UPDATED not in", values, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedBetween(Short value1, Short value2) {
            addCriterion("IS_SCORE_UPDATED between", value1, value2, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andIsScoreUpdatedNotBetween(Short value1, Short value2) {
            addCriterion("IS_SCORE_UPDATED not between", value1, value2, "isScoreUpdated");
            return (Criteria) this;
        }

        public Criteria andServiceTagsIsNull() {
            addCriterion("SERVICE_TAGS is null");
            return (Criteria) this;
        }

        public Criteria andServiceTagsIsNotNull() {
            addCriterion("SERVICE_TAGS is not null");
            return (Criteria) this;
        }

        public Criteria andServiceTagsEqualTo(String value) {
            addCriterion("SERVICE_TAGS =", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsNotEqualTo(String value) {
            addCriterion("SERVICE_TAGS <>", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsGreaterThan(String value) {
            addCriterion("SERVICE_TAGS >", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsGreaterThanOrEqualTo(String value) {
            addCriterion("SERVICE_TAGS >=", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsLessThan(String value) {
            addCriterion("SERVICE_TAGS <", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsLessThanOrEqualTo(String value) {
            addCriterion("SERVICE_TAGS <=", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsLike(String value) {
            addCriterion("SERVICE_TAGS like", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsNotLike(String value) {
            addCriterion("SERVICE_TAGS not like", value, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsIn(List<String> values) {
            addCriterion("SERVICE_TAGS in", values, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsNotIn(List<String> values) {
            addCriterion("SERVICE_TAGS not in", values, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsBetween(String value1, String value2) {
            addCriterion("SERVICE_TAGS between", value1, value2, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andServiceTagsNotBetween(String value1, String value2) {
            addCriterion("SERVICE_TAGS not between", value1, value2, "serviceTags");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIsNull() {
            addCriterion("ZHENGJI_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIsNotNull() {
            addCriterion("ZHENGJI_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS =", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS <>", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusGreaterThan(Short value) {
            addCriterion("ZHENGJI_STATUS >", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS >=", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusLessThan(Short value) {
            addCriterion("ZHENGJI_STATUS <", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusLessThanOrEqualTo(Short value) {
            addCriterion("ZHENGJI_STATUS <=", value, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusIn(List<Short> values) {
            addCriterion("ZHENGJI_STATUS in", values, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotIn(List<Short> values) {
            addCriterion("ZHENGJI_STATUS not in", values, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusBetween(Short value1, Short value2) {
            addCriterion("ZHENGJI_STATUS between", value1, value2, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andZhengjiStatusNotBetween(Short value1, Short value2) {
            addCriterion("ZHENGJI_STATUS not between", value1, value2, "zhengjiStatus");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNull() {
            addCriterion("TARGET_ORDER_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNotNull() {
            addCriterion("TARGET_ORDER_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidEqualTo(Short value) {
            addCriterion("TARGET_ORDER_UKID =", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotEqualTo(Short value) {
            addCriterion("TARGET_ORDER_UKID <>", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThan(Short value) {
            addCriterion("TARGET_ORDER_UKID >", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("TARGET_ORDER_UKID >=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThan(Short value) {
            addCriterion("TARGET_ORDER_UKID <", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThanOrEqualTo(Short value) {
            addCriterion("TARGET_ORDER_UKID <=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIn(List<Short> values) {
            addCriterion("TARGET_ORDER_UKID in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotIn(List<Short> values) {
            addCriterion("TARGET_ORDER_UKID not in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidBetween(Short value1, Short value2) {
            addCriterion("TARGET_ORDER_UKID between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotBetween(Short value1, Short value2) {
            addCriterion("TARGET_ORDER_UKID not between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameIsNull() {
            addCriterion("INVOICE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameIsNotNull() {
            addCriterion("INVOICE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameEqualTo(String value) {
            addCriterion("INVOICE_NAME =", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameNotEqualTo(String value) {
            addCriterion("INVOICE_NAME <>", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameGreaterThan(String value) {
            addCriterion("INVOICE_NAME >", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_NAME >=", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameLessThan(String value) {
            addCriterion("INVOICE_NAME <", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_NAME <=", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameLike(String value) {
            addCriterion("INVOICE_NAME like", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameNotLike(String value) {
            addCriterion("INVOICE_NAME not like", value, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameIn(List<String> values) {
            addCriterion("INVOICE_NAME in", values, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameNotIn(List<String> values) {
            addCriterion("INVOICE_NAME not in", values, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameBetween(String value1, String value2) {
            addCriterion("INVOICE_NAME between", value1, value2, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceNameNotBetween(String value1, String value2) {
            addCriterion("INVOICE_NAME not between", value1, value2, "invoiceName");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeIsNull() {
            addCriterion("INVOICE_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeIsNotNull() {
            addCriterion("INVOICE_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeEqualTo(String value) {
            addCriterion("INVOICE_TYPE =", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeNotEqualTo(String value) {
            addCriterion("INVOICE_TYPE <>", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeGreaterThan(String value) {
            addCriterion("INVOICE_TYPE >", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_TYPE >=", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeLessThan(String value) {
            addCriterion("INVOICE_TYPE <", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_TYPE <=", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeLike(String value) {
            addCriterion("INVOICE_TYPE like", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeNotLike(String value) {
            addCriterion("INVOICE_TYPE not like", value, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeIn(List<String> values) {
            addCriterion("INVOICE_TYPE in", values, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeNotIn(List<String> values) {
            addCriterion("INVOICE_TYPE not in", values, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeBetween(String value1, String value2) {
            addCriterion("INVOICE_TYPE between", value1, value2, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andInvoiceTypeNotBetween(String value1, String value2) {
            addCriterion("INVOICE_TYPE not between", value1, value2, "invoiceType");
            return (Criteria) this;
        }

        public Criteria andEstConTimeIsNull() {
            addCriterion("EST_CON_TIME is null");
            return (Criteria) this;
        }

        public Criteria andEstConTimeIsNotNull() {
            addCriterion("EST_CON_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andEstConTimeEqualTo(String value) {
            addCriterion("EST_CON_TIME =", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeNotEqualTo(String value) {
            addCriterion("EST_CON_TIME <>", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeGreaterThan(String value) {
            addCriterion("EST_CON_TIME >", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeGreaterThanOrEqualTo(String value) {
            addCriterion("EST_CON_TIME >=", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeLessThan(String value) {
            addCriterion("EST_CON_TIME <", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeLessThanOrEqualTo(String value) {
            addCriterion("EST_CON_TIME <=", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeLike(String value) {
            addCriterion("EST_CON_TIME like", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeNotLike(String value) {
            addCriterion("EST_CON_TIME not like", value, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeIn(List<String> values) {
            addCriterion("EST_CON_TIME in", values, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeNotIn(List<String> values) {
            addCriterion("EST_CON_TIME not in", values, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeBetween(String value1, String value2) {
            addCriterion("EST_CON_TIME between", value1, value2, "estConTime");
            return (Criteria) this;
        }

        public Criteria andEstConTimeNotBetween(String value1, String value2) {
            addCriterion("EST_CON_TIME not between", value1, value2, "estConTime");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindIsNull() {
            addCriterion("INVOICE_KIND is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindIsNotNull() {
            addCriterion("INVOICE_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindEqualTo(String value) {
            addCriterion("INVOICE_KIND =", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindNotEqualTo(String value) {
            addCriterion("INVOICE_KIND <>", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindGreaterThan(String value) {
            addCriterion("INVOICE_KIND >", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_KIND >=", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindLessThan(String value) {
            addCriterion("INVOICE_KIND <", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_KIND <=", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindLike(String value) {
            addCriterion("INVOICE_KIND like", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindNotLike(String value) {
            addCriterion("INVOICE_KIND not like", value, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindIn(List<String> values) {
            addCriterion("INVOICE_KIND in", values, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindNotIn(List<String> values) {
            addCriterion("INVOICE_KIND not in", values, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindBetween(String value1, String value2) {
            addCriterion("INVOICE_KIND between", value1, value2, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andInvoiceKindNotBetween(String value1, String value2) {
            addCriterion("INVOICE_KIND not between", value1, value2, "invoiceKind");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeIsNull() {
            addCriterion("PAID_COUPON_FEE is null");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeIsNotNull() {
            addCriterion("PAID_COUPON_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeEqualTo(String value) {
            addCriterion("PAID_COUPON_FEE =", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeNotEqualTo(String value) {
            addCriterion("PAID_COUPON_FEE <>", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeGreaterThan(String value) {
            addCriterion("PAID_COUPON_FEE >", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeGreaterThanOrEqualTo(String value) {
            addCriterion("PAID_COUPON_FEE >=", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeLessThan(String value) {
            addCriterion("PAID_COUPON_FEE <", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeLessThanOrEqualTo(String value) {
            addCriterion("PAID_COUPON_FEE <=", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeLike(String value) {
            addCriterion("PAID_COUPON_FEE like", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeNotLike(String value) {
            addCriterion("PAID_COUPON_FEE not like", value, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeIn(List<String> values) {
            addCriterion("PAID_COUPON_FEE in", values, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeNotIn(List<String> values) {
            addCriterion("PAID_COUPON_FEE not in", values, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeBetween(String value1, String value2) {
            addCriterion("PAID_COUPON_FEE between", value1, value2, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andPaidCouponFeeNotBetween(String value1, String value2) {
            addCriterion("PAID_COUPON_FEE not between", value1, value2, "paidCouponFee");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentIsNull() {
            addCriterion("RECEIVED_PAYMENT is null");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentIsNotNull() {
            addCriterion("RECEIVED_PAYMENT is not null");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentEqualTo(String value) {
            addCriterion("RECEIVED_PAYMENT =", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentNotEqualTo(String value) {
            addCriterion("RECEIVED_PAYMENT <>", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentGreaterThan(String value) {
            addCriterion("RECEIVED_PAYMENT >", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVED_PAYMENT >=", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentLessThan(String value) {
            addCriterion("RECEIVED_PAYMENT <", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentLessThanOrEqualTo(String value) {
            addCriterion("RECEIVED_PAYMENT <=", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentLike(String value) {
            addCriterion("RECEIVED_PAYMENT like", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentNotLike(String value) {
            addCriterion("RECEIVED_PAYMENT not like", value, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentIn(List<String> values) {
            addCriterion("RECEIVED_PAYMENT in", values, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentNotIn(List<String> values) {
            addCriterion("RECEIVED_PAYMENT not in", values, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentBetween(String value1, String value2) {
            addCriterion("RECEIVED_PAYMENT between", value1, value2, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andReceivedPaymentNotBetween(String value1, String value2) {
            addCriterion("RECEIVED_PAYMENT not between", value1, value2, "receivedPayment");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrIsNull() {
            addCriterion("ETICKET_SERVICE_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrIsNotNull() {
            addCriterion("ETICKET_SERVICE_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrEqualTo(String value) {
            addCriterion("ETICKET_SERVICE_ADDR =", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrNotEqualTo(String value) {
            addCriterion("ETICKET_SERVICE_ADDR <>", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrGreaterThan(String value) {
            addCriterion("ETICKET_SERVICE_ADDR >", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrGreaterThanOrEqualTo(String value) {
            addCriterion("ETICKET_SERVICE_ADDR >=", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrLessThan(String value) {
            addCriterion("ETICKET_SERVICE_ADDR <", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrLessThanOrEqualTo(String value) {
            addCriterion("ETICKET_SERVICE_ADDR <=", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrLike(String value) {
            addCriterion("ETICKET_SERVICE_ADDR like", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrNotLike(String value) {
            addCriterion("ETICKET_SERVICE_ADDR not like", value, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrIn(List<String> values) {
            addCriterion("ETICKET_SERVICE_ADDR in", values, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrNotIn(List<String> values) {
            addCriterion("ETICKET_SERVICE_ADDR not in", values, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrBetween(String value1, String value2) {
            addCriterion("ETICKET_SERVICE_ADDR between", value1, value2, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andEticketServiceAddrNotBetween(String value1, String value2) {
            addCriterion("ETICKET_SERVICE_ADDR not between", value1, value2, "eticketServiceAddr");
            return (Criteria) this;
        }

        public Criteria andIsShShipIsNull() {
            addCriterion("IS_SH_SHIP is null");
            return (Criteria) this;
        }

        public Criteria andIsShShipIsNotNull() {
            addCriterion("IS_SH_SHIP is not null");
            return (Criteria) this;
        }

        public Criteria andIsShShipEqualTo(String value) {
            addCriterion("IS_SH_SHIP =", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipNotEqualTo(String value) {
            addCriterion("IS_SH_SHIP <>", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipGreaterThan(String value) {
            addCriterion("IS_SH_SHIP >", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipGreaterThanOrEqualTo(String value) {
            addCriterion("IS_SH_SHIP >=", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipLessThan(String value) {
            addCriterion("IS_SH_SHIP <", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipLessThanOrEqualTo(String value) {
            addCriterion("IS_SH_SHIP <=", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipLike(String value) {
            addCriterion("IS_SH_SHIP like", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipNotLike(String value) {
            addCriterion("IS_SH_SHIP not like", value, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipIn(List<String> values) {
            addCriterion("IS_SH_SHIP in", values, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipNotIn(List<String> values) {
            addCriterion("IS_SH_SHIP not in", values, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipBetween(String value1, String value2) {
            addCriterion("IS_SH_SHIP between", value1, value2, "isShShip");
            return (Criteria) this;
        }

        public Criteria andIsShShipNotBetween(String value1, String value2) {
            addCriterion("IS_SH_SHIP not between", value1, value2, "isShShip");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusIsNull() {
            addCriterion("O2O_SNATCH_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusIsNotNull() {
            addCriterion("O2O_SNATCH_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusEqualTo(String value) {
            addCriterion("O2O_SNATCH_STATUS =", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusNotEqualTo(String value) {
            addCriterion("O2O_SNATCH_STATUS <>", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusGreaterThan(String value) {
            addCriterion("O2O_SNATCH_STATUS >", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusGreaterThanOrEqualTo(String value) {
            addCriterion("O2O_SNATCH_STATUS >=", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusLessThan(String value) {
            addCriterion("O2O_SNATCH_STATUS <", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusLessThanOrEqualTo(String value) {
            addCriterion("O2O_SNATCH_STATUS <=", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusLike(String value) {
            addCriterion("O2O_SNATCH_STATUS like", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusNotLike(String value) {
            addCriterion("O2O_SNATCH_STATUS not like", value, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusIn(List<String> values) {
            addCriterion("O2O_SNATCH_STATUS in", values, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusNotIn(List<String> values) {
            addCriterion("O2O_SNATCH_STATUS not in", values, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusBetween(String value1, String value2) {
            addCriterion("O2O_SNATCH_STATUS between", value1, value2, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andO2oSnatchStatusNotBetween(String value1, String value2) {
            addCriterion("O2O_SNATCH_STATUS not between", value1, value2, "o2oSnatchStatus");
            return (Criteria) this;
        }

        public Criteria andMarketIsNull() {
            addCriterion("MARKET is null");
            return (Criteria) this;
        }

        public Criteria andMarketIsNotNull() {
            addCriterion("MARKET is not null");
            return (Criteria) this;
        }

        public Criteria andMarketEqualTo(String value) {
            addCriterion("MARKET =", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketNotEqualTo(String value) {
            addCriterion("MARKET <>", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketGreaterThan(String value) {
            addCriterion("MARKET >", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketGreaterThanOrEqualTo(String value) {
            addCriterion("MARKET >=", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketLessThan(String value) {
            addCriterion("MARKET <", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketLessThanOrEqualTo(String value) {
            addCriterion("MARKET <=", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketLike(String value) {
            addCriterion("MARKET like", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketNotLike(String value) {
            addCriterion("MARKET not like", value, "market");
            return (Criteria) this;
        }

        public Criteria andMarketIn(List<String> values) {
            addCriterion("MARKET in", values, "market");
            return (Criteria) this;
        }

        public Criteria andMarketNotIn(List<String> values) {
            addCriterion("MARKET not in", values, "market");
            return (Criteria) this;
        }

        public Criteria andMarketBetween(String value1, String value2) {
            addCriterion("MARKET between", value1, value2, "market");
            return (Criteria) this;
        }

        public Criteria andMarketNotBetween(String value1, String value2) {
            addCriterion("MARKET not between", value1, value2, "market");
            return (Criteria) this;
        }

        public Criteria andEtTypeIsNull() {
            addCriterion("ET_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andEtTypeIsNotNull() {
            addCriterion("ET_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andEtTypeEqualTo(String value) {
            addCriterion("ET_TYPE =", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeNotEqualTo(String value) {
            addCriterion("ET_TYPE <>", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeGreaterThan(String value) {
            addCriterion("ET_TYPE >", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeGreaterThanOrEqualTo(String value) {
            addCriterion("ET_TYPE >=", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeLessThan(String value) {
            addCriterion("ET_TYPE <", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeLessThanOrEqualTo(String value) {
            addCriterion("ET_TYPE <=", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeLike(String value) {
            addCriterion("ET_TYPE like", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeNotLike(String value) {
            addCriterion("ET_TYPE not like", value, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeIn(List<String> values) {
            addCriterion("ET_TYPE in", values, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeNotIn(List<String> values) {
            addCriterion("ET_TYPE not in", values, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeBetween(String value1, String value2) {
            addCriterion("ET_TYPE between", value1, value2, "etType");
            return (Criteria) this;
        }

        public Criteria andEtTypeNotBetween(String value1, String value2) {
            addCriterion("ET_TYPE not between", value1, value2, "etType");
            return (Criteria) this;
        }

        public Criteria andEtShopIdIsNull() {
            addCriterion("ET_SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andEtShopIdIsNotNull() {
            addCriterion("ET_SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andEtShopIdEqualTo(Short value) {
            addCriterion("ET_SHOP_ID =", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdNotEqualTo(Short value) {
            addCriterion("ET_SHOP_ID <>", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdGreaterThan(Short value) {
            addCriterion("ET_SHOP_ID >", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdGreaterThanOrEqualTo(Short value) {
            addCriterion("ET_SHOP_ID >=", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdLessThan(Short value) {
            addCriterion("ET_SHOP_ID <", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdLessThanOrEqualTo(Short value) {
            addCriterion("ET_SHOP_ID <=", value, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdIn(List<Short> values) {
            addCriterion("ET_SHOP_ID in", values, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdNotIn(List<Short> values) {
            addCriterion("ET_SHOP_ID not in", values, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdBetween(Short value1, Short value2) {
            addCriterion("ET_SHOP_ID between", value1, value2, "etShopId");
            return (Criteria) this;
        }

        public Criteria andEtShopIdNotBetween(Short value1, Short value2) {
            addCriterion("ET_SHOP_ID not between", value1, value2, "etShopId");
            return (Criteria) this;
        }

        public Criteria andObsIsNull() {
            addCriterion("OBS is null");
            return (Criteria) this;
        }

        public Criteria andObsIsNotNull() {
            addCriterion("OBS is not null");
            return (Criteria) this;
        }

        public Criteria andObsEqualTo(String value) {
            addCriterion("OBS =", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsNotEqualTo(String value) {
            addCriterion("OBS <>", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsGreaterThan(String value) {
            addCriterion("OBS >", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsGreaterThanOrEqualTo(String value) {
            addCriterion("OBS >=", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsLessThan(String value) {
            addCriterion("OBS <", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsLessThanOrEqualTo(String value) {
            addCriterion("OBS <=", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsLike(String value) {
            addCriterion("OBS like", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsNotLike(String value) {
            addCriterion("OBS not like", value, "obs");
            return (Criteria) this;
        }

        public Criteria andObsIn(List<String> values) {
            addCriterion("OBS in", values, "obs");
            return (Criteria) this;
        }

        public Criteria andObsNotIn(List<String> values) {
            addCriterion("OBS not in", values, "obs");
            return (Criteria) this;
        }

        public Criteria andObsBetween(String value1, String value2) {
            addCriterion("OBS between", value1, value2, "obs");
            return (Criteria) this;
        }

        public Criteria andObsNotBetween(String value1, String value2) {
            addCriterion("OBS not between", value1, value2, "obs");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Short value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Short value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Short value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Short> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Short> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Short value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Short value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}