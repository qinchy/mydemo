package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ImPlatformItemIllegalDOMapper {
    long countByExample(ImPlatformItemIllegalDOExample example);

    int deleteByExample(ImPlatformItemIllegalDOExample example);

    int deleteByPrimaryKey(Long platformItemUkid);

    int insert(ImPlatformItemIllegalDO record);

    int insertSelective(ImPlatformItemIllegalDO record);

    List<ImPlatformItemIllegalDO> selectByExample(ImPlatformItemIllegalDOExample example);

    ImPlatformItemIllegalDO selectByPrimaryKey(Long platformItemUkid);

    int updateByExampleSelective(@Param("record") ImPlatformItemIllegalDO record, @Param("example") ImPlatformItemIllegalDOExample example);

    int updateByExample(@Param("record") ImPlatformItemIllegalDO record, @Param("example") ImPlatformItemIllegalDOExample example);

    int updateByPrimaryKeySelective(ImPlatformItemIllegalDO record);

    int updateByPrimaryKey(ImPlatformItemIllegalDO record);
}