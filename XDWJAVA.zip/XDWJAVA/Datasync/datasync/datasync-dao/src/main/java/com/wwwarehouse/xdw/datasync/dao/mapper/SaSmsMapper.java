package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SaSmsDO;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsExample;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface SaSmsMapper {
    long countByExample(SaSmsExample example);

    int deleteByExample(SaSmsExample example);

    int deleteByPrimaryKey(Long smsUkid);

    int insert(SaSmsDO record);

    int insertSelective(SaSmsDO record);

    List<SaSmsDO> selectByExample(SaSmsExample example);

    SaSmsDO selectByPrimaryKey(Long smsUkid);

    int updateByExampleSelective(@Param("record") SaSmsDO record, @Param("example") SaSmsExample example);

    int updateByExample(@Param("record") SaSmsDO record, @Param("example") SaSmsExample example);

    int updateByPrimaryKeySelective(SaSmsDO record);

    int updateByPrimaryKey(SaSmsDO record);

    int updateSmsStatus(@Param("smsListUkids") String smsListUkids,
                        @Param("smsStatus") Long smsStatus,
                        @Param("actualSendTime") Date actualSendTime,
                        @Param("returnText") String returnText);

    List<SaSmsDO> getNeedSendGroupList(@Param("smsAccountUkid") Long smsAccountUkid);

    List<SaSmsDO> getNeedSendList(@Param("smsAccountUkid") Long smsAccountUkid,
                                  @Param("buId") Long buId, @Param("sendBuId") Long sendBuId,
                                  @Param("shopId") Long shopId, @Param("sendContent") String sendContent);
}