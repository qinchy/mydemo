package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SeYhdItemDO implements Serializable {
    private Long itemUkid;

    private Long tradeUkid;

    private Long originOrderStatus;

    private Long shopProductUkid;

    private Long productCodeUkid;

    private String productCode;

    private Date presaleDate;

    private Date downTime;

    private Date updateTime;

    private String workspaceId;

    private Long orderId;

    private String productCname;

    private BigDecimal orderItemAmount;

    private Long orderItemNum;

    private BigDecimal orderItemPrice;

    private BigDecimal originalPrice;

    private Long productId;

    private Long groupFlag;

    private Long merchantId;

    private Date processFinishDate;

    private String outerId;

    private BigDecimal deliveryFeeAmount;

    private BigDecimal promotionAmount;

    private BigDecimal couponAmountMerchant;

    private BigDecimal couponPlatformDiscount;

    private BigDecimal subsidyAmount;

    private BigDecimal productDeposit;

    private BigDecimal discountAmount;

    private Long subOrderId;

    private Long updateUserId;

    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getItemUkid() {
        return itemUkid;
    }

    public void setItemUkid(Long itemUkid) {
        this.itemUkid = itemUkid;
    }

    public Long getTradeUkid() {
        return tradeUkid;
    }

    public void setTradeUkid(Long tradeUkid) {
        this.tradeUkid = tradeUkid;
    }

    public Long getOriginOrderStatus() {
        return originOrderStatus;
    }

    public void setOriginOrderStatus(Long originOrderStatus) {
        this.originOrderStatus = originOrderStatus;
    }

    public Long getShopProductUkid() {
        return shopProductUkid;
    }

    public void setShopProductUkid(Long shopProductUkid) {
        this.shopProductUkid = shopProductUkid;
    }

    public Long getProductCodeUkid() {
        return productCodeUkid;
    }

    public void setProductCodeUkid(Long productCodeUkid) {
        this.productCodeUkid = productCodeUkid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Date getPresaleDate() {
        return presaleDate;
    }

    public void setPresaleDate(Date presaleDate) {
        this.presaleDate = presaleDate;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getWorkspaceId() {
        return workspaceId;
    }

    public void setWorkspaceId(String workspaceId) {
        this.workspaceId = workspaceId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getProductCname() {
        return productCname;
    }

    public void setProductCname(String productCname) {
        this.productCname = productCname;
    }

    public BigDecimal getOrderItemAmount() {
        return orderItemAmount;
    }

    public void setOrderItemAmount(BigDecimal orderItemAmount) {
        this.orderItemAmount = orderItemAmount;
    }

    public Long getOrderItemNum() {
        return orderItemNum;
    }

    public void setOrderItemNum(Long orderItemNum) {
        this.orderItemNum = orderItemNum;
    }

    public BigDecimal getOrderItemPrice() {
        return orderItemPrice;
    }

    public void setOrderItemPrice(BigDecimal orderItemPrice) {
        this.orderItemPrice = orderItemPrice;
    }

    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getGroupFlag() {
        return groupFlag;
    }

    public void setGroupFlag(Long groupFlag) {
        this.groupFlag = groupFlag;
    }

    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public Date getProcessFinishDate() {
        return processFinishDate;
    }

    public void setProcessFinishDate(Date processFinishDate) {
        this.processFinishDate = processFinishDate;
    }

    public String getOuterId() {
        return outerId;
    }

    public void setOuterId(String outerId) {
        this.outerId = outerId;
    }

    public BigDecimal getDeliveryFeeAmount() {
        return deliveryFeeAmount;
    }

    public void setDeliveryFeeAmount(BigDecimal deliveryFeeAmount) {
        this.deliveryFeeAmount = deliveryFeeAmount;
    }

    public BigDecimal getPromotionAmount() {
        return promotionAmount;
    }

    public void setPromotionAmount(BigDecimal promotionAmount) {
        this.promotionAmount = promotionAmount;
    }

    public BigDecimal getCouponAmountMerchant() {
        return couponAmountMerchant;
    }

    public void setCouponAmountMerchant(BigDecimal couponAmountMerchant) {
        this.couponAmountMerchant = couponAmountMerchant;
    }

    public BigDecimal getCouponPlatformDiscount() {
        return couponPlatformDiscount;
    }

    public void setCouponPlatformDiscount(BigDecimal couponPlatformDiscount) {
        this.couponPlatformDiscount = couponPlatformDiscount;
    }

    public BigDecimal getSubsidyAmount() {
        return subsidyAmount;
    }

    public void setSubsidyAmount(BigDecimal subsidyAmount) {
        this.subsidyAmount = subsidyAmount;
    }

    public BigDecimal getProductDeposit() {
        return productDeposit;
    }

    public void setProductDeposit(BigDecimal productDeposit) {
        this.productDeposit = productDeposit;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public Long getSubOrderId() {
        return subOrderId;
    }

    public void setSubOrderId(Long subOrderId) {
        this.subOrderId = subOrderId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", itemUkid=").append(itemUkid);
        sb.append(", tradeUkid=").append(tradeUkid);
        sb.append(", originOrderStatus=").append(originOrderStatus);
        sb.append(", shopProductUkid=").append(shopProductUkid);
        sb.append(", productCodeUkid=").append(productCodeUkid);
        sb.append(", productCode=").append(productCode);
        sb.append(", presaleDate=").append(presaleDate);
        sb.append(", downTime=").append(downTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", workspaceId=").append(workspaceId);
        sb.append(", orderId=").append(orderId);
        sb.append(", productCname=").append(productCname);
        sb.append(", orderItemAmount=").append(orderItemAmount);
        sb.append(", orderItemNum=").append(orderItemNum);
        sb.append(", orderItemPrice=").append(orderItemPrice);
        sb.append(", originalPrice=").append(originalPrice);
        sb.append(", productId=").append(productId);
        sb.append(", groupFlag=").append(groupFlag);
        sb.append(", merchantId=").append(merchantId);
        sb.append(", processFinishDate=").append(processFinishDate);
        sb.append(", outerId=").append(outerId);
        sb.append(", deliveryFeeAmount=").append(deliveryFeeAmount);
        sb.append(", promotionAmount=").append(promotionAmount);
        sb.append(", couponAmountMerchant=").append(couponAmountMerchant);
        sb.append(", couponPlatformDiscount=").append(couponPlatformDiscount);
        sb.append(", subsidyAmount=").append(subsidyAmount);
        sb.append(", productDeposit=").append(productDeposit);
        sb.append(", discountAmount=").append(discountAmount);
        sb.append(", subOrderId=").append(subOrderId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", createTime=").append(createTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeYhdItemDO other = (SeYhdItemDO) that;
        return (this.getItemUkid() == null ? other.getItemUkid() == null : this.getItemUkid().equals(other.getItemUkid()))
            && (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
            && (this.getOriginOrderStatus() == null ? other.getOriginOrderStatus() == null : this.getOriginOrderStatus().equals(other.getOriginOrderStatus()))
            && (this.getShopProductUkid() == null ? other.getShopProductUkid() == null : this.getShopProductUkid().equals(other.getShopProductUkid()))
            && (this.getProductCodeUkid() == null ? other.getProductCodeUkid() == null : this.getProductCodeUkid().equals(other.getProductCodeUkid()))
            && (this.getProductCode() == null ? other.getProductCode() == null : this.getProductCode().equals(other.getProductCode()))
            && (this.getPresaleDate() == null ? other.getPresaleDate() == null : this.getPresaleDate().equals(other.getPresaleDate()))
            && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getWorkspaceId() == null ? other.getWorkspaceId() == null : this.getWorkspaceId().equals(other.getWorkspaceId()))
            && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
            && (this.getProductCname() == null ? other.getProductCname() == null : this.getProductCname().equals(other.getProductCname()))
            && (this.getOrderItemAmount() == null ? other.getOrderItemAmount() == null : this.getOrderItemAmount().equals(other.getOrderItemAmount()))
            && (this.getOrderItemNum() == null ? other.getOrderItemNum() == null : this.getOrderItemNum().equals(other.getOrderItemNum()))
            && (this.getOrderItemPrice() == null ? other.getOrderItemPrice() == null : this.getOrderItemPrice().equals(other.getOrderItemPrice()))
            && (this.getOriginalPrice() == null ? other.getOriginalPrice() == null : this.getOriginalPrice().equals(other.getOriginalPrice()))
            && (this.getProductId() == null ? other.getProductId() == null : this.getProductId().equals(other.getProductId()))
            && (this.getGroupFlag() == null ? other.getGroupFlag() == null : this.getGroupFlag().equals(other.getGroupFlag()))
            && (this.getMerchantId() == null ? other.getMerchantId() == null : this.getMerchantId().equals(other.getMerchantId()))
            && (this.getProcessFinishDate() == null ? other.getProcessFinishDate() == null : this.getProcessFinishDate().equals(other.getProcessFinishDate()))
            && (this.getOuterId() == null ? other.getOuterId() == null : this.getOuterId().equals(other.getOuterId()))
            && (this.getDeliveryFeeAmount() == null ? other.getDeliveryFeeAmount() == null : this.getDeliveryFeeAmount().equals(other.getDeliveryFeeAmount()))
            && (this.getPromotionAmount() == null ? other.getPromotionAmount() == null : this.getPromotionAmount().equals(other.getPromotionAmount()))
            && (this.getCouponAmountMerchant() == null ? other.getCouponAmountMerchant() == null : this.getCouponAmountMerchant().equals(other.getCouponAmountMerchant()))
            && (this.getCouponPlatformDiscount() == null ? other.getCouponPlatformDiscount() == null : this.getCouponPlatformDiscount().equals(other.getCouponPlatformDiscount()))
            && (this.getSubsidyAmount() == null ? other.getSubsidyAmount() == null : this.getSubsidyAmount().equals(other.getSubsidyAmount()))
            && (this.getProductDeposit() == null ? other.getProductDeposit() == null : this.getProductDeposit().equals(other.getProductDeposit()))
            && (this.getDiscountAmount() == null ? other.getDiscountAmount() == null : this.getDiscountAmount().equals(other.getDiscountAmount()))
            && (this.getSubOrderId() == null ? other.getSubOrderId() == null : this.getSubOrderId().equals(other.getSubOrderId()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getItemUkid() == null) ? 0 : getItemUkid().hashCode());
        result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
        result = prime * result + ((getOriginOrderStatus() == null) ? 0 : getOriginOrderStatus().hashCode());
        result = prime * result + ((getShopProductUkid() == null) ? 0 : getShopProductUkid().hashCode());
        result = prime * result + ((getProductCodeUkid() == null) ? 0 : getProductCodeUkid().hashCode());
        result = prime * result + ((getProductCode() == null) ? 0 : getProductCode().hashCode());
        result = prime * result + ((getPresaleDate() == null) ? 0 : getPresaleDate().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getWorkspaceId() == null) ? 0 : getWorkspaceId().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getProductCname() == null) ? 0 : getProductCname().hashCode());
        result = prime * result + ((getOrderItemAmount() == null) ? 0 : getOrderItemAmount().hashCode());
        result = prime * result + ((getOrderItemNum() == null) ? 0 : getOrderItemNum().hashCode());
        result = prime * result + ((getOrderItemPrice() == null) ? 0 : getOrderItemPrice().hashCode());
        result = prime * result + ((getOriginalPrice() == null) ? 0 : getOriginalPrice().hashCode());
        result = prime * result + ((getProductId() == null) ? 0 : getProductId().hashCode());
        result = prime * result + ((getGroupFlag() == null) ? 0 : getGroupFlag().hashCode());
        result = prime * result + ((getMerchantId() == null) ? 0 : getMerchantId().hashCode());
        result = prime * result + ((getProcessFinishDate() == null) ? 0 : getProcessFinishDate().hashCode());
        result = prime * result + ((getOuterId() == null) ? 0 : getOuterId().hashCode());
        result = prime * result + ((getDeliveryFeeAmount() == null) ? 0 : getDeliveryFeeAmount().hashCode());
        result = prime * result + ((getPromotionAmount() == null) ? 0 : getPromotionAmount().hashCode());
        result = prime * result + ((getCouponAmountMerchant() == null) ? 0 : getCouponAmountMerchant().hashCode());
        result = prime * result + ((getCouponPlatformDiscount() == null) ? 0 : getCouponPlatformDiscount().hashCode());
        result = prime * result + ((getSubsidyAmount() == null) ? 0 : getSubsidyAmount().hashCode());
        result = prime * result + ((getProductDeposit() == null) ? 0 : getProductDeposit().hashCode());
        result = prime * result + ((getDiscountAmount() == null) ? 0 : getDiscountAmount().hashCode());
        result = prime * result + ((getSubOrderId() == null) ? 0 : getSubOrderId().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        return result;
    }
}