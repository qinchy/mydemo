package com.wwwarehouse.xdw.datasync.dao.mapper;

import org.apache.ibatis.annotations.Param;

public interface AmDownTimeMapper{

	public int updateInvalid(@Param("relatedId") Long relatedId, @Param("closeUserId") Long closeUserId);
}