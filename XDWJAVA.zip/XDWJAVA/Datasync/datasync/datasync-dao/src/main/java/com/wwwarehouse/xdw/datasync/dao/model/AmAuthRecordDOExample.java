package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AmAuthRecordDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public AmAuthRecordDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAuthRecordUkidIsNull() {
            addCriterion("AUTH_RECORD_UKID is null");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidIsNotNull() {
            addCriterion("AUTH_RECORD_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidEqualTo(Long value) {
            addCriterion("AUTH_RECORD_UKID =", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidNotEqualTo(Long value) {
            addCriterion("AUTH_RECORD_UKID <>", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidGreaterThan(Long value) {
            addCriterion("AUTH_RECORD_UKID >", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("AUTH_RECORD_UKID >=", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidLessThan(Long value) {
            addCriterion("AUTH_RECORD_UKID <", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidLessThanOrEqualTo(Long value) {
            addCriterion("AUTH_RECORD_UKID <=", value, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidIn(List<Long> values) {
            addCriterion("AUTH_RECORD_UKID in", values, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidNotIn(List<Long> values) {
            addCriterion("AUTH_RECORD_UKID not in", values, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidBetween(Long value1, Long value2) {
            addCriterion("AUTH_RECORD_UKID between", value1, value2, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andAuthRecordUkidNotBetween(Long value1, Long value2) {
            addCriterion("AUTH_RECORD_UKID not between", value1, value2, "authRecordUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedIdIsNull() {
            addCriterion("RELATED_ID is null");
            return (Criteria) this;
        }

        public Criteria andRelatedIdIsNotNull() {
            addCriterion("RELATED_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRelatedIdEqualTo(Long value) {
            addCriterion("RELATED_ID =", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdNotEqualTo(Long value) {
            addCriterion("RELATED_ID <>", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdGreaterThan(Long value) {
            addCriterion("RELATED_ID >", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdGreaterThanOrEqualTo(Long value) {
            addCriterion("RELATED_ID >=", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdLessThan(Long value) {
            addCriterion("RELATED_ID <", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdLessThanOrEqualTo(Long value) {
            addCriterion("RELATED_ID <=", value, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdIn(List<Long> values) {
            addCriterion("RELATED_ID in", values, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdNotIn(List<Long> values) {
            addCriterion("RELATED_ID not in", values, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdBetween(Long value1, Long value2) {
            addCriterion("RELATED_ID between", value1, value2, "relatedId");
            return (Criteria) this;
        }

        public Criteria andRelatedIdNotBetween(Long value1, Long value2) {
            addCriterion("RELATED_ID not between", value1, value2, "relatedId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIsNull() {
            addCriterion("ACCESS_TOKEN is null");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIsNotNull() {
            addCriterion("ACCESS_TOKEN is not null");
            return (Criteria) this;
        }

        public Criteria andAccessTokenEqualTo(String value) {
            addCriterion("ACCESS_TOKEN =", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotEqualTo(String value) {
            addCriterion("ACCESS_TOKEN <>", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenGreaterThan(String value) {
            addCriterion("ACCESS_TOKEN >", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenGreaterThanOrEqualTo(String value) {
            addCriterion("ACCESS_TOKEN >=", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLessThan(String value) {
            addCriterion("ACCESS_TOKEN <", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLessThanOrEqualTo(String value) {
            addCriterion("ACCESS_TOKEN <=", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenLike(String value) {
            addCriterion("ACCESS_TOKEN like", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotLike(String value) {
            addCriterion("ACCESS_TOKEN not like", value, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenIn(List<String> values) {
            addCriterion("ACCESS_TOKEN in", values, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotIn(List<String> values) {
            addCriterion("ACCESS_TOKEN not in", values, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenBetween(String value1, String value2) {
            addCriterion("ACCESS_TOKEN between", value1, value2, "accessToken");
            return (Criteria) this;
        }

        public Criteria andAccessTokenNotBetween(String value1, String value2) {
            addCriterion("ACCESS_TOKEN not between", value1, value2, "accessToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIsNull() {
            addCriterion("REFRESH_TOKEN is null");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIsNotNull() {
            addCriterion("REFRESH_TOKEN is not null");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenEqualTo(String value) {
            addCriterion("REFRESH_TOKEN =", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotEqualTo(String value) {
            addCriterion("REFRESH_TOKEN <>", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenGreaterThan(String value) {
            addCriterion("REFRESH_TOKEN >", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenGreaterThanOrEqualTo(String value) {
            addCriterion("REFRESH_TOKEN >=", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLessThan(String value) {
            addCriterion("REFRESH_TOKEN <", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLessThanOrEqualTo(String value) {
            addCriterion("REFRESH_TOKEN <=", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenLike(String value) {
            addCriterion("REFRESH_TOKEN like", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotLike(String value) {
            addCriterion("REFRESH_TOKEN not like", value, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenIn(List<String> values) {
            addCriterion("REFRESH_TOKEN in", values, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotIn(List<String> values) {
            addCriterion("REFRESH_TOKEN not in", values, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenBetween(String value1, String value2) {
            addCriterion("REFRESH_TOKEN between", value1, value2, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andRefreshTokenNotBetween(String value1, String value2) {
            addCriterion("REFRESH_TOKEN not between", value1, value2, "refreshToken");
            return (Criteria) this;
        }

        public Criteria andExpiresInIsNull() {
            addCriterion("EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andExpiresInIsNotNull() {
            addCriterion("EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andExpiresInEqualTo(Long value) {
            addCriterion("EXPIRES_IN =", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotEqualTo(Long value) {
            addCriterion("EXPIRES_IN <>", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInGreaterThan(Long value) {
            addCriterion("EXPIRES_IN >", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("EXPIRES_IN >=", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInLessThan(Long value) {
            addCriterion("EXPIRES_IN <", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("EXPIRES_IN <=", value, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInIn(List<Long> values) {
            addCriterion("EXPIRES_IN in", values, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotIn(List<Long> values) {
            addCriterion("EXPIRES_IN not in", values, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInBetween(Long value1, Long value2) {
            addCriterion("EXPIRES_IN between", value1, value2, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("EXPIRES_IN not between", value1, value2, "expiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIsNull() {
            addCriterion("RE_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIsNotNull() {
            addCriterion("RE_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andReExpiresInEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN =", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN <>", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInGreaterThan(Long value) {
            addCriterion("RE_EXPIRES_IN >", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN >=", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInLessThan(Long value) {
            addCriterion("RE_EXPIRES_IN <", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("RE_EXPIRES_IN <=", value, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInIn(List<Long> values) {
            addCriterion("RE_EXPIRES_IN in", values, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotIn(List<Long> values) {
            addCriterion("RE_EXPIRES_IN not in", values, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInBetween(Long value1, Long value2) {
            addCriterion("RE_EXPIRES_IN between", value1, value2, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andReExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("RE_EXPIRES_IN not between", value1, value2, "reExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIsNull() {
            addCriterion("R1_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIsNotNull() {
            addCriterion("R1_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN =", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN <>", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInGreaterThan(Long value) {
            addCriterion("R1_EXPIRES_IN >", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN >=", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInLessThan(Long value) {
            addCriterion("R1_EXPIRES_IN <", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("R1_EXPIRES_IN <=", value, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInIn(List<Long> values) {
            addCriterion("R1_EXPIRES_IN in", values, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotIn(List<Long> values) {
            addCriterion("R1_EXPIRES_IN not in", values, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInBetween(Long value1, Long value2) {
            addCriterion("R1_EXPIRES_IN between", value1, value2, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR1ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("R1_EXPIRES_IN not between", value1, value2, "r1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIsNull() {
            addCriterion("R2_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIsNotNull() {
            addCriterion("R2_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN =", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN <>", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInGreaterThan(Long value) {
            addCriterion("R2_EXPIRES_IN >", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN >=", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInLessThan(Long value) {
            addCriterion("R2_EXPIRES_IN <", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("R2_EXPIRES_IN <=", value, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInIn(List<Long> values) {
            addCriterion("R2_EXPIRES_IN in", values, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotIn(List<Long> values) {
            addCriterion("R2_EXPIRES_IN not in", values, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInBetween(Long value1, Long value2) {
            addCriterion("R2_EXPIRES_IN between", value1, value2, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andR2ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("R2_EXPIRES_IN not between", value1, value2, "r2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIsNull() {
            addCriterion("W1_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIsNotNull() {
            addCriterion("W1_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN =", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN <>", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInGreaterThan(Long value) {
            addCriterion("W1_EXPIRES_IN >", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN >=", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInLessThan(Long value) {
            addCriterion("W1_EXPIRES_IN <", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("W1_EXPIRES_IN <=", value, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInIn(List<Long> values) {
            addCriterion("W1_EXPIRES_IN in", values, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotIn(List<Long> values) {
            addCriterion("W1_EXPIRES_IN not in", values, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInBetween(Long value1, Long value2) {
            addCriterion("W1_EXPIRES_IN between", value1, value2, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW1ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("W1_EXPIRES_IN not between", value1, value2, "w1ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIsNull() {
            addCriterion("W2_EXPIRES_IN is null");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIsNotNull() {
            addCriterion("W2_EXPIRES_IN is not null");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN =", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN <>", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInGreaterThan(Long value) {
            addCriterion("W2_EXPIRES_IN >", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInGreaterThanOrEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN >=", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInLessThan(Long value) {
            addCriterion("W2_EXPIRES_IN <", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInLessThanOrEqualTo(Long value) {
            addCriterion("W2_EXPIRES_IN <=", value, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInIn(List<Long> values) {
            addCriterion("W2_EXPIRES_IN in", values, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotIn(List<Long> values) {
            addCriterion("W2_EXPIRES_IN not in", values, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInBetween(Long value1, Long value2) {
            addCriterion("W2_EXPIRES_IN between", value1, value2, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andW2ExpiresInNotBetween(Long value1, Long value2) {
            addCriterion("W2_EXPIRES_IN not between", value1, value2, "w2ExpiresIn");
            return (Criteria) this;
        }

        public Criteria andTokenTypeIsNull() {
            addCriterion("TOKEN_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andTokenTypeIsNotNull() {
            addCriterion("TOKEN_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andTokenTypeEqualTo(String value) {
            addCriterion("TOKEN_TYPE =", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeNotEqualTo(String value) {
            addCriterion("TOKEN_TYPE <>", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeGreaterThan(String value) {
            addCriterion("TOKEN_TYPE >", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeGreaterThanOrEqualTo(String value) {
            addCriterion("TOKEN_TYPE >=", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeLessThan(String value) {
            addCriterion("TOKEN_TYPE <", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeLessThanOrEqualTo(String value) {
            addCriterion("TOKEN_TYPE <=", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeLike(String value) {
            addCriterion("TOKEN_TYPE like", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeNotLike(String value) {
            addCriterion("TOKEN_TYPE not like", value, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeIn(List<String> values) {
            addCriterion("TOKEN_TYPE in", values, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeNotIn(List<String> values) {
            addCriterion("TOKEN_TYPE not in", values, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeBetween(String value1, String value2) {
            addCriterion("TOKEN_TYPE between", value1, value2, "tokenType");
            return (Criteria) this;
        }

        public Criteria andTokenTypeNotBetween(String value1, String value2) {
            addCriterion("TOKEN_TYPE not between", value1, value2, "tokenType");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIsNull() {
            addCriterion("PLATFORM_USER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIsNotNull() {
            addCriterion("PLATFORM_USER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK =", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK <>", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickGreaterThan(String value) {
            addCriterion("PLATFORM_USER_NICK >", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK >=", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLessThan(String value) {
            addCriterion("PLATFORM_USER_NICK <", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_NICK <=", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickLike(String value) {
            addCriterion("PLATFORM_USER_NICK like", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotLike(String value) {
            addCriterion("PLATFORM_USER_NICK not like", value, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickIn(List<String> values) {
            addCriterion("PLATFORM_USER_NICK in", values, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotIn(List<String> values) {
            addCriterion("PLATFORM_USER_NICK not in", values, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_NICK between", value1, value2, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserNickNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_NICK not between", value1, value2, "platformUserNick");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIsNull() {
            addCriterion("PLATFORM_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIsNotNull() {
            addCriterion("PLATFORM_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID =", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID <>", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdGreaterThan(String value) {
            addCriterion("PLATFORM_USER_ID >", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID >=", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLessThan(String value) {
            addCriterion("PLATFORM_USER_ID <", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_USER_ID <=", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdLike(String value) {
            addCriterion("PLATFORM_USER_ID like", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotLike(String value) {
            addCriterion("PLATFORM_USER_ID not like", value, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdIn(List<String> values) {
            addCriterion("PLATFORM_USER_ID in", values, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotIn(List<String> values) {
            addCriterion("PLATFORM_USER_ID not in", values, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_ID between", value1, value2, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andPlatformUserIdNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_USER_ID not between", value1, value2, "platformUserId");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthIsNull() {
            addCriterion("IS_LAST_AUTH is null");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthIsNotNull() {
            addCriterion("IS_LAST_AUTH is not null");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthEqualTo(Long value) {
            addCriterion("IS_LAST_AUTH =", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthNotEqualTo(Long value) {
            addCriterion("IS_LAST_AUTH <>", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthGreaterThan(Long value) {
            addCriterion("IS_LAST_AUTH >", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthGreaterThanOrEqualTo(Long value) {
            addCriterion("IS_LAST_AUTH >=", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthLessThan(Long value) {
            addCriterion("IS_LAST_AUTH <", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthLessThanOrEqualTo(Long value) {
            addCriterion("IS_LAST_AUTH <=", value, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthIn(List<Long> values) {
            addCriterion("IS_LAST_AUTH in", values, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthNotIn(List<Long> values) {
            addCriterion("IS_LAST_AUTH not in", values, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthBetween(Long value1, Long value2) {
            addCriterion("IS_LAST_AUTH between", value1, value2, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andIsLastAuthNotBetween(Long value1, Long value2) {
            addCriterion("IS_LAST_AUTH not between", value1, value2, "isLastAuth");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andAppUkidIsNull() {
            addCriterion("APP_UKID is null");
            return (Criteria) this;
        }

        public Criteria andAppUkidIsNotNull() {
            addCriterion("APP_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andAppUkidEqualTo(Long value) {
            addCriterion("APP_UKID =", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotEqualTo(Long value) {
            addCriterion("APP_UKID <>", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThan(Long value) {
            addCriterion("APP_UKID >", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("APP_UKID >=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThan(Long value) {
            addCriterion("APP_UKID <", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThanOrEqualTo(Long value) {
            addCriterion("APP_UKID <=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidIn(List<Long> values) {
            addCriterion("APP_UKID in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotIn(List<Long> values) {
            addCriterion("APP_UKID not in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidBetween(Long value1, Long value2) {
            addCriterion("APP_UKID between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotBetween(Long value1, Long value2) {
            addCriterion("APP_UKID not between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}