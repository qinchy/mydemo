package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SeYhdTradeDO implements Serializable {
    private Long tradeUkid;

    private Long shopId;

    private Date downTime;

    private Date releaseTime;

    private Long originTradeStatus;

    private String orderId;

    private String orderCode;

    private String platformOrderStatus;

    private BigDecimal orderAmount;

    private BigDecimal productAmount;

    private Date orderCreateTime;

    private BigDecimal freightFee;

    private Long orderNeedInvoice;

    private String receiverName;

    private String receiverAddress;

    private String receiverState;

    private String receiverCity;

    private String receiverCounty;

    private String receiverZip;

    private String receiverPhone;

    private String receiverMobile;

    private Date deliveryDate;

    private Date consignTime;

    private String buyerMessage;

    private Long deliverySupplierId;

    private String sellerMemo;

    private Date orderPayTime;

    private Long payServiceType;

    private BigDecimal orderPromotionDiscount;

    private String merchantExpressNbr;

    private Date orderModifyTime;

    private BigDecimal orderCouponDiscount;

    private BigDecimal orderPlatformDiscount;

    private String invoiceTitle;

    private String invoiceContent;

    private String buyerNick;

    private BigDecimal realAmount;

    private Long warehouseId;

    private Long isMobileOrder;

    private Long businessType;

    private BigDecimal orderDeposit;

    private Long isDepositOrder;

    private Date depositPaidTime;

    private Long applyCancel;

    private Long storeId;

    private String storeName;

    private Long externalStoreId;

    private BigDecimal collectOnDeliveryAmount;

    private Long orderProdType;

    private String paymentNo;

    private String gatewayName;

    private String paymentTransaction;

    private Long targetOrderUkid;

    private Long updateUserId;

    private Long createUserId;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getTradeUkid() {
        return tradeUkid;
    }

    public void setTradeUkid(Long tradeUkid) {
        this.tradeUkid = tradeUkid;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public Long getOriginTradeStatus() {
        return originTradeStatus;
    }

    public void setOriginTradeStatus(Long originTradeStatus) {
        this.originTradeStatus = originTradeStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getPlatformOrderStatus() {
        return platformOrderStatus;
    }

    public void setPlatformOrderStatus(String platformOrderStatus) {
        this.platformOrderStatus = platformOrderStatus;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getProductAmount() {
        return productAmount;
    }

    public void setProductAmount(BigDecimal productAmount) {
        this.productAmount = productAmount;
    }

    public Date getOrderCreateTime() {
        return orderCreateTime;
    }

    public void setOrderCreateTime(Date orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }

    public BigDecimal getFreightFee() {
        return freightFee;
    }

    public void setFreightFee(BigDecimal freightFee) {
        this.freightFee = freightFee;
    }

    public Long getOrderNeedInvoice() {
        return orderNeedInvoice;
    }

    public void setOrderNeedInvoice(Long orderNeedInvoice) {
        this.orderNeedInvoice = orderNeedInvoice;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public String getReceiverState() {
        return receiverState;
    }

    public void setReceiverState(String receiverState) {
        this.receiverState = receiverState;
    }

    public String getReceiverCity() {
        return receiverCity;
    }

    public void setReceiverCity(String receiverCity) {
        this.receiverCity = receiverCity;
    }

    public String getReceiverCounty() {
        return receiverCounty;
    }

    public void setReceiverCounty(String receiverCounty) {
        this.receiverCounty = receiverCounty;
    }

    public String getReceiverZip() {
        return receiverZip;
    }

    public void setReceiverZip(String receiverZip) {
        this.receiverZip = receiverZip;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getReceiverMobile() {
        return receiverMobile;
    }

    public void setReceiverMobile(String receiverMobile) {
        this.receiverMobile = receiverMobile;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Date getConsignTime() {
        return consignTime;
    }

    public void setConsignTime(Date consignTime) {
        this.consignTime = consignTime;
    }

    public String getBuyerMessage() {
        return buyerMessage;
    }

    public void setBuyerMessage(String buyerMessage) {
        this.buyerMessage = buyerMessage;
    }

    public Long getDeliverySupplierId() {
        return deliverySupplierId;
    }

    public void setDeliverySupplierId(Long deliverySupplierId) {
        this.deliverySupplierId = deliverySupplierId;
    }

    public String getSellerMemo() {
        return sellerMemo;
    }

    public void setSellerMemo(String sellerMemo) {
        this.sellerMemo = sellerMemo;
    }

    public Date getOrderPayTime() {
        return orderPayTime;
    }

    public void setOrderPayTime(Date orderPayTime) {
        this.orderPayTime = orderPayTime;
    }

    public Long getPayServiceType() {
        return payServiceType;
    }

    public void setPayServiceType(Long payServiceType) {
        this.payServiceType = payServiceType;
    }

    public BigDecimal getOrderPromotionDiscount() {
        return orderPromotionDiscount;
    }

    public void setOrderPromotionDiscount(BigDecimal orderPromotionDiscount) {
        this.orderPromotionDiscount = orderPromotionDiscount;
    }

    public String getMerchantExpressNbr() {
        return merchantExpressNbr;
    }

    public void setMerchantExpressNbr(String merchantExpressNbr) {
        this.merchantExpressNbr = merchantExpressNbr;
    }

    public Date getOrderModifyTime() {
        return orderModifyTime;
    }

    public void setOrderModifyTime(Date orderModifyTime) {
        this.orderModifyTime = orderModifyTime;
    }

    public BigDecimal getOrderCouponDiscount() {
        return orderCouponDiscount;
    }

    public void setOrderCouponDiscount(BigDecimal orderCouponDiscount) {
        this.orderCouponDiscount = orderCouponDiscount;
    }

    public BigDecimal getOrderPlatformDiscount() {
        return orderPlatformDiscount;
    }

    public void setOrderPlatformDiscount(BigDecimal orderPlatformDiscount) {
        this.orderPlatformDiscount = orderPlatformDiscount;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getInvoiceContent() {
        return invoiceContent;
    }

    public void setInvoiceContent(String invoiceContent) {
        this.invoiceContent = invoiceContent;
    }

    public String getBuyerNick() {
        return buyerNick;
    }

    public void setBuyerNick(String buyerNick) {
        this.buyerNick = buyerNick;
    }

    public BigDecimal getRealAmount() {
        return realAmount;
    }

    public void setRealAmount(BigDecimal realAmount) {
        this.realAmount = realAmount;
    }

    public Long getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Long warehouseId) {
        this.warehouseId = warehouseId;
    }

    public Long getIsMobileOrder() {
        return isMobileOrder;
    }

    public void setIsMobileOrder(Long isMobileOrder) {
        this.isMobileOrder = isMobileOrder;
    }

    public Long getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Long businessType) {
        this.businessType = businessType;
    }

    public BigDecimal getOrderDeposit() {
        return orderDeposit;
    }

    public void setOrderDeposit(BigDecimal orderDeposit) {
        this.orderDeposit = orderDeposit;
    }

    public Long getIsDepositOrder() {
        return isDepositOrder;
    }

    public void setIsDepositOrder(Long isDepositOrder) {
        this.isDepositOrder = isDepositOrder;
    }

    public Date getDepositPaidTime() {
        return depositPaidTime;
    }

    public void setDepositPaidTime(Date depositPaidTime) {
        this.depositPaidTime = depositPaidTime;
    }

    public Long getApplyCancel() {
        return applyCancel;
    }

    public void setApplyCancel(Long applyCancel) {
        this.applyCancel = applyCancel;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public Long getExternalStoreId() {
        return externalStoreId;
    }

    public void setExternalStoreId(Long externalStoreId) {
        this.externalStoreId = externalStoreId;
    }

    public BigDecimal getCollectOnDeliveryAmount() {
        return collectOnDeliveryAmount;
    }

    public void setCollectOnDeliveryAmount(BigDecimal collectOnDeliveryAmount) {
        this.collectOnDeliveryAmount = collectOnDeliveryAmount;
    }

    public Long getOrderProdType() {
        return orderProdType;
    }

    public void setOrderProdType(Long orderProdType) {
        this.orderProdType = orderProdType;
    }

    public String getPaymentNo() {
        return paymentNo;
    }

    public void setPaymentNo(String paymentNo) {
        this.paymentNo = paymentNo;
    }

    public String getGatewayName() {
        return gatewayName;
    }

    public void setGatewayName(String gatewayName) {
        this.gatewayName = gatewayName;
    }

    public String getPaymentTransaction() {
        return paymentTransaction;
    }

    public void setPaymentTransaction(String paymentTransaction) {
        this.paymentTransaction = paymentTransaction;
    }

    public Long getTargetOrderUkid() {
        return targetOrderUkid;
    }

    public void setTargetOrderUkid(Long targetOrderUkid) {
        this.targetOrderUkid = targetOrderUkid;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", tradeUkid=").append(tradeUkid);
        sb.append(", shopId=").append(shopId);
        sb.append(", downTime=").append(downTime);
        sb.append(", releaseTime=").append(releaseTime);
        sb.append(", originTradeStatus=").append(originTradeStatus);
        sb.append(", orderId=").append(orderId);
        sb.append(", orderCode=").append(orderCode);
        sb.append(", platformOrderStatus=").append(platformOrderStatus);
        sb.append(", orderAmount=").append(orderAmount);
        sb.append(", productAmount=").append(productAmount);
        sb.append(", orderCreateTime=").append(orderCreateTime);
        sb.append(", freightFee=").append(freightFee);
        sb.append(", orderNeedInvoice=").append(orderNeedInvoice);
        sb.append(", receiverName=").append(receiverName);
        sb.append(", receiverAddress=").append(receiverAddress);
        sb.append(", receiverState=").append(receiverState);
        sb.append(", receiverCity=").append(receiverCity);
        sb.append(", receiverCounty=").append(receiverCounty);
        sb.append(", receiverZip=").append(receiverZip);
        sb.append(", receiverPhone=").append(receiverPhone);
        sb.append(", receiverMobile=").append(receiverMobile);
        sb.append(", deliveryDate=").append(deliveryDate);
        sb.append(", consignTime=").append(consignTime);
        sb.append(", buyerMessage=").append(buyerMessage);
        sb.append(", deliverySupplierId=").append(deliverySupplierId);
        sb.append(", sellerMemo=").append(sellerMemo);
        sb.append(", orderPayTime=").append(orderPayTime);
        sb.append(", payServiceType=").append(payServiceType);
        sb.append(", orderPromotionDiscount=").append(orderPromotionDiscount);
        sb.append(", merchantExpressNbr=").append(merchantExpressNbr);
        sb.append(", orderModifyTime=").append(orderModifyTime);
        sb.append(", orderCouponDiscount=").append(orderCouponDiscount);
        sb.append(", orderPlatformDiscount=").append(orderPlatformDiscount);
        sb.append(", invoiceTitle=").append(invoiceTitle);
        sb.append(", invoiceContent=").append(invoiceContent);
        sb.append(", buyerNick=").append(buyerNick);
        sb.append(", realAmount=").append(realAmount);
        sb.append(", warehouseId=").append(warehouseId);
        sb.append(", isMobileOrder=").append(isMobileOrder);
        sb.append(", businessType=").append(businessType);
        sb.append(", orderDeposit=").append(orderDeposit);
        sb.append(", isDepositOrder=").append(isDepositOrder);
        sb.append(", depositPaidTime=").append(depositPaidTime);
        sb.append(", applyCancel=").append(applyCancel);
        sb.append(", storeId=").append(storeId);
        sb.append(", storeName=").append(storeName);
        sb.append(", externalStoreId=").append(externalStoreId);
        sb.append(", collectOnDeliveryAmount=").append(collectOnDeliveryAmount);
        sb.append(", orderProdType=").append(orderProdType);
        sb.append(", paymentNo=").append(paymentNo);
        sb.append(", gatewayName=").append(gatewayName);
        sb.append(", paymentTransaction=").append(paymentTransaction);
        sb.append(", targetOrderUkid=").append(targetOrderUkid);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeYhdTradeDO other = (SeYhdTradeDO) that;
        return (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
            && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
            && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
            && (this.getReleaseTime() == null ? other.getReleaseTime() == null : this.getReleaseTime().equals(other.getReleaseTime()))
            && (this.getOriginTradeStatus() == null ? other.getOriginTradeStatus() == null : this.getOriginTradeStatus().equals(other.getOriginTradeStatus()))
            && (this.getOrderId() == null ? other.getOrderId() == null : this.getOrderId().equals(other.getOrderId()))
            && (this.getOrderCode() == null ? other.getOrderCode() == null : this.getOrderCode().equals(other.getOrderCode()))
            && (this.getPlatformOrderStatus() == null ? other.getPlatformOrderStatus() == null : this.getPlatformOrderStatus().equals(other.getPlatformOrderStatus()))
            && (this.getOrderAmount() == null ? other.getOrderAmount() == null : this.getOrderAmount().equals(other.getOrderAmount()))
            && (this.getProductAmount() == null ? other.getProductAmount() == null : this.getProductAmount().equals(other.getProductAmount()))
            && (this.getOrderCreateTime() == null ? other.getOrderCreateTime() == null : this.getOrderCreateTime().equals(other.getOrderCreateTime()))
            && (this.getFreightFee() == null ? other.getFreightFee() == null : this.getFreightFee().equals(other.getFreightFee()))
            && (this.getOrderNeedInvoice() == null ? other.getOrderNeedInvoice() == null : this.getOrderNeedInvoice().equals(other.getOrderNeedInvoice()))
            && (this.getReceiverName() == null ? other.getReceiverName() == null : this.getReceiverName().equals(other.getReceiverName()))
            && (this.getReceiverAddress() == null ? other.getReceiverAddress() == null : this.getReceiverAddress().equals(other.getReceiverAddress()))
            && (this.getReceiverState() == null ? other.getReceiverState() == null : this.getReceiverState().equals(other.getReceiverState()))
            && (this.getReceiverCity() == null ? other.getReceiverCity() == null : this.getReceiverCity().equals(other.getReceiverCity()))
            && (this.getReceiverCounty() == null ? other.getReceiverCounty() == null : this.getReceiverCounty().equals(other.getReceiverCounty()))
            && (this.getReceiverZip() == null ? other.getReceiverZip() == null : this.getReceiverZip().equals(other.getReceiverZip()))
            && (this.getReceiverPhone() == null ? other.getReceiverPhone() == null : this.getReceiverPhone().equals(other.getReceiverPhone()))
            && (this.getReceiverMobile() == null ? other.getReceiverMobile() == null : this.getReceiverMobile().equals(other.getReceiverMobile()))
            && (this.getDeliveryDate() == null ? other.getDeliveryDate() == null : this.getDeliveryDate().equals(other.getDeliveryDate()))
            && (this.getConsignTime() == null ? other.getConsignTime() == null : this.getConsignTime().equals(other.getConsignTime()))
            && (this.getBuyerMessage() == null ? other.getBuyerMessage() == null : this.getBuyerMessage().equals(other.getBuyerMessage()))
            && (this.getDeliverySupplierId() == null ? other.getDeliverySupplierId() == null : this.getDeliverySupplierId().equals(other.getDeliverySupplierId()))
            && (this.getSellerMemo() == null ? other.getSellerMemo() == null : this.getSellerMemo().equals(other.getSellerMemo()))
            && (this.getOrderPayTime() == null ? other.getOrderPayTime() == null : this.getOrderPayTime().equals(other.getOrderPayTime()))
            && (this.getPayServiceType() == null ? other.getPayServiceType() == null : this.getPayServiceType().equals(other.getPayServiceType()))
            && (this.getOrderPromotionDiscount() == null ? other.getOrderPromotionDiscount() == null : this.getOrderPromotionDiscount().equals(other.getOrderPromotionDiscount()))
            && (this.getMerchantExpressNbr() == null ? other.getMerchantExpressNbr() == null : this.getMerchantExpressNbr().equals(other.getMerchantExpressNbr()))
            && (this.getOrderModifyTime() == null ? other.getOrderModifyTime() == null : this.getOrderModifyTime().equals(other.getOrderModifyTime()))
            && (this.getOrderCouponDiscount() == null ? other.getOrderCouponDiscount() == null : this.getOrderCouponDiscount().equals(other.getOrderCouponDiscount()))
            && (this.getOrderPlatformDiscount() == null ? other.getOrderPlatformDiscount() == null : this.getOrderPlatformDiscount().equals(other.getOrderPlatformDiscount()))
            && (this.getInvoiceTitle() == null ? other.getInvoiceTitle() == null : this.getInvoiceTitle().equals(other.getInvoiceTitle()))
            && (this.getInvoiceContent() == null ? other.getInvoiceContent() == null : this.getInvoiceContent().equals(other.getInvoiceContent()))
            && (this.getBuyerNick() == null ? other.getBuyerNick() == null : this.getBuyerNick().equals(other.getBuyerNick()))
            && (this.getRealAmount() == null ? other.getRealAmount() == null : this.getRealAmount().equals(other.getRealAmount()))
            && (this.getWarehouseId() == null ? other.getWarehouseId() == null : this.getWarehouseId().equals(other.getWarehouseId()))
            && (this.getIsMobileOrder() == null ? other.getIsMobileOrder() == null : this.getIsMobileOrder().equals(other.getIsMobileOrder()))
            && (this.getBusinessType() == null ? other.getBusinessType() == null : this.getBusinessType().equals(other.getBusinessType()))
            && (this.getOrderDeposit() == null ? other.getOrderDeposit() == null : this.getOrderDeposit().equals(other.getOrderDeposit()))
            && (this.getIsDepositOrder() == null ? other.getIsDepositOrder() == null : this.getIsDepositOrder().equals(other.getIsDepositOrder()))
            && (this.getDepositPaidTime() == null ? other.getDepositPaidTime() == null : this.getDepositPaidTime().equals(other.getDepositPaidTime()))
            && (this.getApplyCancel() == null ? other.getApplyCancel() == null : this.getApplyCancel().equals(other.getApplyCancel()))
            && (this.getStoreId() == null ? other.getStoreId() == null : this.getStoreId().equals(other.getStoreId()))
            && (this.getStoreName() == null ? other.getStoreName() == null : this.getStoreName().equals(other.getStoreName()))
            && (this.getExternalStoreId() == null ? other.getExternalStoreId() == null : this.getExternalStoreId().equals(other.getExternalStoreId()))
            && (this.getCollectOnDeliveryAmount() == null ? other.getCollectOnDeliveryAmount() == null : this.getCollectOnDeliveryAmount().equals(other.getCollectOnDeliveryAmount()))
            && (this.getOrderProdType() == null ? other.getOrderProdType() == null : this.getOrderProdType().equals(other.getOrderProdType()))
            && (this.getPaymentNo() == null ? other.getPaymentNo() == null : this.getPaymentNo().equals(other.getPaymentNo()))
            && (this.getGatewayName() == null ? other.getGatewayName() == null : this.getGatewayName().equals(other.getGatewayName()))
            && (this.getPaymentTransaction() == null ? other.getPaymentTransaction() == null : this.getPaymentTransaction().equals(other.getPaymentTransaction()))
            && (this.getTargetOrderUkid() == null ? other.getTargetOrderUkid() == null : this.getTargetOrderUkid().equals(other.getTargetOrderUkid()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getReleaseTime() == null) ? 0 : getReleaseTime().hashCode());
        result = prime * result + ((getOriginTradeStatus() == null) ? 0 : getOriginTradeStatus().hashCode());
        result = prime * result + ((getOrderId() == null) ? 0 : getOrderId().hashCode());
        result = prime * result + ((getOrderCode() == null) ? 0 : getOrderCode().hashCode());
        result = prime * result + ((getPlatformOrderStatus() == null) ? 0 : getPlatformOrderStatus().hashCode());
        result = prime * result + ((getOrderAmount() == null) ? 0 : getOrderAmount().hashCode());
        result = prime * result + ((getProductAmount() == null) ? 0 : getProductAmount().hashCode());
        result = prime * result + ((getOrderCreateTime() == null) ? 0 : getOrderCreateTime().hashCode());
        result = prime * result + ((getFreightFee() == null) ? 0 : getFreightFee().hashCode());
        result = prime * result + ((getOrderNeedInvoice() == null) ? 0 : getOrderNeedInvoice().hashCode());
        result = prime * result + ((getReceiverName() == null) ? 0 : getReceiverName().hashCode());
        result = prime * result + ((getReceiverAddress() == null) ? 0 : getReceiverAddress().hashCode());
        result = prime * result + ((getReceiverState() == null) ? 0 : getReceiverState().hashCode());
        result = prime * result + ((getReceiverCity() == null) ? 0 : getReceiverCity().hashCode());
        result = prime * result + ((getReceiverCounty() == null) ? 0 : getReceiverCounty().hashCode());
        result = prime * result + ((getReceiverZip() == null) ? 0 : getReceiverZip().hashCode());
        result = prime * result + ((getReceiverPhone() == null) ? 0 : getReceiverPhone().hashCode());
        result = prime * result + ((getReceiverMobile() == null) ? 0 : getReceiverMobile().hashCode());
        result = prime * result + ((getDeliveryDate() == null) ? 0 : getDeliveryDate().hashCode());
        result = prime * result + ((getConsignTime() == null) ? 0 : getConsignTime().hashCode());
        result = prime * result + ((getBuyerMessage() == null) ? 0 : getBuyerMessage().hashCode());
        result = prime * result + ((getDeliverySupplierId() == null) ? 0 : getDeliverySupplierId().hashCode());
        result = prime * result + ((getSellerMemo() == null) ? 0 : getSellerMemo().hashCode());
        result = prime * result + ((getOrderPayTime() == null) ? 0 : getOrderPayTime().hashCode());
        result = prime * result + ((getPayServiceType() == null) ? 0 : getPayServiceType().hashCode());
        result = prime * result + ((getOrderPromotionDiscount() == null) ? 0 : getOrderPromotionDiscount().hashCode());
        result = prime * result + ((getMerchantExpressNbr() == null) ? 0 : getMerchantExpressNbr().hashCode());
        result = prime * result + ((getOrderModifyTime() == null) ? 0 : getOrderModifyTime().hashCode());
        result = prime * result + ((getOrderCouponDiscount() == null) ? 0 : getOrderCouponDiscount().hashCode());
        result = prime * result + ((getOrderPlatformDiscount() == null) ? 0 : getOrderPlatformDiscount().hashCode());
        result = prime * result + ((getInvoiceTitle() == null) ? 0 : getInvoiceTitle().hashCode());
        result = prime * result + ((getInvoiceContent() == null) ? 0 : getInvoiceContent().hashCode());
        result = prime * result + ((getBuyerNick() == null) ? 0 : getBuyerNick().hashCode());
        result = prime * result + ((getRealAmount() == null) ? 0 : getRealAmount().hashCode());
        result = prime * result + ((getWarehouseId() == null) ? 0 : getWarehouseId().hashCode());
        result = prime * result + ((getIsMobileOrder() == null) ? 0 : getIsMobileOrder().hashCode());
        result = prime * result + ((getBusinessType() == null) ? 0 : getBusinessType().hashCode());
        result = prime * result + ((getOrderDeposit() == null) ? 0 : getOrderDeposit().hashCode());
        result = prime * result + ((getIsDepositOrder() == null) ? 0 : getIsDepositOrder().hashCode());
        result = prime * result + ((getDepositPaidTime() == null) ? 0 : getDepositPaidTime().hashCode());
        result = prime * result + ((getApplyCancel() == null) ? 0 : getApplyCancel().hashCode());
        result = prime * result + ((getStoreId() == null) ? 0 : getStoreId().hashCode());
        result = prime * result + ((getStoreName() == null) ? 0 : getStoreName().hashCode());
        result = prime * result + ((getExternalStoreId() == null) ? 0 : getExternalStoreId().hashCode());
        result = prime * result + ((getCollectOnDeliveryAmount() == null) ? 0 : getCollectOnDeliveryAmount().hashCode());
        result = prime * result + ((getOrderProdType() == null) ? 0 : getOrderProdType().hashCode());
        result = prime * result + ((getPaymentNo() == null) ? 0 : getPaymentNo().hashCode());
        result = prime * result + ((getGatewayName() == null) ? 0 : getGatewayName().hashCode());
        result = prime * result + ((getPaymentTransaction() == null) ? 0 : getPaymentTransaction().hashCode());
        result = prime * result + ((getTargetOrderUkid() == null) ? 0 : getTargetOrderUkid().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}