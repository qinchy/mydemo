package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SyParamDO;
import com.wwwarehouse.xdw.datasync.dao.model.SyParamDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SyParamDOMapper {
    long countByExample(SyParamDOExample example);

    int deleteByExample(SyParamDOExample example);

    int deleteByPrimaryKey(@Param("relatedId") Long relatedId, @Param("paramName") String paramName);

    int insert(SyParamDO record);

    int insertSelective(SyParamDO record);

    List<SyParamDO> selectByExample(SyParamDOExample example);

    SyParamDO selectByPrimaryKey(@Param("relatedId") Short relatedId, @Param("paramName") String paramName);

    int updateByExampleSelective(@Param("record") SyParamDO record, @Param("example") SyParamDOExample example);

    int updateByExample(@Param("record") SyParamDO record, @Param("example") SyParamDOExample example);

    int updateByPrimaryKeySelective(SyParamDO record);

    int updateByPrimaryKey(SyParamDO record);
}