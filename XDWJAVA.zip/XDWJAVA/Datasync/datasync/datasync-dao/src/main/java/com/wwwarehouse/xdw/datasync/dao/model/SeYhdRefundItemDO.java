package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SeYhdRefundItemDO implements Serializable {
    private Long refundItemUkid;

    private Long refundUkid;

    private String productId;

    private String productCname;

    private Long orderItemNum;

    private BigDecimal orderItemPrice;

    private Long productRefundNum;

    private Long originalRefundNum;

    private Long orderItemId;

    private Date createTime;

    private Long createUserId;

    private Date updateTime;

    private Long updateUserId;

    private static final long serialVersionUID = 1L;

    public Long getRefundItemUkid() {
        return refundItemUkid;
    }

    public void setRefundItemUkid(Long refundItemUkid) {
        this.refundItemUkid = refundItemUkid;
    }

    public Long getRefundUkid() {
        return refundUkid;
    }

    public void setRefundUkid(Long refundUkid) {
        this.refundUkid = refundUkid;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductCname() {
        return productCname;
    }

    public void setProductCname(String productCname) {
        this.productCname = productCname;
    }

    public Long getOrderItemNum() {
        return orderItemNum;
    }

    public void setOrderItemNum(Long orderItemNum) {
        this.orderItemNum = orderItemNum;
    }

    public BigDecimal getOrderItemPrice() {
        return orderItemPrice;
    }

    public void setOrderItemPrice(BigDecimal orderItemPrice) {
        this.orderItemPrice = orderItemPrice;
    }

    public Long getProductRefundNum() {
        return productRefundNum;
    }

    public void setProductRefundNum(Long productRefundNum) {
        this.productRefundNum = productRefundNum;
    }

    public Long getOriginalRefundNum() {
        return originalRefundNum;
    }

    public void setOriginalRefundNum(Long originalRefundNum) {
        this.originalRefundNum = originalRefundNum;
    }

    public Long getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(Long orderItemId) {
        this.orderItemId = orderItemId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", refundItemUkid=").append(refundItemUkid);
        sb.append(", refundUkid=").append(refundUkid);
        sb.append(", productId=").append(productId);
        sb.append(", productCname=").append(productCname);
        sb.append(", orderItemNum=").append(orderItemNum);
        sb.append(", orderItemPrice=").append(orderItemPrice);
        sb.append(", productRefundNum=").append(productRefundNum);
        sb.append(", originalRefundNum=").append(originalRefundNum);
        sb.append(", orderItemId=").append(orderItemId);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeYhdRefundItemDO other = (SeYhdRefundItemDO) that;
        return (this.getRefundItemUkid() == null ? other.getRefundItemUkid() == null : this.getRefundItemUkid().equals(other.getRefundItemUkid()))
            && (this.getRefundUkid() == null ? other.getRefundUkid() == null : this.getRefundUkid().equals(other.getRefundUkid()))
            && (this.getProductId() == null ? other.getProductId() == null : this.getProductId().equals(other.getProductId()))
            && (this.getProductCname() == null ? other.getProductCname() == null : this.getProductCname().equals(other.getProductCname()))
            && (this.getOrderItemNum() == null ? other.getOrderItemNum() == null : this.getOrderItemNum().equals(other.getOrderItemNum()))
            && (this.getOrderItemPrice() == null ? other.getOrderItemPrice() == null : this.getOrderItemPrice().equals(other.getOrderItemPrice()))
            && (this.getProductRefundNum() == null ? other.getProductRefundNum() == null : this.getProductRefundNum().equals(other.getProductRefundNum()))
            && (this.getOriginalRefundNum() == null ? other.getOriginalRefundNum() == null : this.getOriginalRefundNum().equals(other.getOriginalRefundNum()))
            && (this.getOrderItemId() == null ? other.getOrderItemId() == null : this.getOrderItemId().equals(other.getOrderItemId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getRefundItemUkid() == null) ? 0 : getRefundItemUkid().hashCode());
        result = prime * result + ((getRefundUkid() == null) ? 0 : getRefundUkid().hashCode());
        result = prime * result + ((getProductId() == null) ? 0 : getProductId().hashCode());
        result = prime * result + ((getProductCname() == null) ? 0 : getProductCname().hashCode());
        result = prime * result + ((getOrderItemNum() == null) ? 0 : getOrderItemNum().hashCode());
        result = prime * result + ((getOrderItemPrice() == null) ? 0 : getOrderItemPrice().hashCode());
        result = prime * result + ((getProductRefundNum() == null) ? 0 : getProductRefundNum().hashCode());
        result = prime * result + ((getOriginalRefundNum() == null) ? 0 : getOriginalRefundNum().hashCode());
        result = prime * result + ((getOrderItemId() == null) ? 0 : getOrderItemId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        return result;
    }
}