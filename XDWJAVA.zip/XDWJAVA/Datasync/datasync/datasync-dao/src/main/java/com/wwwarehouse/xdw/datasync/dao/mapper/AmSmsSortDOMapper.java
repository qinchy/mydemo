package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AmSmsSortDOMapper {
    long countByExample(AmSmsSortDOExample example);

    int deleteByExample(AmSmsSortDOExample example);

    int deleteByPrimaryKey(Long smsSortUkid);

    int insert(AmSmsSortDO record);

    int insertSelective(AmSmsSortDO record);

    List<AmSmsSortDO> selectByExample(AmSmsSortDOExample example);

    AmSmsSortDO selectByPrimaryKey(Long smsSortUkid);

    int updateByExampleSelective(@Param("record") AmSmsSortDO record, @Param("example") AmSmsSortDOExample example);

    int updateByExample(@Param("record") AmSmsSortDO record, @Param("example") AmSmsSortDOExample example);

    int updateByPrimaryKeySelective(AmSmsSortDO record);

    int updateByPrimaryKey(AmSmsSortDO record);

    AmSmsSortDO getAmSmsSortByAppUkids(List<Long> appUkids);
}