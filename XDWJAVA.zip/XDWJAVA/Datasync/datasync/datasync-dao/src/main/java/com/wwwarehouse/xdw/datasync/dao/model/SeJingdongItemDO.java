package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SeJingdongItemDO implements Serializable {
    private Long itemUkid;

    private Long tradeUkid;

    private Long originOrderStatus;

    private Long shopProductUkid;

    private Long productCodeUkid;

    private String productCode;

    private Date presaleDate;

    private Date downTime;

    private String workspaceId;

    private String skuId;

    private String outerSkuId;

    private String skuName;

    private BigDecimal jdPrice;

    private BigDecimal giftPoint;

    private String wareId;

    private BigDecimal itemTotal;

    private String productNo;

    private BigDecimal couponPrice;

    private String couponType;

    private Date createTime;

    private Long createUserId;

    private Long updateUserId;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getItemUkid() {
        return itemUkid;
    }

    public void setItemUkid(Long itemUkid) {
        this.itemUkid = itemUkid;
    }

    public Long getTradeUkid() {
        return tradeUkid;
    }

    public void setTradeUkid(Long tradeUkid) {
        this.tradeUkid = tradeUkid;
    }

    public Long getOriginOrderStatus() {
        return originOrderStatus;
    }

    public void setOriginOrderStatus(Long originOrderStatus) {
        this.originOrderStatus = originOrderStatus;
    }

    public Long getShopProductUkid() {
        return shopProductUkid;
    }

    public void setShopProductUkid(Long shopProductUkid) {
        this.shopProductUkid = shopProductUkid;
    }

    public Long getProductCodeUkid() {
        return productCodeUkid;
    }

    public void setProductCodeUkid(Long productCodeUkid) {
        this.productCodeUkid = productCodeUkid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Date getPresaleDate() {
        return presaleDate;
    }

    public void setPresaleDate(Date presaleDate) {
        this.presaleDate = presaleDate;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public String getWorkspaceId() {
        return workspaceId;
    }

    public void setWorkspaceId(String workspaceId) {
        this.workspaceId = workspaceId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getOuterSkuId() {
        return outerSkuId;
    }

    public void setOuterSkuId(String outerSkuId) {
        this.outerSkuId = outerSkuId;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public BigDecimal getJdPrice() {
        return jdPrice;
    }

    public void setJdPrice(BigDecimal jdPrice) {
        this.jdPrice = jdPrice;
    }

    public BigDecimal getGiftPoint() {
        return giftPoint;
    }

    public void setGiftPoint(BigDecimal giftPoint) {
        this.giftPoint = giftPoint;
    }

    public String getWareId() {
        return wareId;
    }

    public void setWareId(String wareId) {
        this.wareId = wareId;
    }

    public BigDecimal getItemTotal() {
        return itemTotal;
    }

    public void setItemTotal(BigDecimal itemTotal) {
        this.itemTotal = itemTotal;
    }

    public String getProductNo() {
        return productNo;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public BigDecimal getCouponPrice() {
        return couponPrice;
    }

    public void setCouponPrice(BigDecimal couponPrice) {
        this.couponPrice = couponPrice;
    }

    public String getCouponType() {
        return couponType;
    }

    public void setCouponType(String couponType) {
        this.couponType = couponType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", itemUkid=").append(itemUkid);
        sb.append(", tradeUkid=").append(tradeUkid);
        sb.append(", originOrderStatus=").append(originOrderStatus);
        sb.append(", shopProductUkid=").append(shopProductUkid);
        sb.append(", productCodeUkid=").append(productCodeUkid);
        sb.append(", productCode=").append(productCode);
        sb.append(", presaleDate=").append(presaleDate);
        sb.append(", downTime=").append(downTime);
        sb.append(", workspaceId=").append(workspaceId);
        sb.append(", skuId=").append(skuId);
        sb.append(", outerSkuId=").append(outerSkuId);
        sb.append(", skuName=").append(skuName);
        sb.append(", jdPrice=").append(jdPrice);
        sb.append(", giftPoint=").append(giftPoint);
        sb.append(", wareId=").append(wareId);
        sb.append(", itemTotal=").append(itemTotal);
        sb.append(", productNo=").append(productNo);
        sb.append(", couponPrice=").append(couponPrice);
        sb.append(", couponType=").append(couponType);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SeJingdongItemDO other = (SeJingdongItemDO) that;
        return (this.getItemUkid() == null ? other.getItemUkid() == null : this.getItemUkid().equals(other.getItemUkid()))
            && (this.getTradeUkid() == null ? other.getTradeUkid() == null : this.getTradeUkid().equals(other.getTradeUkid()))
            && (this.getOriginOrderStatus() == null ? other.getOriginOrderStatus() == null : this.getOriginOrderStatus().equals(other.getOriginOrderStatus()))
            && (this.getShopProductUkid() == null ? other.getShopProductUkid() == null : this.getShopProductUkid().equals(other.getShopProductUkid()))
            && (this.getProductCodeUkid() == null ? other.getProductCodeUkid() == null : this.getProductCodeUkid().equals(other.getProductCodeUkid()))
            && (this.getProductCode() == null ? other.getProductCode() == null : this.getProductCode().equals(other.getProductCode()))
            && (this.getPresaleDate() == null ? other.getPresaleDate() == null : this.getPresaleDate().equals(other.getPresaleDate()))
            && (this.getDownTime() == null ? other.getDownTime() == null : this.getDownTime().equals(other.getDownTime()))
            && (this.getWorkspaceId() == null ? other.getWorkspaceId() == null : this.getWorkspaceId().equals(other.getWorkspaceId()))
            && (this.getSkuId() == null ? other.getSkuId() == null : this.getSkuId().equals(other.getSkuId()))
            && (this.getOuterSkuId() == null ? other.getOuterSkuId() == null : this.getOuterSkuId().equals(other.getOuterSkuId()))
            && (this.getSkuName() == null ? other.getSkuName() == null : this.getSkuName().equals(other.getSkuName()))
            && (this.getJdPrice() == null ? other.getJdPrice() == null : this.getJdPrice().equals(other.getJdPrice()))
            && (this.getGiftPoint() == null ? other.getGiftPoint() == null : this.getGiftPoint().equals(other.getGiftPoint()))
            && (this.getWareId() == null ? other.getWareId() == null : this.getWareId().equals(other.getWareId()))
            && (this.getItemTotal() == null ? other.getItemTotal() == null : this.getItemTotal().equals(other.getItemTotal()))
            && (this.getProductNo() == null ? other.getProductNo() == null : this.getProductNo().equals(other.getProductNo()))
            && (this.getCouponPrice() == null ? other.getCouponPrice() == null : this.getCouponPrice().equals(other.getCouponPrice()))
            && (this.getCouponType() == null ? other.getCouponType() == null : this.getCouponType().equals(other.getCouponType()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getItemUkid() == null) ? 0 : getItemUkid().hashCode());
        result = prime * result + ((getTradeUkid() == null) ? 0 : getTradeUkid().hashCode());
        result = prime * result + ((getOriginOrderStatus() == null) ? 0 : getOriginOrderStatus().hashCode());
        result = prime * result + ((getShopProductUkid() == null) ? 0 : getShopProductUkid().hashCode());
        result = prime * result + ((getProductCodeUkid() == null) ? 0 : getProductCodeUkid().hashCode());
        result = prime * result + ((getProductCode() == null) ? 0 : getProductCode().hashCode());
        result = prime * result + ((getPresaleDate() == null) ? 0 : getPresaleDate().hashCode());
        result = prime * result + ((getDownTime() == null) ? 0 : getDownTime().hashCode());
        result = prime * result + ((getWorkspaceId() == null) ? 0 : getWorkspaceId().hashCode());
        result = prime * result + ((getSkuId() == null) ? 0 : getSkuId().hashCode());
        result = prime * result + ((getOuterSkuId() == null) ? 0 : getOuterSkuId().hashCode());
        result = prime * result + ((getSkuName() == null) ? 0 : getSkuName().hashCode());
        result = prime * result + ((getJdPrice() == null) ? 0 : getJdPrice().hashCode());
        result = prime * result + ((getGiftPoint() == null) ? 0 : getGiftPoint().hashCode());
        result = prime * result + ((getWareId() == null) ? 0 : getWareId().hashCode());
        result = prime * result + ((getItemTotal() == null) ? 0 : getItemTotal().hashCode());
        result = prime * result + ((getProductNo() == null) ? 0 : getProductNo().hashCode());
        result = prime * result + ((getCouponPrice() == null) ? 0 : getCouponPrice().hashCode());
        result = prime * result + ((getCouponType() == null) ? 0 : getCouponType().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}