package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ImPlatformItemDO implements Serializable {
    private Long platformItemUkid;

    private Long platformId;

    private Long shopId;

    private Long ownerId;

    private String identifyCode;

    private Long identifyUkid;

    private Long itemStatus;

    private String productNumId;

    private String productOuterId;

    private String skuNumId;

    private String skuOuterId;

    private String productTitle;

    private String skuName;

    private BigDecimal sellPrice;

    private String platformImgUrl;

    private String brandName;

    private String category;

    private Date createTime;

    private Long createUserId;

    private Date updateTime;

    private Long updateUserId;

    private Long itemCount;

    private String categoryId;

    private Long status;

    private static final long serialVersionUID = 1L;

    public Long getPlatformItemUkid() {
        return platformItemUkid;
    }

    public void setPlatformItemUkid(Long platformItemUkid) {
        this.platformItemUkid = platformItemUkid;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getIdentifyCode() {
        return identifyCode;
    }

    public void setIdentifyCode(String identifyCode) {
        this.identifyCode = identifyCode;
    }

    public Long getIdentifyUkid() {
        return identifyUkid;
    }

    public void setIdentifyUkid(Long identifyUkid) {
        this.identifyUkid = identifyUkid;
    }

    public Long getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(Long itemStatus) {
        this.itemStatus = itemStatus;
    }

    public String getProductNumId() {
        return productNumId;
    }

    public void setProductNumId(String productNumId) {
        this.productNumId = productNumId;
    }

    public String getProductOuterId() {
        return productOuterId;
    }

    public void setProductOuterId(String productOuterId) {
        this.productOuterId = productOuterId;
    }

    public String getSkuNumId() {
        return skuNumId;
    }

    public void setSkuNumId(String skuNumId) {
        this.skuNumId = skuNumId;
    }

    public String getSkuOuterId() {
        return skuOuterId;
    }

    public void setSkuOuterId(String skuOuterId) {
        this.skuOuterId = skuOuterId;
    }

    public String getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getPlatformImgUrl() {
        return platformImgUrl;
    }

    public void setPlatformImgUrl(String platformImgUrl) {
        this.platformImgUrl = platformImgUrl;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Long getItemCount() {
        return itemCount;
    }

    public void setItemCount(Long itemCount) {
        this.itemCount = itemCount;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", platformItemUkid=").append(platformItemUkid);
        sb.append(", platformId=").append(platformId);
        sb.append(", shopId=").append(shopId);
        sb.append(", ownerId=").append(ownerId);
        sb.append(", identifyCode=").append(identifyCode);
        sb.append(", identifyUkid=").append(identifyUkid);
        sb.append(", itemStatus=").append(itemStatus);
        sb.append(", productNumId=").append(productNumId);
        sb.append(", productOuterId=").append(productOuterId);
        sb.append(", skuNumId=").append(skuNumId);
        sb.append(", skuOuterId=").append(skuOuterId);
        sb.append(", productTitle=").append(productTitle);
        sb.append(", skuName=").append(skuName);
        sb.append(", sellPrice=").append(sellPrice);
        sb.append(", platformImgUrl=").append(platformImgUrl);
        sb.append(", brandName=").append(brandName);
        sb.append(", category=").append(category);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", itemCount=").append(itemCount);
        sb.append(", categoryId=").append(categoryId);
        sb.append(", status=").append(status);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ImPlatformItemDO other = (ImPlatformItemDO) that;
        return (this.getPlatformItemUkid() == null ? other.getPlatformItemUkid() == null : this.getPlatformItemUkid().equals(other.getPlatformItemUkid()))
            && (this.getPlatformId() == null ? other.getPlatformId() == null : this.getPlatformId().equals(other.getPlatformId()))
            && (this.getShopId() == null ? other.getShopId() == null : this.getShopId().equals(other.getShopId()))
            && (this.getOwnerId() == null ? other.getOwnerId() == null : this.getOwnerId().equals(other.getOwnerId()))
            && (this.getIdentifyCode() == null ? other.getIdentifyCode() == null : this.getIdentifyCode().equals(other.getIdentifyCode()))
            && (this.getIdentifyUkid() == null ? other.getIdentifyUkid() == null : this.getIdentifyUkid().equals(other.getIdentifyUkid()))
            && (this.getItemStatus() == null ? other.getItemStatus() == null : this.getItemStatus().equals(other.getItemStatus()))
            && (this.getProductNumId() == null ? other.getProductNumId() == null : this.getProductNumId().equals(other.getProductNumId()))
            && (this.getProductOuterId() == null ? other.getProductOuterId() == null : this.getProductOuterId().equals(other.getProductOuterId()))
            && (this.getSkuNumId() == null ? other.getSkuNumId() == null : this.getSkuNumId().equals(other.getSkuNumId()))
            && (this.getSkuOuterId() == null ? other.getSkuOuterId() == null : this.getSkuOuterId().equals(other.getSkuOuterId()))
            && (this.getProductTitle() == null ? other.getProductTitle() == null : this.getProductTitle().equals(other.getProductTitle()))
            && (this.getSkuName() == null ? other.getSkuName() == null : this.getSkuName().equals(other.getSkuName()))
            && (this.getSellPrice() == null ? other.getSellPrice() == null : this.getSellPrice().equals(other.getSellPrice()))
            && (this.getPlatformImgUrl() == null ? other.getPlatformImgUrl() == null : this.getPlatformImgUrl().equals(other.getPlatformImgUrl()))
            && (this.getBrandName() == null ? other.getBrandName() == null : this.getBrandName().equals(other.getBrandName()))
            && (this.getCategory() == null ? other.getCategory() == null : this.getCategory().equals(other.getCategory()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()))
            && (this.getItemCount() == null ? other.getItemCount() == null : this.getItemCount().equals(other.getItemCount()))
            && (this.getCategoryId() == null ? other.getCategoryId() == null : this.getCategoryId().equals(other.getCategoryId()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getPlatformItemUkid() == null) ? 0 : getPlatformItemUkid().hashCode());
        result = prime * result + ((getPlatformId() == null) ? 0 : getPlatformId().hashCode());
        result = prime * result + ((getShopId() == null) ? 0 : getShopId().hashCode());
        result = prime * result + ((getOwnerId() == null) ? 0 : getOwnerId().hashCode());
        result = prime * result + ((getIdentifyCode() == null) ? 0 : getIdentifyCode().hashCode());
        result = prime * result + ((getIdentifyUkid() == null) ? 0 : getIdentifyUkid().hashCode());
        result = prime * result + ((getItemStatus() == null) ? 0 : getItemStatus().hashCode());
        result = prime * result + ((getProductNumId() == null) ? 0 : getProductNumId().hashCode());
        result = prime * result + ((getProductOuterId() == null) ? 0 : getProductOuterId().hashCode());
        result = prime * result + ((getSkuNumId() == null) ? 0 : getSkuNumId().hashCode());
        result = prime * result + ((getSkuOuterId() == null) ? 0 : getSkuOuterId().hashCode());
        result = prime * result + ((getProductTitle() == null) ? 0 : getProductTitle().hashCode());
        result = prime * result + ((getSkuName() == null) ? 0 : getSkuName().hashCode());
        result = prime * result + ((getSellPrice() == null) ? 0 : getSellPrice().hashCode());
        result = prime * result + ((getPlatformImgUrl() == null) ? 0 : getPlatformImgUrl().hashCode());
        result = prime * result + ((getBrandName() == null) ? 0 : getBrandName().hashCode());
        result = prime * result + ((getCategory() == null) ? 0 : getCategory().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        result = prime * result + ((getItemCount() == null) ? 0 : getItemCount().hashCode());
        result = prime * result + ((getCategoryId() == null) ? 0 : getCategoryId().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        return result;
    }
}