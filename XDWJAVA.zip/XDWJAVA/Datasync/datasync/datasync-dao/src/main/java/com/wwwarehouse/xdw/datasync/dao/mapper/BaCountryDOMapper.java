package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BaCountryDOMapper {
    long countByExample(BaCountryDOExample example);

    int deleteByExample(BaCountryDOExample example);

    int deleteByPrimaryKey(String countryId);

    int insert(BaCountryDO record);

    int insertSelective(BaCountryDO record);

    List<BaCountryDO> selectByExample(BaCountryDOExample example);

    BaCountryDO selectByPrimaryKey(String countryId);

    int updateByExampleSelective(@Param("record") BaCountryDO record, @Param("example") BaCountryDOExample example);

    int updateByExample(@Param("record") BaCountryDO record, @Param("example") BaCountryDOExample example);

    int updateByPrimaryKeySelective(BaCountryDO record);

    int updateByPrimaryKey(BaCountryDO record);
}