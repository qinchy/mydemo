package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeYhdTradeDOMapper {
    long countByExample(SeYhdTradeDOExample example);

    int deleteByExample(SeYhdTradeDOExample example);

    int deleteByPrimaryKey(Short tradeUkid);

    int insert(SeYhdTradeDO record);

    int insertSelective(SeYhdTradeDO record);

    List<SeYhdTradeDO> selectByExample(SeYhdTradeDOExample example);

    SeYhdTradeDO selectByPrimaryKey(Short tradeUkid);

    int updateByExampleSelective(@Param("record") SeYhdTradeDO record, @Param("example") SeYhdTradeDOExample example);

    int updateByExample(@Param("record") SeYhdTradeDO record, @Param("example") SeYhdTradeDOExample example);

    int updateByPrimaryKeySelective(SeYhdTradeDO record);

    int updateByPrimaryKey(SeYhdTradeDO record);

    SeYhdTradeDO getByOrderId(@Param("shopId")Long shopId, @Param("orderId")String tid);

    int updateOriginStatus(SeYhdTradeDO oTrade);

    public int updatePlatformInfo(SeYhdTradeDO oTrade);
}