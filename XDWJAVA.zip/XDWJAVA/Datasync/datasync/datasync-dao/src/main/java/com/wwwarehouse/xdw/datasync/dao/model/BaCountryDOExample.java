package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BaCountryDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public BaCountryDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCountryIdIsNull() {
            addCriterion("COUNTRY_ID is null");
            return (Criteria) this;
        }

        public Criteria andCountryIdIsNotNull() {
            addCriterion("COUNTRY_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCountryIdEqualTo(String value) {
            addCriterion("COUNTRY_ID =", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotEqualTo(String value) {
            addCriterion("COUNTRY_ID <>", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdGreaterThan(String value) {
            addCriterion("COUNTRY_ID >", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdGreaterThanOrEqualTo(String value) {
            addCriterion("COUNTRY_ID >=", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLessThan(String value) {
            addCriterion("COUNTRY_ID <", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLessThanOrEqualTo(String value) {
            addCriterion("COUNTRY_ID <=", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLike(String value) {
            addCriterion("COUNTRY_ID like", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotLike(String value) {
            addCriterion("COUNTRY_ID not like", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdIn(List<String> values) {
            addCriterion("COUNTRY_ID in", values, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotIn(List<String> values) {
            addCriterion("COUNTRY_ID not in", values, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdBetween(String value1, String value2) {
            addCriterion("COUNTRY_ID between", value1, value2, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotBetween(String value1, String value2) {
            addCriterion("COUNTRY_ID not between", value1, value2, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnIsNull() {
            addCriterion("COUNTRY_NAME_EN is null");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnIsNotNull() {
            addCriterion("COUNTRY_NAME_EN is not null");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnEqualTo(String value) {
            addCriterion("COUNTRY_NAME_EN =", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnNotEqualTo(String value) {
            addCriterion("COUNTRY_NAME_EN <>", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnGreaterThan(String value) {
            addCriterion("COUNTRY_NAME_EN >", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnGreaterThanOrEqualTo(String value) {
            addCriterion("COUNTRY_NAME_EN >=", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnLessThan(String value) {
            addCriterion("COUNTRY_NAME_EN <", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnLessThanOrEqualTo(String value) {
            addCriterion("COUNTRY_NAME_EN <=", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnLike(String value) {
            addCriterion("COUNTRY_NAME_EN like", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnNotLike(String value) {
            addCriterion("COUNTRY_NAME_EN not like", value, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnIn(List<String> values) {
            addCriterion("COUNTRY_NAME_EN in", values, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnNotIn(List<String> values) {
            addCriterion("COUNTRY_NAME_EN not in", values, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnBetween(String value1, String value2) {
            addCriterion("COUNTRY_NAME_EN between", value1, value2, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameEnNotBetween(String value1, String value2) {
            addCriterion("COUNTRY_NAME_EN not between", value1, value2, "countryNameEn");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhIsNull() {
            addCriterion("COUNTRY_NAME_ZH is null");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhIsNotNull() {
            addCriterion("COUNTRY_NAME_ZH is not null");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhEqualTo(String value) {
            addCriterion("COUNTRY_NAME_ZH =", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhNotEqualTo(String value) {
            addCriterion("COUNTRY_NAME_ZH <>", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhGreaterThan(String value) {
            addCriterion("COUNTRY_NAME_ZH >", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhGreaterThanOrEqualTo(String value) {
            addCriterion("COUNTRY_NAME_ZH >=", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhLessThan(String value) {
            addCriterion("COUNTRY_NAME_ZH <", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhLessThanOrEqualTo(String value) {
            addCriterion("COUNTRY_NAME_ZH <=", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhLike(String value) {
            addCriterion("COUNTRY_NAME_ZH like", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhNotLike(String value) {
            addCriterion("COUNTRY_NAME_ZH not like", value, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhIn(List<String> values) {
            addCriterion("COUNTRY_NAME_ZH in", values, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhNotIn(List<String> values) {
            addCriterion("COUNTRY_NAME_ZH not in", values, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhBetween(String value1, String value2) {
            addCriterion("COUNTRY_NAME_ZH between", value1, value2, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryNameZhNotBetween(String value1, String value2) {
            addCriterion("COUNTRY_NAME_ZH not between", value1, value2, "countryNameZh");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeIsNull() {
            addCriterion("COUNTRY_CALLING_CODE is null");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeIsNotNull() {
            addCriterion("COUNTRY_CALLING_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeEqualTo(String value) {
            addCriterion("COUNTRY_CALLING_CODE =", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeNotEqualTo(String value) {
            addCriterion("COUNTRY_CALLING_CODE <>", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeGreaterThan(String value) {
            addCriterion("COUNTRY_CALLING_CODE >", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeGreaterThanOrEqualTo(String value) {
            addCriterion("COUNTRY_CALLING_CODE >=", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeLessThan(String value) {
            addCriterion("COUNTRY_CALLING_CODE <", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeLessThanOrEqualTo(String value) {
            addCriterion("COUNTRY_CALLING_CODE <=", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeLike(String value) {
            addCriterion("COUNTRY_CALLING_CODE like", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeNotLike(String value) {
            addCriterion("COUNTRY_CALLING_CODE not like", value, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeIn(List<String> values) {
            addCriterion("COUNTRY_CALLING_CODE in", values, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeNotIn(List<String> values) {
            addCriterion("COUNTRY_CALLING_CODE not in", values, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeBetween(String value1, String value2) {
            addCriterion("COUNTRY_CALLING_CODE between", value1, value2, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andCountryCallingCodeNotBetween(String value1, String value2) {
            addCriterion("COUNTRY_CALLING_CODE not between", value1, value2, "countryCallingCode");
            return (Criteria) this;
        }

        public Criteria andTimeZoneIsNull() {
            addCriterion("TIME_ZONE is null");
            return (Criteria) this;
        }

        public Criteria andTimeZoneIsNotNull() {
            addCriterion("TIME_ZONE is not null");
            return (Criteria) this;
        }

        public Criteria andTimeZoneEqualTo(String value) {
            addCriterion("TIME_ZONE =", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneNotEqualTo(String value) {
            addCriterion("TIME_ZONE <>", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneGreaterThan(String value) {
            addCriterion("TIME_ZONE >", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneGreaterThanOrEqualTo(String value) {
            addCriterion("TIME_ZONE >=", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneLessThan(String value) {
            addCriterion("TIME_ZONE <", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneLessThanOrEqualTo(String value) {
            addCriterion("TIME_ZONE <=", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneLike(String value) {
            addCriterion("TIME_ZONE like", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneNotLike(String value) {
            addCriterion("TIME_ZONE not like", value, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneIn(List<String> values) {
            addCriterion("TIME_ZONE in", values, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneNotIn(List<String> values) {
            addCriterion("TIME_ZONE not in", values, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneBetween(String value1, String value2) {
            addCriterion("TIME_ZONE between", value1, value2, "timeZone");
            return (Criteria) this;
        }

        public Criteria andTimeZoneNotBetween(String value1, String value2) {
            addCriterion("TIME_ZONE not between", value1, value2, "timeZone");
            return (Criteria) this;
        }

        public Criteria andJetLagIsNull() {
            addCriterion("JET_LAG is null");
            return (Criteria) this;
        }

        public Criteria andJetLagIsNotNull() {
            addCriterion("JET_LAG is not null");
            return (Criteria) this;
        }

        public Criteria andJetLagEqualTo(Short value) {
            addCriterion("JET_LAG =", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagNotEqualTo(Short value) {
            addCriterion("JET_LAG <>", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagGreaterThan(Short value) {
            addCriterion("JET_LAG >", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagGreaterThanOrEqualTo(Short value) {
            addCriterion("JET_LAG >=", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagLessThan(Short value) {
            addCriterion("JET_LAG <", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagLessThanOrEqualTo(Short value) {
            addCriterion("JET_LAG <=", value, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagIn(List<Short> values) {
            addCriterion("JET_LAG in", values, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagNotIn(List<Short> values) {
            addCriterion("JET_LAG not in", values, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagBetween(Short value1, Short value2) {
            addCriterion("JET_LAG between", value1, value2, "jetLag");
            return (Criteria) this;
        }

        public Criteria andJetLagNotBetween(Short value1, Short value2) {
            addCriterion("JET_LAG not between", value1, value2, "jetLag");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdIsNull() {
            addCriterion("EXTRA_COUNTRY_ID is null");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdIsNotNull() {
            addCriterion("EXTRA_COUNTRY_ID is not null");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdEqualTo(String value) {
            addCriterion("EXTRA_COUNTRY_ID =", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdNotEqualTo(String value) {
            addCriterion("EXTRA_COUNTRY_ID <>", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdGreaterThan(String value) {
            addCriterion("EXTRA_COUNTRY_ID >", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdGreaterThanOrEqualTo(String value) {
            addCriterion("EXTRA_COUNTRY_ID >=", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdLessThan(String value) {
            addCriterion("EXTRA_COUNTRY_ID <", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdLessThanOrEqualTo(String value) {
            addCriterion("EXTRA_COUNTRY_ID <=", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdLike(String value) {
            addCriterion("EXTRA_COUNTRY_ID like", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdNotLike(String value) {
            addCriterion("EXTRA_COUNTRY_ID not like", value, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdIn(List<String> values) {
            addCriterion("EXTRA_COUNTRY_ID in", values, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdNotIn(List<String> values) {
            addCriterion("EXTRA_COUNTRY_ID not in", values, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdBetween(String value1, String value2) {
            addCriterion("EXTRA_COUNTRY_ID between", value1, value2, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andExtraCountryIdNotBetween(String value1, String value2) {
            addCriterion("EXTRA_COUNTRY_ID not between", value1, value2, "extraCountryId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Short value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Short value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Short value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Short value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Short value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Short> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Short> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}