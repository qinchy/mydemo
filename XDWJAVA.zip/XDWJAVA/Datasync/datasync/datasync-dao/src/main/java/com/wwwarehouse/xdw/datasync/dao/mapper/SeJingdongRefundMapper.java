package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeJingdongRefundMapper {
    long countByExample(SeJingdongRefundExample example);

    int deleteByExample(SeJingdongRefundExample example);

    int deleteByPrimaryKey(Long refundUkid);

    int insert(SeJingdongRefundDO record);

    int insertSelective(SeJingdongRefundDO record);

    List<SeJingdongRefundDO> selectByExample(SeJingdongRefundExample example);

    SeJingdongRefundDO selectByPrimaryKey(Long refundUkid);

    int updateByExampleSelective(@Param("record") SeJingdongRefundDO record, @Param("example") SeJingdongRefundExample example);

    int updateByExample(@Param("record") SeJingdongRefundDO record, @Param("example") SeJingdongRefundExample example);

    int updateByPrimaryKeySelective(SeJingdongRefundDO record);

    int updateByPrimaryKey(SeJingdongRefundDO record);
}