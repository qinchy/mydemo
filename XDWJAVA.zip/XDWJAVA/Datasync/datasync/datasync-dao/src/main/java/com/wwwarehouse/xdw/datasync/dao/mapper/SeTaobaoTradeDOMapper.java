package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeTaobaoTradeDOMapper {
    long countByExample(SeTaobaoTradeDOExample example);

    int deleteByExample(SeTaobaoTradeDOExample example);

    int deleteByPrimaryKey(Long tradeUkid);

    int insert(SeTaobaoTradeDO record);

    int insertSelective(SeTaobaoTradeDO record);

    List<SeTaobaoTradeDO> selectByExample(SeTaobaoTradeDOExample example);

    SeTaobaoTradeDO selectByPrimaryKey(Long tradeUkid);

    int updateByExampleSelective(@Param("record") SeTaobaoTradeDO record, @Param("example") SeTaobaoTradeDOExample example);

    int updateByExample(@Param("record") SeTaobaoTradeDO record, @Param("example") SeTaobaoTradeDOExample example);

    int updateByPrimaryKeySelective(SeTaobaoTradeDO record);

    int updateByPrimaryKey(SeTaobaoTradeDO record);

    SeTaobaoTradeDO getByOrderId(@Param("shopId")Long shopId, @Param("orderId")String tid);

    int updateOriginStatus(SeTaobaoTradeDO oTrade);
}