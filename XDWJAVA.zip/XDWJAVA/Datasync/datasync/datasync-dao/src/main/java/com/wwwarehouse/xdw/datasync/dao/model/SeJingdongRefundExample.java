package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeJingdongRefundExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeJingdongRefundExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRefundUkidIsNull() {
            addCriterion("REFUND_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIsNotNull() {
            addCriterion("REFUND_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidEqualTo(Long value) {
            addCriterion("REFUND_UKID =", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotEqualTo(Long value) {
            addCriterion("REFUND_UKID <>", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThan(Long value) {
            addCriterion("REFUND_UKID >", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID >=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThan(Long value) {
            addCriterion("REFUND_UKID <", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID <=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIn(List<Long> values) {
            addCriterion("REFUND_UKID in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotIn(List<Long> values) {
            addCriterion("REFUND_UKID not in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID not between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Long value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Long value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Long value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Long value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Long> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Long> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNull() {
            addCriterion("REFUND_ID is null");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNotNull() {
            addCriterion("REFUND_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundIdEqualTo(String value) {
            addCriterion("REFUND_ID =", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotEqualTo(String value) {
            addCriterion("REFUND_ID <>", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThan(String value) {
            addCriterion("REFUND_ID >", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_ID >=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThan(String value) {
            addCriterion("REFUND_ID <", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThanOrEqualTo(String value) {
            addCriterion("REFUND_ID <=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLike(String value) {
            addCriterion("REFUND_ID like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotLike(String value) {
            addCriterion("REFUND_ID not like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdIn(List<String> values) {
            addCriterion("REFUND_ID in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotIn(List<String> values) {
            addCriterion("REFUND_ID not in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdBetween(String value1, String value2) {
            addCriterion("REFUND_ID between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotBetween(String value1, String value2) {
            addCriterion("REFUND_ID not between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIsNull() {
            addCriterion("CHECK_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIsNotNull() {
            addCriterion("CHECK_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCheckTimeEqualTo(Date value) {
            addCriterion("CHECK_TIME =", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotEqualTo(Date value) {
            addCriterion("CHECK_TIME <>", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeGreaterThan(Date value) {
            addCriterion("CHECK_TIME >", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CHECK_TIME >=", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeLessThan(Date value) {
            addCriterion("CHECK_TIME <", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeLessThanOrEqualTo(Date value) {
            addCriterion("CHECK_TIME <=", value, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeIn(List<Date> values) {
            addCriterion("CHECK_TIME in", values, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotIn(List<Date> values) {
            addCriterion("CHECK_TIME not in", values, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeBetween(Date value1, Date value2) {
            addCriterion("CHECK_TIME between", value1, value2, "checkTime");
            return (Criteria) this;
        }

        public Criteria andCheckTimeNotBetween(Date value1, Date value2) {
            addCriterion("CHECK_TIME not between", value1, value2, "checkTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNull() {
            addCriterion("REFUND_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNotNull() {
            addCriterion("REFUND_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME =", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <>", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThan(Date value) {
            addCriterion("REFUND_CREATE_TIME >", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME >=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThan(Date value) {
            addCriterion("REFUND_CREATE_TIME <", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME not in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME not between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumIsNull() {
            addCriterion("APPLY_REFUND_SUM is null");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumIsNotNull() {
            addCriterion("APPLY_REFUND_SUM is not null");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumEqualTo(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM =", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumNotEqualTo(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM <>", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumGreaterThan(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM >", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM >=", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumLessThan(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM <", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumLessThanOrEqualTo(BigDecimal value) {
            addCriterion("APPLY_REFUND_SUM <=", value, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumIn(List<BigDecimal> values) {
            addCriterion("APPLY_REFUND_SUM in", values, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumNotIn(List<BigDecimal> values) {
            addCriterion("APPLY_REFUND_SUM not in", values, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("APPLY_REFUND_SUM between", value1, value2, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andApplyRefundSumNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("APPLY_REFUND_SUM not between", value1, value2, "applyRefundSum");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(String value) {
            addCriterion("STATUS =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(String value) {
            addCriterion("STATUS <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(String value) {
            addCriterion("STATUS >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(String value) {
            addCriterion("STATUS >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(String value) {
            addCriterion("STATUS <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(String value) {
            addCriterion("STATUS <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(String value) {
            addCriterion("STATUS like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(String value) {
            addCriterion("STATUS not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<String> values) {
            addCriterion("STATUS in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<String> values) {
            addCriterion("STATUS not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(String value1, String value2) {
            addCriterion("STATUS between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(String value1, String value2) {
            addCriterion("STATUS not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameIsNull() {
            addCriterion("CHECK_USERNAME is null");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameIsNotNull() {
            addCriterion("CHECK_USERNAME is not null");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameEqualTo(String value) {
            addCriterion("CHECK_USERNAME =", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameNotEqualTo(String value) {
            addCriterion("CHECK_USERNAME <>", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameGreaterThan(String value) {
            addCriterion("CHECK_USERNAME >", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("CHECK_USERNAME >=", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameLessThan(String value) {
            addCriterion("CHECK_USERNAME <", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameLessThanOrEqualTo(String value) {
            addCriterion("CHECK_USERNAME <=", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameLike(String value) {
            addCriterion("CHECK_USERNAME like", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameNotLike(String value) {
            addCriterion("CHECK_USERNAME not like", value, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameIn(List<String> values) {
            addCriterion("CHECK_USERNAME in", values, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameNotIn(List<String> values) {
            addCriterion("CHECK_USERNAME not in", values, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameBetween(String value1, String value2) {
            addCriterion("CHECK_USERNAME between", value1, value2, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andCheckUsernameNotBetween(String value1, String value2) {
            addCriterion("CHECK_USERNAME not between", value1, value2, "checkUsername");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andSaveNumIsNull() {
            addCriterion("SAVE_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSaveNumIsNotNull() {
            addCriterion("SAVE_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSaveNumEqualTo(Long value) {
            addCriterion("SAVE_NUM =", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumNotEqualTo(Long value) {
            addCriterion("SAVE_NUM <>", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumGreaterThan(Long value) {
            addCriterion("SAVE_NUM >", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumGreaterThanOrEqualTo(Long value) {
            addCriterion("SAVE_NUM >=", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumLessThan(Long value) {
            addCriterion("SAVE_NUM <", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumLessThanOrEqualTo(Long value) {
            addCriterion("SAVE_NUM <=", value, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumIn(List<Long> values) {
            addCriterion("SAVE_NUM in", values, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumNotIn(List<Long> values) {
            addCriterion("SAVE_NUM not in", values, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumBetween(Long value1, Long value2) {
            addCriterion("SAVE_NUM between", value1, value2, "saveNum");
            return (Criteria) this;
        }

        public Criteria andSaveNumNotBetween(Long value1, Long value2) {
            addCriterion("SAVE_NUM not between", value1, value2, "saveNum");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIsNull() {
            addCriterion("CONVERSION_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIsNotNull() {
            addCriterion("CONVERSION_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andConversionStatusEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS =", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS <>", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusGreaterThan(Long value) {
            addCriterion("CONVERSION_STATUS >", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS >=", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusLessThan(Long value) {
            addCriterion("CONVERSION_STATUS <", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusLessThanOrEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS <=", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIn(List<Long> values) {
            addCriterion("CONVERSION_STATUS in", values, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotIn(List<Long> values) {
            addCriterion("CONVERSION_STATUS not in", values, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusBetween(Long value1, Long value2) {
            addCriterion("CONVERSION_STATUS between", value1, value2, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotBetween(Long value1, Long value2) {
            addCriterion("CONVERSION_STATUS not between", value1, value2, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andWareIdIsNull() {
            addCriterion("WARE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWareIdIsNotNull() {
            addCriterion("WARE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWareIdEqualTo(String value) {
            addCriterion("WARE_ID =", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotEqualTo(String value) {
            addCriterion("WARE_ID <>", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdGreaterThan(String value) {
            addCriterion("WARE_ID >", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdGreaterThanOrEqualTo(String value) {
            addCriterion("WARE_ID >=", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLessThan(String value) {
            addCriterion("WARE_ID <", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLessThanOrEqualTo(String value) {
            addCriterion("WARE_ID <=", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLike(String value) {
            addCriterion("WARE_ID like", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotLike(String value) {
            addCriterion("WARE_ID not like", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdIn(List<String> values) {
            addCriterion("WARE_ID in", values, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotIn(List<String> values) {
            addCriterion("WARE_ID not in", values, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdBetween(String value1, String value2) {
            addCriterion("WARE_ID between", value1, value2, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotBetween(String value1, String value2) {
            addCriterion("WARE_ID not between", value1, value2, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareNameIsNull() {
            addCriterion("WARE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andWareNameIsNotNull() {
            addCriterion("WARE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andWareNameEqualTo(String value) {
            addCriterion("WARE_NAME =", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameNotEqualTo(String value) {
            addCriterion("WARE_NAME <>", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameGreaterThan(String value) {
            addCriterion("WARE_NAME >", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameGreaterThanOrEqualTo(String value) {
            addCriterion("WARE_NAME >=", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameLessThan(String value) {
            addCriterion("WARE_NAME <", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameLessThanOrEqualTo(String value) {
            addCriterion("WARE_NAME <=", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameLike(String value) {
            addCriterion("WARE_NAME like", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameNotLike(String value) {
            addCriterion("WARE_NAME not like", value, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameIn(List<String> values) {
            addCriterion("WARE_NAME in", values, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameNotIn(List<String> values) {
            addCriterion("WARE_NAME not in", values, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameBetween(String value1, String value2) {
            addCriterion("WARE_NAME between", value1, value2, "wareName");
            return (Criteria) this;
        }

        public Criteria andWareNameNotBetween(String value1, String value2) {
            addCriterion("WARE_NAME not between", value1, value2, "wareName");
            return (Criteria) this;
        }

        public Criteria andRefundTypeIsNull() {
            addCriterion("REFUND_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andRefundTypeIsNotNull() {
            addCriterion("REFUND_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andRefundTypeEqualTo(String value) {
            addCriterion("REFUND_TYPE =", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeNotEqualTo(String value) {
            addCriterion("REFUND_TYPE <>", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeGreaterThan(String value) {
            addCriterion("REFUND_TYPE >", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_TYPE >=", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeLessThan(String value) {
            addCriterion("REFUND_TYPE <", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeLessThanOrEqualTo(String value) {
            addCriterion("REFUND_TYPE <=", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeLike(String value) {
            addCriterion("REFUND_TYPE like", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeNotLike(String value) {
            addCriterion("REFUND_TYPE not like", value, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeIn(List<String> values) {
            addCriterion("REFUND_TYPE in", values, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeNotIn(List<String> values) {
            addCriterion("REFUND_TYPE not in", values, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeBetween(String value1, String value2) {
            addCriterion("REFUND_TYPE between", value1, value2, "refundType");
            return (Criteria) this;
        }

        public Criteria andRefundTypeNotBetween(String value1, String value2) {
            addCriterion("REFUND_TYPE not between", value1, value2, "refundType");
            return (Criteria) this;
        }

        public Criteria andExpressCodeIsNull() {
            addCriterion("EXPRESS_CODE is null");
            return (Criteria) this;
        }

        public Criteria andExpressCodeIsNotNull() {
            addCriterion("EXPRESS_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andExpressCodeEqualTo(String value) {
            addCriterion("EXPRESS_CODE =", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeNotEqualTo(String value) {
            addCriterion("EXPRESS_CODE <>", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeGreaterThan(String value) {
            addCriterion("EXPRESS_CODE >", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeGreaterThanOrEqualTo(String value) {
            addCriterion("EXPRESS_CODE >=", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeLessThan(String value) {
            addCriterion("EXPRESS_CODE <", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeLessThanOrEqualTo(String value) {
            addCriterion("EXPRESS_CODE <=", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeLike(String value) {
            addCriterion("EXPRESS_CODE like", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeNotLike(String value) {
            addCriterion("EXPRESS_CODE not like", value, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeIn(List<String> values) {
            addCriterion("EXPRESS_CODE in", values, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeNotIn(List<String> values) {
            addCriterion("EXPRESS_CODE not in", values, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeBetween(String value1, String value2) {
            addCriterion("EXPRESS_CODE between", value1, value2, "expressCode");
            return (Criteria) this;
        }

        public Criteria andExpressCodeNotBetween(String value1, String value2) {
            addCriterion("EXPRESS_CODE not between", value1, value2, "expressCode");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectIsNull() {
            addCriterion("CUSTOMER_EXPECT is null");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectIsNotNull() {
            addCriterion("CUSTOMER_EXPECT is not null");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectEqualTo(Long value) {
            addCriterion("CUSTOMER_EXPECT =", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectNotEqualTo(Long value) {
            addCriterion("CUSTOMER_EXPECT <>", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectGreaterThan(Long value) {
            addCriterion("CUSTOMER_EXPECT >", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectGreaterThanOrEqualTo(Long value) {
            addCriterion("CUSTOMER_EXPECT >=", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectLessThan(Long value) {
            addCriterion("CUSTOMER_EXPECT <", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectLessThanOrEqualTo(Long value) {
            addCriterion("CUSTOMER_EXPECT <=", value, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectIn(List<Long> values) {
            addCriterion("CUSTOMER_EXPECT in", values, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectNotIn(List<Long> values) {
            addCriterion("CUSTOMER_EXPECT not in", values, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectBetween(Long value1, Long value2) {
            addCriterion("CUSTOMER_EXPECT between", value1, value2, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andCustomerExpectNotBetween(Long value1, Long value2) {
            addCriterion("CUSTOMER_EXPECT not between", value1, value2, "customerExpect");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNull() {
            addCriterion("PROCESS_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNotNull() {
            addCriterion("PROCESS_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusEqualTo(Long value) {
            addCriterion("PROCESS_STATUS =", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotEqualTo(Long value) {
            addCriterion("PROCESS_STATUS <>", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThan(Long value) {
            addCriterion("PROCESS_STATUS >", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("PROCESS_STATUS >=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThan(Long value) {
            addCriterion("PROCESS_STATUS <", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThanOrEqualTo(Long value) {
            addCriterion("PROCESS_STATUS <=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIn(List<Long> values) {
            addCriterion("PROCESS_STATUS in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotIn(List<Long> values) {
            addCriterion("PROCESS_STATUS not in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusBetween(Long value1, Long value2) {
            addCriterion("PROCESS_STATUS between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotBetween(Long value1, Long value2) {
            addCriterion("PROCESS_STATUS not between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNull() {
            addCriterion("ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNotNull() {
            addCriterion("ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusEqualTo(String value) {
            addCriterion("ORDER_STATUS =", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotEqualTo(String value) {
            addCriterion("ORDER_STATUS <>", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThan(String value) {
            addCriterion("ORDER_STATUS >", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS >=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThan(String value) {
            addCriterion("ORDER_STATUS <", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS <=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLike(String value) {
            addCriterion("ORDER_STATUS like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotLike(String value) {
            addCriterion("ORDER_STATUS not like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIn(List<String> values) {
            addCriterion("ORDER_STATUS in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotIn(List<String> values) {
            addCriterion("ORDER_STATUS not in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS not between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNull() {
            addCriterion("ISCS_RECEIPT_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNotNull() {
            addCriterion("ISCS_RECEIPT_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS =", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <>", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS not like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS not in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS not between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNull() {
            addCriterion("SERVICE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNotNull() {
            addCriterion("SERVICE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusEqualTo(String value) {
            addCriterion("SERVICE_STATUS =", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotEqualTo(String value) {
            addCriterion("SERVICE_STATUS <>", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThan(String value) {
            addCriterion("SERVICE_STATUS >", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS >=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThan(String value) {
            addCriterion("SERVICE_STATUS <", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS <=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLike(String value) {
            addCriterion("SERVICE_STATUS like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotLike(String value) {
            addCriterion("SERVICE_STATUS not like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIn(List<String> values) {
            addCriterion("SERVICE_STATUS in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotIn(List<String> values) {
            addCriterion("SERVICE_STATUS not in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS not between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNull() {
            addCriterion("SUB_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNotNull() {
            addCriterion("SUB_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdEqualTo(String value) {
            addCriterion("SUB_ORDER_ID =", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <>", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThan(String value) {
            addCriterion("SUB_ORDER_ID >", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID >=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThan(String value) {
            addCriterion("SUB_ORDER_ID <", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLike(String value) {
            addCriterion("SUB_ORDER_ID like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotLike(String value) {
            addCriterion("SUB_ORDER_ID not like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIn(List<String> values) {
            addCriterion("SUB_ORDER_ID in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotIn(List<String> values) {
            addCriterion("SUB_ORDER_ID not in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID not between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNull() {
            addCriterion("GOOD_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNotNull() {
            addCriterion("GOOD_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusEqualTo(String value) {
            addCriterion("GOOD_STATUS =", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotEqualTo(String value) {
            addCriterion("GOOD_STATUS <>", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThan(String value) {
            addCriterion("GOOD_STATUS >", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS >=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThan(String value) {
            addCriterion("GOOD_STATUS <", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS <=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLike(String value) {
            addCriterion("GOOD_STATUS like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotLike(String value) {
            addCriterion("GOOD_STATUS not like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIn(List<String> values) {
            addCriterion("GOOD_STATUS in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotIn(List<String> values) {
            addCriterion("GOOD_STATUS not in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS not between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andBuyerIdIsNull() {
            addCriterion("BUYER_ID is null");
            return (Criteria) this;
        }

        public Criteria andBuyerIdIsNotNull() {
            addCriterion("BUYER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerIdEqualTo(String value) {
            addCriterion("BUYER_ID =", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdNotEqualTo(String value) {
            addCriterion("BUYER_ID <>", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdGreaterThan(String value) {
            addCriterion("BUYER_ID >", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_ID >=", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdLessThan(String value) {
            addCriterion("BUYER_ID <", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdLessThanOrEqualTo(String value) {
            addCriterion("BUYER_ID <=", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdLike(String value) {
            addCriterion("BUYER_ID like", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdNotLike(String value) {
            addCriterion("BUYER_ID not like", value, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdIn(List<String> values) {
            addCriterion("BUYER_ID in", values, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdNotIn(List<String> values) {
            addCriterion("BUYER_ID not in", values, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdBetween(String value1, String value2) {
            addCriterion("BUYER_ID between", value1, value2, "buyerId");
            return (Criteria) this;
        }

        public Criteria andBuyerIdNotBetween(String value1, String value2) {
            addCriterion("BUYER_ID not between", value1, value2, "buyerId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}