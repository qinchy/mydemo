package com.wwwarehouse.xdw.datasync.dao.model;


import com.wwwarehouse.commons.utils.StringUtils;

import java.util.Date;

/**
* @date 16-10-13 上午10:09
* @tableComment  平台商品资料,铺货
*/
public class ImPlatformItem extends BaseObject {
    private Long platformItemUkid; // 主键

    private Long platformId; // 平台Id,适当冗余

    private Long shopId; // 店铺ID

    private Long ownerId; // 货主ID

    private String identifyCode; // 识别ID.关联物的识别编码

    private Long identifyUkid; // 关联外部的ukid  :物UKID ;冗余字段，如果是已关联就存在值

    private Long itemStatus; // 平台商品状态：10：未关联、30：无需发货、90：已关联

    private String productNumId; // 商品数字id

    private String productOuterId; // 商品代码

    private String skuNumId; // 规则数字id

    private String skuOuterId; // 规格代码

    private String productTitle; // 商品名称

    private String skuName; // 规格名称

    private Double sellPrice; // 销售单价

    private String platformImgUrl; // 平台商品图片

    private String brandName; // 品牌名称

    private String category; // 类目名称

    private Date createTime; // 创建时间

    private Long createUserId; // 创建人

    private Date updateTime; // 更新时间

    private Long updateUserId; // 更新人

    private Long itemCount; // 商品数量

    private String categoryId;//平台商品的类目ID

    private Long status;//是否同步


    /**
     * 平台商品拼装商品条码，规则：
     * 如果一方为空，则使用另一方
     * 如果一方长度太短（小于5），则可能是要组合的
     * 如果一方包含另一方，则取该数据
     * 如果长度都大于等于一定长度（5），则取长度大的一方
     *
     * @return 条码
     */
    public String buildProductCode(){
        if (StringUtils.isEmpty(productOuterId) || StringUtils.isEmpty(skuOuterId)) {
            if (StringUtils.isNotEmpty(productOuterId)) {
                return productOuterId;
            }
            if (StringUtils.isNotEmpty(skuOuterId)) {
                return skuOuterId;
            }
            return null;
        }

        if (skuOuterId.length() >= 5 && productOuterId.contains(skuOuterId)) {
            return productOuterId;
        }
        if (productOuterId.length() >= 5 && skuOuterId.contains(productOuterId)) {
            return skuOuterId;
        }

        if (skuOuterId.length() >= 5 && productOuterId.length() > skuOuterId.length()) {
            return productOuterId;
        }
        if (productOuterId.length() >= 5 && skuOuterId.length() > productOuterId.length()) {
            return skuOuterId;
        }

        return productOuterId + skuOuterId;
    }

    public Long getPlatformItemUkid() {
        return platformItemUkid;
    }

    public void setPlatformItemUkid(Long platformItemUkid) {
        this.platformItemUkid = platformItemUkid;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getIdentifyCode() {
        return identifyCode;
    }

    public void setIdentifyCode(String identifyCode) {
        this.identifyCode = identifyCode == null ? null : identifyCode.trim();
    }

    public Long getIdentifyUkid() {
        return identifyUkid;
    }

    public void setIdentifyUkid(Long identifyUkid) {
        this.identifyUkid = identifyUkid;
    }

    public Long getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(Long itemStatus) {
        this.itemStatus = itemStatus;
    }

    public String getProductNumId() {
        return productNumId;
    }

    public void setProductNumId(String productNumId) {
        this.productNumId = productNumId == null ? null : productNumId.trim();
    }

    public String getProductOuterId() {
        return productOuterId;
    }

    public void setProductOuterId(String productOuterId) {
        this.productOuterId = productOuterId == null ? null : productOuterId.trim();
    }

    public String getSkuNumId() {
        return skuNumId;
    }

    public void setSkuNumId(String skuNumId) {
        this.skuNumId = skuNumId == null ? null : skuNumId.trim();
    }

    public String getSkuOuterId() {
        return skuOuterId;
    }

    public void setSkuOuterId(String skuOuterId) {
        this.skuOuterId = skuOuterId == null ? null : skuOuterId.trim();
    }

    public String getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle == null ? null : productTitle.trim();
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName == null ? null : skuName.trim();
    }

    public Double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getPlatformImgUrl() {
        return platformImgUrl;
    }

    public void setPlatformImgUrl(String platformImgUrl) {
        this.platformImgUrl = platformImgUrl == null ? null : platformImgUrl.trim();
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName == null ? null : brandName.trim();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category == null ? null : category.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Long getItemCount() {
        return itemCount;
    }

    public void setItemCount(Long itemCount) {
        this.itemCount = itemCount;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", platformItemUkid=").append(platformItemUkid);
        sb.append(", platformId=").append(platformId);
        sb.append(", shopId=").append(shopId);
        sb.append(", ownerId=").append(ownerId);
        sb.append(", identifyCode=").append(identifyCode);
        sb.append(", identifyUkid=").append(identifyUkid);
        sb.append(", itemStatus=").append(itemStatus);
        sb.append(", productNumId=").append(productNumId);
        sb.append(", productOuterId=").append(productOuterId);
        sb.append(", skuNumId=").append(skuNumId);
        sb.append(", skuOuterId=").append(skuOuterId);
        sb.append(", productTitle=").append(productTitle);
        sb.append(", skuName=").append(skuName);
        sb.append(", sellPrice=").append(sellPrice);
        sb.append(", platformImgUrl=").append(platformImgUrl);
        sb.append(", brandName=").append(brandName);
        sb.append(", category=").append(category);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append(", itemCount=").append(itemCount);
        sb.append("]");
        return sb.toString();
    }
}