package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ImPlatformItemDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public ImPlatformItemDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andPlatformItemUkidIsNull() {
            addCriterion("PLATFORM_ITEM_UKID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidIsNotNull() {
            addCriterion("PLATFORM_ITEM_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidEqualTo(Long value) {
            addCriterion("PLATFORM_ITEM_UKID =", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidNotEqualTo(Long value) {
            addCriterion("PLATFORM_ITEM_UKID <>", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidGreaterThan(Long value) {
            addCriterion("PLATFORM_ITEM_UKID >", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ITEM_UKID >=", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidLessThan(Long value) {
            addCriterion("PLATFORM_ITEM_UKID <", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidLessThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ITEM_UKID <=", value, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidIn(List<Long> values) {
            addCriterion("PLATFORM_ITEM_UKID in", values, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidNotIn(List<Long> values) {
            addCriterion("PLATFORM_ITEM_UKID not in", values, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ITEM_UKID between", value1, value2, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformItemUkidNotBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ITEM_UKID not between", value1, value2, "platformItemUkid");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("PLATFORM_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("PLATFORM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Long value) {
            addCriterion("PLATFORM_ID =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Long value) {
            addCriterion("PLATFORM_ID <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Long value) {
            addCriterion("PLATFORM_ID >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Long value) {
            addCriterion("PLATFORM_ID <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Long> values) {
            addCriterion("PLATFORM_ID in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Long> values) {
            addCriterion("PLATFORM_ID not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Long value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Long value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Long value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Long value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Long> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Long> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdIsNull() {
            addCriterion("OWNER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOwnerIdIsNotNull() {
            addCriterion("OWNER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOwnerIdEqualTo(Long value) {
            addCriterion("OWNER_ID =", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdNotEqualTo(Long value) {
            addCriterion("OWNER_ID <>", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdGreaterThan(Long value) {
            addCriterion("OWNER_ID >", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdGreaterThanOrEqualTo(Long value) {
            addCriterion("OWNER_ID >=", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdLessThan(Long value) {
            addCriterion("OWNER_ID <", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdLessThanOrEqualTo(Long value) {
            addCriterion("OWNER_ID <=", value, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdIn(List<Long> values) {
            addCriterion("OWNER_ID in", values, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdNotIn(List<Long> values) {
            addCriterion("OWNER_ID not in", values, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdBetween(Long value1, Long value2) {
            addCriterion("OWNER_ID between", value1, value2, "ownerId");
            return (Criteria) this;
        }

        public Criteria andOwnerIdNotBetween(Long value1, Long value2) {
            addCriterion("OWNER_ID not between", value1, value2, "ownerId");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeIsNull() {
            addCriterion("IDENTIFY_CODE is null");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeIsNotNull() {
            addCriterion("IDENTIFY_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeEqualTo(String value) {
            addCriterion("IDENTIFY_CODE =", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeNotEqualTo(String value) {
            addCriterion("IDENTIFY_CODE <>", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeGreaterThan(String value) {
            addCriterion("IDENTIFY_CODE >", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeGreaterThanOrEqualTo(String value) {
            addCriterion("IDENTIFY_CODE >=", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeLessThan(String value) {
            addCriterion("IDENTIFY_CODE <", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeLessThanOrEqualTo(String value) {
            addCriterion("IDENTIFY_CODE <=", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeLike(String value) {
            addCriterion("IDENTIFY_CODE like", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeNotLike(String value) {
            addCriterion("IDENTIFY_CODE not like", value, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeIn(List<String> values) {
            addCriterion("IDENTIFY_CODE in", values, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeNotIn(List<String> values) {
            addCriterion("IDENTIFY_CODE not in", values, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeBetween(String value1, String value2) {
            addCriterion("IDENTIFY_CODE between", value1, value2, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyCodeNotBetween(String value1, String value2) {
            addCriterion("IDENTIFY_CODE not between", value1, value2, "identifyCode");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidIsNull() {
            addCriterion("IDENTIFY_UKID is null");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidIsNotNull() {
            addCriterion("IDENTIFY_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidEqualTo(Long value) {
            addCriterion("IDENTIFY_UKID =", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidNotEqualTo(Long value) {
            addCriterion("IDENTIFY_UKID <>", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidGreaterThan(Long value) {
            addCriterion("IDENTIFY_UKID >", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("IDENTIFY_UKID >=", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidLessThan(Long value) {
            addCriterion("IDENTIFY_UKID <", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidLessThanOrEqualTo(Long value) {
            addCriterion("IDENTIFY_UKID <=", value, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidIn(List<Long> values) {
            addCriterion("IDENTIFY_UKID in", values, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidNotIn(List<Long> values) {
            addCriterion("IDENTIFY_UKID not in", values, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidBetween(Long value1, Long value2) {
            addCriterion("IDENTIFY_UKID between", value1, value2, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andIdentifyUkidNotBetween(Long value1, Long value2) {
            addCriterion("IDENTIFY_UKID not between", value1, value2, "identifyUkid");
            return (Criteria) this;
        }

        public Criteria andItemStatusIsNull() {
            addCriterion("ITEM_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andItemStatusIsNotNull() {
            addCriterion("ITEM_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andItemStatusEqualTo(Long value) {
            addCriterion("ITEM_STATUS =", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusNotEqualTo(Long value) {
            addCriterion("ITEM_STATUS <>", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusGreaterThan(Long value) {
            addCriterion("ITEM_STATUS >", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("ITEM_STATUS >=", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusLessThan(Long value) {
            addCriterion("ITEM_STATUS <", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusLessThanOrEqualTo(Long value) {
            addCriterion("ITEM_STATUS <=", value, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusIn(List<Long> values) {
            addCriterion("ITEM_STATUS in", values, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusNotIn(List<Long> values) {
            addCriterion("ITEM_STATUS not in", values, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusBetween(Long value1, Long value2) {
            addCriterion("ITEM_STATUS between", value1, value2, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andItemStatusNotBetween(Long value1, Long value2) {
            addCriterion("ITEM_STATUS not between", value1, value2, "itemStatus");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIsNull() {
            addCriterion("PRODUCT_NUM_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIsNotNull() {
            addCriterion("PRODUCT_NUM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductNumIdEqualTo(String value) {
            addCriterion("PRODUCT_NUM_ID =", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotEqualTo(String value) {
            addCriterion("PRODUCT_NUM_ID <>", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdGreaterThan(String value) {
            addCriterion("PRODUCT_NUM_ID >", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NUM_ID >=", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdLessThan(String value) {
            addCriterion("PRODUCT_NUM_ID <", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NUM_ID <=", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdLike(String value) {
            addCriterion("PRODUCT_NUM_ID like", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotLike(String value) {
            addCriterion("PRODUCT_NUM_ID not like", value, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdIn(List<String> values) {
            addCriterion("PRODUCT_NUM_ID in", values, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotIn(List<String> values) {
            addCriterion("PRODUCT_NUM_ID not in", values, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdBetween(String value1, String value2) {
            addCriterion("PRODUCT_NUM_ID between", value1, value2, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductNumIdNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_NUM_ID not between", value1, value2, "productNumId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIsNull() {
            addCriterion("PRODUCT_OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIsNotNull() {
            addCriterion("PRODUCT_OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID =", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID <>", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdGreaterThan(String value) {
            addCriterion("PRODUCT_OUTER_ID >", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID >=", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLessThan(String value) {
            addCriterion("PRODUCT_OUTER_ID <", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_OUTER_ID <=", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdLike(String value) {
            addCriterion("PRODUCT_OUTER_ID like", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotLike(String value) {
            addCriterion("PRODUCT_OUTER_ID not like", value, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdIn(List<String> values) {
            addCriterion("PRODUCT_OUTER_ID in", values, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotIn(List<String> values) {
            addCriterion("PRODUCT_OUTER_ID not in", values, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdBetween(String value1, String value2) {
            addCriterion("PRODUCT_OUTER_ID between", value1, value2, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andProductOuterIdNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_OUTER_ID not between", value1, value2, "productOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIsNull() {
            addCriterion("SKU_NUM_ID is null");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIsNotNull() {
            addCriterion("SKU_NUM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdEqualTo(String value) {
            addCriterion("SKU_NUM_ID =", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotEqualTo(String value) {
            addCriterion("SKU_NUM_ID <>", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdGreaterThan(String value) {
            addCriterion("SKU_NUM_ID >", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_NUM_ID >=", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLessThan(String value) {
            addCriterion("SKU_NUM_ID <", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLessThanOrEqualTo(String value) {
            addCriterion("SKU_NUM_ID <=", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdLike(String value) {
            addCriterion("SKU_NUM_ID like", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotLike(String value) {
            addCriterion("SKU_NUM_ID not like", value, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdIn(List<String> values) {
            addCriterion("SKU_NUM_ID in", values, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotIn(List<String> values) {
            addCriterion("SKU_NUM_ID not in", values, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdBetween(String value1, String value2) {
            addCriterion("SKU_NUM_ID between", value1, value2, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuNumIdNotBetween(String value1, String value2) {
            addCriterion("SKU_NUM_ID not between", value1, value2, "skuNumId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIsNull() {
            addCriterion("SKU_OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIsNotNull() {
            addCriterion("SKU_OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdEqualTo(String value) {
            addCriterion("SKU_OUTER_ID =", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotEqualTo(String value) {
            addCriterion("SKU_OUTER_ID <>", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdGreaterThan(String value) {
            addCriterion("SKU_OUTER_ID >", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_OUTER_ID >=", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLessThan(String value) {
            addCriterion("SKU_OUTER_ID <", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLessThanOrEqualTo(String value) {
            addCriterion("SKU_OUTER_ID <=", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdLike(String value) {
            addCriterion("SKU_OUTER_ID like", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotLike(String value) {
            addCriterion("SKU_OUTER_ID not like", value, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdIn(List<String> values) {
            addCriterion("SKU_OUTER_ID in", values, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotIn(List<String> values) {
            addCriterion("SKU_OUTER_ID not in", values, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdBetween(String value1, String value2) {
            addCriterion("SKU_OUTER_ID between", value1, value2, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andSkuOuterIdNotBetween(String value1, String value2) {
            addCriterion("SKU_OUTER_ID not between", value1, value2, "skuOuterId");
            return (Criteria) this;
        }

        public Criteria andProductTitleIsNull() {
            addCriterion("PRODUCT_TITLE is null");
            return (Criteria) this;
        }

        public Criteria andProductTitleIsNotNull() {
            addCriterion("PRODUCT_TITLE is not null");
            return (Criteria) this;
        }

        public Criteria andProductTitleEqualTo(String value) {
            addCriterion("PRODUCT_TITLE =", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleNotEqualTo(String value) {
            addCriterion("PRODUCT_TITLE <>", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleGreaterThan(String value) {
            addCriterion("PRODUCT_TITLE >", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_TITLE >=", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleLessThan(String value) {
            addCriterion("PRODUCT_TITLE <", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_TITLE <=", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleLike(String value) {
            addCriterion("PRODUCT_TITLE like", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleNotLike(String value) {
            addCriterion("PRODUCT_TITLE not like", value, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleIn(List<String> values) {
            addCriterion("PRODUCT_TITLE in", values, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleNotIn(List<String> values) {
            addCriterion("PRODUCT_TITLE not in", values, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleBetween(String value1, String value2) {
            addCriterion("PRODUCT_TITLE between", value1, value2, "productTitle");
            return (Criteria) this;
        }

        public Criteria andProductTitleNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_TITLE not between", value1, value2, "productTitle");
            return (Criteria) this;
        }

        public Criteria andSkuNameIsNull() {
            addCriterion("SKU_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSkuNameIsNotNull() {
            addCriterion("SKU_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSkuNameEqualTo(String value) {
            addCriterion("SKU_NAME =", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotEqualTo(String value) {
            addCriterion("SKU_NAME <>", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameGreaterThan(String value) {
            addCriterion("SKU_NAME >", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_NAME >=", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLessThan(String value) {
            addCriterion("SKU_NAME <", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLessThanOrEqualTo(String value) {
            addCriterion("SKU_NAME <=", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLike(String value) {
            addCriterion("SKU_NAME like", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotLike(String value) {
            addCriterion("SKU_NAME not like", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameIn(List<String> values) {
            addCriterion("SKU_NAME in", values, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotIn(List<String> values) {
            addCriterion("SKU_NAME not in", values, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameBetween(String value1, String value2) {
            addCriterion("SKU_NAME between", value1, value2, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotBetween(String value1, String value2) {
            addCriterion("SKU_NAME not between", value1, value2, "skuName");
            return (Criteria) this;
        }

        public Criteria andSellPriceIsNull() {
            addCriterion("SELL_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andSellPriceIsNotNull() {
            addCriterion("SELL_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andSellPriceEqualTo(BigDecimal value) {
            addCriterion("SELL_PRICE =", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceNotEqualTo(BigDecimal value) {
            addCriterion("SELL_PRICE <>", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceGreaterThan(BigDecimal value) {
            addCriterion("SELL_PRICE >", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SELL_PRICE >=", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceLessThan(BigDecimal value) {
            addCriterion("SELL_PRICE <", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SELL_PRICE <=", value, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceIn(List<BigDecimal> values) {
            addCriterion("SELL_PRICE in", values, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceNotIn(List<BigDecimal> values) {
            addCriterion("SELL_PRICE not in", values, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELL_PRICE between", value1, value2, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andSellPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SELL_PRICE not between", value1, value2, "sellPrice");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlIsNull() {
            addCriterion("PLATFORM_IMG_URL is null");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlIsNotNull() {
            addCriterion("PLATFORM_IMG_URL is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlEqualTo(String value) {
            addCriterion("PLATFORM_IMG_URL =", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlNotEqualTo(String value) {
            addCriterion("PLATFORM_IMG_URL <>", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlGreaterThan(String value) {
            addCriterion("PLATFORM_IMG_URL >", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_IMG_URL >=", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlLessThan(String value) {
            addCriterion("PLATFORM_IMG_URL <", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_IMG_URL <=", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlLike(String value) {
            addCriterion("PLATFORM_IMG_URL like", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlNotLike(String value) {
            addCriterion("PLATFORM_IMG_URL not like", value, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlIn(List<String> values) {
            addCriterion("PLATFORM_IMG_URL in", values, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlNotIn(List<String> values) {
            addCriterion("PLATFORM_IMG_URL not in", values, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlBetween(String value1, String value2) {
            addCriterion("PLATFORM_IMG_URL between", value1, value2, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andPlatformImgUrlNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_IMG_URL not between", value1, value2, "platformImgUrl");
            return (Criteria) this;
        }

        public Criteria andBrandNameIsNull() {
            addCriterion("BRAND_NAME is null");
            return (Criteria) this;
        }

        public Criteria andBrandNameIsNotNull() {
            addCriterion("BRAND_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andBrandNameEqualTo(String value) {
            addCriterion("BRAND_NAME =", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameNotEqualTo(String value) {
            addCriterion("BRAND_NAME <>", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameGreaterThan(String value) {
            addCriterion("BRAND_NAME >", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameGreaterThanOrEqualTo(String value) {
            addCriterion("BRAND_NAME >=", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameLessThan(String value) {
            addCriterion("BRAND_NAME <", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameLessThanOrEqualTo(String value) {
            addCriterion("BRAND_NAME <=", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameLike(String value) {
            addCriterion("BRAND_NAME like", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameNotLike(String value) {
            addCriterion("BRAND_NAME not like", value, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameIn(List<String> values) {
            addCriterion("BRAND_NAME in", values, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameNotIn(List<String> values) {
            addCriterion("BRAND_NAME not in", values, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameBetween(String value1, String value2) {
            addCriterion("BRAND_NAME between", value1, value2, "brandName");
            return (Criteria) this;
        }

        public Criteria andBrandNameNotBetween(String value1, String value2) {
            addCriterion("BRAND_NAME not between", value1, value2, "brandName");
            return (Criteria) this;
        }

        public Criteria andCategoryIsNull() {
            addCriterion("CATEGORY is null");
            return (Criteria) this;
        }

        public Criteria andCategoryIsNotNull() {
            addCriterion("CATEGORY is not null");
            return (Criteria) this;
        }

        public Criteria andCategoryEqualTo(String value) {
            addCriterion("CATEGORY =", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryNotEqualTo(String value) {
            addCriterion("CATEGORY <>", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryGreaterThan(String value) {
            addCriterion("CATEGORY >", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryGreaterThanOrEqualTo(String value) {
            addCriterion("CATEGORY >=", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryLessThan(String value) {
            addCriterion("CATEGORY <", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryLessThanOrEqualTo(String value) {
            addCriterion("CATEGORY <=", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryLike(String value) {
            addCriterion("CATEGORY like", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryNotLike(String value) {
            addCriterion("CATEGORY not like", value, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryIn(List<String> values) {
            addCriterion("CATEGORY in", values, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryNotIn(List<String> values) {
            addCriterion("CATEGORY not in", values, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryBetween(String value1, String value2) {
            addCriterion("CATEGORY between", value1, value2, "category");
            return (Criteria) this;
        }

        public Criteria andCategoryNotBetween(String value1, String value2) {
            addCriterion("CATEGORY not between", value1, value2, "category");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andItemCountIsNull() {
            addCriterion("ITEM_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andItemCountIsNotNull() {
            addCriterion("ITEM_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andItemCountEqualTo(Long value) {
            addCriterion("ITEM_COUNT =", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountNotEqualTo(Long value) {
            addCriterion("ITEM_COUNT <>", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountGreaterThan(Long value) {
            addCriterion("ITEM_COUNT >", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountGreaterThanOrEqualTo(Long value) {
            addCriterion("ITEM_COUNT >=", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountLessThan(Long value) {
            addCriterion("ITEM_COUNT <", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountLessThanOrEqualTo(Long value) {
            addCriterion("ITEM_COUNT <=", value, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountIn(List<Long> values) {
            addCriterion("ITEM_COUNT in", values, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountNotIn(List<Long> values) {
            addCriterion("ITEM_COUNT not in", values, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountBetween(Long value1, Long value2) {
            addCriterion("ITEM_COUNT between", value1, value2, "itemCount");
            return (Criteria) this;
        }

        public Criteria andItemCountNotBetween(Long value1, Long value2) {
            addCriterion("ITEM_COUNT not between", value1, value2, "itemCount");
            return (Criteria) this;
        }

        public Criteria andCategoryIdIsNull() {
            addCriterion("CATEGORY_ID is null");
            return (Criteria) this;
        }

        public Criteria andCategoryIdIsNotNull() {
            addCriterion("CATEGORY_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCategoryIdEqualTo(String value) {
            addCriterion("CATEGORY_ID =", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdNotEqualTo(String value) {
            addCriterion("CATEGORY_ID <>", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdGreaterThan(String value) {
            addCriterion("CATEGORY_ID >", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdGreaterThanOrEqualTo(String value) {
            addCriterion("CATEGORY_ID >=", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdLessThan(String value) {
            addCriterion("CATEGORY_ID <", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdLessThanOrEqualTo(String value) {
            addCriterion("CATEGORY_ID <=", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdLike(String value) {
            addCriterion("CATEGORY_ID like", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdNotLike(String value) {
            addCriterion("CATEGORY_ID not like", value, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdIn(List<String> values) {
            addCriterion("CATEGORY_ID in", values, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdNotIn(List<String> values) {
            addCriterion("CATEGORY_ID not in", values, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdBetween(String value1, String value2) {
            addCriterion("CATEGORY_ID between", value1, value2, "categoryId");
            return (Criteria) this;
        }

        public Criteria andCategoryIdNotBetween(String value1, String value2) {
            addCriterion("CATEGORY_ID not between", value1, value2, "categoryId");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Long value) {
            addCriterion("STATUS =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Long value) {
            addCriterion("STATUS <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Long value) {
            addCriterion("STATUS >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("STATUS >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Long value) {
            addCriterion("STATUS <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Long value) {
            addCriterion("STATUS <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Long> values) {
            addCriterion("STATUS in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Long> values) {
            addCriterion("STATUS not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Long value1, Long value2) {
            addCriterion("STATUS between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Long value1, Long value2) {
            addCriterion("STATUS not between", value1, value2, "status");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}