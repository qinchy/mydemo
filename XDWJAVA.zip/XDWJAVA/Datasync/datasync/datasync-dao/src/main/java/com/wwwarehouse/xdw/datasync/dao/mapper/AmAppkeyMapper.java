package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AmAppkeyMapper {
    long countByExample(AmAppkeyExample example);

    int deleteByExample(AmAppkeyExample example);

    int deleteByPrimaryKey(Long appUkid);

    int insert(AmAppkeyDO record);

    int insertSelective(AmAppkeyDO record);

    List<AmAppkeyDO> selectByExample(AmAppkeyExample example);

    AmAppkeyDO selectByPrimaryKey(Long appUkid);

    int updateByExampleSelective(@Param("record") AmAppkeyDO record, @Param("example") AmAppkeyExample example);

    int updateByExample(@Param("record") AmAppkeyDO record, @Param("example") AmAppkeyExample example);

    int updateByPrimaryKeySelective(AmAppkeyDO record);

    int updateByPrimaryKey(AmAppkeyDO record);
}