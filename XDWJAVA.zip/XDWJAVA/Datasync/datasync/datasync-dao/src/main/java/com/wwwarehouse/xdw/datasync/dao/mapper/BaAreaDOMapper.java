package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDO;
import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BaAreaDOMapper {
    long countByExample(BaAreaDOExample example);

    int deleteByExample(BaAreaDOExample example);

    int deleteByPrimaryKey(@Param("areaId") String areaId, @Param("countryId") String countryId);

    int insert(BaAreaDO record);

    int insertSelective(BaAreaDO record);

    List<BaAreaDO> selectByExample(BaAreaDOExample example);

    BaAreaDO selectByPrimaryKey(@Param("areaId") String areaId, @Param("countryId") String countryId);

    int updateByExampleSelective(@Param("record") BaAreaDO record, @Param("example") BaAreaDOExample example);

    int updateByExample(@Param("record") BaAreaDO record, @Param("example") BaAreaDOExample example);

    int updateByPrimaryKeySelective(BaAreaDO record);

    int updateByPrimaryKey(BaAreaDO record);
}