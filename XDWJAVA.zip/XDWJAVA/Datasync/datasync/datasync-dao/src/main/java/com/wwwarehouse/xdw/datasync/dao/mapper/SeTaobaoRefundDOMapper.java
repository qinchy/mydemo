package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeTaobaoRefundDOMapper {
    long countByExample(SeTaobaoRefundDOExample example);

    int deleteByExample(SeTaobaoRefundDOExample example);

    int deleteByPrimaryKey(Long refundUkid);

    int insert(SeTaobaoRefundDO record);

    int insertSelective(SeTaobaoRefundDO record);

    List<SeTaobaoRefundDO> selectByExample(SeTaobaoRefundDOExample example);

    SeTaobaoRefundDO selectByPrimaryKey(Long refundUkid);

    int updateByExampleSelective(@Param("record") SeTaobaoRefundDO record, @Param("example") SeTaobaoRefundDOExample example);

    int updateByExample(@Param("record") SeTaobaoRefundDO record, @Param("example") SeTaobaoRefundDOExample example);

    int updateByPrimaryKeySelective(SeTaobaoRefundDO record);

    int updateByPrimaryKey(SeTaobaoRefundDO record);

    SeTaobaoRefundDO getRefund(@Param("refundId") String refundId, @Param("sku") String skuNumId) throws Exception;

    int updatePlatfromStatus(SeTaobaoRefundDO o) throws Exception;

    int updateProcessStatus(SeTaobaoRefundDO o) throws Exception;
}