package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaSmsExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SaSmsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSmsUkidIsNull() {
            addCriterion("SMS_UKID is null");
            return (Criteria) this;
        }

        public Criteria andSmsUkidIsNotNull() {
            addCriterion("SMS_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andSmsUkidEqualTo(Long value) {
            addCriterion("SMS_UKID =", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidNotEqualTo(Long value) {
            addCriterion("SMS_UKID <>", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidGreaterThan(Long value) {
            addCriterion("SMS_UKID >", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SMS_UKID >=", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidLessThan(Long value) {
            addCriterion("SMS_UKID <", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidLessThanOrEqualTo(Long value) {
            addCriterion("SMS_UKID <=", value, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidIn(List<Long> values) {
            addCriterion("SMS_UKID in", values, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidNotIn(List<Long> values) {
            addCriterion("SMS_UKID not in", values, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidBetween(Long value1, Long value2) {
            addCriterion("SMS_UKID between", value1, value2, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andSmsUkidNotBetween(Long value1, Long value2) {
            addCriterion("SMS_UKID not between", value1, value2, "smsUkid");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdIsNull() {
            addCriterion("SERVICE_BU_ID is null");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdIsNotNull() {
            addCriterion("SERVICE_BU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdEqualTo(Long value) {
            addCriterion("SERVICE_BU_ID =", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdNotEqualTo(Long value) {
            addCriterion("SERVICE_BU_ID <>", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdGreaterThan(Long value) {
            addCriterion("SERVICE_BU_ID >", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SERVICE_BU_ID >=", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdLessThan(Long value) {
            addCriterion("SERVICE_BU_ID <", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdLessThanOrEqualTo(Long value) {
            addCriterion("SERVICE_BU_ID <=", value, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdIn(List<Long> values) {
            addCriterion("SERVICE_BU_ID in", values, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdNotIn(List<Long> values) {
            addCriterion("SERVICE_BU_ID not in", values, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdBetween(Long value1, Long value2) {
            addCriterion("SERVICE_BU_ID between", value1, value2, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andServiceBuIdNotBetween(Long value1, Long value2) {
            addCriterion("SERVICE_BU_ID not between", value1, value2, "serviceBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdIsNull() {
            addCriterion("SEND_BU_ID is null");
            return (Criteria) this;
        }

        public Criteria andSendBuIdIsNotNull() {
            addCriterion("SEND_BU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSendBuIdEqualTo(Long value) {
            addCriterion("SEND_BU_ID =", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdNotEqualTo(Long value) {
            addCriterion("SEND_BU_ID <>", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdGreaterThan(Long value) {
            addCriterion("SEND_BU_ID >", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SEND_BU_ID >=", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdLessThan(Long value) {
            addCriterion("SEND_BU_ID <", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdLessThanOrEqualTo(Long value) {
            addCriterion("SEND_BU_ID <=", value, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdIn(List<Long> values) {
            addCriterion("SEND_BU_ID in", values, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdNotIn(List<Long> values) {
            addCriterion("SEND_BU_ID not in", values, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdBetween(Long value1, Long value2) {
            addCriterion("SEND_BU_ID between", value1, value2, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andSendBuIdNotBetween(Long value1, Long value2) {
            addCriterion("SEND_BU_ID not between", value1, value2, "sendBuId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("PLATFORM_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("PLATFORM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Long value) {
            addCriterion("PLATFORM_ID =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Long value) {
            addCriterion("PLATFORM_ID <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Long value) {
            addCriterion("PLATFORM_ID >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Long value) {
            addCriterion("PLATFORM_ID <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Long> values) {
            addCriterion("PLATFORM_ID in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Long> values) {
            addCriterion("PLATFORM_ID not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andMobileNoIsNull() {
            addCriterion("MOBILE_NO is null");
            return (Criteria) this;
        }

        public Criteria andMobileNoIsNotNull() {
            addCriterion("MOBILE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andMobileNoEqualTo(String value) {
            addCriterion("MOBILE_NO =", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoNotEqualTo(String value) {
            addCriterion("MOBILE_NO <>", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoGreaterThan(String value) {
            addCriterion("MOBILE_NO >", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoGreaterThanOrEqualTo(String value) {
            addCriterion("MOBILE_NO >=", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoLessThan(String value) {
            addCriterion("MOBILE_NO <", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoLessThanOrEqualTo(String value) {
            addCriterion("MOBILE_NO <=", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoLike(String value) {
            addCriterion("MOBILE_NO like", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoNotLike(String value) {
            addCriterion("MOBILE_NO not like", value, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoIn(List<String> values) {
            addCriterion("MOBILE_NO in", values, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoNotIn(List<String> values) {
            addCriterion("MOBILE_NO not in", values, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoBetween(String value1, String value2) {
            addCriterion("MOBILE_NO between", value1, value2, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andMobileNoNotBetween(String value1, String value2) {
            addCriterion("MOBILE_NO not between", value1, value2, "mobileNo");
            return (Criteria) this;
        }

        public Criteria andSmsNumIsNull() {
            addCriterion("SMS_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSmsNumIsNotNull() {
            addCriterion("SMS_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSmsNumEqualTo(Long value) {
            addCriterion("SMS_NUM =", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumNotEqualTo(Long value) {
            addCriterion("SMS_NUM <>", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumGreaterThan(Long value) {
            addCriterion("SMS_NUM >", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumGreaterThanOrEqualTo(Long value) {
            addCriterion("SMS_NUM >=", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumLessThan(Long value) {
            addCriterion("SMS_NUM <", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumLessThanOrEqualTo(Long value) {
            addCriterion("SMS_NUM <=", value, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumIn(List<Long> values) {
            addCriterion("SMS_NUM in", values, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumNotIn(List<Long> values) {
            addCriterion("SMS_NUM not in", values, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumBetween(Long value1, Long value2) {
            addCriterion("SMS_NUM between", value1, value2, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsNumNotBetween(Long value1, Long value2) {
            addCriterion("SMS_NUM not between", value1, value2, "smsNum");
            return (Criteria) this;
        }

        public Criteria andSmsStatusIsNull() {
            addCriterion("SMS_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andSmsStatusIsNotNull() {
            addCriterion("SMS_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andSmsStatusEqualTo(Short value) {
            addCriterion("SMS_STATUS =", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusNotEqualTo(Short value) {
            addCriterion("SMS_STATUS <>", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusGreaterThan(Short value) {
            addCriterion("SMS_STATUS >", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("SMS_STATUS >=", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusLessThan(Short value) {
            addCriterion("SMS_STATUS <", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusLessThanOrEqualTo(Short value) {
            addCriterion("SMS_STATUS <=", value, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusIn(List<Short> values) {
            addCriterion("SMS_STATUS in", values, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusNotIn(List<Short> values) {
            addCriterion("SMS_STATUS not in", values, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusBetween(Short value1, Short value2) {
            addCriterion("SMS_STATUS between", value1, value2, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsStatusNotBetween(Short value1, Short value2) {
            addCriterion("SMS_STATUS not between", value1, value2, "smsStatus");
            return (Criteria) this;
        }

        public Criteria andSmsTypeIsNull() {
            addCriterion("SMS_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andSmsTypeIsNotNull() {
            addCriterion("SMS_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andSmsTypeEqualTo(String value) {
            addCriterion("SMS_TYPE =", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeNotEqualTo(String value) {
            addCriterion("SMS_TYPE <>", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeGreaterThan(String value) {
            addCriterion("SMS_TYPE >", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SMS_TYPE >=", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeLessThan(String value) {
            addCriterion("SMS_TYPE <", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeLessThanOrEqualTo(String value) {
            addCriterion("SMS_TYPE <=", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeLike(String value) {
            addCriterion("SMS_TYPE like", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeNotLike(String value) {
            addCriterion("SMS_TYPE not like", value, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeIn(List<String> values) {
            addCriterion("SMS_TYPE in", values, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeNotIn(List<String> values) {
            addCriterion("SMS_TYPE not in", values, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeBetween(String value1, String value2) {
            addCriterion("SMS_TYPE between", value1, value2, "smsType");
            return (Criteria) this;
        }

        public Criteria andSmsTypeNotBetween(String value1, String value2) {
            addCriterion("SMS_TYPE not between", value1, value2, "smsType");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeIsNull() {
            addCriterion("PLAN_SEND_TIME is null");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeIsNotNull() {
            addCriterion("PLAN_SEND_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeEqualTo(Date value) {
            addCriterion("PLAN_SEND_TIME =", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeNotEqualTo(Date value) {
            addCriterion("PLAN_SEND_TIME <>", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeGreaterThan(Date value) {
            addCriterion("PLAN_SEND_TIME >", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("PLAN_SEND_TIME >=", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeLessThan(Date value) {
            addCriterion("PLAN_SEND_TIME <", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeLessThanOrEqualTo(Date value) {
            addCriterion("PLAN_SEND_TIME <=", value, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeIn(List<Date> values) {
            addCriterion("PLAN_SEND_TIME in", values, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeNotIn(List<Date> values) {
            addCriterion("PLAN_SEND_TIME not in", values, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeBetween(Date value1, Date value2) {
            addCriterion("PLAN_SEND_TIME between", value1, value2, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andPlanSendTimeNotBetween(Date value1, Date value2) {
            addCriterion("PLAN_SEND_TIME not between", value1, value2, "planSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeIsNull() {
            addCriterion("ACTUAL_SEND_TIME is null");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeIsNotNull() {
            addCriterion("ACTUAL_SEND_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeEqualTo(Date value) {
            addCriterion("ACTUAL_SEND_TIME =", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeNotEqualTo(Date value) {
            addCriterion("ACTUAL_SEND_TIME <>", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeGreaterThan(Date value) {
            addCriterion("ACTUAL_SEND_TIME >", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ACTUAL_SEND_TIME >=", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeLessThan(Date value) {
            addCriterion("ACTUAL_SEND_TIME <", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeLessThanOrEqualTo(Date value) {
            addCriterion("ACTUAL_SEND_TIME <=", value, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeIn(List<Date> values) {
            addCriterion("ACTUAL_SEND_TIME in", values, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeNotIn(List<Date> values) {
            addCriterion("ACTUAL_SEND_TIME not in", values, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeBetween(Date value1, Date value2) {
            addCriterion("ACTUAL_SEND_TIME between", value1, value2, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andActualSendTimeNotBetween(Date value1, Date value2) {
            addCriterion("ACTUAL_SEND_TIME not between", value1, value2, "actualSendTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNull() {
            addCriterion("CANCEL_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNotNull() {
            addCriterion("CANCEL_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeEqualTo(Date value) {
            addCriterion("CANCEL_TIME =", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotEqualTo(Date value) {
            addCriterion("CANCEL_TIME <>", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThan(Date value) {
            addCriterion("CANCEL_TIME >", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CANCEL_TIME >=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThan(Date value) {
            addCriterion("CANCEL_TIME <", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThanOrEqualTo(Date value) {
            addCriterion("CANCEL_TIME <=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIn(List<Date> values) {
            addCriterion("CANCEL_TIME in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotIn(List<Date> values) {
            addCriterion("CANCEL_TIME not in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeBetween(Date value1, Date value2) {
            addCriterion("CANCEL_TIME between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotBetween(Date value1, Date value2) {
            addCriterion("CANCEL_TIME not between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdIsNull() {
            addCriterion("CANCEL_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdIsNotNull() {
            addCriterion("CANCEL_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdEqualTo(Long value) {
            addCriterion("CANCEL_USER_ID =", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdNotEqualTo(Long value) {
            addCriterion("CANCEL_USER_ID <>", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdGreaterThan(Long value) {
            addCriterion("CANCEL_USER_ID >", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CANCEL_USER_ID >=", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdLessThan(Long value) {
            addCriterion("CANCEL_USER_ID <", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CANCEL_USER_ID <=", value, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdIn(List<Long> values) {
            addCriterion("CANCEL_USER_ID in", values, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdNotIn(List<Long> values) {
            addCriterion("CANCEL_USER_ID not in", values, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdBetween(Long value1, Long value2) {
            addCriterion("CANCEL_USER_ID between", value1, value2, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andCancelUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CANCEL_USER_ID not between", value1, value2, "cancelUserId");
            return (Criteria) this;
        }

        public Criteria andReturnTextIsNull() {
            addCriterion("RETURN_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andReturnTextIsNotNull() {
            addCriterion("RETURN_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andReturnTextEqualTo(String value) {
            addCriterion("RETURN_TEXT =", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextNotEqualTo(String value) {
            addCriterion("RETURN_TEXT <>", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextGreaterThan(String value) {
            addCriterion("RETURN_TEXT >", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextGreaterThanOrEqualTo(String value) {
            addCriterion("RETURN_TEXT >=", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextLessThan(String value) {
            addCriterion("RETURN_TEXT <", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextLessThanOrEqualTo(String value) {
            addCriterion("RETURN_TEXT <=", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextLike(String value) {
            addCriterion("RETURN_TEXT like", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextNotLike(String value) {
            addCriterion("RETURN_TEXT not like", value, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextIn(List<String> values) {
            addCriterion("RETURN_TEXT in", values, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextNotIn(List<String> values) {
            addCriterion("RETURN_TEXT not in", values, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextBetween(String value1, String value2) {
            addCriterion("RETURN_TEXT between", value1, value2, "returnText");
            return (Criteria) this;
        }

        public Criteria andReturnTextNotBetween(String value1, String value2) {
            addCriterion("RETURN_TEXT not between", value1, value2, "returnText");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidIsNull() {
            addCriterion("SMS_TEMPLATE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidIsNotNull() {
            addCriterion("SMS_TEMPLATE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidEqualTo(Long value) {
            addCriterion("SMS_TEMPLATE_UKID =", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidNotEqualTo(Long value) {
            addCriterion("SMS_TEMPLATE_UKID <>", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidGreaterThan(Long value) {
            addCriterion("SMS_TEMPLATE_UKID >", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SMS_TEMPLATE_UKID >=", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidLessThan(Long value) {
            addCriterion("SMS_TEMPLATE_UKID <", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidLessThanOrEqualTo(Long value) {
            addCriterion("SMS_TEMPLATE_UKID <=", value, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidIn(List<Long> values) {
            addCriterion("SMS_TEMPLATE_UKID in", values, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidNotIn(List<Long> values) {
            addCriterion("SMS_TEMPLATE_UKID not in", values, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidBetween(Long value1, Long value2) {
            addCriterion("SMS_TEMPLATE_UKID between", value1, value2, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsTemplateUkidNotBetween(Long value1, Long value2) {
            addCriterion("SMS_TEMPLATE_UKID not between", value1, value2, "smsTemplateUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidIsNull() {
            addCriterion("SMS_ACCOUNT_UKID is null");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidIsNotNull() {
            addCriterion("SMS_ACCOUNT_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidEqualTo(Long value) {
            addCriterion("SMS_ACCOUNT_UKID =", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidNotEqualTo(Long value) {
            addCriterion("SMS_ACCOUNT_UKID <>", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidGreaterThan(Long value) {
            addCriterion("SMS_ACCOUNT_UKID >", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SMS_ACCOUNT_UKID >=", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidLessThan(Long value) {
            addCriterion("SMS_ACCOUNT_UKID <", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidLessThanOrEqualTo(Long value) {
            addCriterion("SMS_ACCOUNT_UKID <=", value, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidIn(List<Long> values) {
            addCriterion("SMS_ACCOUNT_UKID in", values, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidNotIn(List<Long> values) {
            addCriterion("SMS_ACCOUNT_UKID not in", values, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidBetween(Long value1, Long value2) {
            addCriterion("SMS_ACCOUNT_UKID between", value1, value2, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andSmsAccountUkidNotBetween(Long value1, Long value2) {
            addCriterion("SMS_ACCOUNT_UKID not between", value1, value2, "smsAccountUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeIsNull() {
            addCriterion("RELATED_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeIsNotNull() {
            addCriterion("RELATED_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeEqualTo(String value) {
            addCriterion("RELATED_TYPE =", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeNotEqualTo(String value) {
            addCriterion("RELATED_TYPE <>", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeGreaterThan(String value) {
            addCriterion("RELATED_TYPE >", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeGreaterThanOrEqualTo(String value) {
            addCriterion("RELATED_TYPE >=", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeLessThan(String value) {
            addCriterion("RELATED_TYPE <", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeLessThanOrEqualTo(String value) {
            addCriterion("RELATED_TYPE <=", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeLike(String value) {
            addCriterion("RELATED_TYPE like", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeNotLike(String value) {
            addCriterion("RELATED_TYPE not like", value, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeIn(List<String> values) {
            addCriterion("RELATED_TYPE in", values, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeNotIn(List<String> values) {
            addCriterion("RELATED_TYPE not in", values, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeBetween(String value1, String value2) {
            addCriterion("RELATED_TYPE between", value1, value2, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedTypeNotBetween(String value1, String value2) {
            addCriterion("RELATED_TYPE not between", value1, value2, "relatedType");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidIsNull() {
            addCriterion("RELATED_ORDER_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidIsNotNull() {
            addCriterion("RELATED_ORDER_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidEqualTo(Long value) {
            addCriterion("RELATED_ORDER_UKID =", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidNotEqualTo(Long value) {
            addCriterion("RELATED_ORDER_UKID <>", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidGreaterThan(Long value) {
            addCriterion("RELATED_ORDER_UKID >", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("RELATED_ORDER_UKID >=", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidLessThan(Long value) {
            addCriterion("RELATED_ORDER_UKID <", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidLessThanOrEqualTo(Long value) {
            addCriterion("RELATED_ORDER_UKID <=", value, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidIn(List<Long> values) {
            addCriterion("RELATED_ORDER_UKID in", values, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidNotIn(List<Long> values) {
            addCriterion("RELATED_ORDER_UKID not in", values, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidBetween(Long value1, Long value2) {
            addCriterion("RELATED_ORDER_UKID between", value1, value2, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andRelatedOrderUkidNotBetween(Long value1, Long value2) {
            addCriterion("RELATED_ORDER_UKID not between", value1, value2, "relatedOrderUkid");
            return (Criteria) this;
        }

        public Criteria andSendContentIsNull() {
            addCriterion("SEND_CONTENT is null");
            return (Criteria) this;
        }

        public Criteria andSendContentIsNotNull() {
            addCriterion("SEND_CONTENT is not null");
            return (Criteria) this;
        }

        public Criteria andSendContentEqualTo(String value) {
            addCriterion("SEND_CONTENT =", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentNotEqualTo(String value) {
            addCriterion("SEND_CONTENT <>", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentGreaterThan(String value) {
            addCriterion("SEND_CONTENT >", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentGreaterThanOrEqualTo(String value) {
            addCriterion("SEND_CONTENT >=", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentLessThan(String value) {
            addCriterion("SEND_CONTENT <", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentLessThanOrEqualTo(String value) {
            addCriterion("SEND_CONTENT <=", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentLike(String value) {
            addCriterion("SEND_CONTENT like", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentNotLike(String value) {
            addCriterion("SEND_CONTENT not like", value, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentIn(List<String> values) {
            addCriterion("SEND_CONTENT in", values, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentNotIn(List<String> values) {
            addCriterion("SEND_CONTENT not in", values, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentBetween(String value1, String value2) {
            addCriterion("SEND_CONTENT between", value1, value2, "sendContent");
            return (Criteria) this;
        }

        public Criteria andSendContentNotBetween(String value1, String value2) {
            addCriterion("SEND_CONTENT not between", value1, value2, "sendContent");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}