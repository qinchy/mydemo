package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionExample;

import java.util.HashMap;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AmAppSubscriptionMapper {
    long countByExample(AmAppSubscriptionExample example);

    int deleteByExample(AmAppSubscriptionExample example);

    int deleteByPrimaryKey(Long subscriptionUkid);

    int insert(AmAppSubscriptionDO record);

    int insertSelective(AmAppSubscriptionDO record);

    List<AmAppSubscriptionDO> selectByExample(AmAppSubscriptionExample example);

    AmAppSubscriptionDO selectByPrimaryKey(Long subscriptionUkid);

    int updateByExampleSelective(@Param("record") AmAppSubscriptionDO record, @Param("example") AmAppSubscriptionExample example);

    int updateByExample(@Param("record") AmAppSubscriptionDO record, @Param("example") AmAppSubscriptionExample example);

    int updateByPrimaryKeySelective(AmAppSubscriptionDO record);

    int updateByPrimaryKey(AmAppSubscriptionDO record);

    List<AmAppSubscriptionDO> getsNeedRefresh();

    public List<AmAppSubscriptionDO> getsBySharding(@Param("map")HashMap params,
                                                  @Param("shardingCount")Integer shardingCount,
                                                  @Param("shardingItem")Integer shardingItem);

}