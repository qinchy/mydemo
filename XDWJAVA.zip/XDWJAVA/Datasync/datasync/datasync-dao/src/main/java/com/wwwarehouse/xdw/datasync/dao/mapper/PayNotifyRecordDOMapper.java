package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDOExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PayNotifyRecordDOMapper {
    long countByExample(PayNotifyRecordDOExample example);

    int deleteByExample(PayNotifyRecordDOExample example);

    int deleteByPrimaryKey(Long payRecordUkid);

    int insert(PayNotifyRecordDO record);

    int insertSelective(PayNotifyRecordDO record);

    List<PayNotifyRecordDO> selectByExample(PayNotifyRecordDOExample example);

    PayNotifyRecordDO selectByPrimaryKey(Long payRecordUkid);

    int updateByExampleSelective(@Param("record") PayNotifyRecordDO record, @Param("example") PayNotifyRecordDOExample example);

    int updateByExample(@Param("record") PayNotifyRecordDO record, @Param("example") PayNotifyRecordDOExample example);

    int updateByPrimaryKeySelective(PayNotifyRecordDO record);

    int updateByPrimaryKey(PayNotifyRecordDO record);
}