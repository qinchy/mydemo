package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeYhdItemDOMapper {
    long countByExample(SeYhdItemDOExample example);

    int deleteByExample(SeYhdItemDOExample example);

    int deleteByPrimaryKey(Short itemUkid);

    int insert(SeYhdItemDO record);

    int insertSelective(SeYhdItemDO record);

    List<SeYhdItemDO> selectByExample(SeYhdItemDOExample example);

    SeYhdItemDO selectByPrimaryKey(Short itemUkid);

    int updateByExampleSelective(@Param("record") SeYhdItemDO record, @Param("example") SeYhdItemDOExample example);

    int updateByExample(@Param("record") SeYhdItemDO record, @Param("example") SeYhdItemDOExample example);

    int updateByPrimaryKeySelective(SeYhdItemDO record);

    int updateByPrimaryKey(SeYhdItemDO record);

    int updateOriginStatus(SeYhdItemDO oItem);

    List<SeYhdItemDO> getsByTradeUkid(Long tradeUkid);

}