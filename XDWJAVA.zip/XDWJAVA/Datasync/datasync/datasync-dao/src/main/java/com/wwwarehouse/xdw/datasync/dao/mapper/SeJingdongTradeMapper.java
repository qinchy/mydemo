package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SeJingdongTradeMapper {
    long countByExample(SeJingdongTradeExample example);

    int deleteByExample(SeJingdongTradeExample example);

    int deleteByPrimaryKey(Long tradeUkid);

    int insert(SeJingdongTradeDO record);

    int insertSelective(SeJingdongTradeDO record);

    List<SeJingdongTradeDO> selectByExample(SeJingdongTradeExample example);

    SeJingdongTradeDO selectByPrimaryKey(Long tradeUkid);

    int updateByExampleSelective(@Param("record") SeJingdongTradeDO record, @Param("example") SeJingdongTradeExample example);

    int updateByExample(@Param("record") SeJingdongTradeDO record, @Param("example") SeJingdongTradeExample example);

    int updateByPrimaryKeySelective(SeJingdongTradeDO record);

    int updateByPrimaryKey(SeJingdongTradeDO record);
}