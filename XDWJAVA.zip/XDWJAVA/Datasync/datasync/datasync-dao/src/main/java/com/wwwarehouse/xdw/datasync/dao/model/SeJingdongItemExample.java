package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeJingdongItemExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeJingdongItemExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andItemUkidIsNull() {
            addCriterion("ITEM_UKID is null");
            return (Criteria) this;
        }

        public Criteria andItemUkidIsNotNull() {
            addCriterion("ITEM_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andItemUkidEqualTo(Long value) {
            addCriterion("ITEM_UKID =", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotEqualTo(Long value) {
            addCriterion("ITEM_UKID <>", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThan(Long value) {
            addCriterion("ITEM_UKID >", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("ITEM_UKID >=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThan(Long value) {
            addCriterion("ITEM_UKID <", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidLessThanOrEqualTo(Long value) {
            addCriterion("ITEM_UKID <=", value, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidIn(List<Long> values) {
            addCriterion("ITEM_UKID in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotIn(List<Long> values) {
            addCriterion("ITEM_UKID not in", values, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidBetween(Long value1, Long value2) {
            addCriterion("ITEM_UKID between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andItemUkidNotBetween(Long value1, Long value2) {
            addCriterion("ITEM_UKID not between", value1, value2, "itemUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Long value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Long value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Long value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Long value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Long> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Long> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNull() {
            addCriterion("ORIGIN_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIsNotNull() {
            addCriterion("ORIGIN_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS =", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <>", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThan(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS >", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS >=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThan(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusLessThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_ORDER_STATUS <=", value, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusIn(List<Long> values) {
            addCriterion("ORIGIN_ORDER_STATUS in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotIn(List<Long> values) {
            addCriterion("ORIGIN_ORDER_STATUS not in", values, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_ORDER_STATUS between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOriginOrderStatusNotBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_ORDER_STATUS not between", value1, value2, "originOrderStatus");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNull() {
            addCriterion("SHOP_PRODUCT_UKID is null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIsNotNull() {
            addCriterion("SHOP_PRODUCT_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID =", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <>", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThan(Long value) {
            addCriterion("SHOP_PRODUCT_UKID >", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID >=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThan(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_PRODUCT_UKID <=", value, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidIn(List<Long> values) {
            addCriterion("SHOP_PRODUCT_UKID in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotIn(List<Long> values) {
            addCriterion("SHOP_PRODUCT_UKID not in", values, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidBetween(Long value1, Long value2) {
            addCriterion("SHOP_PRODUCT_UKID between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andShopProductUkidNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_PRODUCT_UKID not between", value1, value2, "shopProductUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNull() {
            addCriterion("PRODUCT_CODE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIsNotNull() {
            addCriterion("PRODUCT_CODE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID =", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID <>", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThan(Long value) {
            addCriterion("PRODUCT_CODE_UKID >", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID >=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThan(Long value) {
            addCriterion("PRODUCT_CODE_UKID <", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidLessThanOrEqualTo(Long value) {
            addCriterion("PRODUCT_CODE_UKID <=", value, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidIn(List<Long> values) {
            addCriterion("PRODUCT_CODE_UKID in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotIn(List<Long> values) {
            addCriterion("PRODUCT_CODE_UKID not in", values, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_CODE_UKID between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeUkidNotBetween(Long value1, Long value2) {
            addCriterion("PRODUCT_CODE_UKID not between", value1, value2, "productCodeUkid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("PRODUCT_CODE is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("PRODUCT_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("PRODUCT_CODE =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("PRODUCT_CODE <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("PRODUCT_CODE >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("PRODUCT_CODE <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("PRODUCT_CODE like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("PRODUCT_CODE not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("PRODUCT_CODE in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("PRODUCT_CODE not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNull() {
            addCriterion("PRESALE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIsNotNull() {
            addCriterion("PRESALE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andPresaleDateEqualTo(Date value) {
            addCriterion("PRESALE_DATE =", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotEqualTo(Date value) {
            addCriterion("PRESALE_DATE <>", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThan(Date value) {
            addCriterion("PRESALE_DATE >", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateGreaterThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE >=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThan(Date value) {
            addCriterion("PRESALE_DATE <", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateLessThanOrEqualTo(Date value) {
            addCriterion("PRESALE_DATE <=", value, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateIn(List<Date> values) {
            addCriterion("PRESALE_DATE in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotIn(List<Date> values) {
            addCriterion("PRESALE_DATE not in", values, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andPresaleDateNotBetween(Date value1, Date value2) {
            addCriterion("PRESALE_DATE not between", value1, value2, "presaleDate");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNull() {
            addCriterion("WORKSPACE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIsNotNull() {
            addCriterion("WORKSPACE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdEqualTo(String value) {
            addCriterion("WORKSPACE_ID =", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotEqualTo(String value) {
            addCriterion("WORKSPACE_ID <>", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThan(String value) {
            addCriterion("WORKSPACE_ID >", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdGreaterThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID >=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThan(String value) {
            addCriterion("WORKSPACE_ID <", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLessThanOrEqualTo(String value) {
            addCriterion("WORKSPACE_ID <=", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdLike(String value) {
            addCriterion("WORKSPACE_ID like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotLike(String value) {
            addCriterion("WORKSPACE_ID not like", value, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdIn(List<String> values) {
            addCriterion("WORKSPACE_ID in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotIn(List<String> values) {
            addCriterion("WORKSPACE_ID not in", values, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andWorkspaceIdNotBetween(String value1, String value2) {
            addCriterion("WORKSPACE_ID not between", value1, value2, "workspaceId");
            return (Criteria) this;
        }

        public Criteria andSkuIdIsNull() {
            addCriterion("SKU_ID is null");
            return (Criteria) this;
        }

        public Criteria andSkuIdIsNotNull() {
            addCriterion("SKU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSkuIdEqualTo(String value) {
            addCriterion("SKU_ID =", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdNotEqualTo(String value) {
            addCriterion("SKU_ID <>", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdGreaterThan(String value) {
            addCriterion("SKU_ID >", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_ID >=", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdLessThan(String value) {
            addCriterion("SKU_ID <", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdLessThanOrEqualTo(String value) {
            addCriterion("SKU_ID <=", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdLike(String value) {
            addCriterion("SKU_ID like", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdNotLike(String value) {
            addCriterion("SKU_ID not like", value, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdIn(List<String> values) {
            addCriterion("SKU_ID in", values, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdNotIn(List<String> values) {
            addCriterion("SKU_ID not in", values, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdBetween(String value1, String value2) {
            addCriterion("SKU_ID between", value1, value2, "skuId");
            return (Criteria) this;
        }

        public Criteria andSkuIdNotBetween(String value1, String value2) {
            addCriterion("SKU_ID not between", value1, value2, "skuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdIsNull() {
            addCriterion("OUTER_SKU_ID is null");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdIsNotNull() {
            addCriterion("OUTER_SKU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdEqualTo(String value) {
            addCriterion("OUTER_SKU_ID =", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdNotEqualTo(String value) {
            addCriterion("OUTER_SKU_ID <>", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdGreaterThan(String value) {
            addCriterion("OUTER_SKU_ID >", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdGreaterThanOrEqualTo(String value) {
            addCriterion("OUTER_SKU_ID >=", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdLessThan(String value) {
            addCriterion("OUTER_SKU_ID <", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdLessThanOrEqualTo(String value) {
            addCriterion("OUTER_SKU_ID <=", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdLike(String value) {
            addCriterion("OUTER_SKU_ID like", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdNotLike(String value) {
            addCriterion("OUTER_SKU_ID not like", value, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdIn(List<String> values) {
            addCriterion("OUTER_SKU_ID in", values, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdNotIn(List<String> values) {
            addCriterion("OUTER_SKU_ID not in", values, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdBetween(String value1, String value2) {
            addCriterion("OUTER_SKU_ID between", value1, value2, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andOuterSkuIdNotBetween(String value1, String value2) {
            addCriterion("OUTER_SKU_ID not between", value1, value2, "outerSkuId");
            return (Criteria) this;
        }

        public Criteria andSkuNameIsNull() {
            addCriterion("SKU_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSkuNameIsNotNull() {
            addCriterion("SKU_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSkuNameEqualTo(String value) {
            addCriterion("SKU_NAME =", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotEqualTo(String value) {
            addCriterion("SKU_NAME <>", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameGreaterThan(String value) {
            addCriterion("SKU_NAME >", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameGreaterThanOrEqualTo(String value) {
            addCriterion("SKU_NAME >=", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLessThan(String value) {
            addCriterion("SKU_NAME <", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLessThanOrEqualTo(String value) {
            addCriterion("SKU_NAME <=", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameLike(String value) {
            addCriterion("SKU_NAME like", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotLike(String value) {
            addCriterion("SKU_NAME not like", value, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameIn(List<String> values) {
            addCriterion("SKU_NAME in", values, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotIn(List<String> values) {
            addCriterion("SKU_NAME not in", values, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameBetween(String value1, String value2) {
            addCriterion("SKU_NAME between", value1, value2, "skuName");
            return (Criteria) this;
        }

        public Criteria andSkuNameNotBetween(String value1, String value2) {
            addCriterion("SKU_NAME not between", value1, value2, "skuName");
            return (Criteria) this;
        }

        public Criteria andJdPriceIsNull() {
            addCriterion("JD_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andJdPriceIsNotNull() {
            addCriterion("JD_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andJdPriceEqualTo(BigDecimal value) {
            addCriterion("JD_PRICE =", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceNotEqualTo(BigDecimal value) {
            addCriterion("JD_PRICE <>", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceGreaterThan(BigDecimal value) {
            addCriterion("JD_PRICE >", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("JD_PRICE >=", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceLessThan(BigDecimal value) {
            addCriterion("JD_PRICE <", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("JD_PRICE <=", value, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceIn(List<BigDecimal> values) {
            addCriterion("JD_PRICE in", values, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceNotIn(List<BigDecimal> values) {
            addCriterion("JD_PRICE not in", values, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("JD_PRICE between", value1, value2, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andJdPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("JD_PRICE not between", value1, value2, "jdPrice");
            return (Criteria) this;
        }

        public Criteria andGiftPointIsNull() {
            addCriterion("GIFT_POINT is null");
            return (Criteria) this;
        }

        public Criteria andGiftPointIsNotNull() {
            addCriterion("GIFT_POINT is not null");
            return (Criteria) this;
        }

        public Criteria andGiftPointEqualTo(BigDecimal value) {
            addCriterion("GIFT_POINT =", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointNotEqualTo(BigDecimal value) {
            addCriterion("GIFT_POINT <>", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointGreaterThan(BigDecimal value) {
            addCriterion("GIFT_POINT >", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GIFT_POINT >=", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointLessThan(BigDecimal value) {
            addCriterion("GIFT_POINT <", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GIFT_POINT <=", value, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointIn(List<BigDecimal> values) {
            addCriterion("GIFT_POINT in", values, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointNotIn(List<BigDecimal> values) {
            addCriterion("GIFT_POINT not in", values, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GIFT_POINT between", value1, value2, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andGiftPointNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GIFT_POINT not between", value1, value2, "giftPoint");
            return (Criteria) this;
        }

        public Criteria andWareIdIsNull() {
            addCriterion("WARE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWareIdIsNotNull() {
            addCriterion("WARE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWareIdEqualTo(String value) {
            addCriterion("WARE_ID =", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotEqualTo(String value) {
            addCriterion("WARE_ID <>", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdGreaterThan(String value) {
            addCriterion("WARE_ID >", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdGreaterThanOrEqualTo(String value) {
            addCriterion("WARE_ID >=", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLessThan(String value) {
            addCriterion("WARE_ID <", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLessThanOrEqualTo(String value) {
            addCriterion("WARE_ID <=", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdLike(String value) {
            addCriterion("WARE_ID like", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotLike(String value) {
            addCriterion("WARE_ID not like", value, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdIn(List<String> values) {
            addCriterion("WARE_ID in", values, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotIn(List<String> values) {
            addCriterion("WARE_ID not in", values, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdBetween(String value1, String value2) {
            addCriterion("WARE_ID between", value1, value2, "wareId");
            return (Criteria) this;
        }

        public Criteria andWareIdNotBetween(String value1, String value2) {
            addCriterion("WARE_ID not between", value1, value2, "wareId");
            return (Criteria) this;
        }

        public Criteria andItemTotalIsNull() {
            addCriterion("ITEM_TOTAL is null");
            return (Criteria) this;
        }

        public Criteria andItemTotalIsNotNull() {
            addCriterion("ITEM_TOTAL is not null");
            return (Criteria) this;
        }

        public Criteria andItemTotalEqualTo(BigDecimal value) {
            addCriterion("ITEM_TOTAL =", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalNotEqualTo(BigDecimal value) {
            addCriterion("ITEM_TOTAL <>", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalGreaterThan(BigDecimal value) {
            addCriterion("ITEM_TOTAL >", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ITEM_TOTAL >=", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalLessThan(BigDecimal value) {
            addCriterion("ITEM_TOTAL <", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ITEM_TOTAL <=", value, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalIn(List<BigDecimal> values) {
            addCriterion("ITEM_TOTAL in", values, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalNotIn(List<BigDecimal> values) {
            addCriterion("ITEM_TOTAL not in", values, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ITEM_TOTAL between", value1, value2, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andItemTotalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ITEM_TOTAL not between", value1, value2, "itemTotal");
            return (Criteria) this;
        }

        public Criteria andProductNoIsNull() {
            addCriterion("PRODUCT_NO is null");
            return (Criteria) this;
        }

        public Criteria andProductNoIsNotNull() {
            addCriterion("PRODUCT_NO is not null");
            return (Criteria) this;
        }

        public Criteria andProductNoEqualTo(String value) {
            addCriterion("PRODUCT_NO =", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoNotEqualTo(String value) {
            addCriterion("PRODUCT_NO <>", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoGreaterThan(String value) {
            addCriterion("PRODUCT_NO >", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NO >=", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoLessThan(String value) {
            addCriterion("PRODUCT_NO <", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_NO <=", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoLike(String value) {
            addCriterion("PRODUCT_NO like", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoNotLike(String value) {
            addCriterion("PRODUCT_NO not like", value, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoIn(List<String> values) {
            addCriterion("PRODUCT_NO in", values, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoNotIn(List<String> values) {
            addCriterion("PRODUCT_NO not in", values, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoBetween(String value1, String value2) {
            addCriterion("PRODUCT_NO between", value1, value2, "productNo");
            return (Criteria) this;
        }

        public Criteria andProductNoNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_NO not between", value1, value2, "productNo");
            return (Criteria) this;
        }

        public Criteria andCouponPriceIsNull() {
            addCriterion("COUPON_PRICE is null");
            return (Criteria) this;
        }

        public Criteria andCouponPriceIsNotNull() {
            addCriterion("COUPON_PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andCouponPriceEqualTo(BigDecimal value) {
            addCriterion("COUPON_PRICE =", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceNotEqualTo(BigDecimal value) {
            addCriterion("COUPON_PRICE <>", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceGreaterThan(BigDecimal value) {
            addCriterion("COUPON_PRICE >", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_PRICE >=", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceLessThan(BigDecimal value) {
            addCriterion("COUPON_PRICE <", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("COUPON_PRICE <=", value, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceIn(List<BigDecimal> values) {
            addCriterion("COUPON_PRICE in", values, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceNotIn(List<BigDecimal> values) {
            addCriterion("COUPON_PRICE not in", values, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_PRICE between", value1, value2, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COUPON_PRICE not between", value1, value2, "couponPrice");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIsNull() {
            addCriterion("COUPON_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIsNotNull() {
            addCriterion("COUPON_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andCouponTypeEqualTo(String value) {
            addCriterion("COUPON_TYPE =", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotEqualTo(String value) {
            addCriterion("COUPON_TYPE <>", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeGreaterThan(String value) {
            addCriterion("COUPON_TYPE >", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeGreaterThanOrEqualTo(String value) {
            addCriterion("COUPON_TYPE >=", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeLessThan(String value) {
            addCriterion("COUPON_TYPE <", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeLessThanOrEqualTo(String value) {
            addCriterion("COUPON_TYPE <=", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeLike(String value) {
            addCriterion("COUPON_TYPE like", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotLike(String value) {
            addCriterion("COUPON_TYPE not like", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIn(List<String> values) {
            addCriterion("COUPON_TYPE in", values, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotIn(List<String> values) {
            addCriterion("COUPON_TYPE not in", values, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeBetween(String value1, String value2) {
            addCriterion("COUPON_TYPE between", value1, value2, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotBetween(String value1, String value2) {
            addCriterion("COUPON_TYPE not between", value1, value2, "couponType");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}