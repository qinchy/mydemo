package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

/**
* @date 16-10-21 上午11:36
* @tableComment  物流跟踪原始信息表
*/
public class TmLogisticsTrackingOriginalDO extends BaseObject {
    private Long trackingOriginalUkid; // UKID

    private String outSid; // 运单号

    private String logisticsCompanyCode; // 物流公司编码

    private String logisticsCompanyName; // 物流公司名称

    private String logisticsStatus; // 物流状态(字典表, type:LOGISTICS_TRACKING_STATUS)

    private String logisticsInfo; // 物流信息

    private Date logisticsTime; // 物流时间

    private Date createTime; // 创建时间

    private Date updateTime; // 更新时间

    private Long createUserId; // 创建人UKID

    private Long updateUserId; // 更新人UKID

    public Long getTrackingOriginalUkid() {
        return trackingOriginalUkid;
    }

    public void setTrackingOriginalUkid(Long trackingOriginalUkid) {
        this.trackingOriginalUkid = trackingOriginalUkid;
    }

    public String getOutSid() {
        return outSid;
    }

    public void setOutSid(String outSid) {
        this.outSid = outSid == null ? null : outSid.trim();
    }

    public String getLogisticsCompanyCode() {
        return logisticsCompanyCode;
    }

    public void setLogisticsCompanyCode(String logisticsCompanyCode) {
        this.logisticsCompanyCode = logisticsCompanyCode == null ? null : logisticsCompanyCode.trim();
    }

    public String getLogisticsCompanyName() {
        return logisticsCompanyName;
    }

    public void setLogisticsCompanyName(String logisticsCompanyName) {
        this.logisticsCompanyName = logisticsCompanyName == null ? null : logisticsCompanyName.trim();
    }

    public String getLogisticsStatus() {
        return logisticsStatus;
    }

    public void setLogisticsStatus(String logisticsStatus) {
        this.logisticsStatus = logisticsStatus == null ? null : logisticsStatus.trim();
    }

    public String getLogisticsInfo() {
        return logisticsInfo;
    }

    public void setLogisticsInfo(String logisticsInfo) {
        this.logisticsInfo = logisticsInfo == null ? null : logisticsInfo.trim();
    }

    public Date getLogisticsTime() {
        return logisticsTime;
    }

    public void setLogisticsTime(Date logisticsTime) {
        this.logisticsTime = logisticsTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", trackingOriginalUkid=").append(trackingOriginalUkid);
        sb.append(", outSid=").append(outSid);
        sb.append(", logisticsCompanyCode=").append(logisticsCompanyCode);
        sb.append(", logisticsCompanyName=").append(logisticsCompanyName);
        sb.append(", logisticsStatus=").append(logisticsStatus);
        sb.append(", logisticsInfo=").append(logisticsInfo);
        sb.append(", logisticsTime=").append(logisticsTime);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append("]");
        return sb.toString();
    }
}