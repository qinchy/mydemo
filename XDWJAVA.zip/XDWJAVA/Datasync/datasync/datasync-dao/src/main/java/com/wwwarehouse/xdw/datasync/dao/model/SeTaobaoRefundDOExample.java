package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeTaobaoRefundDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeTaobaoRefundDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRefundUkidIsNull() {
            addCriterion("REFUND_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIsNotNull() {
            addCriterion("REFUND_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidEqualTo(Short value) {
            addCriterion("REFUND_UKID =", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotEqualTo(Short value) {
            addCriterion("REFUND_UKID <>", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThan(Short value) {
            addCriterion("REFUND_UKID >", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThanOrEqualTo(Short value) {
            addCriterion("REFUND_UKID >=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThan(Short value) {
            addCriterion("REFUND_UKID <", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThanOrEqualTo(Short value) {
            addCriterion("REFUND_UKID <=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIn(List<Short> values) {
            addCriterion("REFUND_UKID in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotIn(List<Short> values) {
            addCriterion("REFUND_UKID not in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidBetween(Short value1, Short value2) {
            addCriterion("REFUND_UKID between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotBetween(Short value1, Short value2) {
            addCriterion("REFUND_UKID not between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNull() {
            addCriterion("REFUND_ID is null");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNotNull() {
            addCriterion("REFUND_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundIdEqualTo(String value) {
            addCriterion("REFUND_ID =", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotEqualTo(String value) {
            addCriterion("REFUND_ID <>", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThan(String value) {
            addCriterion("REFUND_ID >", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_ID >=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThan(String value) {
            addCriterion("REFUND_ID <", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThanOrEqualTo(String value) {
            addCriterion("REFUND_ID <=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLike(String value) {
            addCriterion("REFUND_ID like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotLike(String value) {
            addCriterion("REFUND_ID not like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdIn(List<String> values) {
            addCriterion("REFUND_ID in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotIn(List<String> values) {
            addCriterion("REFUND_ID not in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdBetween(String value1, String value2) {
            addCriterion("REFUND_ID between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotBetween(String value1, String value2) {
            addCriterion("REFUND_ID not between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Short value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Short value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Short value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Short value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Short value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Short value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Short> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Short> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Short value1, Short value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Short value1, Short value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNull() {
            addCriterion("SHIPPING_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIsNotNull() {
            addCriterion("SHIPPING_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andShippingTypeEqualTo(String value) {
            addCriterion("SHIPPING_TYPE =", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <>", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThan(String value) {
            addCriterion("SHIPPING_TYPE >", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE >=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThan(String value) {
            addCriterion("SHIPPING_TYPE <", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLessThanOrEqualTo(String value) {
            addCriterion("SHIPPING_TYPE <=", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeLike(String value) {
            addCriterion("SHIPPING_TYPE like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotLike(String value) {
            addCriterion("SHIPPING_TYPE not like", value, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeIn(List<String> values) {
            addCriterion("SHIPPING_TYPE in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotIn(List<String> values) {
            addCriterion("SHIPPING_TYPE not in", values, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andShippingTypeNotBetween(String value1, String value2) {
            addCriterion("SHIPPING_TYPE not between", value1, value2, "shippingType");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNull() {
            addCriterion("SUB_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNotNull() {
            addCriterion("SUB_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdEqualTo(String value) {
            addCriterion("SUB_ORDER_ID =", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <>", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThan(String value) {
            addCriterion("SUB_ORDER_ID >", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID >=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThan(String value) {
            addCriterion("SUB_ORDER_ID <", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLike(String value) {
            addCriterion("SUB_ORDER_ID like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotLike(String value) {
            addCriterion("SUB_ORDER_ID not like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIn(List<String> values) {
            addCriterion("SUB_ORDER_ID in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotIn(List<String> values) {
            addCriterion("SUB_ORDER_ID not in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID not between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andAlipayNoIsNull() {
            addCriterion("ALIPAY_NO is null");
            return (Criteria) this;
        }

        public Criteria andAlipayNoIsNotNull() {
            addCriterion("ALIPAY_NO is not null");
            return (Criteria) this;
        }

        public Criteria andAlipayNoEqualTo(String value) {
            addCriterion("ALIPAY_NO =", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoNotEqualTo(String value) {
            addCriterion("ALIPAY_NO <>", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoGreaterThan(String value) {
            addCriterion("ALIPAY_NO >", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoGreaterThanOrEqualTo(String value) {
            addCriterion("ALIPAY_NO >=", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoLessThan(String value) {
            addCriterion("ALIPAY_NO <", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoLessThanOrEqualTo(String value) {
            addCriterion("ALIPAY_NO <=", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoLike(String value) {
            addCriterion("ALIPAY_NO like", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoNotLike(String value) {
            addCriterion("ALIPAY_NO not like", value, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoIn(List<String> values) {
            addCriterion("ALIPAY_NO in", values, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoNotIn(List<String> values) {
            addCriterion("ALIPAY_NO not in", values, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoBetween(String value1, String value2) {
            addCriterion("ALIPAY_NO between", value1, value2, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andAlipayNoNotBetween(String value1, String value2) {
            addCriterion("ALIPAY_NO not between", value1, value2, "alipayNo");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNull() {
            addCriterion("TOTAL_FEE is null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIsNotNull() {
            addCriterion("TOTAL_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andTotalFeeEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE =", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <>", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThan(BigDecimal value) {
            addCriterion("TOTAL_FEE >", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE >=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThan(BigDecimal value) {
            addCriterion("TOTAL_FEE <", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("TOTAL_FEE <=", value, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotIn(List<BigDecimal> values) {
            addCriterion("TOTAL_FEE not in", values, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andTotalFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("TOTAL_FEE not between", value1, value2, "totalFee");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNull() {
            addCriterion("SELLER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andSellerNickIsNotNull() {
            addCriterion("SELLER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andSellerNickEqualTo(String value) {
            addCriterion("SELLER_NICK =", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotEqualTo(String value) {
            addCriterion("SELLER_NICK <>", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThan(String value) {
            addCriterion("SELLER_NICK >", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK >=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThan(String value) {
            addCriterion("SELLER_NICK <", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLessThanOrEqualTo(String value) {
            addCriterion("SELLER_NICK <=", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickLike(String value) {
            addCriterion("SELLER_NICK like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotLike(String value) {
            addCriterion("SELLER_NICK not like", value, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickIn(List<String> values) {
            addCriterion("SELLER_NICK in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotIn(List<String> values) {
            addCriterion("SELLER_NICK not in", values, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickBetween(String value1, String value2) {
            addCriterion("SELLER_NICK between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andSellerNickNotBetween(String value1, String value2) {
            addCriterion("SELLER_NICK not between", value1, value2, "sellerNick");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNull() {
            addCriterion("REFUND_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNotNull() {
            addCriterion("REFUND_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME =", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <>", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThan(Date value) {
            addCriterion("REFUND_CREATE_TIME >", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME >=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThan(Date value) {
            addCriterion("REFUND_CREATE_TIME <", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME not in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME not between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andModifiedIsNull() {
            addCriterion("MODIFIED is null");
            return (Criteria) this;
        }

        public Criteria andModifiedIsNotNull() {
            addCriterion("MODIFIED is not null");
            return (Criteria) this;
        }

        public Criteria andModifiedEqualTo(Date value) {
            addCriterion("MODIFIED =", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotEqualTo(Date value) {
            addCriterion("MODIFIED <>", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedGreaterThan(Date value) {
            addCriterion("MODIFIED >", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFIED >=", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedLessThan(Date value) {
            addCriterion("MODIFIED <", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedLessThanOrEqualTo(Date value) {
            addCriterion("MODIFIED <=", value, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedIn(List<Date> values) {
            addCriterion("MODIFIED in", values, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotIn(List<Date> values) {
            addCriterion("MODIFIED not in", values, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedBetween(Date value1, Date value2) {
            addCriterion("MODIFIED between", value1, value2, "modified");
            return (Criteria) this;
        }

        public Criteria andModifiedNotBetween(Date value1, Date value2) {
            addCriterion("MODIFIED not between", value1, value2, "modified");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNull() {
            addCriterion("ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNotNull() {
            addCriterion("ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusEqualTo(String value) {
            addCriterion("ORDER_STATUS =", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotEqualTo(String value) {
            addCriterion("ORDER_STATUS <>", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThan(String value) {
            addCriterion("ORDER_STATUS >", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS >=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThan(String value) {
            addCriterion("ORDER_STATUS <", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS <=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLike(String value) {
            addCriterion("ORDER_STATUS like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotLike(String value) {
            addCriterion("ORDER_STATUS not like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIn(List<String> values) {
            addCriterion("ORDER_STATUS in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotIn(List<String> values) {
            addCriterion("ORDER_STATUS not in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS not between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(String value) {
            addCriterion("STATUS =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(String value) {
            addCriterion("STATUS <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(String value) {
            addCriterion("STATUS >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(String value) {
            addCriterion("STATUS >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(String value) {
            addCriterion("STATUS <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(String value) {
            addCriterion("STATUS <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(String value) {
            addCriterion("STATUS like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(String value) {
            addCriterion("STATUS not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<String> values) {
            addCriterion("STATUS in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<String> values) {
            addCriterion("STATUS not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(String value1, String value2) {
            addCriterion("STATUS between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(String value1, String value2) {
            addCriterion("STATUS not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNull() {
            addCriterion("GOOD_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNotNull() {
            addCriterion("GOOD_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusEqualTo(String value) {
            addCriterion("GOOD_STATUS =", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotEqualTo(String value) {
            addCriterion("GOOD_STATUS <>", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThan(String value) {
            addCriterion("GOOD_STATUS >", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS >=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThan(String value) {
            addCriterion("GOOD_STATUS <", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS <=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLike(String value) {
            addCriterion("GOOD_STATUS like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotLike(String value) {
            addCriterion("GOOD_STATUS not like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIn(List<String> values) {
            addCriterion("GOOD_STATUS in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotIn(List<String> values) {
            addCriterion("GOOD_STATUS not in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS not between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnIsNull() {
            addCriterion("HAS_GOOD_RETURN is null");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnIsNotNull() {
            addCriterion("HAS_GOOD_RETURN is not null");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnEqualTo(Short value) {
            addCriterion("HAS_GOOD_RETURN =", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnNotEqualTo(Short value) {
            addCriterion("HAS_GOOD_RETURN <>", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnGreaterThan(Short value) {
            addCriterion("HAS_GOOD_RETURN >", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnGreaterThanOrEqualTo(Short value) {
            addCriterion("HAS_GOOD_RETURN >=", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnLessThan(Short value) {
            addCriterion("HAS_GOOD_RETURN <", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnLessThanOrEqualTo(Short value) {
            addCriterion("HAS_GOOD_RETURN <=", value, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnIn(List<Short> values) {
            addCriterion("HAS_GOOD_RETURN in", values, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnNotIn(List<Short> values) {
            addCriterion("HAS_GOOD_RETURN not in", values, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnBetween(Short value1, Short value2) {
            addCriterion("HAS_GOOD_RETURN between", value1, value2, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andHasGoodReturnNotBetween(Short value1, Short value2) {
            addCriterion("HAS_GOOD_RETURN not between", value1, value2, "hasGoodReturn");
            return (Criteria) this;
        }

        public Criteria andRefundFeeIsNull() {
            addCriterion("REFUND_FEE is null");
            return (Criteria) this;
        }

        public Criteria andRefundFeeIsNotNull() {
            addCriterion("REFUND_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andRefundFeeEqualTo(BigDecimal value) {
            addCriterion("REFUND_FEE =", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeNotEqualTo(BigDecimal value) {
            addCriterion("REFUND_FEE <>", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeGreaterThan(BigDecimal value) {
            addCriterion("REFUND_FEE >", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("REFUND_FEE >=", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeLessThan(BigDecimal value) {
            addCriterion("REFUND_FEE <", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("REFUND_FEE <=", value, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeIn(List<BigDecimal> values) {
            addCriterion("REFUND_FEE in", values, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeNotIn(List<BigDecimal> values) {
            addCriterion("REFUND_FEE not in", values, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("REFUND_FEE between", value1, value2, "refundFee");
            return (Criteria) this;
        }

        public Criteria andRefundFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("REFUND_FEE not between", value1, value2, "refundFee");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNull() {
            addCriterion("PAYMENT is null");
            return (Criteria) this;
        }

        public Criteria andPaymentIsNotNull() {
            addCriterion("PAYMENT is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentEqualTo(BigDecimal value) {
            addCriterion("PAYMENT =", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <>", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThan(BigDecimal value) {
            addCriterion("PAYMENT >", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT >=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThan(BigDecimal value) {
            addCriterion("PAYMENT <", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PAYMENT <=", value, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentIn(List<BigDecimal> values) {
            addCriterion("PAYMENT in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotIn(List<BigDecimal> values) {
            addCriterion("PAYMENT not in", values, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andPaymentNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PAYMENT not between", value1, value2, "payment");
            return (Criteria) this;
        }

        public Criteria andReasonIsNull() {
            addCriterion("REASON is null");
            return (Criteria) this;
        }

        public Criteria andReasonIsNotNull() {
            addCriterion("REASON is not null");
            return (Criteria) this;
        }

        public Criteria andReasonEqualTo(String value) {
            addCriterion("REASON =", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonNotEqualTo(String value) {
            addCriterion("REASON <>", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonGreaterThan(String value) {
            addCriterion("REASON >", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonGreaterThanOrEqualTo(String value) {
            addCriterion("REASON >=", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonLessThan(String value) {
            addCriterion("REASON <", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonLessThanOrEqualTo(String value) {
            addCriterion("REASON <=", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonLike(String value) {
            addCriterion("REASON like", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonNotLike(String value) {
            addCriterion("REASON not like", value, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonIn(List<String> values) {
            addCriterion("REASON in", values, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonNotIn(List<String> values) {
            addCriterion("REASON not in", values, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonBetween(String value1, String value2) {
            addCriterion("REASON between", value1, value2, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonNotBetween(String value1, String value2) {
            addCriterion("REASON not between", value1, value2, "reason");
            return (Criteria) this;
        }

        public Criteria andReasonDescIsNull() {
            addCriterion("REASON_DESC is null");
            return (Criteria) this;
        }

        public Criteria andReasonDescIsNotNull() {
            addCriterion("REASON_DESC is not null");
            return (Criteria) this;
        }

        public Criteria andReasonDescEqualTo(String value) {
            addCriterion("REASON_DESC =", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescNotEqualTo(String value) {
            addCriterion("REASON_DESC <>", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescGreaterThan(String value) {
            addCriterion("REASON_DESC >", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescGreaterThanOrEqualTo(String value) {
            addCriterion("REASON_DESC >=", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescLessThan(String value) {
            addCriterion("REASON_DESC <", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescLessThanOrEqualTo(String value) {
            addCriterion("REASON_DESC <=", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescLike(String value) {
            addCriterion("REASON_DESC like", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescNotLike(String value) {
            addCriterion("REASON_DESC not like", value, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescIn(List<String> values) {
            addCriterion("REASON_DESC in", values, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescNotIn(List<String> values) {
            addCriterion("REASON_DESC not in", values, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescBetween(String value1, String value2) {
            addCriterion("REASON_DESC between", value1, value2, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andReasonDescNotBetween(String value1, String value2) {
            addCriterion("REASON_DESC not between", value1, value2, "reasonDesc");
            return (Criteria) this;
        }

        public Criteria andTitleIsNull() {
            addCriterion("TITLE is null");
            return (Criteria) this;
        }

        public Criteria andTitleIsNotNull() {
            addCriterion("TITLE is not null");
            return (Criteria) this;
        }

        public Criteria andTitleEqualTo(String value) {
            addCriterion("TITLE =", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotEqualTo(String value) {
            addCriterion("TITLE <>", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThan(String value) {
            addCriterion("TITLE >", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThanOrEqualTo(String value) {
            addCriterion("TITLE >=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThan(String value) {
            addCriterion("TITLE <", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThanOrEqualTo(String value) {
            addCriterion("TITLE <=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLike(String value) {
            addCriterion("TITLE like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotLike(String value) {
            addCriterion("TITLE not like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleIn(List<String> values) {
            addCriterion("TITLE in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotIn(List<String> values) {
            addCriterion("TITLE not in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleBetween(String value1, String value2) {
            addCriterion("TITLE between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotBetween(String value1, String value2) {
            addCriterion("TITLE not between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("PRICE is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("PRICE is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(BigDecimal value) {
            addCriterion("PRICE =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(BigDecimal value) {
            addCriterion("PRICE <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(BigDecimal value) {
            addCriterion("PRICE >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(BigDecimal value) {
            addCriterion("PRICE <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRICE <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<BigDecimal> values) {
            addCriterion("PRICE in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<BigDecimal> values) {
            addCriterion("PRICE not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRICE not between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andNumIsNull() {
            addCriterion("NUM is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("NUM is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(Short value) {
            addCriterion("NUM =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(Short value) {
            addCriterion("NUM <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(Short value) {
            addCriterion("NUM >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(Short value) {
            addCriterion("NUM >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(Short value) {
            addCriterion("NUM <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(Short value) {
            addCriterion("NUM <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<Short> values) {
            addCriterion("NUM in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<Short> values) {
            addCriterion("NUM not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(Short value1, Short value2) {
            addCriterion("NUM between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(Short value1, Short value2) {
            addCriterion("NUM not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeIsNull() {
            addCriterion("GOOD_RETURN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeIsNotNull() {
            addCriterion("GOOD_RETURN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeEqualTo(Date value) {
            addCriterion("GOOD_RETURN_TIME =", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeNotEqualTo(Date value) {
            addCriterion("GOOD_RETURN_TIME <>", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeGreaterThan(Date value) {
            addCriterion("GOOD_RETURN_TIME >", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("GOOD_RETURN_TIME >=", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeLessThan(Date value) {
            addCriterion("GOOD_RETURN_TIME <", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeLessThanOrEqualTo(Date value) {
            addCriterion("GOOD_RETURN_TIME <=", value, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeIn(List<Date> values) {
            addCriterion("GOOD_RETURN_TIME in", values, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeNotIn(List<Date> values) {
            addCriterion("GOOD_RETURN_TIME not in", values, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeBetween(Date value1, Date value2) {
            addCriterion("GOOD_RETURN_TIME between", value1, value2, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andGoodReturnTimeNotBetween(Date value1, Date value2) {
            addCriterion("GOOD_RETURN_TIME not between", value1, value2, "goodReturnTime");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIsNull() {
            addCriterion("COMPANY_NAME is null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIsNotNull() {
            addCriterion("COMPANY_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameEqualTo(String value) {
            addCriterion("COMPANY_NAME =", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotEqualTo(String value) {
            addCriterion("COMPANY_NAME <>", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameGreaterThan(String value) {
            addCriterion("COMPANY_NAME >", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameGreaterThanOrEqualTo(String value) {
            addCriterion("COMPANY_NAME >=", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLessThan(String value) {
            addCriterion("COMPANY_NAME <", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLessThanOrEqualTo(String value) {
            addCriterion("COMPANY_NAME <=", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLike(String value) {
            addCriterion("COMPANY_NAME like", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotLike(String value) {
            addCriterion("COMPANY_NAME not like", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIn(List<String> values) {
            addCriterion("COMPANY_NAME in", values, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotIn(List<String> values) {
            addCriterion("COMPANY_NAME not in", values, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameBetween(String value1, String value2) {
            addCriterion("COMPANY_NAME between", value1, value2, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotBetween(String value1, String value2) {
            addCriterion("COMPANY_NAME not between", value1, value2, "companyName");
            return (Criteria) this;
        }

        public Criteria andSidIsNull() {
            addCriterion("SID is null");
            return (Criteria) this;
        }

        public Criteria andSidIsNotNull() {
            addCriterion("SID is not null");
            return (Criteria) this;
        }

        public Criteria andSidEqualTo(String value) {
            addCriterion("SID =", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidNotEqualTo(String value) {
            addCriterion("SID <>", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidGreaterThan(String value) {
            addCriterion("SID >", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidGreaterThanOrEqualTo(String value) {
            addCriterion("SID >=", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidLessThan(String value) {
            addCriterion("SID <", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidLessThanOrEqualTo(String value) {
            addCriterion("SID <=", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidLike(String value) {
            addCriterion("SID like", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidNotLike(String value) {
            addCriterion("SID not like", value, "sid");
            return (Criteria) this;
        }

        public Criteria andSidIn(List<String> values) {
            addCriterion("SID in", values, "sid");
            return (Criteria) this;
        }

        public Criteria andSidNotIn(List<String> values) {
            addCriterion("SID not in", values, "sid");
            return (Criteria) this;
        }

        public Criteria andSidBetween(String value1, String value2) {
            addCriterion("SID between", value1, value2, "sid");
            return (Criteria) this;
        }

        public Criteria andSidNotBetween(String value1, String value2) {
            addCriterion("SID not between", value1, value2, "sid");
            return (Criteria) this;
        }

        public Criteria andAddressIsNull() {
            addCriterion("ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andAddressIsNotNull() {
            addCriterion("ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andAddressEqualTo(String value) {
            addCriterion("ADDRESS =", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotEqualTo(String value) {
            addCriterion("ADDRESS <>", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressGreaterThan(String value) {
            addCriterion("ADDRESS >", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressGreaterThanOrEqualTo(String value) {
            addCriterion("ADDRESS >=", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLessThan(String value) {
            addCriterion("ADDRESS <", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLessThanOrEqualTo(String value) {
            addCriterion("ADDRESS <=", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLike(String value) {
            addCriterion("ADDRESS like", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotLike(String value) {
            addCriterion("ADDRESS not like", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressIn(List<String> values) {
            addCriterion("ADDRESS in", values, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotIn(List<String> values) {
            addCriterion("ADDRESS not in", values, "address");
            return (Criteria) this;
        }

        public Criteria andAddressBetween(String value1, String value2) {
            addCriterion("ADDRESS between", value1, value2, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotBetween(String value1, String value2) {
            addCriterion("ADDRESS not between", value1, value2, "address");
            return (Criteria) this;
        }

        public Criteria andNumIidIsNull() {
            addCriterion("NUM_IID is null");
            return (Criteria) this;
        }

        public Criteria andNumIidIsNotNull() {
            addCriterion("NUM_IID is not null");
            return (Criteria) this;
        }

        public Criteria andNumIidEqualTo(Short value) {
            addCriterion("NUM_IID =", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotEqualTo(Short value) {
            addCriterion("NUM_IID <>", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidGreaterThan(Short value) {
            addCriterion("NUM_IID >", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidGreaterThanOrEqualTo(Short value) {
            addCriterion("NUM_IID >=", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidLessThan(Short value) {
            addCriterion("NUM_IID <", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidLessThanOrEqualTo(Short value) {
            addCriterion("NUM_IID <=", value, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidIn(List<Short> values) {
            addCriterion("NUM_IID in", values, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotIn(List<Short> values) {
            addCriterion("NUM_IID not in", values, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidBetween(Short value1, Short value2) {
            addCriterion("NUM_IID between", value1, value2, "numIid");
            return (Criteria) this;
        }

        public Criteria andNumIidNotBetween(Short value1, Short value2) {
            addCriterion("NUM_IID not between", value1, value2, "numIid");
            return (Criteria) this;
        }

        public Criteria andCsStatusIsNull() {
            addCriterion("CS_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andCsStatusIsNotNull() {
            addCriterion("CS_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andCsStatusEqualTo(Short value) {
            addCriterion("CS_STATUS =", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusNotEqualTo(Short value) {
            addCriterion("CS_STATUS <>", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusGreaterThan(Short value) {
            addCriterion("CS_STATUS >", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("CS_STATUS >=", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusLessThan(Short value) {
            addCriterion("CS_STATUS <", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusLessThanOrEqualTo(Short value) {
            addCriterion("CS_STATUS <=", value, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusIn(List<Short> values) {
            addCriterion("CS_STATUS in", values, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusNotIn(List<Short> values) {
            addCriterion("CS_STATUS not in", values, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusBetween(Short value1, Short value2) {
            addCriterion("CS_STATUS between", value1, value2, "csStatus");
            return (Criteria) this;
        }

        public Criteria andCsStatusNotBetween(Short value1, Short value2) {
            addCriterion("CS_STATUS not between", value1, value2, "csStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusIsNull() {
            addCriterion("ADVANCE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusIsNotNull() {
            addCriterion("ADVANCE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusEqualTo(Short value) {
            addCriterion("ADVANCE_STATUS =", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusNotEqualTo(Short value) {
            addCriterion("ADVANCE_STATUS <>", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusGreaterThan(Short value) {
            addCriterion("ADVANCE_STATUS >", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("ADVANCE_STATUS >=", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusLessThan(Short value) {
            addCriterion("ADVANCE_STATUS <", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusLessThanOrEqualTo(Short value) {
            addCriterion("ADVANCE_STATUS <=", value, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusIn(List<Short> values) {
            addCriterion("ADVANCE_STATUS in", values, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusNotIn(List<Short> values) {
            addCriterion("ADVANCE_STATUS not in", values, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusBetween(Short value1, Short value2) {
            addCriterion("ADVANCE_STATUS between", value1, value2, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andAdvanceStatusNotBetween(Short value1, Short value2) {
            addCriterion("ADVANCE_STATUS not between", value1, value2, "advanceStatus");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeIsNull() {
            addCriterion("SPLIT_TAOBAO_FEE is null");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeIsNotNull() {
            addCriterion("SPLIT_TAOBAO_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeEqualTo(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE =", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeNotEqualTo(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE <>", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeGreaterThan(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE >", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE >=", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeLessThan(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE <", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SPLIT_TAOBAO_FEE <=", value, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeIn(List<BigDecimal> values) {
            addCriterion("SPLIT_TAOBAO_FEE in", values, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeNotIn(List<BigDecimal> values) {
            addCriterion("SPLIT_TAOBAO_FEE not in", values, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SPLIT_TAOBAO_FEE between", value1, value2, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitTaobaoFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SPLIT_TAOBAO_FEE not between", value1, value2, "splitTaobaoFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeIsNull() {
            addCriterion("SPLIT_SELLER_FEE is null");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeIsNotNull() {
            addCriterion("SPLIT_SELLER_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeEqualTo(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE =", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeNotEqualTo(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE <>", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeGreaterThan(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE >", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE >=", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeLessThan(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE <", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("SPLIT_SELLER_FEE <=", value, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeIn(List<BigDecimal> values) {
            addCriterion("SPLIT_SELLER_FEE in", values, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeNotIn(List<BigDecimal> values) {
            addCriterion("SPLIT_SELLER_FEE not in", values, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SPLIT_SELLER_FEE between", value1, value2, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andSplitSellerFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("SPLIT_SELLER_FEE not between", value1, value2, "splitSellerFee");
            return (Criteria) this;
        }

        public Criteria andRemindTypeIsNull() {
            addCriterion("REMIND_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andRemindTypeIsNotNull() {
            addCriterion("REMIND_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andRemindTypeEqualTo(Short value) {
            addCriterion("REMIND_TYPE =", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeNotEqualTo(Short value) {
            addCriterion("REMIND_TYPE <>", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeGreaterThan(Short value) {
            addCriterion("REMIND_TYPE >", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeGreaterThanOrEqualTo(Short value) {
            addCriterion("REMIND_TYPE >=", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeLessThan(Short value) {
            addCriterion("REMIND_TYPE <", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeLessThanOrEqualTo(Short value) {
            addCriterion("REMIND_TYPE <=", value, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeIn(List<Short> values) {
            addCriterion("REMIND_TYPE in", values, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeNotIn(List<Short> values) {
            addCriterion("REMIND_TYPE not in", values, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeBetween(Short value1, Short value2) {
            addCriterion("REMIND_TYPE between", value1, value2, "remindType");
            return (Criteria) this;
        }

        public Criteria andRemindTypeNotBetween(Short value1, Short value2) {
            addCriterion("REMIND_TYPE not between", value1, value2, "remindType");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutIsNull() {
            addCriterion("EXIST_TIMEOUT is null");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutIsNotNull() {
            addCriterion("EXIST_TIMEOUT is not null");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutEqualTo(Short value) {
            addCriterion("EXIST_TIMEOUT =", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutNotEqualTo(Short value) {
            addCriterion("EXIST_TIMEOUT <>", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutGreaterThan(Short value) {
            addCriterion("EXIST_TIMEOUT >", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutGreaterThanOrEqualTo(Short value) {
            addCriterion("EXIST_TIMEOUT >=", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutLessThan(Short value) {
            addCriterion("EXIST_TIMEOUT <", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutLessThanOrEqualTo(Short value) {
            addCriterion("EXIST_TIMEOUT <=", value, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutIn(List<Short> values) {
            addCriterion("EXIST_TIMEOUT in", values, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutNotIn(List<Short> values) {
            addCriterion("EXIST_TIMEOUT not in", values, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutBetween(Short value1, Short value2) {
            addCriterion("EXIST_TIMEOUT between", value1, value2, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andExistTimeoutNotBetween(Short value1, Short value2) {
            addCriterion("EXIST_TIMEOUT not between", value1, value2, "existTimeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutIsNull() {
            addCriterion("TIMEOUT is null");
            return (Criteria) this;
        }

        public Criteria andTimeoutIsNotNull() {
            addCriterion("TIMEOUT is not null");
            return (Criteria) this;
        }

        public Criteria andTimeoutEqualTo(Date value) {
            addCriterion("TIMEOUT =", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutNotEqualTo(Date value) {
            addCriterion("TIMEOUT <>", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutGreaterThan(Date value) {
            addCriterion("TIMEOUT >", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutGreaterThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT >=", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutLessThan(Date value) {
            addCriterion("TIMEOUT <", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutLessThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT <=", value, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutIn(List<Date> values) {
            addCriterion("TIMEOUT in", values, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutNotIn(List<Date> values) {
            addCriterion("TIMEOUT not in", values, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT between", value1, value2, "timeout");
            return (Criteria) this;
        }

        public Criteria andTimeoutNotBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT not between", value1, value2, "timeout");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseIsNull() {
            addCriterion("REFUND_PHASE is null");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseIsNotNull() {
            addCriterion("REFUND_PHASE is not null");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseEqualTo(String value) {
            addCriterion("REFUND_PHASE =", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseNotEqualTo(String value) {
            addCriterion("REFUND_PHASE <>", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseGreaterThan(String value) {
            addCriterion("REFUND_PHASE >", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_PHASE >=", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseLessThan(String value) {
            addCriterion("REFUND_PHASE <", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseLessThanOrEqualTo(String value) {
            addCriterion("REFUND_PHASE <=", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseLike(String value) {
            addCriterion("REFUND_PHASE like", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseNotLike(String value) {
            addCriterion("REFUND_PHASE not like", value, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseIn(List<String> values) {
            addCriterion("REFUND_PHASE in", values, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseNotIn(List<String> values) {
            addCriterion("REFUND_PHASE not in", values, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseBetween(String value1, String value2) {
            addCriterion("REFUND_PHASE between", value1, value2, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundPhaseNotBetween(String value1, String value2) {
            addCriterion("REFUND_PHASE not between", value1, value2, "refundPhase");
            return (Criteria) this;
        }

        public Criteria andRefundVersionIsNull() {
            addCriterion("REFUND_VERSION is null");
            return (Criteria) this;
        }

        public Criteria andRefundVersionIsNotNull() {
            addCriterion("REFUND_VERSION is not null");
            return (Criteria) this;
        }

        public Criteria andRefundVersionEqualTo(Short value) {
            addCriterion("REFUND_VERSION =", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionNotEqualTo(Short value) {
            addCriterion("REFUND_VERSION <>", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionGreaterThan(Short value) {
            addCriterion("REFUND_VERSION >", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionGreaterThanOrEqualTo(Short value) {
            addCriterion("REFUND_VERSION >=", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionLessThan(Short value) {
            addCriterion("REFUND_VERSION <", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionLessThanOrEqualTo(Short value) {
            addCriterion("REFUND_VERSION <=", value, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionIn(List<Short> values) {
            addCriterion("REFUND_VERSION in", values, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionNotIn(List<Short> values) {
            addCriterion("REFUND_VERSION not in", values, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionBetween(Short value1, Short value2) {
            addCriterion("REFUND_VERSION between", value1, value2, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andRefundVersionNotBetween(Short value1, Short value2) {
            addCriterion("REFUND_VERSION not between", value1, value2, "refundVersion");
            return (Criteria) this;
        }

        public Criteria andSkuIsNull() {
            addCriterion("SKU is null");
            return (Criteria) this;
        }

        public Criteria andSkuIsNotNull() {
            addCriterion("SKU is not null");
            return (Criteria) this;
        }

        public Criteria andSkuEqualTo(String value) {
            addCriterion("SKU =", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuNotEqualTo(String value) {
            addCriterion("SKU <>", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuGreaterThan(String value) {
            addCriterion("SKU >", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuGreaterThanOrEqualTo(String value) {
            addCriterion("SKU >=", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuLessThan(String value) {
            addCriterion("SKU <", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuLessThanOrEqualTo(String value) {
            addCriterion("SKU <=", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuLike(String value) {
            addCriterion("SKU like", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuNotLike(String value) {
            addCriterion("SKU not like", value, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuIn(List<String> values) {
            addCriterion("SKU in", values, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuNotIn(List<String> values) {
            addCriterion("SKU not in", values, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuBetween(String value1, String value2) {
            addCriterion("SKU between", value1, value2, "sku");
            return (Criteria) this;
        }

        public Criteria andSkuNotBetween(String value1, String value2) {
            addCriterion("SKU not between", value1, value2, "sku");
            return (Criteria) this;
        }

        public Criteria andAttributeIsNull() {
            addCriterion("ATTRIBUTE is null");
            return (Criteria) this;
        }

        public Criteria andAttributeIsNotNull() {
            addCriterion("ATTRIBUTE is not null");
            return (Criteria) this;
        }

        public Criteria andAttributeEqualTo(String value) {
            addCriterion("ATTRIBUTE =", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeNotEqualTo(String value) {
            addCriterion("ATTRIBUTE <>", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeGreaterThan(String value) {
            addCriterion("ATTRIBUTE >", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeGreaterThanOrEqualTo(String value) {
            addCriterion("ATTRIBUTE >=", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeLessThan(String value) {
            addCriterion("ATTRIBUTE <", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeLessThanOrEqualTo(String value) {
            addCriterion("ATTRIBUTE <=", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeLike(String value) {
            addCriterion("ATTRIBUTE like", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeNotLike(String value) {
            addCriterion("ATTRIBUTE not like", value, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeIn(List<String> values) {
            addCriterion("ATTRIBUTE in", values, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeNotIn(List<String> values) {
            addCriterion("ATTRIBUTE not in", values, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeBetween(String value1, String value2) {
            addCriterion("ATTRIBUTE between", value1, value2, "attribute");
            return (Criteria) this;
        }

        public Criteria andAttributeNotBetween(String value1, String value2) {
            addCriterion("ATTRIBUTE not between", value1, value2, "attribute");
            return (Criteria) this;
        }

        public Criteria andOuterIdIsNull() {
            addCriterion("OUTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOuterIdIsNotNull() {
            addCriterion("OUTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOuterIdEqualTo(String value) {
            addCriterion("OUTER_ID =", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotEqualTo(String value) {
            addCriterion("OUTER_ID <>", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdGreaterThan(String value) {
            addCriterion("OUTER_ID >", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdGreaterThanOrEqualTo(String value) {
            addCriterion("OUTER_ID >=", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLessThan(String value) {
            addCriterion("OUTER_ID <", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLessThanOrEqualTo(String value) {
            addCriterion("OUTER_ID <=", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdLike(String value) {
            addCriterion("OUTER_ID like", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotLike(String value) {
            addCriterion("OUTER_ID not like", value, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdIn(List<String> values) {
            addCriterion("OUTER_ID in", values, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotIn(List<String> values) {
            addCriterion("OUTER_ID not in", values, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdBetween(String value1, String value2) {
            addCriterion("OUTER_ID between", value1, value2, "outerId");
            return (Criteria) this;
        }

        public Criteria andOuterIdNotBetween(String value1, String value2) {
            addCriterion("OUTER_ID not between", value1, value2, "outerId");
            return (Criteria) this;
        }

        public Criteria andOperationContraintIsNull() {
            addCriterion("OPERATION_CONTRAINT is null");
            return (Criteria) this;
        }

        public Criteria andOperationContraintIsNotNull() {
            addCriterion("OPERATION_CONTRAINT is not null");
            return (Criteria) this;
        }

        public Criteria andOperationContraintEqualTo(String value) {
            addCriterion("OPERATION_CONTRAINT =", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintNotEqualTo(String value) {
            addCriterion("OPERATION_CONTRAINT <>", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintGreaterThan(String value) {
            addCriterion("OPERATION_CONTRAINT >", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintGreaterThanOrEqualTo(String value) {
            addCriterion("OPERATION_CONTRAINT >=", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintLessThan(String value) {
            addCriterion("OPERATION_CONTRAINT <", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintLessThanOrEqualTo(String value) {
            addCriterion("OPERATION_CONTRAINT <=", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintLike(String value) {
            addCriterion("OPERATION_CONTRAINT like", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintNotLike(String value) {
            addCriterion("OPERATION_CONTRAINT not like", value, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintIn(List<String> values) {
            addCriterion("OPERATION_CONTRAINT in", values, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintNotIn(List<String> values) {
            addCriterion("OPERATION_CONTRAINT not in", values, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintBetween(String value1, String value2) {
            addCriterion("OPERATION_CONTRAINT between", value1, value2, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andOperationContraintNotBetween(String value1, String value2) {
            addCriterion("OPERATION_CONTRAINT not between", value1, value2, "operationContraint");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNull() {
            addCriterion("ISCS_RECEIPT_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNotNull() {
            addCriterion("ISCS_RECEIPT_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS =", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <>", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS not like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS not in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS not between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNull() {
            addCriterion("SERVICE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNotNull() {
            addCriterion("SERVICE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusEqualTo(String value) {
            addCriterion("SERVICE_STATUS =", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotEqualTo(String value) {
            addCriterion("SERVICE_STATUS <>", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThan(String value) {
            addCriterion("SERVICE_STATUS >", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS >=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThan(String value) {
            addCriterion("SERVICE_STATUS <", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS <=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLike(String value) {
            addCriterion("SERVICE_STATUS like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotLike(String value) {
            addCriterion("SERVICE_STATUS not like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIn(List<String> values) {
            addCriterion("SERVICE_STATUS in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotIn(List<String> values) {
            addCriterion("SERVICE_STATUS not in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS not between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNull() {
            addCriterion("PROCESS_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNotNull() {
            addCriterion("PROCESS_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusEqualTo(Short value) {
            addCriterion("PROCESS_STATUS =", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotEqualTo(Short value) {
            addCriterion("PROCESS_STATUS <>", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThan(Short value) {
            addCriterion("PROCESS_STATUS >", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThanOrEqualTo(Short value) {
            addCriterion("PROCESS_STATUS >=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThan(Short value) {
            addCriterion("PROCESS_STATUS <", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThanOrEqualTo(Short value) {
            addCriterion("PROCESS_STATUS <=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIn(List<Short> values) {
            addCriterion("PROCESS_STATUS in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotIn(List<Short> values) {
            addCriterion("PROCESS_STATUS not in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusBetween(Short value1, Short value2) {
            addCriterion("PROCESS_STATUS between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotBetween(Short value1, Short value2) {
            addCriterion("PROCESS_STATUS not between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Short value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Short value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Short value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Short> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Short> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Short value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Short value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Short value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Short> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Short value1, Short value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}