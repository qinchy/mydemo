package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.Date;

public class AmAppkeyDO implements Serializable {
    private Long appUkid;

    private String appName;

    private Long platformId;

    private Long ownerBuId;

    private String appType;

    private Short status;

    private String authType;

    private String apiUrl;

    private String appKey;

    private String appSecret;

    private String dataFormat;

    private String charset;

    private String signMethod;

    private Long dataEncrypt;

    private String dataEncryptType;

    private String authFilePath;

    private String whiteIp;

    private String blackIp;

    private String sysParamFormat;

    private String serviceCode;

    private String platformAccountId;

    private Date createTime;

    private Long createUserId;

    private Date updateTime;

    private Long updateUserId;

    private static final long serialVersionUID = 1L;

    public Long getAppUkid() {
        return appUkid;
    }

    public void setAppUkid(Long appUkid) {
        this.appUkid = appUkid;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Long getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Long platformId) {
        this.platformId = platformId;
    }

    public Long getOwnerBuId() {
        return ownerBuId;
    }

    public void setOwnerBuId(Long ownerBuId) {
        this.ownerBuId = ownerBuId;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getDataFormat() {
        return dataFormat;
    }

    public void setDataFormat(String dataFormat) {
        this.dataFormat = dataFormat;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getSignMethod() {
        return signMethod;
    }

    public void setSignMethod(String signMethod) {
        this.signMethod = signMethod;
    }

    public Long getDataEncrypt() {
        return dataEncrypt;
    }

    public void setDataEncrypt(Long dataEncrypt) {
        this.dataEncrypt = dataEncrypt;
    }

    public String getDataEncryptType() {
        return dataEncryptType;
    }

    public void setDataEncryptType(String dataEncryptType) {
        this.dataEncryptType = dataEncryptType;
    }

    public String getAuthFilePath() {
        return authFilePath;
    }

    public void setAuthFilePath(String authFilePath) {
        this.authFilePath = authFilePath;
    }

    public String getWhiteIp() {
        return whiteIp;
    }

    public void setWhiteIp(String whiteIp) {
        this.whiteIp = whiteIp;
    }

    public String getBlackIp() {
        return blackIp;
    }

    public void setBlackIp(String blackIp) {
        this.blackIp = blackIp;
    }

    public String getSysParamFormat() {
        return sysParamFormat;
    }

    public void setSysParamFormat(String sysParamFormat) {
        this.sysParamFormat = sysParamFormat;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getPlatformAccountId() {
        return platformAccountId;
    }

    public void setPlatformAccountId(String platformAccountId) {
        this.platformAccountId = platformAccountId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", appUkid=").append(appUkid);
        sb.append(", appName=").append(appName);
        sb.append(", platformId=").append(platformId);
        sb.append(", ownerBuId=").append(ownerBuId);
        sb.append(", appType=").append(appType);
        sb.append(", status=").append(status);
        sb.append(", authType=").append(authType);
        sb.append(", apiUrl=").append(apiUrl);
        sb.append(", appKey=").append(appKey);
        sb.append(", appSecret=").append(appSecret);
        sb.append(", dataFormat=").append(dataFormat);
        sb.append(", charset=").append(charset);
        sb.append(", signMethod=").append(signMethod);
        sb.append(", dataEncrypt=").append(dataEncrypt);
        sb.append(", dataEncryptType=").append(dataEncryptType);
        sb.append(", authFilePath=").append(authFilePath);
        sb.append(", whiteIp=").append(whiteIp);
        sb.append(", blackIp=").append(blackIp);
        sb.append(", sysParamFormat=").append(sysParamFormat);
        sb.append(", serviceCode=").append(serviceCode);
        sb.append(", platformAccountId=").append(platformAccountId);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AmAppkeyDO other = (AmAppkeyDO) that;
        return (this.getAppUkid() == null ? other.getAppUkid() == null : this.getAppUkid().equals(other.getAppUkid()))
            && (this.getAppName() == null ? other.getAppName() == null : this.getAppName().equals(other.getAppName()))
            && (this.getPlatformId() == null ? other.getPlatformId() == null : this.getPlatformId().equals(other.getPlatformId()))
            && (this.getOwnerBuId() == null ? other.getOwnerBuId() == null : this.getOwnerBuId().equals(other.getOwnerBuId()))
            && (this.getAppType() == null ? other.getAppType() == null : this.getAppType().equals(other.getAppType()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getAuthType() == null ? other.getAuthType() == null : this.getAuthType().equals(other.getAuthType()))
            && (this.getApiUrl() == null ? other.getApiUrl() == null : this.getApiUrl().equals(other.getApiUrl()))
            && (this.getAppKey() == null ? other.getAppKey() == null : this.getAppKey().equals(other.getAppKey()))
            && (this.getAppSecret() == null ? other.getAppSecret() == null : this.getAppSecret().equals(other.getAppSecret()))
            && (this.getDataFormat() == null ? other.getDataFormat() == null : this.getDataFormat().equals(other.getDataFormat()))
            && (this.getCharset() == null ? other.getCharset() == null : this.getCharset().equals(other.getCharset()))
            && (this.getSignMethod() == null ? other.getSignMethod() == null : this.getSignMethod().equals(other.getSignMethod()))
            && (this.getDataEncrypt() == null ? other.getDataEncrypt() == null : this.getDataEncrypt().equals(other.getDataEncrypt()))
            && (this.getDataEncryptType() == null ? other.getDataEncryptType() == null : this.getDataEncryptType().equals(other.getDataEncryptType()))
            && (this.getAuthFilePath() == null ? other.getAuthFilePath() == null : this.getAuthFilePath().equals(other.getAuthFilePath()))
            && (this.getWhiteIp() == null ? other.getWhiteIp() == null : this.getWhiteIp().equals(other.getWhiteIp()))
            && (this.getBlackIp() == null ? other.getBlackIp() == null : this.getBlackIp().equals(other.getBlackIp()))
            && (this.getSysParamFormat() == null ? other.getSysParamFormat() == null : this.getSysParamFormat().equals(other.getSysParamFormat()))
            && (this.getServiceCode() == null ? other.getServiceCode() == null : this.getServiceCode().equals(other.getServiceCode()))
            && (this.getPlatformAccountId() == null ? other.getPlatformAccountId() == null : this.getPlatformAccountId().equals(other.getPlatformAccountId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getAppUkid() == null) ? 0 : getAppUkid().hashCode());
        result = prime * result + ((getAppName() == null) ? 0 : getAppName().hashCode());
        result = prime * result + ((getPlatformId() == null) ? 0 : getPlatformId().hashCode());
        result = prime * result + ((getOwnerBuId() == null) ? 0 : getOwnerBuId().hashCode());
        result = prime * result + ((getAppType() == null) ? 0 : getAppType().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getAuthType() == null) ? 0 : getAuthType().hashCode());
        result = prime * result + ((getApiUrl() == null) ? 0 : getApiUrl().hashCode());
        result = prime * result + ((getAppKey() == null) ? 0 : getAppKey().hashCode());
        result = prime * result + ((getAppSecret() == null) ? 0 : getAppSecret().hashCode());
        result = prime * result + ((getDataFormat() == null) ? 0 : getDataFormat().hashCode());
        result = prime * result + ((getCharset() == null) ? 0 : getCharset().hashCode());
        result = prime * result + ((getSignMethod() == null) ? 0 : getSignMethod().hashCode());
        result = prime * result + ((getDataEncrypt() == null) ? 0 : getDataEncrypt().hashCode());
        result = prime * result + ((getDataEncryptType() == null) ? 0 : getDataEncryptType().hashCode());
        result = prime * result + ((getAuthFilePath() == null) ? 0 : getAuthFilePath().hashCode());
        result = prime * result + ((getWhiteIp() == null) ? 0 : getWhiteIp().hashCode());
        result = prime * result + ((getBlackIp() == null) ? 0 : getBlackIp().hashCode());
        result = prime * result + ((getSysParamFormat() == null) ? 0 : getSysParamFormat().hashCode());
        result = prime * result + ((getServiceCode() == null) ? 0 : getServiceCode().hashCode());
        result = prime * result + ((getPlatformAccountId() == null) ? 0 : getPlatformAccountId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        return result;
    }
}