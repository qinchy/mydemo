package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeYhdRefundDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeYhdRefundDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRefundUkidIsNull() {
            addCriterion("REFUND_UKID is null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIsNotNull() {
            addCriterion("REFUND_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundUkidEqualTo(Long value) {
            addCriterion("REFUND_UKID =", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotEqualTo(Long value) {
            addCriterion("REFUND_UKID <>", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThan(Long value) {
            addCriterion("REFUND_UKID >", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID >=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThan(Long value) {
            addCriterion("REFUND_UKID <", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidLessThanOrEqualTo(Long value) {
            addCriterion("REFUND_UKID <=", value, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidIn(List<Long> values) {
            addCriterion("REFUND_UKID in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotIn(List<Long> values) {
            addCriterion("REFUND_UKID not in", values, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andRefundUkidNotBetween(Long value1, Long value2) {
            addCriterion("REFUND_UKID not between", value1, value2, "refundUkid");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Long value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Long value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Long value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Long value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Long> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Long> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNull() {
            addCriterion("REFUND_ID is null");
            return (Criteria) this;
        }

        public Criteria andRefundIdIsNotNull() {
            addCriterion("REFUND_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRefundIdEqualTo(String value) {
            addCriterion("REFUND_ID =", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotEqualTo(String value) {
            addCriterion("REFUND_ID <>", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThan(String value) {
            addCriterion("REFUND_ID >", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_ID >=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThan(String value) {
            addCriterion("REFUND_ID <", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLessThanOrEqualTo(String value) {
            addCriterion("REFUND_ID <=", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdLike(String value) {
            addCriterion("REFUND_ID like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotLike(String value) {
            addCriterion("REFUND_ID not like", value, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdIn(List<String> values) {
            addCriterion("REFUND_ID in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotIn(List<String> values) {
            addCriterion("REFUND_ID not in", values, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdBetween(String value1, String value2) {
            addCriterion("REFUND_ID between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andRefundIdNotBetween(String value1, String value2) {
            addCriterion("REFUND_ID not between", value1, value2, "refundId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIsNull() {
            addCriterion("ORDER_CODE is null");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIsNotNull() {
            addCriterion("ORDER_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCodeEqualTo(String value) {
            addCriterion("ORDER_CODE =", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotEqualTo(String value) {
            addCriterion("ORDER_CODE <>", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeGreaterThan(String value) {
            addCriterion("ORDER_CODE >", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_CODE >=", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLessThan(String value) {
            addCriterion("ORDER_CODE <", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLessThanOrEqualTo(String value) {
            addCriterion("ORDER_CODE <=", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLike(String value) {
            addCriterion("ORDER_CODE like", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotLike(String value) {
            addCriterion("ORDER_CODE not like", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIn(List<String> values) {
            addCriterion("ORDER_CODE in", values, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotIn(List<String> values) {
            addCriterion("ORDER_CODE not in", values, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeBetween(String value1, String value2) {
            addCriterion("ORDER_CODE between", value1, value2, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotBetween(String value1, String value2) {
            addCriterion("ORDER_CODE not between", value1, value2, "orderCode");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIsNull() {
            addCriterion("REFUND_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIsNotNull() {
            addCriterion("REFUND_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andRefundStatusEqualTo(String value) {
            addCriterion("REFUND_STATUS =", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotEqualTo(String value) {
            addCriterion("REFUND_STATUS <>", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusGreaterThan(String value) {
            addCriterion("REFUND_STATUS >", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_STATUS >=", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLessThan(String value) {
            addCriterion("REFUND_STATUS <", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLessThanOrEqualTo(String value) {
            addCriterion("REFUND_STATUS <=", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusLike(String value) {
            addCriterion("REFUND_STATUS like", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotLike(String value) {
            addCriterion("REFUND_STATUS not like", value, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusIn(List<String> values) {
            addCriterion("REFUND_STATUS in", values, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotIn(List<String> values) {
            addCriterion("REFUND_STATUS not in", values, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusBetween(String value1, String value2) {
            addCriterion("REFUND_STATUS between", value1, value2, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andRefundStatusNotBetween(String value1, String value2) {
            addCriterion("REFUND_STATUS not between", value1, value2, "refundStatus");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeIsNull() {
            addCriterion("DELIVERY_FEE is null");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeIsNotNull() {
            addCriterion("DELIVERY_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE =", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeNotEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE <>", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeGreaterThan(BigDecimal value) {
            addCriterion("DELIVERY_FEE >", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE >=", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeLessThan(BigDecimal value) {
            addCriterion("DELIVERY_FEE <", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DELIVERY_FEE <=", value, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeIn(List<BigDecimal> values) {
            addCriterion("DELIVERY_FEE in", values, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeNotIn(List<BigDecimal> values) {
            addCriterion("DELIVERY_FEE not in", values, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DELIVERY_FEE between", value1, value2, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andDeliveryFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DELIVERY_FEE not between", value1, value2, "deliveryFee");
            return (Criteria) this;
        }

        public Criteria andProductAmountIsNull() {
            addCriterion("PRODUCT_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andProductAmountIsNotNull() {
            addCriterion("PRODUCT_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andProductAmountEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT =", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <>", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountGreaterThan(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT >", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT >=", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountLessThan(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <=", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_AMOUNT in", values, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_AMOUNT not in", values, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_AMOUNT between", value1, value2, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_AMOUNT not between", value1, value2, "productAmount");
            return (Criteria) this;
        }

        public Criteria andContactNameIsNull() {
            addCriterion("CONTACT_NAME is null");
            return (Criteria) this;
        }

        public Criteria andContactNameIsNotNull() {
            addCriterion("CONTACT_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andContactNameEqualTo(String value) {
            addCriterion("CONTACT_NAME =", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameNotEqualTo(String value) {
            addCriterion("CONTACT_NAME <>", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameGreaterThan(String value) {
            addCriterion("CONTACT_NAME >", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameGreaterThanOrEqualTo(String value) {
            addCriterion("CONTACT_NAME >=", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameLessThan(String value) {
            addCriterion("CONTACT_NAME <", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameLessThanOrEqualTo(String value) {
            addCriterion("CONTACT_NAME <=", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameLike(String value) {
            addCriterion("CONTACT_NAME like", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameNotLike(String value) {
            addCriterion("CONTACT_NAME not like", value, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameIn(List<String> values) {
            addCriterion("CONTACT_NAME in", values, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameNotIn(List<String> values) {
            addCriterion("CONTACT_NAME not in", values, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameBetween(String value1, String value2) {
            addCriterion("CONTACT_NAME between", value1, value2, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactNameNotBetween(String value1, String value2) {
            addCriterion("CONTACT_NAME not between", value1, value2, "contactName");
            return (Criteria) this;
        }

        public Criteria andContactPhoneIsNull() {
            addCriterion("CONTACT_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andContactPhoneIsNotNull() {
            addCriterion("CONTACT_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andContactPhoneEqualTo(String value) {
            addCriterion("CONTACT_PHONE =", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneNotEqualTo(String value) {
            addCriterion("CONTACT_PHONE <>", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneGreaterThan(String value) {
            addCriterion("CONTACT_PHONE >", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("CONTACT_PHONE >=", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneLessThan(String value) {
            addCriterion("CONTACT_PHONE <", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneLessThanOrEqualTo(String value) {
            addCriterion("CONTACT_PHONE <=", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneLike(String value) {
            addCriterion("CONTACT_PHONE like", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneNotLike(String value) {
            addCriterion("CONTACT_PHONE not like", value, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneIn(List<String> values) {
            addCriterion("CONTACT_PHONE in", values, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneNotIn(List<String> values) {
            addCriterion("CONTACT_PHONE not in", values, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneBetween(String value1, String value2) {
            addCriterion("CONTACT_PHONE between", value1, value2, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andContactPhoneNotBetween(String value1, String value2) {
            addCriterion("CONTACT_PHONE not between", value1, value2, "contactPhone");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressIsNull() {
            addCriterion("SEND_BACK_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressIsNotNull() {
            addCriterion("SEND_BACK_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressEqualTo(String value) {
            addCriterion("SEND_BACK_ADDRESS =", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressNotEqualTo(String value) {
            addCriterion("SEND_BACK_ADDRESS <>", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressGreaterThan(String value) {
            addCriterion("SEND_BACK_ADDRESS >", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressGreaterThanOrEqualTo(String value) {
            addCriterion("SEND_BACK_ADDRESS >=", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressLessThan(String value) {
            addCriterion("SEND_BACK_ADDRESS <", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressLessThanOrEqualTo(String value) {
            addCriterion("SEND_BACK_ADDRESS <=", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressLike(String value) {
            addCriterion("SEND_BACK_ADDRESS like", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressNotLike(String value) {
            addCriterion("SEND_BACK_ADDRESS not like", value, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressIn(List<String> values) {
            addCriterion("SEND_BACK_ADDRESS in", values, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressNotIn(List<String> values) {
            addCriterion("SEND_BACK_ADDRESS not in", values, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressBetween(String value1, String value2) {
            addCriterion("SEND_BACK_ADDRESS between", value1, value2, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andSendBackAddressNotBetween(String value1, String value2) {
            addCriterion("SEND_BACK_ADDRESS not between", value1, value2, "sendBackAddress");
            return (Criteria) this;
        }

        public Criteria andReasonMsgIsNull() {
            addCriterion("REASON_MSG is null");
            return (Criteria) this;
        }

        public Criteria andReasonMsgIsNotNull() {
            addCriterion("REASON_MSG is not null");
            return (Criteria) this;
        }

        public Criteria andReasonMsgEqualTo(String value) {
            addCriterion("REASON_MSG =", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgNotEqualTo(String value) {
            addCriterion("REASON_MSG <>", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgGreaterThan(String value) {
            addCriterion("REASON_MSG >", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgGreaterThanOrEqualTo(String value) {
            addCriterion("REASON_MSG >=", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgLessThan(String value) {
            addCriterion("REASON_MSG <", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgLessThanOrEqualTo(String value) {
            addCriterion("REASON_MSG <=", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgLike(String value) {
            addCriterion("REASON_MSG like", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgNotLike(String value) {
            addCriterion("REASON_MSG not like", value, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgIn(List<String> values) {
            addCriterion("REASON_MSG in", values, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgNotIn(List<String> values) {
            addCriterion("REASON_MSG not in", values, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgBetween(String value1, String value2) {
            addCriterion("REASON_MSG between", value1, value2, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andReasonMsgNotBetween(String value1, String value2) {
            addCriterion("REASON_MSG not between", value1, value2, "reasonMsg");
            return (Criteria) this;
        }

        public Criteria andRefundProblemIsNull() {
            addCriterion("REFUND_PROBLEM is null");
            return (Criteria) this;
        }

        public Criteria andRefundProblemIsNotNull() {
            addCriterion("REFUND_PROBLEM is not null");
            return (Criteria) this;
        }

        public Criteria andRefundProblemEqualTo(String value) {
            addCriterion("REFUND_PROBLEM =", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemNotEqualTo(String value) {
            addCriterion("REFUND_PROBLEM <>", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemGreaterThan(String value) {
            addCriterion("REFUND_PROBLEM >", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemGreaterThanOrEqualTo(String value) {
            addCriterion("REFUND_PROBLEM >=", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemLessThan(String value) {
            addCriterion("REFUND_PROBLEM <", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemLessThanOrEqualTo(String value) {
            addCriterion("REFUND_PROBLEM <=", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemLike(String value) {
            addCriterion("REFUND_PROBLEM like", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemNotLike(String value) {
            addCriterion("REFUND_PROBLEM not like", value, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemIn(List<String> values) {
            addCriterion("REFUND_PROBLEM in", values, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemNotIn(List<String> values) {
            addCriterion("REFUND_PROBLEM not in", values, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemBetween(String value1, String value2) {
            addCriterion("REFUND_PROBLEM between", value1, value2, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andRefundProblemNotBetween(String value1, String value2) {
            addCriterion("REFUND_PROBLEM not between", value1, value2, "refundProblem");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsIsNull() {
            addCriterion("EVIDENCE_PIC_URLS is null");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsIsNotNull() {
            addCriterion("EVIDENCE_PIC_URLS is not null");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsEqualTo(String value) {
            addCriterion("EVIDENCE_PIC_URLS =", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsNotEqualTo(String value) {
            addCriterion("EVIDENCE_PIC_URLS <>", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsGreaterThan(String value) {
            addCriterion("EVIDENCE_PIC_URLS >", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsGreaterThanOrEqualTo(String value) {
            addCriterion("EVIDENCE_PIC_URLS >=", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsLessThan(String value) {
            addCriterion("EVIDENCE_PIC_URLS <", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsLessThanOrEqualTo(String value) {
            addCriterion("EVIDENCE_PIC_URLS <=", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsLike(String value) {
            addCriterion("EVIDENCE_PIC_URLS like", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsNotLike(String value) {
            addCriterion("EVIDENCE_PIC_URLS not like", value, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsIn(List<String> values) {
            addCriterion("EVIDENCE_PIC_URLS in", values, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsNotIn(List<String> values) {
            addCriterion("EVIDENCE_PIC_URLS not in", values, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsBetween(String value1, String value2) {
            addCriterion("EVIDENCE_PIC_URLS between", value1, value2, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andEvidencePicUrlsNotBetween(String value1, String value2) {
            addCriterion("EVIDENCE_PIC_URLS not between", value1, value2, "evidencePicUrls");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNull() {
            addCriterion("RECEIVER_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNotNull() {
            addCriterion("RECEIVER_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneEqualTo(String value) {
            addCriterion("RECEIVER_PHONE =", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <>", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThan(String value) {
            addCriterion("RECEIVER_PHONE >", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE >=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThan(String value) {
            addCriterion("RECEIVER_PHONE <", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLike(String value) {
            addCriterion("RECEIVER_PHONE like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotLike(String value) {
            addCriterion("RECEIVER_PHONE not like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIn(List<String> values) {
            addCriterion("RECEIVER_PHONE in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotIn(List<String> values) {
            addCriterion("RECEIVER_PHONE not in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE not between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNull() {
            addCriterion("RECEIVER_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNotNull() {
            addCriterion("RECEIVER_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS =", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <>", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThan(String value) {
            addCriterion("RECEIVER_ADDRESS >", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS >=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThan(String value) {
            addCriterion("RECEIVER_ADDRESS <", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLike(String value) {
            addCriterion("RECEIVER_ADDRESS like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotLike(String value) {
            addCriterion("RECEIVER_ADDRESS not like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS not in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS not between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNull() {
            addCriterion("REFUND_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIsNotNull() {
            addCriterion("REFUND_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME =", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <>", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThan(Date value) {
            addCriterion("REFUND_CREATE_TIME >", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME >=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThan(Date value) {
            addCriterion("REFUND_CREATE_TIME <", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("REFUND_CREATE_TIME <=", value, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotIn(List<Date> values) {
            addCriterion("REFUND_CREATE_TIME not in", values, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andRefundCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("REFUND_CREATE_TIME not between", value1, value2, "refundCreateTime");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkIsNull() {
            addCriterion("MERCHANT_MARK is null");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkIsNotNull() {
            addCriterion("MERCHANT_MARK is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkEqualTo(String value) {
            addCriterion("MERCHANT_MARK =", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkNotEqualTo(String value) {
            addCriterion("MERCHANT_MARK <>", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkGreaterThan(String value) {
            addCriterion("MERCHANT_MARK >", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkGreaterThanOrEqualTo(String value) {
            addCriterion("MERCHANT_MARK >=", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkLessThan(String value) {
            addCriterion("MERCHANT_MARK <", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkLessThanOrEqualTo(String value) {
            addCriterion("MERCHANT_MARK <=", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkLike(String value) {
            addCriterion("MERCHANT_MARK like", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkNotLike(String value) {
            addCriterion("MERCHANT_MARK not like", value, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkIn(List<String> values) {
            addCriterion("MERCHANT_MARK in", values, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkNotIn(List<String> values) {
            addCriterion("MERCHANT_MARK not in", values, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkBetween(String value1, String value2) {
            addCriterion("MERCHANT_MARK between", value1, value2, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantMarkNotBetween(String value1, String value2) {
            addCriterion("MERCHANT_MARK not between", value1, value2, "merchantMark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkIsNull() {
            addCriterion("MERCHANT_REMARK is null");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkIsNotNull() {
            addCriterion("MERCHANT_REMARK is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkEqualTo(String value) {
            addCriterion("MERCHANT_REMARK =", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkNotEqualTo(String value) {
            addCriterion("MERCHANT_REMARK <>", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkGreaterThan(String value) {
            addCriterion("MERCHANT_REMARK >", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("MERCHANT_REMARK >=", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkLessThan(String value) {
            addCriterion("MERCHANT_REMARK <", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkLessThanOrEqualTo(String value) {
            addCriterion("MERCHANT_REMARK <=", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkLike(String value) {
            addCriterion("MERCHANT_REMARK like", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkNotLike(String value) {
            addCriterion("MERCHANT_REMARK not like", value, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkIn(List<String> values) {
            addCriterion("MERCHANT_REMARK in", values, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkNotIn(List<String> values) {
            addCriterion("MERCHANT_REMARK not in", values, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkBetween(String value1, String value2) {
            addCriterion("MERCHANT_REMARK between", value1, value2, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andMerchantRemarkNotBetween(String value1, String value2) {
            addCriterion("MERCHANT_REMARK not between", value1, value2, "merchantRemark");
            return (Criteria) this;
        }

        public Criteria andApproveDateIsNull() {
            addCriterion("APPROVE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andApproveDateIsNotNull() {
            addCriterion("APPROVE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andApproveDateEqualTo(Date value) {
            addCriterion("APPROVE_DATE =", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateNotEqualTo(Date value) {
            addCriterion("APPROVE_DATE <>", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateGreaterThan(Date value) {
            addCriterion("APPROVE_DATE >", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateGreaterThanOrEqualTo(Date value) {
            addCriterion("APPROVE_DATE >=", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateLessThan(Date value) {
            addCriterion("APPROVE_DATE <", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateLessThanOrEqualTo(Date value) {
            addCriterion("APPROVE_DATE <=", value, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateIn(List<Date> values) {
            addCriterion("APPROVE_DATE in", values, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateNotIn(List<Date> values) {
            addCriterion("APPROVE_DATE not in", values, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateBetween(Date value1, Date value2) {
            addCriterion("APPROVE_DATE between", value1, value2, "approveDate");
            return (Criteria) this;
        }

        public Criteria andApproveDateNotBetween(Date value1, Date value2) {
            addCriterion("APPROVE_DATE not between", value1, value2, "approveDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateIsNull() {
            addCriterion("SEND_BACK_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSendBackDateIsNotNull() {
            addCriterion("SEND_BACK_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSendBackDateEqualTo(Date value) {
            addCriterion("SEND_BACK_DATE =", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateNotEqualTo(Date value) {
            addCriterion("SEND_BACK_DATE <>", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateGreaterThan(Date value) {
            addCriterion("SEND_BACK_DATE >", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateGreaterThanOrEqualTo(Date value) {
            addCriterion("SEND_BACK_DATE >=", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateLessThan(Date value) {
            addCriterion("SEND_BACK_DATE <", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateLessThanOrEqualTo(Date value) {
            addCriterion("SEND_BACK_DATE <=", value, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateIn(List<Date> values) {
            addCriterion("SEND_BACK_DATE in", values, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateNotIn(List<Date> values) {
            addCriterion("SEND_BACK_DATE not in", values, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateBetween(Date value1, Date value2) {
            addCriterion("SEND_BACK_DATE between", value1, value2, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andSendBackDateNotBetween(Date value1, Date value2) {
            addCriterion("SEND_BACK_DATE not between", value1, value2, "sendBackDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateIsNull() {
            addCriterion("REJECT_DATE is null");
            return (Criteria) this;
        }

        public Criteria andRejectDateIsNotNull() {
            addCriterion("REJECT_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andRejectDateEqualTo(Date value) {
            addCriterion("REJECT_DATE =", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateNotEqualTo(Date value) {
            addCriterion("REJECT_DATE <>", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateGreaterThan(Date value) {
            addCriterion("REJECT_DATE >", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateGreaterThanOrEqualTo(Date value) {
            addCriterion("REJECT_DATE >=", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateLessThan(Date value) {
            addCriterion("REJECT_DATE <", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateLessThanOrEqualTo(Date value) {
            addCriterion("REJECT_DATE <=", value, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateIn(List<Date> values) {
            addCriterion("REJECT_DATE in", values, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateNotIn(List<Date> values) {
            addCriterion("REJECT_DATE not in", values, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateBetween(Date value1, Date value2) {
            addCriterion("REJECT_DATE between", value1, value2, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andRejectDateNotBetween(Date value1, Date value2) {
            addCriterion("REJECT_DATE not between", value1, value2, "rejectDate");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNull() {
            addCriterion("CANCEL_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNotNull() {
            addCriterion("CANCEL_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeEqualTo(Date value) {
            addCriterion("CANCEL_TIME =", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotEqualTo(Date value) {
            addCriterion("CANCEL_TIME <>", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThan(Date value) {
            addCriterion("CANCEL_TIME >", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CANCEL_TIME >=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThan(Date value) {
            addCriterion("CANCEL_TIME <", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThanOrEqualTo(Date value) {
            addCriterion("CANCEL_TIME <=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIn(List<Date> values) {
            addCriterion("CANCEL_TIME in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotIn(List<Date> values) {
            addCriterion("CANCEL_TIME not in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeBetween(Date value1, Date value2) {
            addCriterion("CANCEL_TIME between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotBetween(Date value1, Date value2) {
            addCriterion("CANCEL_TIME not between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andExpressNameIsNull() {
            addCriterion("EXPRESS_NAME is null");
            return (Criteria) this;
        }

        public Criteria andExpressNameIsNotNull() {
            addCriterion("EXPRESS_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andExpressNameEqualTo(String value) {
            addCriterion("EXPRESS_NAME =", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameNotEqualTo(String value) {
            addCriterion("EXPRESS_NAME <>", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameGreaterThan(String value) {
            addCriterion("EXPRESS_NAME >", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameGreaterThanOrEqualTo(String value) {
            addCriterion("EXPRESS_NAME >=", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameLessThan(String value) {
            addCriterion("EXPRESS_NAME <", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameLessThanOrEqualTo(String value) {
            addCriterion("EXPRESS_NAME <=", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameLike(String value) {
            addCriterion("EXPRESS_NAME like", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameNotLike(String value) {
            addCriterion("EXPRESS_NAME not like", value, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameIn(List<String> values) {
            addCriterion("EXPRESS_NAME in", values, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameNotIn(List<String> values) {
            addCriterion("EXPRESS_NAME not in", values, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameBetween(String value1, String value2) {
            addCriterion("EXPRESS_NAME between", value1, value2, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNameNotBetween(String value1, String value2) {
            addCriterion("EXPRESS_NAME not between", value1, value2, "expressName");
            return (Criteria) this;
        }

        public Criteria andExpressNbrIsNull() {
            addCriterion("EXPRESS_NBR is null");
            return (Criteria) this;
        }

        public Criteria andExpressNbrIsNotNull() {
            addCriterion("EXPRESS_NBR is not null");
            return (Criteria) this;
        }

        public Criteria andExpressNbrEqualTo(String value) {
            addCriterion("EXPRESS_NBR =", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrNotEqualTo(String value) {
            addCriterion("EXPRESS_NBR <>", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrGreaterThan(String value) {
            addCriterion("EXPRESS_NBR >", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrGreaterThanOrEqualTo(String value) {
            addCriterion("EXPRESS_NBR >=", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrLessThan(String value) {
            addCriterion("EXPRESS_NBR <", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrLessThanOrEqualTo(String value) {
            addCriterion("EXPRESS_NBR <=", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrLike(String value) {
            addCriterion("EXPRESS_NBR like", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrNotLike(String value) {
            addCriterion("EXPRESS_NBR not like", value, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrIn(List<String> values) {
            addCriterion("EXPRESS_NBR in", values, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrNotIn(List<String> values) {
            addCriterion("EXPRESS_NBR not in", values, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrBetween(String value1, String value2) {
            addCriterion("EXPRESS_NBR between", value1, value2, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andExpressNbrNotBetween(String value1, String value2) {
            addCriterion("EXPRESS_NBR not between", value1, value2, "expressNbr");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIsNull() {
            addCriterion("CONVERSION_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIsNotNull() {
            addCriterion("CONVERSION_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andConversionStatusEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS =", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS <>", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusGreaterThan(Long value) {
            addCriterion("CONVERSION_STATUS >", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS >=", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusLessThan(Long value) {
            addCriterion("CONVERSION_STATUS <", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusLessThanOrEqualTo(Long value) {
            addCriterion("CONVERSION_STATUS <=", value, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusIn(List<Long> values) {
            addCriterion("CONVERSION_STATUS in", values, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotIn(List<Long> values) {
            addCriterion("CONVERSION_STATUS not in", values, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusBetween(Long value1, Long value2) {
            addCriterion("CONVERSION_STATUS between", value1, value2, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andConversionStatusNotBetween(Long value1, Long value2) {
            addCriterion("CONVERSION_STATUS not between", value1, value2, "conversionStatus");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNull() {
            addCriterion("TARGET_ORDER_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNotNull() {
            addCriterion("TARGET_ORDER_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID =", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <>", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThan(Long value) {
            addCriterion("TARGET_ORDER_UKID >", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID >=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThan(Long value) {
            addCriterion("TARGET_ORDER_UKID <", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID not in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID not between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNull() {
            addCriterion("ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNotNull() {
            addCriterion("ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusEqualTo(String value) {
            addCriterion("ORDER_STATUS =", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotEqualTo(String value) {
            addCriterion("ORDER_STATUS <>", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThan(String value) {
            addCriterion("ORDER_STATUS >", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS >=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThan(String value) {
            addCriterion("ORDER_STATUS <", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("ORDER_STATUS <=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLike(String value) {
            addCriterion("ORDER_STATUS like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotLike(String value) {
            addCriterion("ORDER_STATUS not like", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIn(List<String> values) {
            addCriterion("ORDER_STATUS in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotIn(List<String> values) {
            addCriterion("ORDER_STATUS not in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotBetween(String value1, String value2) {
            addCriterion("ORDER_STATUS not between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNull() {
            addCriterion("ISCS_RECEIPT_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIsNotNull() {
            addCriterion("ISCS_RECEIPT_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS =", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <>", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusGreaterThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS >=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThan(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLessThanOrEqualTo(String value) {
            addCriterion("ISCS_RECEIPT_STATUS <=", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotLike(String value) {
            addCriterion("ISCS_RECEIPT_STATUS not like", value, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotIn(List<String> values) {
            addCriterion("ISCS_RECEIPT_STATUS not in", values, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andIscsReceiptStatusNotBetween(String value1, String value2) {
            addCriterion("ISCS_RECEIPT_STATUS not between", value1, value2, "iscsReceiptStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNull() {
            addCriterion("SERVICE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIsNotNull() {
            addCriterion("SERVICE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andServiceStatusEqualTo(String value) {
            addCriterion("SERVICE_STATUS =", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotEqualTo(String value) {
            addCriterion("SERVICE_STATUS <>", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThan(String value) {
            addCriterion("SERVICE_STATUS >", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusGreaterThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS >=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThan(String value) {
            addCriterion("SERVICE_STATUS <", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLessThanOrEqualTo(String value) {
            addCriterion("SERVICE_STATUS <=", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusLike(String value) {
            addCriterion("SERVICE_STATUS like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotLike(String value) {
            addCriterion("SERVICE_STATUS not like", value, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusIn(List<String> values) {
            addCriterion("SERVICE_STATUS in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotIn(List<String> values) {
            addCriterion("SERVICE_STATUS not in", values, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andServiceStatusNotBetween(String value1, String value2) {
            addCriterion("SERVICE_STATUS not between", value1, value2, "serviceStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNull() {
            addCriterion("PROCESS_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIsNotNull() {
            addCriterion("PROCESS_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andProcessStatusEqualTo(Long value) {
            addCriterion("PROCESS_STATUS =", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotEqualTo(Long value) {
            addCriterion("PROCESS_STATUS <>", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThan(Long value) {
            addCriterion("PROCESS_STATUS >", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("PROCESS_STATUS >=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThan(Long value) {
            addCriterion("PROCESS_STATUS <", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusLessThanOrEqualTo(Long value) {
            addCriterion("PROCESS_STATUS <=", value, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusIn(List<Long> values) {
            addCriterion("PROCESS_STATUS in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotIn(List<Long> values) {
            addCriterion("PROCESS_STATUS not in", values, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusBetween(Long value1, Long value2) {
            addCriterion("PROCESS_STATUS between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andProcessStatusNotBetween(Long value1, Long value2) {
            addCriterion("PROCESS_STATUS not between", value1, value2, "processStatus");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNull() {
            addCriterion("SUB_ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIsNotNull() {
            addCriterion("SUB_ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdEqualTo(String value) {
            addCriterion("SUB_ORDER_ID =", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <>", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThan(String value) {
            addCriterion("SUB_ORDER_ID >", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID >=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThan(String value) {
            addCriterion("SUB_ORDER_ID <", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLessThanOrEqualTo(String value) {
            addCriterion("SUB_ORDER_ID <=", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdLike(String value) {
            addCriterion("SUB_ORDER_ID like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotLike(String value) {
            addCriterion("SUB_ORDER_ID not like", value, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdIn(List<String> values) {
            addCriterion("SUB_ORDER_ID in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotIn(List<String> values) {
            addCriterion("SUB_ORDER_ID not in", values, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andSubOrderIdNotBetween(String value1, String value2) {
            addCriterion("SUB_ORDER_ID not between", value1, value2, "subOrderId");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNull() {
            addCriterion("GOOD_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIsNotNull() {
            addCriterion("GOOD_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andGoodStatusEqualTo(String value) {
            addCriterion("GOOD_STATUS =", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotEqualTo(String value) {
            addCriterion("GOOD_STATUS <>", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThan(String value) {
            addCriterion("GOOD_STATUS >", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusGreaterThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS >=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThan(String value) {
            addCriterion("GOOD_STATUS <", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLessThanOrEqualTo(String value) {
            addCriterion("GOOD_STATUS <=", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusLike(String value) {
            addCriterion("GOOD_STATUS like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotLike(String value) {
            addCriterion("GOOD_STATUS not like", value, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusIn(List<String> values) {
            addCriterion("GOOD_STATUS in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotIn(List<String> values) {
            addCriterion("GOOD_STATUS not in", values, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andGoodStatusNotBetween(String value1, String value2) {
            addCriterion("GOOD_STATUS not between", value1, value2, "goodStatus");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}