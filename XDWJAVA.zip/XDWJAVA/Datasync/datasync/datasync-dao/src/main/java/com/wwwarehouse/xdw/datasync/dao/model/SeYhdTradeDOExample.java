package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeYhdTradeDOExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public SeYhdTradeDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTradeUkidIsNull() {
            addCriterion("TRADE_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIsNotNull() {
            addCriterion("TRADE_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTradeUkidEqualTo(Long value) {
            addCriterion("TRADE_UKID =", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotEqualTo(Long value) {
            addCriterion("TRADE_UKID <>", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThan(Long value) {
            addCriterion("TRADE_UKID >", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID >=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThan(Long value) {
            addCriterion("TRADE_UKID <", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidLessThanOrEqualTo(Long value) {
            addCriterion("TRADE_UKID <=", value, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidIn(List<Long> values) {
            addCriterion("TRADE_UKID in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotIn(List<Long> values) {
            addCriterion("TRADE_UKID not in", values, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andTradeUkidNotBetween(Long value1, Long value2) {
            addCriterion("TRADE_UKID not between", value1, value2, "tradeUkid");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNull() {
            addCriterion("SHOP_ID is null");
            return (Criteria) this;
        }

        public Criteria andShopIdIsNotNull() {
            addCriterion("SHOP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andShopIdEqualTo(Long value) {
            addCriterion("SHOP_ID =", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotEqualTo(Long value) {
            addCriterion("SHOP_ID <>", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThan(Long value) {
            addCriterion("SHOP_ID >", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdGreaterThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID >=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThan(Long value) {
            addCriterion("SHOP_ID <", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdLessThanOrEqualTo(Long value) {
            addCriterion("SHOP_ID <=", value, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdIn(List<Long> values) {
            addCriterion("SHOP_ID in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotIn(List<Long> values) {
            addCriterion("SHOP_ID not in", values, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andShopIdNotBetween(Long value1, Long value2) {
            addCriterion("SHOP_ID not between", value1, value2, "shopId");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNull() {
            addCriterion("DOWN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDownTimeIsNotNull() {
            addCriterion("DOWN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDownTimeEqualTo(Date value) {
            addCriterion("DOWN_TIME =", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotEqualTo(Date value) {
            addCriterion("DOWN_TIME <>", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThan(Date value) {
            addCriterion("DOWN_TIME >", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME >=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThan(Date value) {
            addCriterion("DOWN_TIME <", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeLessThanOrEqualTo(Date value) {
            addCriterion("DOWN_TIME <=", value, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeIn(List<Date> values) {
            addCriterion("DOWN_TIME in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotIn(List<Date> values) {
            addCriterion("DOWN_TIME not in", values, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andDownTimeNotBetween(Date value1, Date value2) {
            addCriterion("DOWN_TIME not between", value1, value2, "downTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNull() {
            addCriterion("RELEASE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIsNotNull() {
            addCriterion("RELEASE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeEqualTo(Date value) {
            addCriterion("RELEASE_TIME =", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotEqualTo(Date value) {
            addCriterion("RELEASE_TIME <>", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThan(Date value) {
            addCriterion("RELEASE_TIME >", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME >=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThan(Date value) {
            addCriterion("RELEASE_TIME <", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeLessThanOrEqualTo(Date value) {
            addCriterion("RELEASE_TIME <=", value, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeIn(List<Date> values) {
            addCriterion("RELEASE_TIME in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotIn(List<Date> values) {
            addCriterion("RELEASE_TIME not in", values, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andReleaseTimeNotBetween(Date value1, Date value2) {
            addCriterion("RELEASE_TIME not between", value1, value2, "releaseTime");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNull() {
            addCriterion("ORIGIN_TRADE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIsNotNull() {
            addCriterion("ORIGIN_TRADE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS =", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <>", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThan(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS >", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS >=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThan(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusLessThanOrEqualTo(Long value) {
            addCriterion("ORIGIN_TRADE_STATUS <=", value, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusIn(List<Long> values) {
            addCriterion("ORIGIN_TRADE_STATUS in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotIn(List<Long> values) {
            addCriterion("ORIGIN_TRADE_STATUS not in", values, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_TRADE_STATUS between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOriginTradeStatusNotBetween(Long value1, Long value2) {
            addCriterion("ORIGIN_TRADE_STATUS not between", value1, value2, "originTradeStatus");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("ORDER_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("ORDER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("ORDER_ID =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("ORDER_ID <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("ORDER_ID >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_ID >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("ORDER_ID <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("ORDER_ID <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("ORDER_ID like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("ORDER_ID not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("ORDER_ID in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("ORDER_ID not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("ORDER_ID between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("ORDER_ID not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIsNull() {
            addCriterion("ORDER_CODE is null");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIsNotNull() {
            addCriterion("ORDER_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCodeEqualTo(String value) {
            addCriterion("ORDER_CODE =", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotEqualTo(String value) {
            addCriterion("ORDER_CODE <>", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeGreaterThan(String value) {
            addCriterion("ORDER_CODE >", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_CODE >=", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLessThan(String value) {
            addCriterion("ORDER_CODE <", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLessThanOrEqualTo(String value) {
            addCriterion("ORDER_CODE <=", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeLike(String value) {
            addCriterion("ORDER_CODE like", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotLike(String value) {
            addCriterion("ORDER_CODE not like", value, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeIn(List<String> values) {
            addCriterion("ORDER_CODE in", values, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotIn(List<String> values) {
            addCriterion("ORDER_CODE not in", values, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeBetween(String value1, String value2) {
            addCriterion("ORDER_CODE between", value1, value2, "orderCode");
            return (Criteria) this;
        }

        public Criteria andOrderCodeNotBetween(String value1, String value2) {
            addCriterion("ORDER_CODE not between", value1, value2, "orderCode");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNull() {
            addCriterion("PLATFORM_ORDER_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIsNotNull() {
            addCriterion("PLATFORM_ORDER_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS =", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <>", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS >=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThan(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ORDER_STATUS <=", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotLike(String value) {
            addCriterion("PLATFORM_ORDER_STATUS not like", value, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotIn(List<String> values) {
            addCriterion("PLATFORM_ORDER_STATUS not in", values, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andPlatformOrderStatusNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_ORDER_STATUS not between", value1, value2, "platformOrderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIsNull() {
            addCriterion("ORDER_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIsNotNull() {
            addCriterion("ORDER_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderAmountEqualTo(BigDecimal value) {
            addCriterion("ORDER_AMOUNT =", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_AMOUNT <>", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountGreaterThan(BigDecimal value) {
            addCriterion("ORDER_AMOUNT >", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_AMOUNT >=", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountLessThan(BigDecimal value) {
            addCriterion("ORDER_AMOUNT <", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_AMOUNT <=", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIn(List<BigDecimal> values) {
            addCriterion("ORDER_AMOUNT in", values, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_AMOUNT not in", values, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_AMOUNT between", value1, value2, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_AMOUNT not between", value1, value2, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountIsNull() {
            addCriterion("PRODUCT_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andProductAmountIsNotNull() {
            addCriterion("PRODUCT_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andProductAmountEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT =", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <>", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountGreaterThan(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT >", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT >=", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountLessThan(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PRODUCT_AMOUNT <=", value, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_AMOUNT in", values, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotIn(List<BigDecimal> values) {
            addCriterion("PRODUCT_AMOUNT not in", values, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_AMOUNT between", value1, value2, "productAmount");
            return (Criteria) this;
        }

        public Criteria andProductAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PRODUCT_AMOUNT not between", value1, value2, "productAmount");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNull() {
            addCriterion("ORDER_CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIsNotNull() {
            addCriterion("ORDER_CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME =", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <>", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThan(Date value) {
            addCriterion("ORDER_CREATE_TIME >", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME >=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThan(Date value) {
            addCriterion("ORDER_CREATE_TIME <", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_CREATE_TIME <=", value, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotIn(List<Date> values) {
            addCriterion("ORDER_CREATE_TIME not in", values, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andOrderCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_CREATE_TIME not between", value1, value2, "orderCreateTime");
            return (Criteria) this;
        }

        public Criteria andFreightFeeIsNull() {
            addCriterion("FREIGHT_FEE is null");
            return (Criteria) this;
        }

        public Criteria andFreightFeeIsNotNull() {
            addCriterion("FREIGHT_FEE is not null");
            return (Criteria) this;
        }

        public Criteria andFreightFeeEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_FEE =", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeNotEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_FEE <>", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeGreaterThan(BigDecimal value) {
            addCriterion("FREIGHT_FEE >", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_FEE >=", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeLessThan(BigDecimal value) {
            addCriterion("FREIGHT_FEE <", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FREIGHT_FEE <=", value, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeIn(List<BigDecimal> values) {
            addCriterion("FREIGHT_FEE in", values, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeNotIn(List<BigDecimal> values) {
            addCriterion("FREIGHT_FEE not in", values, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FREIGHT_FEE between", value1, value2, "freightFee");
            return (Criteria) this;
        }

        public Criteria andFreightFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FREIGHT_FEE not between", value1, value2, "freightFee");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceIsNull() {
            addCriterion("ORDER_NEED_INVOICE is null");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceIsNotNull() {
            addCriterion("ORDER_NEED_INVOICE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceEqualTo(Long value) {
            addCriterion("ORDER_NEED_INVOICE =", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceNotEqualTo(Long value) {
            addCriterion("ORDER_NEED_INVOICE <>", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceGreaterThan(Long value) {
            addCriterion("ORDER_NEED_INVOICE >", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_NEED_INVOICE >=", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceLessThan(Long value) {
            addCriterion("ORDER_NEED_INVOICE <", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_NEED_INVOICE <=", value, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceIn(List<Long> values) {
            addCriterion("ORDER_NEED_INVOICE in", values, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceNotIn(List<Long> values) {
            addCriterion("ORDER_NEED_INVOICE not in", values, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceBetween(Long value1, Long value2) {
            addCriterion("ORDER_NEED_INVOICE between", value1, value2, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andOrderNeedInvoiceNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_NEED_INVOICE not between", value1, value2, "orderNeedInvoice");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNull() {
            addCriterion("RECEIVER_NAME is null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIsNotNull() {
            addCriterion("RECEIVER_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverNameEqualTo(String value) {
            addCriterion("RECEIVER_NAME =", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotEqualTo(String value) {
            addCriterion("RECEIVER_NAME <>", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThan(String value) {
            addCriterion("RECEIVER_NAME >", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME >=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThan(String value) {
            addCriterion("RECEIVER_NAME <", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_NAME <=", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameLike(String value) {
            addCriterion("RECEIVER_NAME like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotLike(String value) {
            addCriterion("RECEIVER_NAME not like", value, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameIn(List<String> values) {
            addCriterion("RECEIVER_NAME in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotIn(List<String> values) {
            addCriterion("RECEIVER_NAME not in", values, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverNameNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_NAME not between", value1, value2, "receiverName");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNull() {
            addCriterion("RECEIVER_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIsNotNull() {
            addCriterion("RECEIVER_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS =", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <>", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThan(String value) {
            addCriterion("RECEIVER_ADDRESS >", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS >=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThan(String value) {
            addCriterion("RECEIVER_ADDRESS <", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ADDRESS <=", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressLike(String value) {
            addCriterion("RECEIVER_ADDRESS like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotLike(String value) {
            addCriterion("RECEIVER_ADDRESS not like", value, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotIn(List<String> values) {
            addCriterion("RECEIVER_ADDRESS not in", values, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverAddressNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ADDRESS not between", value1, value2, "receiverAddress");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNull() {
            addCriterion("RECEIVER_STATE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIsNotNull() {
            addCriterion("RECEIVER_STATE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverStateEqualTo(String value) {
            addCriterion("RECEIVER_STATE =", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotEqualTo(String value) {
            addCriterion("RECEIVER_STATE <>", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThan(String value) {
            addCriterion("RECEIVER_STATE >", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE >=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThan(String value) {
            addCriterion("RECEIVER_STATE <", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_STATE <=", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateLike(String value) {
            addCriterion("RECEIVER_STATE like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotLike(String value) {
            addCriterion("RECEIVER_STATE not like", value, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateIn(List<String> values) {
            addCriterion("RECEIVER_STATE in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotIn(List<String> values) {
            addCriterion("RECEIVER_STATE not in", values, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverStateNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_STATE not between", value1, value2, "receiverState");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNull() {
            addCriterion("RECEIVER_CITY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIsNotNull() {
            addCriterion("RECEIVER_CITY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCityEqualTo(String value) {
            addCriterion("RECEIVER_CITY =", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotEqualTo(String value) {
            addCriterion("RECEIVER_CITY <>", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThan(String value) {
            addCriterion("RECEIVER_CITY >", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY >=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThan(String value) {
            addCriterion("RECEIVER_CITY <", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_CITY <=", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityLike(String value) {
            addCriterion("RECEIVER_CITY like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotLike(String value) {
            addCriterion("RECEIVER_CITY not like", value, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityIn(List<String> values) {
            addCriterion("RECEIVER_CITY in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotIn(List<String> values) {
            addCriterion("RECEIVER_CITY not in", values, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCityNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_CITY not between", value1, value2, "receiverCity");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNull() {
            addCriterion("RECEIVER_COUNTY is null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIsNotNull() {
            addCriterion("RECEIVER_COUNTY is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY =", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <>", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThan(String value) {
            addCriterion("RECEIVER_COUNTY >", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY >=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThan(String value) {
            addCriterion("RECEIVER_COUNTY <", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_COUNTY <=", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyLike(String value) {
            addCriterion("RECEIVER_COUNTY like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotLike(String value) {
            addCriterion("RECEIVER_COUNTY not like", value, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotIn(List<String> values) {
            addCriterion("RECEIVER_COUNTY not in", values, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverCountyNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_COUNTY not between", value1, value2, "receiverCounty");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNull() {
            addCriterion("RECEIVER_ZIP is null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIsNotNull() {
            addCriterion("RECEIVER_ZIP is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverZipEqualTo(String value) {
            addCriterion("RECEIVER_ZIP =", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <>", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThan(String value) {
            addCriterion("RECEIVER_ZIP >", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP >=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThan(String value) {
            addCriterion("RECEIVER_ZIP <", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_ZIP <=", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipLike(String value) {
            addCriterion("RECEIVER_ZIP like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotLike(String value) {
            addCriterion("RECEIVER_ZIP not like", value, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipIn(List<String> values) {
            addCriterion("RECEIVER_ZIP in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotIn(List<String> values) {
            addCriterion("RECEIVER_ZIP not in", values, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverZipNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_ZIP not between", value1, value2, "receiverZip");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNull() {
            addCriterion("RECEIVER_PHONE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIsNotNull() {
            addCriterion("RECEIVER_PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneEqualTo(String value) {
            addCriterion("RECEIVER_PHONE =", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <>", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThan(String value) {
            addCriterion("RECEIVER_PHONE >", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE >=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThan(String value) {
            addCriterion("RECEIVER_PHONE <", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_PHONE <=", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneLike(String value) {
            addCriterion("RECEIVER_PHONE like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotLike(String value) {
            addCriterion("RECEIVER_PHONE not like", value, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneIn(List<String> values) {
            addCriterion("RECEIVER_PHONE in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotIn(List<String> values) {
            addCriterion("RECEIVER_PHONE not in", values, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverPhoneNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_PHONE not between", value1, value2, "receiverPhone");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNull() {
            addCriterion("RECEIVER_MOBILE is null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIsNotNull() {
            addCriterion("RECEIVER_MOBILE is not null");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE =", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <>", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThan(String value) {
            addCriterion("RECEIVER_MOBILE >", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileGreaterThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE >=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThan(String value) {
            addCriterion("RECEIVER_MOBILE <", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLessThanOrEqualTo(String value) {
            addCriterion("RECEIVER_MOBILE <=", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileLike(String value) {
            addCriterion("RECEIVER_MOBILE like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotLike(String value) {
            addCriterion("RECEIVER_MOBILE not like", value, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotIn(List<String> values) {
            addCriterion("RECEIVER_MOBILE not in", values, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andReceiverMobileNotBetween(String value1, String value2) {
            addCriterion("RECEIVER_MOBILE not between", value1, value2, "receiverMobile");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateIsNull() {
            addCriterion("DELIVERY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateIsNotNull() {
            addCriterion("DELIVERY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateEqualTo(Date value) {
            addCriterion("DELIVERY_DATE =", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateNotEqualTo(Date value) {
            addCriterion("DELIVERY_DATE <>", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateGreaterThan(Date value) {
            addCriterion("DELIVERY_DATE >", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateGreaterThanOrEqualTo(Date value) {
            addCriterion("DELIVERY_DATE >=", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateLessThan(Date value) {
            addCriterion("DELIVERY_DATE <", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateLessThanOrEqualTo(Date value) {
            addCriterion("DELIVERY_DATE <=", value, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateIn(List<Date> values) {
            addCriterion("DELIVERY_DATE in", values, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateNotIn(List<Date> values) {
            addCriterion("DELIVERY_DATE not in", values, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateBetween(Date value1, Date value2) {
            addCriterion("DELIVERY_DATE between", value1, value2, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andDeliveryDateNotBetween(Date value1, Date value2) {
            addCriterion("DELIVERY_DATE not between", value1, value2, "deliveryDate");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNull() {
            addCriterion("CONSIGN_TIME is null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIsNotNull() {
            addCriterion("CONSIGN_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andConsignTimeEqualTo(Date value) {
            addCriterion("CONSIGN_TIME =", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <>", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThan(Date value) {
            addCriterion("CONSIGN_TIME >", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME >=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThan(Date value) {
            addCriterion("CONSIGN_TIME <", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeLessThanOrEqualTo(Date value) {
            addCriterion("CONSIGN_TIME <=", value, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeIn(List<Date> values) {
            addCriterion("CONSIGN_TIME in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotIn(List<Date> values) {
            addCriterion("CONSIGN_TIME not in", values, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andConsignTimeNotBetween(Date value1, Date value2) {
            addCriterion("CONSIGN_TIME not between", value1, value2, "consignTime");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNull() {
            addCriterion("BUYER_MESSAGE is null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIsNotNull() {
            addCriterion("BUYER_MESSAGE is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageEqualTo(String value) {
            addCriterion("BUYER_MESSAGE =", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <>", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThan(String value) {
            addCriterion("BUYER_MESSAGE >", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE >=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThan(String value) {
            addCriterion("BUYER_MESSAGE <", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLessThanOrEqualTo(String value) {
            addCriterion("BUYER_MESSAGE <=", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageLike(String value) {
            addCriterion("BUYER_MESSAGE like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotLike(String value) {
            addCriterion("BUYER_MESSAGE not like", value, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageIn(List<String> values) {
            addCriterion("BUYER_MESSAGE in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotIn(List<String> values) {
            addCriterion("BUYER_MESSAGE not in", values, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andBuyerMessageNotBetween(String value1, String value2) {
            addCriterion("BUYER_MESSAGE not between", value1, value2, "buyerMessage");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdIsNull() {
            addCriterion("DELIVERY_SUPPLIER_ID is null");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdIsNotNull() {
            addCriterion("DELIVERY_SUPPLIER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdEqualTo(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID =", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdNotEqualTo(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID <>", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdGreaterThan(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID >", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdGreaterThanOrEqualTo(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID >=", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdLessThan(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID <", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdLessThanOrEqualTo(Long value) {
            addCriterion("DELIVERY_SUPPLIER_ID <=", value, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdIn(List<Long> values) {
            addCriterion("DELIVERY_SUPPLIER_ID in", values, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdNotIn(List<Long> values) {
            addCriterion("DELIVERY_SUPPLIER_ID not in", values, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdBetween(Long value1, Long value2) {
            addCriterion("DELIVERY_SUPPLIER_ID between", value1, value2, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andDeliverySupplierIdNotBetween(Long value1, Long value2) {
            addCriterion("DELIVERY_SUPPLIER_ID not between", value1, value2, "deliverySupplierId");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNull() {
            addCriterion("SELLER_MEMO is null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIsNotNull() {
            addCriterion("SELLER_MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andSellerMemoEqualTo(String value) {
            addCriterion("SELLER_MEMO =", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotEqualTo(String value) {
            addCriterion("SELLER_MEMO <>", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThan(String value) {
            addCriterion("SELLER_MEMO >", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoGreaterThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO >=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThan(String value) {
            addCriterion("SELLER_MEMO <", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLessThanOrEqualTo(String value) {
            addCriterion("SELLER_MEMO <=", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoLike(String value) {
            addCriterion("SELLER_MEMO like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotLike(String value) {
            addCriterion("SELLER_MEMO not like", value, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoIn(List<String> values) {
            addCriterion("SELLER_MEMO in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotIn(List<String> values) {
            addCriterion("SELLER_MEMO not in", values, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andSellerMemoNotBetween(String value1, String value2) {
            addCriterion("SELLER_MEMO not between", value1, value2, "sellerMemo");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNull() {
            addCriterion("ORDER_PAY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIsNotNull() {
            addCriterion("ORDER_PAY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME =", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <>", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThan(Date value) {
            addCriterion("ORDER_PAY_TIME >", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME >=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThan(Date value) {
            addCriterion("ORDER_PAY_TIME <", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_PAY_TIME <=", value, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotIn(List<Date> values) {
            addCriterion("ORDER_PAY_TIME not in", values, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andOrderPayTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_PAY_TIME not between", value1, value2, "orderPayTime");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeIsNull() {
            addCriterion("PAY_SERVICE_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeIsNotNull() {
            addCriterion("PAY_SERVICE_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeEqualTo(Long value) {
            addCriterion("PAY_SERVICE_TYPE =", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeNotEqualTo(Long value) {
            addCriterion("PAY_SERVICE_TYPE <>", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeGreaterThan(Long value) {
            addCriterion("PAY_SERVICE_TYPE >", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeGreaterThanOrEqualTo(Long value) {
            addCriterion("PAY_SERVICE_TYPE >=", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeLessThan(Long value) {
            addCriterion("PAY_SERVICE_TYPE <", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeLessThanOrEqualTo(Long value) {
            addCriterion("PAY_SERVICE_TYPE <=", value, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeIn(List<Long> values) {
            addCriterion("PAY_SERVICE_TYPE in", values, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeNotIn(List<Long> values) {
            addCriterion("PAY_SERVICE_TYPE not in", values, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeBetween(Long value1, Long value2) {
            addCriterion("PAY_SERVICE_TYPE between", value1, value2, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andPayServiceTypeNotBetween(Long value1, Long value2) {
            addCriterion("PAY_SERVICE_TYPE not between", value1, value2, "payServiceType");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountIsNull() {
            addCriterion("ORDER_PROMOTION_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountIsNotNull() {
            addCriterion("ORDER_PROMOTION_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountEqualTo(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT =", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT <>", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountGreaterThan(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT >", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT >=", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountLessThan(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT <", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PROMOTION_DISCOUNT <=", value, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountIn(List<BigDecimal> values) {
            addCriterion("ORDER_PROMOTION_DISCOUNT in", values, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_PROMOTION_DISCOUNT not in", values, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PROMOTION_DISCOUNT between", value1, value2, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPromotionDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PROMOTION_DISCOUNT not between", value1, value2, "orderPromotionDiscount");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrIsNull() {
            addCriterion("MERCHANT_EXPRESS_NBR is null");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrIsNotNull() {
            addCriterion("MERCHANT_EXPRESS_NBR is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrEqualTo(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR =", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrNotEqualTo(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR <>", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrGreaterThan(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR >", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrGreaterThanOrEqualTo(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR >=", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrLessThan(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR <", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrLessThanOrEqualTo(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR <=", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrLike(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR like", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrNotLike(String value) {
            addCriterion("MERCHANT_EXPRESS_NBR not like", value, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrIn(List<String> values) {
            addCriterion("MERCHANT_EXPRESS_NBR in", values, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrNotIn(List<String> values) {
            addCriterion("MERCHANT_EXPRESS_NBR not in", values, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrBetween(String value1, String value2) {
            addCriterion("MERCHANT_EXPRESS_NBR between", value1, value2, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andMerchantExpressNbrNotBetween(String value1, String value2) {
            addCriterion("MERCHANT_EXPRESS_NBR not between", value1, value2, "merchantExpressNbr");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNull() {
            addCriterion("ORDER_MODIFY_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIsNotNull() {
            addCriterion("ORDER_MODIFY_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME =", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <>", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME >", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME >=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThan(Date value) {
            addCriterion("ORDER_MODIFY_TIME <", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeLessThanOrEqualTo(Date value) {
            addCriterion("ORDER_MODIFY_TIME <=", value, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotIn(List<Date> values) {
            addCriterion("ORDER_MODIFY_TIME not in", values, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderModifyTimeNotBetween(Date value1, Date value2) {
            addCriterion("ORDER_MODIFY_TIME not between", value1, value2, "orderModifyTime");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountIsNull() {
            addCriterion("ORDER_COUPON_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountIsNotNull() {
            addCriterion("ORDER_COUPON_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountEqualTo(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT =", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT <>", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountGreaterThan(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT >", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT >=", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountLessThan(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT <", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_COUPON_DISCOUNT <=", value, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountIn(List<BigDecimal> values) {
            addCriterion("ORDER_COUPON_DISCOUNT in", values, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_COUPON_DISCOUNT not in", values, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_COUPON_DISCOUNT between", value1, value2, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderCouponDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_COUPON_DISCOUNT not between", value1, value2, "orderCouponDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountIsNull() {
            addCriterion("ORDER_PLATFORM_DISCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountIsNotNull() {
            addCriterion("ORDER_PLATFORM_DISCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountEqualTo(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT =", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT <>", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountGreaterThan(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT >", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT >=", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountLessThan(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT <", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_PLATFORM_DISCOUNT <=", value, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountIn(List<BigDecimal> values) {
            addCriterion("ORDER_PLATFORM_DISCOUNT in", values, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_PLATFORM_DISCOUNT not in", values, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PLATFORM_DISCOUNT between", value1, value2, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andOrderPlatformDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_PLATFORM_DISCOUNT not between", value1, value2, "orderPlatformDiscount");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleIsNull() {
            addCriterion("INVOICE_TITLE is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleIsNotNull() {
            addCriterion("INVOICE_TITLE is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleEqualTo(String value) {
            addCriterion("INVOICE_TITLE =", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleNotEqualTo(String value) {
            addCriterion("INVOICE_TITLE <>", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleGreaterThan(String value) {
            addCriterion("INVOICE_TITLE >", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_TITLE >=", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleLessThan(String value) {
            addCriterion("INVOICE_TITLE <", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_TITLE <=", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleLike(String value) {
            addCriterion("INVOICE_TITLE like", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleNotLike(String value) {
            addCriterion("INVOICE_TITLE not like", value, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleIn(List<String> values) {
            addCriterion("INVOICE_TITLE in", values, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleNotIn(List<String> values) {
            addCriterion("INVOICE_TITLE not in", values, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleBetween(String value1, String value2) {
            addCriterion("INVOICE_TITLE between", value1, value2, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceTitleNotBetween(String value1, String value2) {
            addCriterion("INVOICE_TITLE not between", value1, value2, "invoiceTitle");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentIsNull() {
            addCriterion("INVOICE_CONTENT is null");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentIsNotNull() {
            addCriterion("INVOICE_CONTENT is not null");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentEqualTo(String value) {
            addCriterion("INVOICE_CONTENT =", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentNotEqualTo(String value) {
            addCriterion("INVOICE_CONTENT <>", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentGreaterThan(String value) {
            addCriterion("INVOICE_CONTENT >", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentGreaterThanOrEqualTo(String value) {
            addCriterion("INVOICE_CONTENT >=", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentLessThan(String value) {
            addCriterion("INVOICE_CONTENT <", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentLessThanOrEqualTo(String value) {
            addCriterion("INVOICE_CONTENT <=", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentLike(String value) {
            addCriterion("INVOICE_CONTENT like", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentNotLike(String value) {
            addCriterion("INVOICE_CONTENT not like", value, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentIn(List<String> values) {
            addCriterion("INVOICE_CONTENT in", values, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentNotIn(List<String> values) {
            addCriterion("INVOICE_CONTENT not in", values, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentBetween(String value1, String value2) {
            addCriterion("INVOICE_CONTENT between", value1, value2, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andInvoiceContentNotBetween(String value1, String value2) {
            addCriterion("INVOICE_CONTENT not between", value1, value2, "invoiceContent");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNull() {
            addCriterion("BUYER_NICK is null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIsNotNull() {
            addCriterion("BUYER_NICK is not null");
            return (Criteria) this;
        }

        public Criteria andBuyerNickEqualTo(String value) {
            addCriterion("BUYER_NICK =", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotEqualTo(String value) {
            addCriterion("BUYER_NICK <>", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThan(String value) {
            addCriterion("BUYER_NICK >", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickGreaterThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK >=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThan(String value) {
            addCriterion("BUYER_NICK <", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLessThanOrEqualTo(String value) {
            addCriterion("BUYER_NICK <=", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickLike(String value) {
            addCriterion("BUYER_NICK like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotLike(String value) {
            addCriterion("BUYER_NICK not like", value, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickIn(List<String> values) {
            addCriterion("BUYER_NICK in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotIn(List<String> values) {
            addCriterion("BUYER_NICK not in", values, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickBetween(String value1, String value2) {
            addCriterion("BUYER_NICK between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andBuyerNickNotBetween(String value1, String value2) {
            addCriterion("BUYER_NICK not between", value1, value2, "buyerNick");
            return (Criteria) this;
        }

        public Criteria andRealAmountIsNull() {
            addCriterion("REAL_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andRealAmountIsNotNull() {
            addCriterion("REAL_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andRealAmountEqualTo(BigDecimal value) {
            addCriterion("REAL_AMOUNT =", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountNotEqualTo(BigDecimal value) {
            addCriterion("REAL_AMOUNT <>", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountGreaterThan(BigDecimal value) {
            addCriterion("REAL_AMOUNT >", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("REAL_AMOUNT >=", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountLessThan(BigDecimal value) {
            addCriterion("REAL_AMOUNT <", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("REAL_AMOUNT <=", value, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountIn(List<BigDecimal> values) {
            addCriterion("REAL_AMOUNT in", values, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountNotIn(List<BigDecimal> values) {
            addCriterion("REAL_AMOUNT not in", values, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("REAL_AMOUNT between", value1, value2, "realAmount");
            return (Criteria) this;
        }

        public Criteria andRealAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("REAL_AMOUNT not between", value1, value2, "realAmount");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdIsNull() {
            addCriterion("WAREHOUSE_ID is null");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdIsNotNull() {
            addCriterion("WAREHOUSE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdEqualTo(Long value) {
            addCriterion("WAREHOUSE_ID =", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdNotEqualTo(Long value) {
            addCriterion("WAREHOUSE_ID <>", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdGreaterThan(Long value) {
            addCriterion("WAREHOUSE_ID >", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdGreaterThanOrEqualTo(Long value) {
            addCriterion("WAREHOUSE_ID >=", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdLessThan(Long value) {
            addCriterion("WAREHOUSE_ID <", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdLessThanOrEqualTo(Long value) {
            addCriterion("WAREHOUSE_ID <=", value, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdIn(List<Long> values) {
            addCriterion("WAREHOUSE_ID in", values, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdNotIn(List<Long> values) {
            addCriterion("WAREHOUSE_ID not in", values, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdBetween(Long value1, Long value2) {
            addCriterion("WAREHOUSE_ID between", value1, value2, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andWarehouseIdNotBetween(Long value1, Long value2) {
            addCriterion("WAREHOUSE_ID not between", value1, value2, "warehouseId");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderIsNull() {
            addCriterion("IS_MOBILE_ORDER is null");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderIsNotNull() {
            addCriterion("IS_MOBILE_ORDER is not null");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderEqualTo(Long value) {
            addCriterion("IS_MOBILE_ORDER =", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderNotEqualTo(Long value) {
            addCriterion("IS_MOBILE_ORDER <>", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderGreaterThan(Long value) {
            addCriterion("IS_MOBILE_ORDER >", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderGreaterThanOrEqualTo(Long value) {
            addCriterion("IS_MOBILE_ORDER >=", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderLessThan(Long value) {
            addCriterion("IS_MOBILE_ORDER <", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderLessThanOrEqualTo(Long value) {
            addCriterion("IS_MOBILE_ORDER <=", value, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderIn(List<Long> values) {
            addCriterion("IS_MOBILE_ORDER in", values, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderNotIn(List<Long> values) {
            addCriterion("IS_MOBILE_ORDER not in", values, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderBetween(Long value1, Long value2) {
            addCriterion("IS_MOBILE_ORDER between", value1, value2, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andIsMobileOrderNotBetween(Long value1, Long value2) {
            addCriterion("IS_MOBILE_ORDER not between", value1, value2, "isMobileOrder");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeIsNull() {
            addCriterion("BUSINESS_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeIsNotNull() {
            addCriterion("BUSINESS_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeEqualTo(Long value) {
            addCriterion("BUSINESS_TYPE =", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeNotEqualTo(Long value) {
            addCriterion("BUSINESS_TYPE <>", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeGreaterThan(Long value) {
            addCriterion("BUSINESS_TYPE >", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeGreaterThanOrEqualTo(Long value) {
            addCriterion("BUSINESS_TYPE >=", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeLessThan(Long value) {
            addCriterion("BUSINESS_TYPE <", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeLessThanOrEqualTo(Long value) {
            addCriterion("BUSINESS_TYPE <=", value, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeIn(List<Long> values) {
            addCriterion("BUSINESS_TYPE in", values, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeNotIn(List<Long> values) {
            addCriterion("BUSINESS_TYPE not in", values, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeBetween(Long value1, Long value2) {
            addCriterion("BUSINESS_TYPE between", value1, value2, "businessType");
            return (Criteria) this;
        }

        public Criteria andBusinessTypeNotBetween(Long value1, Long value2) {
            addCriterion("BUSINESS_TYPE not between", value1, value2, "businessType");
            return (Criteria) this;
        }

        public Criteria andOrderDepositIsNull() {
            addCriterion("ORDER_DEPOSIT is null");
            return (Criteria) this;
        }

        public Criteria andOrderDepositIsNotNull() {
            addCriterion("ORDER_DEPOSIT is not null");
            return (Criteria) this;
        }

        public Criteria andOrderDepositEqualTo(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT =", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositNotEqualTo(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT <>", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositGreaterThan(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT >", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT >=", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositLessThan(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT <", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ORDER_DEPOSIT <=", value, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositIn(List<BigDecimal> values) {
            addCriterion("ORDER_DEPOSIT in", values, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositNotIn(List<BigDecimal> values) {
            addCriterion("ORDER_DEPOSIT not in", values, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_DEPOSIT between", value1, value2, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andOrderDepositNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ORDER_DEPOSIT not between", value1, value2, "orderDeposit");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderIsNull() {
            addCriterion("IS_DEPOSIT_ORDER is null");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderIsNotNull() {
            addCriterion("IS_DEPOSIT_ORDER is not null");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderEqualTo(Long value) {
            addCriterion("IS_DEPOSIT_ORDER =", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderNotEqualTo(Long value) {
            addCriterion("IS_DEPOSIT_ORDER <>", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderGreaterThan(Long value) {
            addCriterion("IS_DEPOSIT_ORDER >", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderGreaterThanOrEqualTo(Long value) {
            addCriterion("IS_DEPOSIT_ORDER >=", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderLessThan(Long value) {
            addCriterion("IS_DEPOSIT_ORDER <", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderLessThanOrEqualTo(Long value) {
            addCriterion("IS_DEPOSIT_ORDER <=", value, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderIn(List<Long> values) {
            addCriterion("IS_DEPOSIT_ORDER in", values, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderNotIn(List<Long> values) {
            addCriterion("IS_DEPOSIT_ORDER not in", values, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderBetween(Long value1, Long value2) {
            addCriterion("IS_DEPOSIT_ORDER between", value1, value2, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andIsDepositOrderNotBetween(Long value1, Long value2) {
            addCriterion("IS_DEPOSIT_ORDER not between", value1, value2, "isDepositOrder");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeIsNull() {
            addCriterion("DEPOSIT_PAID_TIME is null");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeIsNotNull() {
            addCriterion("DEPOSIT_PAID_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeEqualTo(Date value) {
            addCriterion("DEPOSIT_PAID_TIME =", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeNotEqualTo(Date value) {
            addCriterion("DEPOSIT_PAID_TIME <>", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeGreaterThan(Date value) {
            addCriterion("DEPOSIT_PAID_TIME >", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("DEPOSIT_PAID_TIME >=", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeLessThan(Date value) {
            addCriterion("DEPOSIT_PAID_TIME <", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeLessThanOrEqualTo(Date value) {
            addCriterion("DEPOSIT_PAID_TIME <=", value, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeIn(List<Date> values) {
            addCriterion("DEPOSIT_PAID_TIME in", values, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeNotIn(List<Date> values) {
            addCriterion("DEPOSIT_PAID_TIME not in", values, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeBetween(Date value1, Date value2) {
            addCriterion("DEPOSIT_PAID_TIME between", value1, value2, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andDepositPaidTimeNotBetween(Date value1, Date value2) {
            addCriterion("DEPOSIT_PAID_TIME not between", value1, value2, "depositPaidTime");
            return (Criteria) this;
        }

        public Criteria andApplyCancelIsNull() {
            addCriterion("APPLY_CANCEL is null");
            return (Criteria) this;
        }

        public Criteria andApplyCancelIsNotNull() {
            addCriterion("APPLY_CANCEL is not null");
            return (Criteria) this;
        }

        public Criteria andApplyCancelEqualTo(Long value) {
            addCriterion("APPLY_CANCEL =", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelNotEqualTo(Long value) {
            addCriterion("APPLY_CANCEL <>", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelGreaterThan(Long value) {
            addCriterion("APPLY_CANCEL >", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelGreaterThanOrEqualTo(Long value) {
            addCriterion("APPLY_CANCEL >=", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelLessThan(Long value) {
            addCriterion("APPLY_CANCEL <", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelLessThanOrEqualTo(Long value) {
            addCriterion("APPLY_CANCEL <=", value, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelIn(List<Long> values) {
            addCriterion("APPLY_CANCEL in", values, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelNotIn(List<Long> values) {
            addCriterion("APPLY_CANCEL not in", values, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelBetween(Long value1, Long value2) {
            addCriterion("APPLY_CANCEL between", value1, value2, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andApplyCancelNotBetween(Long value1, Long value2) {
            addCriterion("APPLY_CANCEL not between", value1, value2, "applyCancel");
            return (Criteria) this;
        }

        public Criteria andStoreIdIsNull() {
            addCriterion("STORE_ID is null");
            return (Criteria) this;
        }

        public Criteria andStoreIdIsNotNull() {
            addCriterion("STORE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andStoreIdEqualTo(Long value) {
            addCriterion("STORE_ID =", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdNotEqualTo(Long value) {
            addCriterion("STORE_ID <>", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdGreaterThan(Long value) {
            addCriterion("STORE_ID >", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdGreaterThanOrEqualTo(Long value) {
            addCriterion("STORE_ID >=", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdLessThan(Long value) {
            addCriterion("STORE_ID <", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdLessThanOrEqualTo(Long value) {
            addCriterion("STORE_ID <=", value, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdIn(List<Long> values) {
            addCriterion("STORE_ID in", values, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdNotIn(List<Long> values) {
            addCriterion("STORE_ID not in", values, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdBetween(Long value1, Long value2) {
            addCriterion("STORE_ID between", value1, value2, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreIdNotBetween(Long value1, Long value2) {
            addCriterion("STORE_ID not between", value1, value2, "storeId");
            return (Criteria) this;
        }

        public Criteria andStoreNameIsNull() {
            addCriterion("STORE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andStoreNameIsNotNull() {
            addCriterion("STORE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andStoreNameEqualTo(String value) {
            addCriterion("STORE_NAME =", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameNotEqualTo(String value) {
            addCriterion("STORE_NAME <>", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameGreaterThan(String value) {
            addCriterion("STORE_NAME >", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameGreaterThanOrEqualTo(String value) {
            addCriterion("STORE_NAME >=", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameLessThan(String value) {
            addCriterion("STORE_NAME <", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameLessThanOrEqualTo(String value) {
            addCriterion("STORE_NAME <=", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameLike(String value) {
            addCriterion("STORE_NAME like", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameNotLike(String value) {
            addCriterion("STORE_NAME not like", value, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameIn(List<String> values) {
            addCriterion("STORE_NAME in", values, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameNotIn(List<String> values) {
            addCriterion("STORE_NAME not in", values, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameBetween(String value1, String value2) {
            addCriterion("STORE_NAME between", value1, value2, "storeName");
            return (Criteria) this;
        }

        public Criteria andStoreNameNotBetween(String value1, String value2) {
            addCriterion("STORE_NAME not between", value1, value2, "storeName");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdIsNull() {
            addCriterion("EXTERNAL_STORE_ID is null");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdIsNotNull() {
            addCriterion("EXTERNAL_STORE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdEqualTo(Long value) {
            addCriterion("EXTERNAL_STORE_ID =", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdNotEqualTo(Long value) {
            addCriterion("EXTERNAL_STORE_ID <>", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdGreaterThan(Long value) {
            addCriterion("EXTERNAL_STORE_ID >", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdGreaterThanOrEqualTo(Long value) {
            addCriterion("EXTERNAL_STORE_ID >=", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdLessThan(Long value) {
            addCriterion("EXTERNAL_STORE_ID <", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdLessThanOrEqualTo(Long value) {
            addCriterion("EXTERNAL_STORE_ID <=", value, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdIn(List<Long> values) {
            addCriterion("EXTERNAL_STORE_ID in", values, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdNotIn(List<Long> values) {
            addCriterion("EXTERNAL_STORE_ID not in", values, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdBetween(Long value1, Long value2) {
            addCriterion("EXTERNAL_STORE_ID between", value1, value2, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andExternalStoreIdNotBetween(Long value1, Long value2) {
            addCriterion("EXTERNAL_STORE_ID not between", value1, value2, "externalStoreId");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountIsNull() {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountIsNotNull() {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountEqualTo(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT =", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountNotEqualTo(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT <>", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountGreaterThan(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT >", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT >=", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountLessThan(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT <", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT <=", value, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountIn(List<BigDecimal> values) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT in", values, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountNotIn(List<BigDecimal> values) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT not in", values, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT between", value1, value2, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andCollectOnDeliveryAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("COLLECT_ON_DELIVERY_AMOUNT not between", value1, value2, "collectOnDeliveryAmount");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeIsNull() {
            addCriterion("ORDER_PROD_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeIsNotNull() {
            addCriterion("ORDER_PROD_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeEqualTo(Long value) {
            addCriterion("ORDER_PROD_TYPE =", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeNotEqualTo(Long value) {
            addCriterion("ORDER_PROD_TYPE <>", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeGreaterThan(Long value) {
            addCriterion("ORDER_PROD_TYPE >", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeGreaterThanOrEqualTo(Long value) {
            addCriterion("ORDER_PROD_TYPE >=", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeLessThan(Long value) {
            addCriterion("ORDER_PROD_TYPE <", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeLessThanOrEqualTo(Long value) {
            addCriterion("ORDER_PROD_TYPE <=", value, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeIn(List<Long> values) {
            addCriterion("ORDER_PROD_TYPE in", values, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeNotIn(List<Long> values) {
            addCriterion("ORDER_PROD_TYPE not in", values, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeBetween(Long value1, Long value2) {
            addCriterion("ORDER_PROD_TYPE between", value1, value2, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andOrderProdTypeNotBetween(Long value1, Long value2) {
            addCriterion("ORDER_PROD_TYPE not between", value1, value2, "orderProdType");
            return (Criteria) this;
        }

        public Criteria andPaymentNoIsNull() {
            addCriterion("PAYMENT_NO is null");
            return (Criteria) this;
        }

        public Criteria andPaymentNoIsNotNull() {
            addCriterion("PAYMENT_NO is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentNoEqualTo(String value) {
            addCriterion("PAYMENT_NO =", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoNotEqualTo(String value) {
            addCriterion("PAYMENT_NO <>", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoGreaterThan(String value) {
            addCriterion("PAYMENT_NO >", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoGreaterThanOrEqualTo(String value) {
            addCriterion("PAYMENT_NO >=", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoLessThan(String value) {
            addCriterion("PAYMENT_NO <", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoLessThanOrEqualTo(String value) {
            addCriterion("PAYMENT_NO <=", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoLike(String value) {
            addCriterion("PAYMENT_NO like", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoNotLike(String value) {
            addCriterion("PAYMENT_NO not like", value, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoIn(List<String> values) {
            addCriterion("PAYMENT_NO in", values, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoNotIn(List<String> values) {
            addCriterion("PAYMENT_NO not in", values, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoBetween(String value1, String value2) {
            addCriterion("PAYMENT_NO between", value1, value2, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andPaymentNoNotBetween(String value1, String value2) {
            addCriterion("PAYMENT_NO not between", value1, value2, "paymentNo");
            return (Criteria) this;
        }

        public Criteria andGatewayNameIsNull() {
            addCriterion("GATEWAY_NAME is null");
            return (Criteria) this;
        }

        public Criteria andGatewayNameIsNotNull() {
            addCriterion("GATEWAY_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andGatewayNameEqualTo(String value) {
            addCriterion("GATEWAY_NAME =", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameNotEqualTo(String value) {
            addCriterion("GATEWAY_NAME <>", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameGreaterThan(String value) {
            addCriterion("GATEWAY_NAME >", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameGreaterThanOrEqualTo(String value) {
            addCriterion("GATEWAY_NAME >=", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameLessThan(String value) {
            addCriterion("GATEWAY_NAME <", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameLessThanOrEqualTo(String value) {
            addCriterion("GATEWAY_NAME <=", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameLike(String value) {
            addCriterion("GATEWAY_NAME like", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameNotLike(String value) {
            addCriterion("GATEWAY_NAME not like", value, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameIn(List<String> values) {
            addCriterion("GATEWAY_NAME in", values, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameNotIn(List<String> values) {
            addCriterion("GATEWAY_NAME not in", values, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameBetween(String value1, String value2) {
            addCriterion("GATEWAY_NAME between", value1, value2, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andGatewayNameNotBetween(String value1, String value2) {
            addCriterion("GATEWAY_NAME not between", value1, value2, "gatewayName");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionIsNull() {
            addCriterion("PAYMENT_TRANSACTION is null");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionIsNotNull() {
            addCriterion("PAYMENT_TRANSACTION is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionEqualTo(String value) {
            addCriterion("PAYMENT_TRANSACTION =", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionNotEqualTo(String value) {
            addCriterion("PAYMENT_TRANSACTION <>", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionGreaterThan(String value) {
            addCriterion("PAYMENT_TRANSACTION >", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionGreaterThanOrEqualTo(String value) {
            addCriterion("PAYMENT_TRANSACTION >=", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionLessThan(String value) {
            addCriterion("PAYMENT_TRANSACTION <", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionLessThanOrEqualTo(String value) {
            addCriterion("PAYMENT_TRANSACTION <=", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionLike(String value) {
            addCriterion("PAYMENT_TRANSACTION like", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionNotLike(String value) {
            addCriterion("PAYMENT_TRANSACTION not like", value, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionIn(List<String> values) {
            addCriterion("PAYMENT_TRANSACTION in", values, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionNotIn(List<String> values) {
            addCriterion("PAYMENT_TRANSACTION not in", values, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionBetween(String value1, String value2) {
            addCriterion("PAYMENT_TRANSACTION between", value1, value2, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andPaymentTransactionNotBetween(String value1, String value2) {
            addCriterion("PAYMENT_TRANSACTION not between", value1, value2, "paymentTransaction");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNull() {
            addCriterion("TARGET_ORDER_UKID is null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIsNotNull() {
            addCriterion("TARGET_ORDER_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID =", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <>", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThan(Long value) {
            addCriterion("TARGET_ORDER_UKID >", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID >=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThan(Long value) {
            addCriterion("TARGET_ORDER_UKID <", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidLessThanOrEqualTo(Long value) {
            addCriterion("TARGET_ORDER_UKID <=", value, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotIn(List<Long> values) {
            addCriterion("TARGET_ORDER_UKID not in", values, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andTargetOrderUkidNotBetween(Long value1, Long value2) {
            addCriterion("TARGET_ORDER_UKID not between", value1, value2, "targetOrderUkid");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}