package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.Date;

public class AmAppSubscriptionDO implements Serializable {
    private Long subscriptionUkid;

    private Long appUkid;

    private Long subscriptionBuId;

    private Date subscriptionDate;

    private String platformUserId;

    private String platformUserNick;

    private String targetAppKey;

    private String accessToken;

    private String refreshToken;

    private Date lastAuthTime;

    private Long expiresIn;

    private Long reExpiresIn;

    private Long r1ExpiresIn;

    private Long r2ExpiresIn;

    private Long w1ExpiresIn;

    private Long w2ExpiresIn;

    private String publicKey;

    private String privateKey;

    private String publicKeyOut;

    private String dataEncryptType;

    private String dataEncryptKey;

    private String dataEncryptPwd;

    private Short status;

    private Date createTime;

    private Long createUserId;

    private Date updateTime;

    private Long updateUserId;

    private static final long serialVersionUID = 1L;

    public Long getSubscriptionUkid() {
        return subscriptionUkid;
    }

    public void setSubscriptionUkid(Long subscriptionUkid) {
        this.subscriptionUkid = subscriptionUkid;
    }

    public Long getAppUkid() {
        return appUkid;
    }

    public void setAppUkid(Long appUkid) {
        this.appUkid = appUkid;
    }

    public Long getSubscriptionBuId() {
        return subscriptionBuId;
    }

    public void setSubscriptionBuId(Long subscriptionBuId) {
        this.subscriptionBuId = subscriptionBuId;
    }

    public Date getSubscriptionDate() {
        return subscriptionDate;
    }

    public void setSubscriptionDate(Date subscriptionDate) {
        this.subscriptionDate = subscriptionDate;
    }

    public String getPlatformUserId() {
        return platformUserId;
    }

    public void setPlatformUserId(String platformUserId) {
        this.platformUserId = platformUserId;
    }

    public String getPlatformUserNick() {
        return platformUserNick;
    }

    public void setPlatformUserNick(String platformUserNick) {
        this.platformUserNick = platformUserNick;
    }

    public String getTargetAppKey() {
        return targetAppKey;
    }

    public void setTargetAppKey(String targetAppKey) {
        this.targetAppKey = targetAppKey;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public Date getLastAuthTime() {
        return lastAuthTime;
    }

    public void setLastAuthTime(Date lastAuthTime) {
        this.lastAuthTime = lastAuthTime;
    }

    public Long getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Long expiresIn) {
        this.expiresIn = expiresIn;
    }

    public Long getReExpiresIn() {
        return reExpiresIn;
    }

    public void setReExpiresIn(Long reExpiresIn) {
        this.reExpiresIn = reExpiresIn;
    }

    public Long getR1ExpiresIn() {
        return r1ExpiresIn;
    }

    public void setR1ExpiresIn(Long r1ExpiresIn) {
        this.r1ExpiresIn = r1ExpiresIn;
    }

    public Long getR2ExpiresIn() {
        return r2ExpiresIn;
    }

    public void setR2ExpiresIn(Long r2ExpiresIn) {
        this.r2ExpiresIn = r2ExpiresIn;
    }

    public Long getW1ExpiresIn() {
        return w1ExpiresIn;
    }

    public void setW1ExpiresIn(Long w1ExpiresIn) {
        this.w1ExpiresIn = w1ExpiresIn;
    }

    public Long getW2ExpiresIn() {
        return w2ExpiresIn;
    }

    public void setW2ExpiresIn(Long w2ExpiresIn) {
        this.w2ExpiresIn = w2ExpiresIn;
    }

    public String getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public String getPublicKeyOut() {
        return publicKeyOut;
    }

    public void setPublicKeyOut(String publicKeyOut) {
        this.publicKeyOut = publicKeyOut;
    }

    public String getDataEncryptType() {
        return dataEncryptType;
    }

    public void setDataEncryptType(String dataEncryptType) {
        this.dataEncryptType = dataEncryptType;
    }

    public String getDataEncryptKey() {
        return dataEncryptKey;
    }

    public void setDataEncryptKey(String dataEncryptKey) {
        this.dataEncryptKey = dataEncryptKey;
    }

    public String getDataEncryptPwd() {
        return dataEncryptPwd;
    }

    public void setDataEncryptPwd(String dataEncryptPwd) {
        this.dataEncryptPwd = dataEncryptPwd;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", subscriptionUkid=").append(subscriptionUkid);
        sb.append(", appUkid=").append(appUkid);
        sb.append(", subscriptionBuId=").append(subscriptionBuId);
        sb.append(", subscriptionDate=").append(subscriptionDate);
        sb.append(", platformUserId=").append(platformUserId);
        sb.append(", platformUserNick=").append(platformUserNick);
        sb.append(", targetAppKey=").append(targetAppKey);
        sb.append(", accessToken=").append(accessToken);
        sb.append(", refreshToken=").append(refreshToken);
        sb.append(", lastAuthTime=").append(lastAuthTime);
        sb.append(", expiresIn=").append(expiresIn);
        sb.append(", reExpiresIn=").append(reExpiresIn);
        sb.append(", r1ExpiresIn=").append(r1ExpiresIn);
        sb.append(", r2ExpiresIn=").append(r2ExpiresIn);
        sb.append(", w1ExpiresIn=").append(w1ExpiresIn);
        sb.append(", w2ExpiresIn=").append(w2ExpiresIn);
        sb.append(", publicKey=").append(publicKey);
        sb.append(", privateKey=").append(privateKey);
        sb.append(", publicKeyOut=").append(publicKeyOut);
        sb.append(", dataEncryptType=").append(dataEncryptType);
        sb.append(", dataEncryptKey=").append(dataEncryptKey);
        sb.append(", dataEncryptPwd=").append(dataEncryptPwd);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createUserId=").append(createUserId);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateUserId=").append(updateUserId);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AmAppSubscriptionDO other = (AmAppSubscriptionDO) that;
        return (this.getSubscriptionUkid() == null ? other.getSubscriptionUkid() == null : this.getSubscriptionUkid().equals(other.getSubscriptionUkid()))
            && (this.getAppUkid() == null ? other.getAppUkid() == null : this.getAppUkid().equals(other.getAppUkid()))
            && (this.getSubscriptionBuId() == null ? other.getSubscriptionBuId() == null : this.getSubscriptionBuId().equals(other.getSubscriptionBuId()))
            && (this.getSubscriptionDate() == null ? other.getSubscriptionDate() == null : this.getSubscriptionDate().equals(other.getSubscriptionDate()))
            && (this.getPlatformUserId() == null ? other.getPlatformUserId() == null : this.getPlatformUserId().equals(other.getPlatformUserId()))
            && (this.getPlatformUserNick() == null ? other.getPlatformUserNick() == null : this.getPlatformUserNick().equals(other.getPlatformUserNick()))
            && (this.getTargetAppKey() == null ? other.getTargetAppKey() == null : this.getTargetAppKey().equals(other.getTargetAppKey()))
            && (this.getAccessToken() == null ? other.getAccessToken() == null : this.getAccessToken().equals(other.getAccessToken()))
            && (this.getRefreshToken() == null ? other.getRefreshToken() == null : this.getRefreshToken().equals(other.getRefreshToken()))
            && (this.getLastAuthTime() == null ? other.getLastAuthTime() == null : this.getLastAuthTime().equals(other.getLastAuthTime()))
            && (this.getExpiresIn() == null ? other.getExpiresIn() == null : this.getExpiresIn().equals(other.getExpiresIn()))
            && (this.getReExpiresIn() == null ? other.getReExpiresIn() == null : this.getReExpiresIn().equals(other.getReExpiresIn()))
            && (this.getR1ExpiresIn() == null ? other.getR1ExpiresIn() == null : this.getR1ExpiresIn().equals(other.getR1ExpiresIn()))
            && (this.getR2ExpiresIn() == null ? other.getR2ExpiresIn() == null : this.getR2ExpiresIn().equals(other.getR2ExpiresIn()))
            && (this.getW1ExpiresIn() == null ? other.getW1ExpiresIn() == null : this.getW1ExpiresIn().equals(other.getW1ExpiresIn()))
            && (this.getW2ExpiresIn() == null ? other.getW2ExpiresIn() == null : this.getW2ExpiresIn().equals(other.getW2ExpiresIn()))
            && (this.getPublicKey() == null ? other.getPublicKey() == null : this.getPublicKey().equals(other.getPublicKey()))
            && (this.getPrivateKey() == null ? other.getPrivateKey() == null : this.getPrivateKey().equals(other.getPrivateKey()))
            && (this.getPublicKeyOut() == null ? other.getPublicKeyOut() == null : this.getPublicKeyOut().equals(other.getPublicKeyOut()))
            && (this.getDataEncryptType() == null ? other.getDataEncryptType() == null : this.getDataEncryptType().equals(other.getDataEncryptType()))
            && (this.getDataEncryptKey() == null ? other.getDataEncryptKey() == null : this.getDataEncryptKey().equals(other.getDataEncryptKey()))
            && (this.getDataEncryptPwd() == null ? other.getDataEncryptPwd() == null : this.getDataEncryptPwd().equals(other.getDataEncryptPwd()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateUserId() == null ? other.getCreateUserId() == null : this.getCreateUserId().equals(other.getCreateUserId()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateUserId() == null ? other.getUpdateUserId() == null : this.getUpdateUserId().equals(other.getUpdateUserId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getSubscriptionUkid() == null) ? 0 : getSubscriptionUkid().hashCode());
        result = prime * result + ((getAppUkid() == null) ? 0 : getAppUkid().hashCode());
        result = prime * result + ((getSubscriptionBuId() == null) ? 0 : getSubscriptionBuId().hashCode());
        result = prime * result + ((getSubscriptionDate() == null) ? 0 : getSubscriptionDate().hashCode());
        result = prime * result + ((getPlatformUserId() == null) ? 0 : getPlatformUserId().hashCode());
        result = prime * result + ((getPlatformUserNick() == null) ? 0 : getPlatformUserNick().hashCode());
        result = prime * result + ((getTargetAppKey() == null) ? 0 : getTargetAppKey().hashCode());
        result = prime * result + ((getAccessToken() == null) ? 0 : getAccessToken().hashCode());
        result = prime * result + ((getRefreshToken() == null) ? 0 : getRefreshToken().hashCode());
        result = prime * result + ((getLastAuthTime() == null) ? 0 : getLastAuthTime().hashCode());
        result = prime * result + ((getExpiresIn() == null) ? 0 : getExpiresIn().hashCode());
        result = prime * result + ((getReExpiresIn() == null) ? 0 : getReExpiresIn().hashCode());
        result = prime * result + ((getR1ExpiresIn() == null) ? 0 : getR1ExpiresIn().hashCode());
        result = prime * result + ((getR2ExpiresIn() == null) ? 0 : getR2ExpiresIn().hashCode());
        result = prime * result + ((getW1ExpiresIn() == null) ? 0 : getW1ExpiresIn().hashCode());
        result = prime * result + ((getW2ExpiresIn() == null) ? 0 : getW2ExpiresIn().hashCode());
        result = prime * result + ((getPublicKey() == null) ? 0 : getPublicKey().hashCode());
        result = prime * result + ((getPrivateKey() == null) ? 0 : getPrivateKey().hashCode());
        result = prime * result + ((getPublicKeyOut() == null) ? 0 : getPublicKeyOut().hashCode());
        result = prime * result + ((getDataEncryptType() == null) ? 0 : getDataEncryptType().hashCode());
        result = prime * result + ((getDataEncryptKey() == null) ? 0 : getDataEncryptKey().hashCode());
        result = prime * result + ((getDataEncryptPwd() == null) ? 0 : getDataEncryptPwd().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateUserId() == null) ? 0 : getCreateUserId().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateUserId() == null) ? 0 : getUpdateUserId().hashCode());
        return result;
    }
}