package com.wwwarehouse.xdw.datasync.dao.model;

/**
 * Created by shisheng.wang on 17/6/6.
 */
public class ItemDO {
    private Long itemId;
    private String itemName;
    private String features;

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getFeatures() {
        return features;
    }

    public void setFeatures(String features) {
        this.features = features;
    }
}
