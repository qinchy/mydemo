package com.wwwarehouse.xdw.datasync.dao.mapper;

import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ImPlatformItemDOMapper {
    long countByExample(ImPlatformItemDOExample example);

    int deleteByExample(ImPlatformItemDOExample example);

    int deleteByPrimaryKey(Long platformItemUkid);

    int insert(ImPlatformItemDO record);

    int insertSelective(ImPlatformItemDO record);

    List<ImPlatformItemDO> selectByExample(ImPlatformItemDOExample example);

    ImPlatformItemDO selectByPrimaryKey(Long platformItemUkid);

    int updateByExampleSelective(@Param("record") ImPlatformItemDO record, @Param("example") ImPlatformItemDOExample example);

    int updateByExample(@Param("record") ImPlatformItemDO record, @Param("example") ImPlatformItemDOExample example);

    int updateByPrimaryKeySelective(ImPlatformItemDO record);

    int updateByPrimaryKey(ImPlatformItemDO record);
}