package com.wwwarehouse.xdw.datasync.dao.mapper;


import com.wwwarehouse.commons.ukid.model.SyNextNumberDO;

public interface SyNextNumberMapper {
    SyNextNumberDO select(String numberType);

    String getNextNumber(SyNextNumberDO nn);

    /**
     * 获取iscs_seq的序列：从100000开始每次增1的数字
     * @return
     */
    public Long getNextSeq();

    public String getAppSecret();
}
