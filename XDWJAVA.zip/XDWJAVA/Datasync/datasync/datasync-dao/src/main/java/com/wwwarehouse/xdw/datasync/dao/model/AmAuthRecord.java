package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

public class AmAuthRecord extends BaseObject {
    private Long authRecordUkid;
    private Long appUkid;
    private Long relatedId;
    private Long createUserId;
    private Date createTime;
    private Long updateUserId;
    private Date updateTime;
    private String accessToken;
    private String refreshToken;
    private Long expiresIn;
    private Long reExpiresIn;
    private Long r1ExpiresIn;
    private Long r2ExpiresIn;
    private Long w1ExpiresIn;
    private Long w2ExpiresIn;
    private String tokenType;
    private String platformUserNick;
    private String platformUserId;
    private Long isLastAuth;

    public Long getAuthRecordUkid() {
        return authRecordUkid;
    }

    public void setAuthRecordUkid(Long authRecordUkid) {
        this.authRecordUkid = authRecordUkid;
    }

    public Long getRelatedId() {
        return relatedId;
    }

    public void setRelatedId(Long relatedId) {
        this.relatedId = relatedId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken == null ? null : accessToken.trim();
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken == null ? null : refreshToken.trim();
    }

    public Long getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Long expiresIn) {
        this.expiresIn = expiresIn;
    }

    public Long getReExpiresIn() {
        return reExpiresIn;
    }

    public void setReExpiresIn(Long reExpiresIn) {
        this.reExpiresIn = reExpiresIn;
    }

    public Long getR1ExpiresIn() {
        return r1ExpiresIn;
    }

    public void setR1ExpiresIn(Long r1ExpiresIn) {
        this.r1ExpiresIn = r1ExpiresIn;
    }

    public Long getR2ExpiresIn() {
        return r2ExpiresIn;
    }

    public void setR2ExpiresIn(Long r2ExpiresIn) {
        this.r2ExpiresIn = r2ExpiresIn;
    }

    public Long getW1ExpiresIn() {
        return w1ExpiresIn;
    }

    public void setW1ExpiresIn(Long w1ExpiresIn) {
        this.w1ExpiresIn = w1ExpiresIn;
    }

    public Long getW2ExpiresIn() {
        return w2ExpiresIn;
    }

    public void setW2ExpiresIn(Long w2ExpiresIn) {
        this.w2ExpiresIn = w2ExpiresIn;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType == null ? null : tokenType.trim();
    }

    public String getPlatformUserNick() {
        return platformUserNick;
    }

    public void setPlatformUserNick(String platformUserNick) {
        this.platformUserNick = platformUserNick == null ? null : platformUserNick.trim();
    }

    public String getPlatformUserId() {
        return platformUserId;
    }

    public void setPlatformUserId(String platformUserId) {
        this.platformUserId = platformUserId == null ? null : platformUserId.trim();
    }

    public Long getIsLastAuth() {
        return isLastAuth;
    }

    public void setIsLastAuth(Long isLastAuth) {
        this.isLastAuth = isLastAuth;
    }

	public Long getAppUkid() {
		return appUkid;
	}

	public void setAppUkid(Long appUkid) {
		this.appUkid = appUkid;
	}

	public Long getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(Long createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }
}