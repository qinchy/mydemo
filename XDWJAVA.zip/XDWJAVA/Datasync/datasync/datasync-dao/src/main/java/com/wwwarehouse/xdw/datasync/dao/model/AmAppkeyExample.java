package com.wwwarehouse.xdw.datasync.dao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AmAppkeyExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private static final long serialVersionUID = 1L;

    private Integer limit;

    private Integer offset;

    public AmAppkeyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria implements Serializable {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAppUkidIsNull() {
            addCriterion("APP_UKID is null");
            return (Criteria) this;
        }

        public Criteria andAppUkidIsNotNull() {
            addCriterion("APP_UKID is not null");
            return (Criteria) this;
        }

        public Criteria andAppUkidEqualTo(Long value) {
            addCriterion("APP_UKID =", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotEqualTo(Long value) {
            addCriterion("APP_UKID <>", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThan(Long value) {
            addCriterion("APP_UKID >", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidGreaterThanOrEqualTo(Long value) {
            addCriterion("APP_UKID >=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThan(Long value) {
            addCriterion("APP_UKID <", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidLessThanOrEqualTo(Long value) {
            addCriterion("APP_UKID <=", value, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidIn(List<Long> values) {
            addCriterion("APP_UKID in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotIn(List<Long> values) {
            addCriterion("APP_UKID not in", values, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidBetween(Long value1, Long value2) {
            addCriterion("APP_UKID between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppUkidNotBetween(Long value1, Long value2) {
            addCriterion("APP_UKID not between", value1, value2, "appUkid");
            return (Criteria) this;
        }

        public Criteria andAppNameIsNull() {
            addCriterion("APP_NAME is null");
            return (Criteria) this;
        }

        public Criteria andAppNameIsNotNull() {
            addCriterion("APP_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andAppNameEqualTo(String value) {
            addCriterion("APP_NAME =", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotEqualTo(String value) {
            addCriterion("APP_NAME <>", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameGreaterThan(String value) {
            addCriterion("APP_NAME >", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameGreaterThanOrEqualTo(String value) {
            addCriterion("APP_NAME >=", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLessThan(String value) {
            addCriterion("APP_NAME <", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLessThanOrEqualTo(String value) {
            addCriterion("APP_NAME <=", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLike(String value) {
            addCriterion("APP_NAME like", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotLike(String value) {
            addCriterion("APP_NAME not like", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameIn(List<String> values) {
            addCriterion("APP_NAME in", values, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotIn(List<String> values) {
            addCriterion("APP_NAME not in", values, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameBetween(String value1, String value2) {
            addCriterion("APP_NAME between", value1, value2, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotBetween(String value1, String value2) {
            addCriterion("APP_NAME not between", value1, value2, "appName");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNull() {
            addCriterion("PLATFORM_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIsNotNull() {
            addCriterion("PLATFORM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIdEqualTo(Long value) {
            addCriterion("PLATFORM_ID =", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotEqualTo(Long value) {
            addCriterion("PLATFORM_ID <>", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThan(Long value) {
            addCriterion("PLATFORM_ID >", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdGreaterThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID >=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThan(Long value) {
            addCriterion("PLATFORM_ID <", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdLessThanOrEqualTo(Long value) {
            addCriterion("PLATFORM_ID <=", value, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdIn(List<Long> values) {
            addCriterion("PLATFORM_ID in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotIn(List<Long> values) {
            addCriterion("PLATFORM_ID not in", values, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andPlatformIdNotBetween(Long value1, Long value2) {
            addCriterion("PLATFORM_ID not between", value1, value2, "platformId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdIsNull() {
            addCriterion("OWNER_BU_ID is null");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdIsNotNull() {
            addCriterion("OWNER_BU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdEqualTo(Long value) {
            addCriterion("OWNER_BU_ID =", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdNotEqualTo(Long value) {
            addCriterion("OWNER_BU_ID <>", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdGreaterThan(Long value) {
            addCriterion("OWNER_BU_ID >", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdGreaterThanOrEqualTo(Long value) {
            addCriterion("OWNER_BU_ID >=", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdLessThan(Long value) {
            addCriterion("OWNER_BU_ID <", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdLessThanOrEqualTo(Long value) {
            addCriterion("OWNER_BU_ID <=", value, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdIn(List<Long> values) {
            addCriterion("OWNER_BU_ID in", values, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdNotIn(List<Long> values) {
            addCriterion("OWNER_BU_ID not in", values, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdBetween(Long value1, Long value2) {
            addCriterion("OWNER_BU_ID between", value1, value2, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andOwnerBuIdNotBetween(Long value1, Long value2) {
            addCriterion("OWNER_BU_ID not between", value1, value2, "ownerBuId");
            return (Criteria) this;
        }

        public Criteria andAppTypeIsNull() {
            addCriterion("APP_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andAppTypeIsNotNull() {
            addCriterion("APP_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andAppTypeEqualTo(String value) {
            addCriterion("APP_TYPE =", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeNotEqualTo(String value) {
            addCriterion("APP_TYPE <>", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeGreaterThan(String value) {
            addCriterion("APP_TYPE >", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeGreaterThanOrEqualTo(String value) {
            addCriterion("APP_TYPE >=", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeLessThan(String value) {
            addCriterion("APP_TYPE <", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeLessThanOrEqualTo(String value) {
            addCriterion("APP_TYPE <=", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeLike(String value) {
            addCriterion("APP_TYPE like", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeNotLike(String value) {
            addCriterion("APP_TYPE not like", value, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeIn(List<String> values) {
            addCriterion("APP_TYPE in", values, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeNotIn(List<String> values) {
            addCriterion("APP_TYPE not in", values, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeBetween(String value1, String value2) {
            addCriterion("APP_TYPE between", value1, value2, "appType");
            return (Criteria) this;
        }

        public Criteria andAppTypeNotBetween(String value1, String value2) {
            addCriterion("APP_TYPE not between", value1, value2, "appType");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("STATUS is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Long value) {
            addCriterion("STATUS =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Long value) {
            addCriterion("STATUS <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Long value) {
            addCriterion("STATUS >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Long value) {
            addCriterion("STATUS >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Long value) {
            addCriterion("STATUS <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Long value) {
            addCriterion("STATUS <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Long> values) {
            addCriterion("STATUS in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Long> values) {
            addCriterion("STATUS not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Long value1, Long value2) {
            addCriterion("STATUS between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Long value1, Long value2) {
            addCriterion("STATUS not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andAuthTypeIsNull() {
            addCriterion("AUTH_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andAuthTypeIsNotNull() {
            addCriterion("AUTH_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andAuthTypeEqualTo(String value) {
            addCriterion("AUTH_TYPE =", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeNotEqualTo(String value) {
            addCriterion("AUTH_TYPE <>", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeGreaterThan(String value) {
            addCriterion("AUTH_TYPE >", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeGreaterThanOrEqualTo(String value) {
            addCriterion("AUTH_TYPE >=", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeLessThan(String value) {
            addCriterion("AUTH_TYPE <", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeLessThanOrEqualTo(String value) {
            addCriterion("AUTH_TYPE <=", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeLike(String value) {
            addCriterion("AUTH_TYPE like", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeNotLike(String value) {
            addCriterion("AUTH_TYPE not like", value, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeIn(List<String> values) {
            addCriterion("AUTH_TYPE in", values, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeNotIn(List<String> values) {
            addCriterion("AUTH_TYPE not in", values, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeBetween(String value1, String value2) {
            addCriterion("AUTH_TYPE between", value1, value2, "authType");
            return (Criteria) this;
        }

        public Criteria andAuthTypeNotBetween(String value1, String value2) {
            addCriterion("AUTH_TYPE not between", value1, value2, "authType");
            return (Criteria) this;
        }

        public Criteria andApiUrlIsNull() {
            addCriterion("API_URL is null");
            return (Criteria) this;
        }

        public Criteria andApiUrlIsNotNull() {
            addCriterion("API_URL is not null");
            return (Criteria) this;
        }

        public Criteria andApiUrlEqualTo(String value) {
            addCriterion("API_URL =", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlNotEqualTo(String value) {
            addCriterion("API_URL <>", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlGreaterThan(String value) {
            addCriterion("API_URL >", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlGreaterThanOrEqualTo(String value) {
            addCriterion("API_URL >=", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlLessThan(String value) {
            addCriterion("API_URL <", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlLessThanOrEqualTo(String value) {
            addCriterion("API_URL <=", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlLike(String value) {
            addCriterion("API_URL like", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlNotLike(String value) {
            addCriterion("API_URL not like", value, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlIn(List<String> values) {
            addCriterion("API_URL in", values, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlNotIn(List<String> values) {
            addCriterion("API_URL not in", values, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlBetween(String value1, String value2) {
            addCriterion("API_URL between", value1, value2, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andApiUrlNotBetween(String value1, String value2) {
            addCriterion("API_URL not between", value1, value2, "apiUrl");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNull() {
            addCriterion("APP_KEY is null");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNotNull() {
            addCriterion("APP_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andAppKeyEqualTo(String value) {
            addCriterion("APP_KEY =", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotEqualTo(String value) {
            addCriterion("APP_KEY <>", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThan(String value) {
            addCriterion("APP_KEY >", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("APP_KEY >=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThan(String value) {
            addCriterion("APP_KEY <", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThanOrEqualTo(String value) {
            addCriterion("APP_KEY <=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLike(String value) {
            addCriterion("APP_KEY like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotLike(String value) {
            addCriterion("APP_KEY not like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyIn(List<String> values) {
            addCriterion("APP_KEY in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotIn(List<String> values) {
            addCriterion("APP_KEY not in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyBetween(String value1, String value2) {
            addCriterion("APP_KEY between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotBetween(String value1, String value2) {
            addCriterion("APP_KEY not between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNull() {
            addCriterion("APP_SECRET is null");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNotNull() {
            addCriterion("APP_SECRET is not null");
            return (Criteria) this;
        }

        public Criteria andAppSecretEqualTo(String value) {
            addCriterion("APP_SECRET =", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotEqualTo(String value) {
            addCriterion("APP_SECRET <>", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThan(String value) {
            addCriterion("APP_SECRET >", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("APP_SECRET >=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThan(String value) {
            addCriterion("APP_SECRET <", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThanOrEqualTo(String value) {
            addCriterion("APP_SECRET <=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLike(String value) {
            addCriterion("APP_SECRET like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotLike(String value) {
            addCriterion("APP_SECRET not like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretIn(List<String> values) {
            addCriterion("APP_SECRET in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotIn(List<String> values) {
            addCriterion("APP_SECRET not in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretBetween(String value1, String value2) {
            addCriterion("APP_SECRET between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotBetween(String value1, String value2) {
            addCriterion("APP_SECRET not between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andDataFormatIsNull() {
            addCriterion("DATA_FORMAT is null");
            return (Criteria) this;
        }

        public Criteria andDataFormatIsNotNull() {
            addCriterion("DATA_FORMAT is not null");
            return (Criteria) this;
        }

        public Criteria andDataFormatEqualTo(String value) {
            addCriterion("DATA_FORMAT =", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatNotEqualTo(String value) {
            addCriterion("DATA_FORMAT <>", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatGreaterThan(String value) {
            addCriterion("DATA_FORMAT >", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_FORMAT >=", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatLessThan(String value) {
            addCriterion("DATA_FORMAT <", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatLessThanOrEqualTo(String value) {
            addCriterion("DATA_FORMAT <=", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatLike(String value) {
            addCriterion("DATA_FORMAT like", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatNotLike(String value) {
            addCriterion("DATA_FORMAT not like", value, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatIn(List<String> values) {
            addCriterion("DATA_FORMAT in", values, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatNotIn(List<String> values) {
            addCriterion("DATA_FORMAT not in", values, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatBetween(String value1, String value2) {
            addCriterion("DATA_FORMAT between", value1, value2, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andDataFormatNotBetween(String value1, String value2) {
            addCriterion("DATA_FORMAT not between", value1, value2, "dataFormat");
            return (Criteria) this;
        }

        public Criteria andCharsetIsNull() {
            addCriterion("CHARSET is null");
            return (Criteria) this;
        }

        public Criteria andCharsetIsNotNull() {
            addCriterion("CHARSET is not null");
            return (Criteria) this;
        }

        public Criteria andCharsetEqualTo(String value) {
            addCriterion("CHARSET =", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetNotEqualTo(String value) {
            addCriterion("CHARSET <>", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetGreaterThan(String value) {
            addCriterion("CHARSET >", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetGreaterThanOrEqualTo(String value) {
            addCriterion("CHARSET >=", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetLessThan(String value) {
            addCriterion("CHARSET <", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetLessThanOrEqualTo(String value) {
            addCriterion("CHARSET <=", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetLike(String value) {
            addCriterion("CHARSET like", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetNotLike(String value) {
            addCriterion("CHARSET not like", value, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetIn(List<String> values) {
            addCriterion("CHARSET in", values, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetNotIn(List<String> values) {
            addCriterion("CHARSET not in", values, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetBetween(String value1, String value2) {
            addCriterion("CHARSET between", value1, value2, "charset");
            return (Criteria) this;
        }

        public Criteria andCharsetNotBetween(String value1, String value2) {
            addCriterion("CHARSET not between", value1, value2, "charset");
            return (Criteria) this;
        }

        public Criteria andSignMethodIsNull() {
            addCriterion("SIGN_METHOD is null");
            return (Criteria) this;
        }

        public Criteria andSignMethodIsNotNull() {
            addCriterion("SIGN_METHOD is not null");
            return (Criteria) this;
        }

        public Criteria andSignMethodEqualTo(String value) {
            addCriterion("SIGN_METHOD =", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodNotEqualTo(String value) {
            addCriterion("SIGN_METHOD <>", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodGreaterThan(String value) {
            addCriterion("SIGN_METHOD >", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodGreaterThanOrEqualTo(String value) {
            addCriterion("SIGN_METHOD >=", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodLessThan(String value) {
            addCriterion("SIGN_METHOD <", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodLessThanOrEqualTo(String value) {
            addCriterion("SIGN_METHOD <=", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodLike(String value) {
            addCriterion("SIGN_METHOD like", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodNotLike(String value) {
            addCriterion("SIGN_METHOD not like", value, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodIn(List<String> values) {
            addCriterion("SIGN_METHOD in", values, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodNotIn(List<String> values) {
            addCriterion("SIGN_METHOD not in", values, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodBetween(String value1, String value2) {
            addCriterion("SIGN_METHOD between", value1, value2, "signMethod");
            return (Criteria) this;
        }

        public Criteria andSignMethodNotBetween(String value1, String value2) {
            addCriterion("SIGN_METHOD not between", value1, value2, "signMethod");
            return (Criteria) this;
        }

        public Criteria andDataEncryptIsNull() {
            addCriterion("DATA_ENCRYPT is null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptIsNotNull() {
            addCriterion("DATA_ENCRYPT is not null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptEqualTo(Long value) {
            addCriterion("DATA_ENCRYPT =", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptNotEqualTo(Long value) {
            addCriterion("DATA_ENCRYPT <>", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptGreaterThan(Long value) {
            addCriterion("DATA_ENCRYPT >", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptGreaterThanOrEqualTo(Long value) {
            addCriterion("DATA_ENCRYPT >=", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptLessThan(Long value) {
            addCriterion("DATA_ENCRYPT <", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptLessThanOrEqualTo(Long value) {
            addCriterion("DATA_ENCRYPT <=", value, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptIn(List<Long> values) {
            addCriterion("DATA_ENCRYPT in", values, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptNotIn(List<Long> values) {
            addCriterion("DATA_ENCRYPT not in", values, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptBetween(Long value1, Long value2) {
            addCriterion("DATA_ENCRYPT between", value1, value2, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptNotBetween(Long value1, Long value2) {
            addCriterion("DATA_ENCRYPT not between", value1, value2, "dataEncrypt");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIsNull() {
            addCriterion("DATA_ENCRYPT_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIsNotNull() {
            addCriterion("DATA_ENCRYPT_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE =", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <>", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeGreaterThan(String value) {
            addCriterion("DATA_ENCRYPT_TYPE >", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE >=", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLessThan(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLessThanOrEqualTo(String value) {
            addCriterion("DATA_ENCRYPT_TYPE <=", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeLike(String value) {
            addCriterion("DATA_ENCRYPT_TYPE like", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotLike(String value) {
            addCriterion("DATA_ENCRYPT_TYPE not like", value, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_TYPE in", values, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotIn(List<String> values) {
            addCriterion("DATA_ENCRYPT_TYPE not in", values, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_TYPE between", value1, value2, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andDataEncryptTypeNotBetween(String value1, String value2) {
            addCriterion("DATA_ENCRYPT_TYPE not between", value1, value2, "dataEncryptType");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathIsNull() {
            addCriterion("AUTH_FILE_PATH is null");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathIsNotNull() {
            addCriterion("AUTH_FILE_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathEqualTo(String value) {
            addCriterion("AUTH_FILE_PATH =", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathNotEqualTo(String value) {
            addCriterion("AUTH_FILE_PATH <>", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathGreaterThan(String value) {
            addCriterion("AUTH_FILE_PATH >", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathGreaterThanOrEqualTo(String value) {
            addCriterion("AUTH_FILE_PATH >=", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathLessThan(String value) {
            addCriterion("AUTH_FILE_PATH <", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathLessThanOrEqualTo(String value) {
            addCriterion("AUTH_FILE_PATH <=", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathLike(String value) {
            addCriterion("AUTH_FILE_PATH like", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathNotLike(String value) {
            addCriterion("AUTH_FILE_PATH not like", value, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathIn(List<String> values) {
            addCriterion("AUTH_FILE_PATH in", values, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathNotIn(List<String> values) {
            addCriterion("AUTH_FILE_PATH not in", values, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathBetween(String value1, String value2) {
            addCriterion("AUTH_FILE_PATH between", value1, value2, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andAuthFilePathNotBetween(String value1, String value2) {
            addCriterion("AUTH_FILE_PATH not between", value1, value2, "authFilePath");
            return (Criteria) this;
        }

        public Criteria andWhiteIpIsNull() {
            addCriterion("WHITE_IP is null");
            return (Criteria) this;
        }

        public Criteria andWhiteIpIsNotNull() {
            addCriterion("WHITE_IP is not null");
            return (Criteria) this;
        }

        public Criteria andWhiteIpEqualTo(String value) {
            addCriterion("WHITE_IP =", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpNotEqualTo(String value) {
            addCriterion("WHITE_IP <>", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpGreaterThan(String value) {
            addCriterion("WHITE_IP >", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpGreaterThanOrEqualTo(String value) {
            addCriterion("WHITE_IP >=", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpLessThan(String value) {
            addCriterion("WHITE_IP <", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpLessThanOrEqualTo(String value) {
            addCriterion("WHITE_IP <=", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpLike(String value) {
            addCriterion("WHITE_IP like", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpNotLike(String value) {
            addCriterion("WHITE_IP not like", value, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpIn(List<String> values) {
            addCriterion("WHITE_IP in", values, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpNotIn(List<String> values) {
            addCriterion("WHITE_IP not in", values, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpBetween(String value1, String value2) {
            addCriterion("WHITE_IP between", value1, value2, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andWhiteIpNotBetween(String value1, String value2) {
            addCriterion("WHITE_IP not between", value1, value2, "whiteIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpIsNull() {
            addCriterion("BLACK_IP is null");
            return (Criteria) this;
        }

        public Criteria andBlackIpIsNotNull() {
            addCriterion("BLACK_IP is not null");
            return (Criteria) this;
        }

        public Criteria andBlackIpEqualTo(String value) {
            addCriterion("BLACK_IP =", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpNotEqualTo(String value) {
            addCriterion("BLACK_IP <>", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpGreaterThan(String value) {
            addCriterion("BLACK_IP >", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpGreaterThanOrEqualTo(String value) {
            addCriterion("BLACK_IP >=", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpLessThan(String value) {
            addCriterion("BLACK_IP <", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpLessThanOrEqualTo(String value) {
            addCriterion("BLACK_IP <=", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpLike(String value) {
            addCriterion("BLACK_IP like", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpNotLike(String value) {
            addCriterion("BLACK_IP not like", value, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpIn(List<String> values) {
            addCriterion("BLACK_IP in", values, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpNotIn(List<String> values) {
            addCriterion("BLACK_IP not in", values, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpBetween(String value1, String value2) {
            addCriterion("BLACK_IP between", value1, value2, "blackIp");
            return (Criteria) this;
        }

        public Criteria andBlackIpNotBetween(String value1, String value2) {
            addCriterion("BLACK_IP not between", value1, value2, "blackIp");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatIsNull() {
            addCriterion("SYS_PARAM_FORMAT is null");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatIsNotNull() {
            addCriterion("SYS_PARAM_FORMAT is not null");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatEqualTo(String value) {
            addCriterion("SYS_PARAM_FORMAT =", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatNotEqualTo(String value) {
            addCriterion("SYS_PARAM_FORMAT <>", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatGreaterThan(String value) {
            addCriterion("SYS_PARAM_FORMAT >", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatGreaterThanOrEqualTo(String value) {
            addCriterion("SYS_PARAM_FORMAT >=", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatLessThan(String value) {
            addCriterion("SYS_PARAM_FORMAT <", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatLessThanOrEqualTo(String value) {
            addCriterion("SYS_PARAM_FORMAT <=", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatLike(String value) {
            addCriterion("SYS_PARAM_FORMAT like", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatNotLike(String value) {
            addCriterion("SYS_PARAM_FORMAT not like", value, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatIn(List<String> values) {
            addCriterion("SYS_PARAM_FORMAT in", values, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatNotIn(List<String> values) {
            addCriterion("SYS_PARAM_FORMAT not in", values, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatBetween(String value1, String value2) {
            addCriterion("SYS_PARAM_FORMAT between", value1, value2, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andSysParamFormatNotBetween(String value1, String value2) {
            addCriterion("SYS_PARAM_FORMAT not between", value1, value2, "sysParamFormat");
            return (Criteria) this;
        }

        public Criteria andServiceCodeIsNull() {
            addCriterion("SERVICE_CODE is null");
            return (Criteria) this;
        }

        public Criteria andServiceCodeIsNotNull() {
            addCriterion("SERVICE_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andServiceCodeEqualTo(String value) {
            addCriterion("SERVICE_CODE =", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeNotEqualTo(String value) {
            addCriterion("SERVICE_CODE <>", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeGreaterThan(String value) {
            addCriterion("SERVICE_CODE >", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeGreaterThanOrEqualTo(String value) {
            addCriterion("SERVICE_CODE >=", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeLessThan(String value) {
            addCriterion("SERVICE_CODE <", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeLessThanOrEqualTo(String value) {
            addCriterion("SERVICE_CODE <=", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeLike(String value) {
            addCriterion("SERVICE_CODE like", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeNotLike(String value) {
            addCriterion("SERVICE_CODE not like", value, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeIn(List<String> values) {
            addCriterion("SERVICE_CODE in", values, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeNotIn(List<String> values) {
            addCriterion("SERVICE_CODE not in", values, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeBetween(String value1, String value2) {
            addCriterion("SERVICE_CODE between", value1, value2, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andServiceCodeNotBetween(String value1, String value2) {
            addCriterion("SERVICE_CODE not between", value1, value2, "serviceCode");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdIsNull() {
            addCriterion("PLATFORM_ACCOUNT_ID is null");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdIsNotNull() {
            addCriterion("PLATFORM_ACCOUNT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdEqualTo(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID =", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdNotEqualTo(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID <>", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdGreaterThan(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID >", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdGreaterThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID >=", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdLessThan(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID <", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdLessThanOrEqualTo(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID <=", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdLike(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID like", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdNotLike(String value) {
            addCriterion("PLATFORM_ACCOUNT_ID not like", value, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdIn(List<String> values) {
            addCriterion("PLATFORM_ACCOUNT_ID in", values, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdNotIn(List<String> values) {
            addCriterion("PLATFORM_ACCOUNT_ID not in", values, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdBetween(String value1, String value2) {
            addCriterion("PLATFORM_ACCOUNT_ID between", value1, value2, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andPlatformAccountIdNotBetween(String value1, String value2) {
            addCriterion("PLATFORM_ACCOUNT_ID not between", value1, value2, "platformAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNull() {
            addCriterion("CREATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIsNotNull() {
            addCriterion("CREATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdEqualTo(Long value) {
            addCriterion("CREATE_USER_ID =", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <>", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThan(Long value) {
            addCriterion("CREATE_USER_ID >", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID >=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThan(Long value) {
            addCriterion("CREATE_USER_ID <", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("CREATE_USER_ID <=", value, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdIn(List<Long> values) {
            addCriterion("CREATE_USER_ID in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotIn(List<Long> values) {
            addCriterion("CREATE_USER_ID not in", values, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andCreateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("CREATE_USER_ID not between", value1, value2, "createUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("UPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("UPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("UPDATE_TIME =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("UPDATE_TIME <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("UPDATE_TIME >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("UPDATE_TIME <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TIME <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("UPDATE_TIME in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("UPDATE_TIME not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TIME not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("UPDATE_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("UPDATE_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(Long value) {
            addCriterion("UPDATE_USER_ID >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(Long value) {
            addCriterion("UPDATE_USER_ID <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(Long value) {
            addCriterion("UPDATE_USER_ID <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<Long> values) {
            addCriterion("UPDATE_USER_ID not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(Long value1, Long value2) {
            addCriterion("UPDATE_USER_ID not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria implements Serializable {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion implements Serializable {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}