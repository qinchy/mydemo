package com.wwwarehouse.xdw.datasync.dao.model;

import java.util.Date;

public class AmDownTimeDO extends BaseObject{
	private Long ukid;
	private Long relatedId;
	private Date startDownTime;
	private Date endDownTime;
	private Date createTime;
	private Date closeTime;
	private Date updateTime;
	private Long openUserId;
	private Long closeUserId;
	private Integer isValid;

	public Long getUkid() {
		return ukid;
	}

	public void setUkid(Long ukid) {
		this.ukid = ukid;
	}

	public Long getRelatedId() {
		return relatedId;
	}

	public void setRelatedId(Long relatedId) {
		this.relatedId = relatedId;
	}

	public Date getStartDownTime() {
		return startDownTime;
	}

	public void setStartDownTime(Date startDownTime) {
		this.startDownTime = startDownTime;
	}

	public Date getEndDownTime() {
		return endDownTime;
	}

	public void setEndDownTime(Date endDownTime) {
		this.endDownTime = endDownTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getCloseTime() {
		return closeTime;
	}

	public void setCloseTime(Date closeTime) {
		this.closeTime = closeTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getOpenUserId() {
		return openUserId;
	}

	public void setOpenUserId(Long openUserId) {
		this.openUserId = openUserId;
	}

	public Long getCloseUserId() {
		return closeUserId;
	}

	public void setCloseUserId(Long closeUserId) {
		this.closeUserId = closeUserId;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}
}