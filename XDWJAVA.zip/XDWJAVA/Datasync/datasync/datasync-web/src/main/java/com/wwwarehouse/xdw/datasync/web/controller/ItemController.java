package com.wwwarehouse.xdw.datasync.web.controller;

import com.wwwarehouse.commons.web.BaseResult;
import com.wwwarehouse.xdw.datasync.model.Item;
import com.wwwarehouse.xdw.datasync.service.ItemService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

/**
 * Created by shisheng.wang on 17/6/6.
 */
@RequestMapping("/item")
@Controller
public class ItemController {

    @Resource
    ItemService itemService;

    @RequestMapping("/get")
    @ResponseBody
    public Object get() {
        Item item = itemService.get(51885300000006948L);
        BaseResult baseResult = new BaseResult(0, "", item);
        baseResult.setCode(0);
        return baseResult;
    }
}
