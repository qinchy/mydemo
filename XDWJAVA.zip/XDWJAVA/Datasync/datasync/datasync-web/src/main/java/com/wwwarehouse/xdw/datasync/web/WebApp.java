package com.wwwarehouse.xdw.datasync.web;

/**
 * Created by shisheng.wang on 17/6/6.
 */
public class WebApp {

}
