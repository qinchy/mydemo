package com.wwwarehouse.xdw.datasync.web.mq;


import com.wwwarehouse.commons.mq.MessageListener;
import com.wwwarehouse.commons.mq.MqConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by shisheng.wang on 17/6/15.
 */
public class DemoListener extends MessageListener {
    private static final Logger logger = LoggerFactory.getLogger(DemoListener.class);

    @Override
    public void onMessage(String topic, String key, String value) throws Exception {
        logger.info("t {} k {} v {}", topic, key, value);
    }
}
