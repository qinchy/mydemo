package com.wwwarehouse.xdw.datasync.web.controller.edi;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.service.IAmAppkeyService;
import com.wwwarehouse.xdw.datasync.service.IAmSubscriptionService;
import com.wwwarehouse.xdw.datasync.service.IAuthService;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by guanjianjun on 2016/10/9 0009.
 */
@Controller
@RequestMapping("/edi")
public class GrantAction {
    private static final Logger logger = LogManager.getLogger(GrantAction.class);

    @Resource
    private IAmAppkeyService amAppkeyService;
//    @Resource
//    private IBaShopService baShopService;
    @Resource
    private IAuthService authService;
    @Resource
    private IAmSubscriptionService amSubscriptionService;


    @ResponseBody
    @RequestMapping("grant")
    public AbsResponse<Object> grant(HttpServletResponse response,
                                     HttpServletRequest request) throws Exception {
        String code = request.getParameter("code");
        String state = request.getParameter("state");
//		String error = request.getParameter("error");
        String errorDescription = request.getParameter("error_description");
        logger.info("code:" + code + "____ ,state:" + state + "____ ,errorDescription" + errorDescription);
        AbsResponse<String> ret = new AbsResponse<>();
        Long userId = null;
//        try {
////            RequestCheckUtils.checkNotEmptyI18n(state, 905001, "state");
            String[] states = state.split("-");
            if (states.length < 4) {
                logger.error("参数格式不合法");
//                throw new ApiCheckException(905001, "参数格式不合法！");
            }
            userId = NumberUtils.toLong(states[0]);;
            Long cardUkid = NumberUtils.toLong(states[1]);
            Long platformId = NumberUtils.toLong(states[2]);
            Long shopId = NumberUtils.toLong(states[3]);// 可能是随机数，后面再去赋真实值

            if (StringUtils.isEmpty(code)) {
                AbsResponse<String> translateres = translate(errorDescription);
                logger.error(translateres.getMsg());
//                throw new ApiCheckException(translateres.getCode(), translateres.getMsg());
            }
//            RequestCheckUtils.checkNotEmptyI18n(code, 905001, "code");
            if (userId == null || cardUkid == null || platformId == null || shopId == null) {
                logger.error("参数格式不合法");
//                throw new ApiCheckException(905001, "参数格式不合法！");
            }


            AmAppkeyDTO amAppKey = amAppkeyService.getByType(platformId, Constants.WCKJ, "EC");
            if (amAppKey == null) {
//               throw new ApiCheckException(905001, "平台授权信息不完整！");
            }
              AbsResponse<AmAuthRecordDTO> authResult = authService.grantAuth(amAppKey,code);

            if (!authResult.isSuccess()) {
//                throw new ApiCheckException(authResult.getCode(), authResult.getMsg());
            }
//
            AmAuthRecordDTO authRecord = authResult.getData();
            authRecord.setAppUkid(amAppKey.getAppUkid());
            AbsResponse<AmAppSubscriptionDTO> saveAuthResult = authService.saveAuth(shopId,
                    platformId, authRecord, userId);
            if (!saveAuthResult.isSuccess()) {
//                throw new ApiCheckException(saveAuthResult.getCode(), saveAuthResult.getMsg());
            }
            AmAppSubscriptionDTO subscription = saveAuthResult.getData();
            subscription.setApp(amAppKey);
            subscription.setPlatformId(amAppKey.getPlatformId());
//
//            BaShop shop = baShopService.get(shopId);
//
//            if (shop != null) {
//                updateShop(subscription, shop, userId);
//            } else {
//                AbsResponse<Long> saveShopResult = catchShop(shopId, subscription, userId, cardUkid);
//                if (!saveShopResult.isSuccess()) {
//                    throw new ApiCheckException(saveShopResult.getCode(), saveShopResult.getMsg());
//                }
//                logger.info("========================catchShop成功=========================");
//                shop = baShopService.get(saveShopResult.getData());
//                subscription.setSubscriptionBuId(shop.getShopId());
//            }
//
//            ret.setData(shop);
//            ret.setMsg("店铺授权成功");
//            ReqUtil.setSuccAbs(ret, 0);
//            push(cardUkid, userId, shop.getSellerId(), subscription.getSubscriptionUkid());
//        } catch (ApiCheckException e) {
//            ret.setResult(e.getErrCode(), e.getErrMsg());
//            ReqUtil.setErrAbs(ret, e.getErrCode(), e.getErrMsg());
//            logger.error("ApiCheckException", e);
//        } catch (Exception e) {
//            ret.setResult(905001, "发生异常:" + e.getMessage());
//            ReqUtil.setErrAbs(ret, 905001);
//            logger.error(state, e);
//        }
////        finally {
////            if (api != null) {
////                mongoDao.dumpRecords(api.getAccessLogList());
////            }
//
////        }
//        push(ret, String.valueOf(userId));
        return null;
    }

//    /*发送任务消息*/
//    private void push(Long cardUkid, Long userId, Long ownerBuId, Long subscriptionUkid) {
//        try {
//            Map<String, Object> map = new HashMap<>();
//            map.put("subscriptionUkid", subscriptionUkid);
//            map.put("ownerBuId", ownerBuId);
//
//            taskRouteService.createFeatureAndNewTask(cardUkid,
//                    "ActiveShopService", userId, subscriptionUkid, null, map, "DONE", userId);
//        } catch (Exception e) {
//            logger.error(e.getMessage(), e);
//        }
//    }

//    private AbsResponse<Long> catchShop(Long shopId, AmAppSubscriptionDTO subscription, Long userId, Long cardUkid) throws Exception {
//        AbsResponse<Long> catchResult = new AbsResponse<>();
//        IShopApi api = null;
//        try {
//            api = ApiUtil.getShopApi(subscription);
//            AbsResponse<cn.com.iscs.external.entity.BaShop> baShopRes = null;
//            baShopRes = api.getShop(subscription.getPlatformUserNick());
//            if (baShopRes.getCode() != 0) {
//                throw new ApiCheckException(baShopRes.getCode(), baShopRes.getMsg());
//            }
//
//            AbsResponse<BaShop> shopRes = saveShop(subscription, baShopRes.getData(), userId, cardUkid);
//            if (shopRes.getCode() != 0) {
//                throw new ApiCheckException(shopRes.getCode(), shopRes.getMsg());
//            }
//            logger.info("========================saveShop成功=========================");
//
//
//            //shopId可能是前面产生的随机机，数据与保存好的店铺Id不一致，则要修改
//            if (!shopId.equals(shopRes.getData().getShopId())) {
//
//
//                subscription.setSubscriptionBuId(shopRes.getData().getShopId());
//                amSubscriptionService.updateAuthBuId(subscription);
//                logger.info("========================amSubscriptionService跟新=========================");
//                amAuthRecordMapper.updateRelatedId(subscription.getAppUkid(), shopId, shopRes.getData().getShopId());
//                logger.info("========================amAuthRecordMapper.updateRelatedId=========================");
//            }
//
//            catchResult.setData(shopRes.getData().getShopId());
//            logger.info("========================catchResult========================");
//        } catch (ApiCheckException e) {
//            logger.error(e.getErrCode() + "", e);
//            ReqUtil.setErrAbs(catchResult, e.getErrCode(), e.getErrMsg());
//        } catch (Exception e) {
//            logger.error(905001, e);
//            ReqUtil.setErrAbs(catchResult, 905001, "发生异常:" + e.getMessage());
//        }
////        finally {
////            if (api != null) {
////                mongoDao.dumpRecords(api.getAccessLogList());
////            }
////        }
//        return catchResult;
//    }

//    private void updateShop(AmAppSubscription subscription, BaShop baShop, Long userId) throws Exception {
//        baShop.setIsAuth(1L);
//        baShop.setUpdateUserId(userId);
//        Date expiredDate = DateUtil.addSeconds(subscription.getLastAuthTime(), subscription.getExpiresIn().intValue());
//        baShop.setAuthExpireIn(expiredDate);
//        baShopService.updateAuth(baShop);
//    }

//    private AbsResponse<BaShop> saveShop(AmAppSubscription subscription,
//                                         cn.com.iscs.external.entity.BaShop shop, Long userId, Long cardUkid) throws Exception {
//        Long ownerBuId = msCardService.getCreatorByCardUkid(userId, cardUkid);
//        Long platformId = subscription.getApp().getPlatformId();
//
//        Date expiredDate = null;
//        if (subscription.getExpiresIn() != null) {
//            expiredDate = DateUtil.addSeconds(subscription.getLastAuthTime(),
//                    subscription.getExpiresIn().intValue());
//        }
//
//        AbsResponse<BaShop> res = baShopService.saveShop(ownerBuId, shop.getSellerNick(),
//                shop.getShopName(), platformId, 1L, 10L, shop.getShopCreated(), expiredDate, null, userId);
//        if (!res.isSuccess()) {
//            return res.setResult(905003, shop.getSellerNick());
//        }
//
//        BaShop baShop = res.getData();
//        String unitCode = baUnitCustomService.getUnitCode(ownerBuId,userId,"件");
//		/*新增物（店铺） */
//        ImItem item = itemService.saveItem(IdentifyType.SHOP.name(), baShop.getShopName(),
//                unitCode, 10L, null, null, null, null, null, userId, baShop.getShopId());
//
//		/*识别*/
//        identifyRelationService.addCmIdentifyRelation(baShop.getShopId().toString(),
//                ownerBuId, item, userId, IdentifyType.SHOP.name());
//
//		/*参与者*/
//        participantService.addPPT(baShop.getShopName(), "BS", baShop.getShopId(), (short) 1, userId);
//
//        //保存销售服务作业点
//        gsSellPointService.savePointShopRelation(baShop.getShopId(), baShop.getPlatformId(), baShop.getSellerNick(), baShop.getSellerId(), userId);
//        res.setData(baShop);
//        return res;
//    }

    private AbsResponse<String> translate(String errorDescription) {
        AbsResponse<String> ret = new AbsResponse<>();
        if (errorDescription == null) {
            return ret.setResult(905001, "无错误信息");
        }
        if (errorDescription.contains("need purchase")) {
            return ret.setResult(905002, "您还没有订购网仓应用，请先购买。");
        }

        return ret.setResult(905001, errorDescription);
    }

//    private void push(AbsResponse<?> abs, String userId) {
//        PushClient pushClient = (PushClient) SpringUtil.getBean("pushClient");
//        //String json = JsonUtils.toJson(abs);
//        //pushClient.push("shopAuth", userId, json);
//        pushClient.push("", userId, new PushSpec("shopAuth", abs, "店铺授权"), PushType.Socket);
//    }

}

