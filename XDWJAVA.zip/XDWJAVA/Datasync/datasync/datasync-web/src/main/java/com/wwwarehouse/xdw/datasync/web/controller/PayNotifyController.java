package com.wwwarehouse.xdw.datasync.web.controller;

import com.wwwarehouse.commons.utils.IOUtil;
import com.wwwarehouse.xdw.datasync.service.PayService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by chengwei on 2017/6/9 10:02.
 */
@RestController
@RequestMapping("/payNotify")
public class PayNotifyController {
	private static final Logger logger = LogManager.getLogger(PayNotifyController.class);

	@Resource
	private PayService payService;

	@RequestMapping(value = "/alipay", method = RequestMethod.POST)
	public String alipay(HttpServletRequest request) throws Exception {
		String requestStr = null;
		String result = null;
		try {
			requestStr = IOUtil.toString(request.getInputStream(), "utf-8");
		} catch (IOException e) {
			logger.error("支付宝异步通知：", e);
			result = "failure";
			return result;
		}
		result = payService.aliAnalyzeData(requestStr);

		return result;
	}

	/**
	 * @ApiMethod:true
	 * @ApiMethodName:接收银联商户通知,获取支付结果,并应答银联
	 * @ApiRequestParams:
	 * @ApiResponse: 成功返回:"ok"
	 * @ApiMethodEnd
	 */
	@RequestMapping(value = "/unipay", method = RequestMethod.POST)
	public String unipay(HttpServletRequest req, HttpServletResponse resp) {
		String returnType = "error";
		String requestStr = null;
		try {
			// 获取不到参数，要转换一下。
			requestStr = IOUtil.toString(req.getInputStream(), "utf-8");
			returnType = payService.UnionAnalyzeData(requestStr);
		} catch (Exception e) {
			logger.error("银联异步通知", e);
			return returnType;
		}
		return returnType;
	}

	/**
	 * @ApiMethod:true
	 * @ApiMethodName: 接收微信商户通知,获取支付结果并应答微信
	 * @ApiRequestParams:
	 * @ApiResponse: 成功返回:<xml><return_code><![CDATA[SUCCESS]]></return_code></xml>
	 * @ApiMethodEnd
	 */
	@RequestMapping(value = "/wechatpay", method = RequestMethod.POST)
	public String wechatpay(HttpServletRequest req, HttpServletResponse resp) {
		String returnType = "<xml><return_code><![CDATA[FAIL]]></return_code></xml>";
		String requestStr = null;
		try {
			// 获取不到参数，要转换一下。
			requestStr = IOUtil.toString(req.getInputStream(), "utf-8");
			returnType = payService.wechatAnalyzeData(requestStr);
		} catch (Exception e) {
			logger.error("微信异步通知", e);
			return returnType;
		}
		return returnType;
	}

}
