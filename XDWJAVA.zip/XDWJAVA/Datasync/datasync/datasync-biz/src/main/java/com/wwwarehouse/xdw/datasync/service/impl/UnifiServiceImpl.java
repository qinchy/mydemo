package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.xdw.datasync.outer.api.hardware.UnifiApi;
import com.wwwarehouse.xdw.datasync.service.UnifiService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by lidan.wu on  2017/6/20 .
 */

@Service
public class UnifiServiceImpl  implements UnifiService{

    private String site = "default";
    private String baseUrl = "https://testac.iscs.com.cn:8443";
    private String version = "v5";
    private UnifiApi unifiApi = null;

    @Override
    public boolean login(String username, String password) {
        unifiApi = new UnifiApi(baseUrl, site, version);
        boolean isLogin = unifiApi.login(username, password);
        return isLogin;
    }


    @Override
    public List<Object> sites() {
        return unifiApi.sites();
    }

    @Override
    public boolean logout() {
        return unifiApi.logout();
    }
}
