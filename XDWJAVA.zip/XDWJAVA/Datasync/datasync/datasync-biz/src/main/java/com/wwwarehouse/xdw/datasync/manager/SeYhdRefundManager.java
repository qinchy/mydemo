package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDOExample;

/**
* SeYhdRefundService
*  on 2017/6/14.
*/
public interface SeYhdRefundManager extends BaseService<SeYhdRefundDO, SeYhdRefundDOExample> {

}