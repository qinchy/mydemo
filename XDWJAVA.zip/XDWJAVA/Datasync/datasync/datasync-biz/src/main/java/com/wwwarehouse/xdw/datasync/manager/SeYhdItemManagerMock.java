package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDOExample;

/**
* SeYhdItemService
*  on 2017/6/14.
*/
public class SeYhdItemManagerMock extends BaseServiceMock<SeYhdItemDOMapper, SeYhdItemDO, SeYhdItemDOExample> implements SeYhdItemManager {

}
