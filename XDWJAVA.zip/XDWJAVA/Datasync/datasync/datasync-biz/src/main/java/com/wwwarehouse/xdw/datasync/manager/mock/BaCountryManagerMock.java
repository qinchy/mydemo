package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.manager.BaCountryManager;
import com.wwwarehouse.xdw.datasync.model.BaCountry;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDOExample;

import java.util.List;

/**
* BaCountryManager
*  on 2017/6/16.
*/
public class BaCountryManagerMock extends BaseManagerMock<BaCountry, BaCountryDOExample> implements BaCountryManager {

    @Override
    public List<BaCountryDO> listAllBaCountry() {
        return null;
    }
}
