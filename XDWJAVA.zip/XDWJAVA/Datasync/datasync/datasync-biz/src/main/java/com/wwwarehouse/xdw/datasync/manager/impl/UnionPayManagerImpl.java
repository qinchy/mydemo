package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.manager.UnionPayManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IPayApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.PayPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.AcpService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chengwei on 2017/6/12 10:13.
 */
@Service
public class UnionPayManagerImpl implements UnionPayManager {
	@Resource
	private PayNotifyRecordManager payNotifyRecordManager;

	@Override
	public AbsResponse launchCommonPay(AmAppSubscriptionDTO appSuber, PayParamsDTO payParamsDTO) throws Exception {
		IPayApi payApi = ApiUtil.getPayApi(appSuber);

		return payApi.buildPayUrl(payParamsDTO.getTradeNo(), payParamsDTO.getTitle(), payParamsDTO.getTitle(), payParamsDTO.getAmount());
	}

	@Override
	public String unionAnalyzeData(String request) throws Exception {
		String returnType = "error";

		Map<String, String> orgMap = WebUtils.getUrlParams(request);
		Map<String, String> valideData = new HashMap<>();
		for (String strs : orgMap.keySet()) {
			valideData.put(strs, CodecUtils.urlDecode(orgMap.get(strs)));
		}
		if (unionPayValidate(valideData)) {// 验签成功
			String orderId = valideData.get("orderId"); // 获取订单流水号
			String respCode = valideData.get("respCode"); // 获取应答码
			insertPayRecord(valideData, orderId, respCode);

			if ("00".equals(respCode)) {// 支付成功
				returnType = "ok";
				//TODO 推送给底盘
			}
		}
		return returnType;
	}

	private void insertPayRecord(Map<String, String> valideData, String outTradeNo, String tradeStatus) {
		PayNotifyRecordDTO payNotifyRecordDTO = new PayNotifyRecordDTO();
		payNotifyRecordDTO.setOutTradeNo(outTradeNo);
		payNotifyRecordDTO.setPlatformId((short) PayPlatform.WECHATPAY.getId());
		payNotifyRecordDTO.setResultCode(tradeStatus);
		payNotifyRecordDTO.setTransactionId(valideData.get("queryId"));
		payNotifyRecordDTO.setTotalFee(new BigDecimal(valideData.get("txnAmt")));
		payNotifyRecordDTO.setTimeEnd(DateUtil.parse(valideData.get("txnTime"), "yyyyMMddhhmmss"));
		payNotifyRecordDTO.setBuyerId(valideData.get("accNo"));
		payNotifyRecordDTO.setReturnMsg(JsonUtils.toJson(valideData));
		payNotifyRecordDTO.setPayRecordUkid(UKID.getUKID());

		payNotifyRecordManager.add(payNotifyRecordDTO);
	}

	/**
	 * 银联验证签名
	 *
	 * @param validate
	 * @return
	 */
	private boolean unionPayValidate(Map<String, String> validate) {
		return AcpService.validate(validate, "");
	}

}
