package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;

import java.util.Date;

/**
 * Created by jianjun.guan on 2017/6/16 0016.
 */
public interface SeBaseProductManager {

    public AbsResponse<String> downPlatformItems(AmAppSubscriptionDTO amAppSubscription);
}
