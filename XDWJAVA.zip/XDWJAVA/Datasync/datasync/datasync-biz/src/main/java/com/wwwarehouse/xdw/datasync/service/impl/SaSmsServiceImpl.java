package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.xdw.datasync.manager.SaSmsManager;
import com.wwwarehouse.xdw.datasync.service.SaSmsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by yinsheng.wang on 2017/6/9.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class SaSmsServiceImpl implements SaSmsService {
    @Resource
    private SaSmsManager saSmsManager;

    @Override
    public String sendSms(String mobile, String smsContent,Long platformId) throws Exception {
        //smsContent=【网仓科技】验证码:123456，仅用于注册，请勿告知他人。工作人员不会向您索取。
        String smsResult = saSmsManager.sendSms(mobile,smsContent,platformId);
       return  smsResult;
    }
}
