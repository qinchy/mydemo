package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemExample;
import com.wwwarehouse.xdw.datasync.model.SeJingdongItemDTO;

import java.util.List;

/**
* SeJingdongItemService
*  on 2017/6/13.
*/
public interface SeJingdongItemManager extends BaseService<SeJingdongItemDO, SeJingdongItemExample> {
    List<SeJingdongItemDTO> getsOrderByTradeUkid(Long tradeUkid);
    SeJingdongItemDTO matchItem(List<SeJingdongItemDTO> oItemList, SeJingdongItemDTO pItem) throws Exception;
    int saveItem(SeJingdongItemDTO item) throws Exception;
    int updateItem(SeJingdongItemDTO item) throws Exception;
    int updateOriginItemStatus(SeJingdongItemDTO oItem);
}