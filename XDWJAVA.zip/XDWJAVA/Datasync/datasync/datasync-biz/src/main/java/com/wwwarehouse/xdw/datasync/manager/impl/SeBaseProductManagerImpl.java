package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemManager;
import com.wwwarehouse.xdw.datasync.manager.SeBaseProductManager;
import com.wwwarehouse.xdw.datasync.manager.SyParamManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.model.SyParamDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IProductApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/16 0016.
 */
@Service
public class SeBaseProductManagerImpl implements SeBaseProductManager {
    private static Logger _log = LoggerFactory.getLogger(SeBaseProductManagerImpl.class);

    @Resource
    ImPlatformItemManager imPlatformItemManager;
    @Resource
    SyParamManager syParamManager;

    @Override
    public AbsResponse<String> downPlatformItems(AmAppSubscriptionDTO amAppSubscription) {
        AbsResponse<String> retBean = new AbsResponse<>();
        Long platformId = amAppSubscription.getPlatformId();
        Long shopId = amAppSubscription.getSubscriptionBuId();
        IProductApi productApi = null;
        try {
            //TODO 店铺未确定
//            BaShop baShop = baShopService.get(shopId);
//            Long ownerId = baShop.getSellerId();
            Long ownerId = Constants.WCKJ;
            ;

            String hisTime = syParamManager.getParamValue(shopId,
                    SyParamDTO.L_PRODUCT_TIME_RANGE);
            Integer hisTimeRange = null;
            if (StringUtils.isEmpty(hisTime)) {
                hisTimeRange = 90;
            } else {
                hisTimeRange = Integer.valueOf(hisTime);
            }

            Date[] downDates = new Date[2];

            downDates[0] = DateUtil.addDays(new Date(), -hisTimeRange);
            downDates[1] = new Date();
            DateUtil.DateIterator di = new DateUtil.DateIterator(downDates[0],
                    downDates[1], Calendar.MONTH, 1);

            Date startDate = di.nextTime();
            while (di.hasNext()) {
                Date endDate = di.nextTime();
                AbsResponse trade = productApi.queryProducts(2, "", startDate,
                        endDate);
                List<ImPlatformItemDTO> list = (List<ImPlatformItemDTO>)
                        trade.getData();
                imPlatformItemManager.savePlatformItems(list, platformId, shopId, ownerId);

                if (di.hasNext()) {
                    startDate = new Date(endDate.getTime());
                }
            }
        } catch (Exception e) {
            retBean.setResult(500, "下载商品发生错误" + e.getMessage());
            _log.error("下载商品资料异常:" + shopId, e);
        }
//		finally {
//			try {
//				if (productApi != null && productApi.getAccessLogList() != null)
//				{
//					mongoDao.dumpRecords(productApi.getAccessLogList());
//				}
//			} catch (Exception e) {
//				logger.error("dump mongodb error", e);
//			}
//		}

        return retBean;
    }
}
