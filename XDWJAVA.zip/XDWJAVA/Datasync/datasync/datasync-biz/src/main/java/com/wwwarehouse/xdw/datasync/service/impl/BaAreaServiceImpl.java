package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.BaAreaManager;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;
import com.wwwarehouse.xdw.datasync.service.BaAreaService;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by jingchun.zhang on 2017/6/16.
 */
public class BaAreaServiceImpl implements BaAreaService {

    @Resource
    BaAreaManager baAreaManager;

    @Override
    public List<BaAreaDTO> listAllBaAreas() throws Exception {
        return baAreaManager.listAllBaAreas();
    }

    @Override
    public AbsResponse<BaAreaDTO> getBaArea(String areaId, String areaName) throws Exception {
        return baAreaManager.getBaArea(areaId,areaName);
    }
}
