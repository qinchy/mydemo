package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.BaCountryDOMapper;
import com.wwwarehouse.xdw.datasync.model.BaCountry;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDOExample;
import com.wwwarehouse.xdw.datasync.manager.BaCountryManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* BaCountryManagerImpl
*  on 2017/6/16.
*/
@Service
@Transactional
public class BaCountryManagerImpl extends BaseManagerImpl<BaCountryDOMapper, BaCountry, BaCountryDO, BaCountryDOExample> implements BaCountryManager {

    private static Logger _log = LoggerFactory.getLogger(BaCountryManagerImpl.class);

    @Autowired
    BaCountryDOMapper baCountryDOMapper;

    @Override
    public BaCountryDOMapper getMapper() {
        return baCountryDOMapper;
    }

    @Override
    public List<BaCountryDO> listAllBaCountry() {
        return baCountryDOMapper.selectByExample(null);
    }
}