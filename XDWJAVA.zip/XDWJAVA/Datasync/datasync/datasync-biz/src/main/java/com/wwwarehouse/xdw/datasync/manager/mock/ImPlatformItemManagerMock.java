package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemManager;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDOExample;

import java.util.List;

/**
* ImPlatformItemManager
*  on 2017/6/16.
*/
public class ImPlatformItemManagerMock extends BaseManagerMock<ImPlatformItemDTO, ImPlatformItemDOExample> implements ImPlatformItemManager {
    public ImPlatformItemManagerMock() {
        super();
    }

    @Override
    public AbsResponse<String> savePlatformItems(List<ImPlatformItemDTO> platformItems, Long platformId, Long shopId, Long ownerId) throws Exception {
        return null;
    }

    @Override
    public int countByExample(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.countByExample(imPlatformItemDOExample);
    }

    @Override
    public int deleteByExample(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.deleteByExample(imPlatformItemDOExample);
    }

    @Override
    public int deleteByPrimaryKey(Long id) {
        return super.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(ImPlatformItemDTO imPlatformItemDTO) {
        return super.insert(imPlatformItemDTO);
    }

    @Override
    public int insertSelective(ImPlatformItemDTO imPlatformItemDTO) {
        return super.insertSelective(imPlatformItemDTO);
    }

    @Override
    public List<ImPlatformItemDTO> selectByExampleWithBLOBs(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.selectByExampleWithBLOBs(imPlatformItemDOExample);
    }

    @Override
    public List<ImPlatformItemDTO> selectByExample(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.selectByExample(imPlatformItemDOExample);
    }

    @Override
    public ImPlatformItemDTO selectFirstByExample(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.selectFirstByExample(imPlatformItemDOExample);
    }

    @Override
    public ImPlatformItemDTO selectFirstByExampleWithBLOBs(ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.selectFirstByExampleWithBLOBs(imPlatformItemDOExample);
    }

    @Override
    public ImPlatformItemDTO selectByPrimaryKey(Long id) {
        return super.selectByPrimaryKey(id);
    }

    @Override
    public int updateByExampleSelective(ImPlatformItemDTO imPlatformItemDTO, ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.updateByExampleSelective(imPlatformItemDTO, imPlatformItemDOExample);
    }

    @Override
    public int updateByExampleWithBLOBs(ImPlatformItemDTO imPlatformItemDTO, ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.updateByExampleWithBLOBs(imPlatformItemDTO, imPlatformItemDOExample);
    }

    @Override
    public int updateByExample(ImPlatformItemDTO imPlatformItemDTO, ImPlatformItemDOExample imPlatformItemDOExample) {
        return super.updateByExample(imPlatformItemDTO, imPlatformItemDOExample);
    }

    @Override
    public int updateByPrimaryKeySelective(ImPlatformItemDTO imPlatformItemDTO) {
        return super.updateByPrimaryKeySelective(imPlatformItemDTO);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(ImPlatformItemDTO imPlatformItemDTO) {
        return super.updateByPrimaryKeyWithBLOBs(imPlatformItemDTO);
    }

    @Override
    public int updateByPrimaryKey(ImPlatformItemDTO imPlatformItemDTO) {
        return super.updateByPrimaryKey(imPlatformItemDTO);
    }

    @Override
    public int deleteByPrimaryKeys(String ids) {
        return super.deleteByPrimaryKeys(ids);
    }
}
