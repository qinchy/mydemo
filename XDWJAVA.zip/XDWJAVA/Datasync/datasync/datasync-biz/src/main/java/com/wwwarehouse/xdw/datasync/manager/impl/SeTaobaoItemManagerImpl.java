package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDOExample;
import com.wwwarehouse.xdw.datasync.manager.SeTaobaoItemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
* SeTaobaoItemService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeTaobaoItemManagerImpl extends BaseServiceImpl<SeTaobaoItemDOMapper, SeTaobaoItemDO, SeTaobaoItemDOExample> implements SeTaobaoItemManager {

    private static Logger _log = LoggerFactory.getLogger(SeTaobaoItemManagerImpl.class);

    @Autowired
    SeTaobaoItemDOMapper seTaobaoItemMapper;

    @Override
    public SeTaobaoItemDOMapper getMapper() {
        return seTaobaoItemMapper;
    }
}