package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.dao.mapper.ImPlatformItemDOMapper;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemIllegalManager;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDOExample;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemManager;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemIllegalDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
* ImPlatformItemManagerImpl
*  on 2017/6/16.
*/
@Service
@Transactional
public class ImPlatformItemManagerImpl extends BaseManagerImpl<ImPlatformItemDOMapper, ImPlatformItemDTO, ImPlatformItemDO, ImPlatformItemDOExample> implements ImPlatformItemManager {

    private static Logger _log = LoggerFactory.getLogger(ImPlatformItemManagerImpl.class);

    @Resource
    ImPlatformItemDOMapper imPlatformItemDOMapper;
    @Resource
    ImPlatformItemIllegalManager imPlatformItemIllegalManager;

    private Long userId = 999L;

    @Override
    public ImPlatformItemDOMapper getMapper() {
        return imPlatformItemDOMapper;
    }



    @Override
    public AbsResponse<String> savePlatformItems(List<ImPlatformItemDTO> platformItems, Long platformId, Long shopId, Long ownerId) throws Exception {
        AbsResponse<String> abs = new AbsResponse<>();
        if (platformItems.isEmpty()) {
            return abs;
        }
        // 铺货批次ID
        Long lotId = UKID.getUKID();
        for (ImPlatformItemDTO platItem : platformItems) {
            try {
                savePlatformItem(platformId, shopId, ownerId, lotId, platItem,
                        userId);
            } catch (Exception e) {
                abs.setResult(500, "新增外部商品出现异常");
                _log.error("下载商品资料异常", e);
            }
        }
        return abs;
    }

    public void savePlatformItem(Long platformId, Long shopId, Long ownerId, Long LotUkid,
                                 ImPlatformItemDTO platItem, Long userId) throws Exception {
        platItem.setPlatformId(platformId);
        platItem.setShopId(shopId);
        platItem.setOwnerId(ownerId);
        String identityCode = platItem.buildProductCode();
        platItem.setIdentifyCode(identityCode);
        platItem.setCreateUserId(userId);
        platItem.setUpdateUserId(userId);

        // 检查铺货信息格式是否合格
        Short checkPlatformResult = checkPlatformItem(platItem);
        if (checkPlatformResult > 0) {
            ImPlatformItemIllegalDTO platformItemIllegal = new ImPlatformItemIllegalDTO();
            BeanUtils.copyProperties(platItem, platformItemIllegal);
            platformItemIllegal.setReasonType(checkPlatformResult);
            imPlatformItemIllegalManager.saveIllegal(LotUkid, platformItemIllegal);
            return;
        }
    }
/**
 * 检查铺货信息是否合格  0 合格   1 null   2 商品名为空   3 商品码和规格码都为空 4 商品
 数字ID为空
 *
 * @param platItem
 * @return
 */

    private Short checkPlatformItem(ImPlatformItemDTO platItem) {
        if (platItem == null) {
            return 1;
        }

        //商品码和规格码都为空
        if (StringUtils.isEmpty(platItem.getProductOuterId()) &&
                StringUtils.isEmpty(platItem.getSkuOuterId())) {
            return 3;
        }
        //商品数字ID为空
        if (StringUtils.isEmpty(platItem.getProductNumId())) {
            return 4;
        }

        return 0;
    }
}