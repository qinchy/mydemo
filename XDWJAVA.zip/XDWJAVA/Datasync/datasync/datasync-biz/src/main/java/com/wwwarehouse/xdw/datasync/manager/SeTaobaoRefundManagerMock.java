package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoRefundDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDOExample;

/**
* SeTaobaoRefundService
*  on 2017/6/14.
*/
public class SeTaobaoRefundManagerMock extends BaseServiceMock<SeTaobaoRefundDOMapper, SeTaobaoRefundDO, SeTaobaoRefundDOExample> implements SeTaobaoRefundManager {

}
