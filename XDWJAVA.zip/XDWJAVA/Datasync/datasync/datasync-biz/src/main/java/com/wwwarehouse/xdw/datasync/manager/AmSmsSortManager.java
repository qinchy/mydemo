package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDO;
import com.wwwarehouse.xdw.datasync.model.AmSmsSort;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDOExample;

import java.util.List;

/**
* AmSmsSortManager
*  on 2017/6/21.
*/
public interface AmSmsSortManager extends BaseManager<AmSmsSort, AmSmsSortDOExample> {

    AmSmsSortDO getAmSmsSortByAppUkids(List<Long> appUkids);
}