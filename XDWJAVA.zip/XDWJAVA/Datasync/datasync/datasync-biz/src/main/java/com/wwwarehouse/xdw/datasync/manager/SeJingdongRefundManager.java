package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundExample;

/**
* SeJingdongRefundService
*  on 2017/6/13.
*/
public interface SeJingdongRefundManager extends BaseService<SeJingdongRefundDO, SeJingdongRefundExample> {

}