package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.exception.ServiceException;
import com.wwwarehouse.xdw.datasync.constant.DataSyncResultConstant;
import com.wwwarehouse.xdw.datasync.exception.DataSyncException;
import com.wwwarehouse.xdw.datasync.manager.ItemManager;
import com.wwwarehouse.xdw.datasync.model.Item;
import com.wwwarehouse.xdw.datasync.service.ItemService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * rpc接口实现
 * 调用manager,一般比较简洁
 * Created by shisheng.wang on 17/6/6.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class ItemServiceImpl implements ItemService {

    @Resource
    ItemManager itemManager;

    @Override
    public Item get(long itemId) {
        new DataSyncException(DataSyncResultConstant.UNKNOW_ERROR);
        return itemManager.get(itemId);
    }

    @Transactional
    @Override
    public int add(Item item) {
        return itemManager.add(item);
    }
}
