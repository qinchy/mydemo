package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.manager.IbsMapManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IMapApi;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by huahui.wu on 2017/6/15.
 */
@Service
public class IbsMapManagerImpl implements IbsMapManager {

	@Override
	public AbsResponse<Object> geoCodeGeo(String address, String city, String location, AmAppSubscriptionDTO appSuber) throws Exception {
		AbsResponse<Object> abs = new AbsResponse<>();
		IMapApi mapApi = ApiUtil.getMapApi(appSuber);
		if (mapApi == null) {
			throw new IscsException("选择了未知的地图");
		}
		if (StringUtils.isNotEmpty(location)) {
			abs = mapApi.geocodeRegeo(location);
		} else {
			abs = mapApi.geocodeGeo(address, city);
		}
		return abs;
	}

	@Override
	public AbsResponse<Object> direction(String origin, String destination, String strategy, String mode, AmAppSubscriptionDTO appSuber) throws Exception {
		AbsResponse<Object> abs = new AbsResponse<>();
		IMapApi mapApi = ApiUtil.getMapApi(appSuber);
		if (mapApi == null) {
			throw new IscsException("选择了未知的地图");
		}
		if ("driving".equals(mode)) { //驾车
			abs = mapApi.directionDriving(origin, destination, strategy);
		} else if ("walking".equals(mode)) { //步行
			abs = mapApi.directionWalking(origin, destination);
		} else {
			throw new IscsException("请选择正确的导航模式");
		}
		return abs;
	}

	@Override
	public Map<String, Double> getLocation(String city, String keywords, AmAppSubscriptionDTO appSuber) throws Exception{
		Map<String, Double> map = new HashMap<>();
		IMapApi mapApi = ApiUtil.getMapApi(appSuber);
		if (mapApi == null) {
			throw new IscsException("选择了未知的地图");
		}
		map = mapApi.getLocation(city, keywords);
		return map;
	}
}
