package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAppSubscriptionMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionExample;
import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * AmAppSubscriptionService
 * on 2017/6/13.
 */
@Service
@Transactional
public class AmAppSubscriptionManagerImpl extends BaseServiceImpl<AmAppSubscriptionMapper, AmAppSubscriptionDO, AmAppSubscriptionExample> implements AmAppSubscriptionManager {

    private static Logger _log = LoggerFactory.getLogger(AmAppSubscriptionManagerImpl.class);

    @Autowired
    AmAppSubscriptionMapper amAppSubscriptionMapper;
    @Resource
    private AmAppKeyManager amAppKeyManager;

    @Override
    public AmAppSubscriptionMapper getMapper() {
        return amAppSubscriptionMapper;
    }

    @Override
    public AmAppSubscriptionDTO get(Long subscriptionUkid) {
        AmAppSubscriptionDO amAppSubscriptionDO = amAppSubscriptionMapper.selectByPrimaryKey(subscriptionUkid);
        AmAppSubscriptionDTO amAppSubscription = new AmAppSubscriptionDTO();
        BeanUtils.copyProperties(amAppSubscriptionDO, amAppSubscription);
        return amAppSubscription;
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long suberBuId, String appType) {
        return getSubscription(platformId, null, suberBuId, appType);
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long appOwnerId, Long suberBuId, String appType) {
        List<AmAppkeyDTO> appkeyList = amAppKeyManager.getsByType(platformId, appOwnerId, null, appType, 1L);
        if (appkeyList.isEmpty()) {
            return null;
        }
        AmAppkeyDTO app = appkeyList.get(0);

        List<AmAppSubscriptionDTO> subscriptionList = getsByAppUkid(app.getAppUkid(), suberBuId,  1L);
        if (subscriptionList.isEmpty()) {
            return null;
        }
        AmAppSubscriptionDTO subscription = subscriptionList.get(0);

        return packageAppSub(subscription, app);
    }

    @Override
    public AmAppSubscriptionDTO packageAppSub(AmAppSubscriptionDTO subscription, AmAppkeyDTO app) {
        if (app == null) {
            app = amAppKeyManager.get(subscription.getAppUkid());
        }

        if (app != null) {
            subscription.setApp(app);
            subscription.setPlatformId(app.getPlatformId());
        }

        return subscription;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, Long suberBuId,
                                                    Long status) {
        AmAppSubscriptionExample example = new AmAppSubscriptionExample();
        AmAppSubscriptionExample.Criteria criteria = example.createCriteria();
        if(appUkid!=null){
            criteria.andAppUkidEqualTo(appUkid);
        }
        if (suberBuId != null) {
            criteria.andSubscriptionBuIdEqualTo(suberBuId);
        }
        if (status != null) {
            criteria.andStatusEqualTo(status);
        }
        List<AmAppSubscriptionDO> amAppSubscriptionDOList = amAppSubscriptionMapper.selectByExample(example);
        List<AmAppSubscriptionDTO> amAppSubscriptionList = new ArrayList<>();
        for(AmAppSubscriptionDO amAppSubscriptionDO:amAppSubscriptionDOList){
            AmAppSubscriptionDTO amAppSubscriptionDTO=new AmAppSubscriptionDTO();
            BeanUtils.copyProperties(amAppSubscriptionDO, amAppSubscriptionDTO);
            amAppSubscriptionList.add(amAppSubscriptionDTO);
        }
        return amAppSubscriptionList;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, int shardingCount, int shardingItem) {
        HashMap<String, Object> paramMap = new HashMap<>();
        paramMap.put("app_ukid", appUkid);
        paramMap.put("status", 1L);
        List<AmAppSubscriptionDO> amAppSubscriptionDOList = amAppSubscriptionMapper.getsBySharding(paramMap, shardingCount, shardingItem);
        List<AmAppSubscriptionDTO> amAppSubscriptionList = new ArrayList<>();
        for(AmAppSubscriptionDO amAppSubscriptionDO:amAppSubscriptionDOList){
            AmAppSubscriptionDTO amAppSubscriptionDTO=new AmAppSubscriptionDTO();
            BeanUtils.copyProperties(amAppSubscriptionDO, amAppSubscriptionDTO);
            amAppSubscriptionList.add(amAppSubscriptionDTO);
        }
        return amAppSubscriptionList;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByBuid(Long buId, Long status) {
        AmAppSubscriptionExample example = new AmAppSubscriptionExample();
        example.createCriteria().andSubscriptionBuIdEqualTo(buId).andStatusEqualTo(status);
        List<AmAppSubscriptionDO> amAppSubscriptionDOList = amAppSubscriptionMapper.selectByExample(example);
        List<AmAppSubscriptionDTO> amAppSubscriptionList = new ArrayList<>();
        for(AmAppSubscriptionDO amAppSubscriptionDO:amAppSubscriptionDOList){
            AmAppSubscriptionDTO amAppSubscriptionDTO=new AmAppSubscriptionDTO();
            BeanUtils.copyProperties(amAppSubscriptionDO, amAppSubscriptionDTO);
            amAppSubscriptionList.add(amAppSubscriptionDTO);
        }
        return amAppSubscriptionList;
    }

    public AmAppSubscriptionDTO getValidByAppUkid(Long appUkid, Long suberBuId) {
        List<AmAppSubscriptionDTO> suberList = getsByAppUkid(appUkid, suberBuId,  1L);
        return suberList.isEmpty() ? null : suberList.get(0);
    }

    @Override
    public int insertSubscription(AmAppSubscriptionDTO subscription) {
        AmAppSubscriptionDO amAppSubscriptionDO = new AmAppSubscriptionDO();
        BeanUtils.copyProperties(subscription, amAppSubscriptionDO);
        return amAppSubscriptionMapper.insert(amAppSubscriptionDO);
    }

    @Override
    public List<AmAppSubscriptionDTO> getsNeedRefresh() {
        List<AmAppSubscriptionDO> amAppSubscriptionDOList = amAppSubscriptionMapper.getsNeedRefresh();
        List<AmAppSubscriptionDTO> amAppSubscriptionList = new ArrayList<>();
        for(AmAppSubscriptionDO amAppSubscriptionDO:amAppSubscriptionDOList){
            AmAppSubscriptionDTO amAppSubscriptionDTO=new AmAppSubscriptionDTO();
            BeanUtils.copyProperties(amAppSubscriptionDO, amAppSubscriptionDTO);
            amAppSubscriptionList.add(amAppSubscriptionDTO);
        }
        return amAppSubscriptionList;
    }

    @Override
    public int updateAuthBuId(AmAppSubscriptionDTO subscription) {
        AmAppSubscriptionDO amAppSubscriptionDO = new AmAppSubscriptionDO();
        BeanUtils.copyProperties(subscription, amAppSubscriptionDO);
        return amAppSubscriptionMapper.updateByPrimaryKeySelective(amAppSubscriptionDO);
    }

    @Override
    public int updateSubscription(AmAppSubscriptionDTO subscription) {
        AmAppSubscriptionDO amAppSubscriptionDO = new AmAppSubscriptionDO();
        BeanUtils.copyProperties(subscription, amAppSubscriptionDO);
        return amAppSubscriptionMapper.updateByPrimaryKeySelective(amAppSubscriptionDO);
    }

    @Override
    public int update(AmAppSubscriptionDTO subscription) {
        AmAppSubscriptionDO amAppSubscriptionDO = new AmAppSubscriptionDO();
        BeanUtils.copyProperties(subscription, amAppSubscriptionDO);
        return amAppSubscriptionMapper.updateByPrimaryKey(amAppSubscriptionDO);
    }
}