package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.AuthManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.service.IAuthService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by jianjun.guan on 2017/6/19 0019.
 */
@Service
public class AuthServiceImpl implements IAuthService {
    @Resource
    AuthManager authManager;
    @Override
    public AbsResponse<String> getAuthUrl(Long platformId, String state) {
        return authManager.getAuthUrl(platformId,state);
    }

    @Override
    public AbsResponse<AmAppSubscriptionDTO> saveAuth(Long shopId, Long platformId, AmAuthRecordDTO authRecord, Long userId) throws Exception {
        return authManager.saveAuth(shopId, platformId, authRecord, userId);
    }

    @Override
    public AbsResponse<AmAppSubscriptionDTO> refreshAuth(AmAppSubscriptionDTO amAppSubscription, Long userId) throws Exception {
        return authManager.refreshAuth(amAppSubscription, userId);
    }

    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(AmAppkeyDTO amAppKey, String code) {
        return authManager.grantAuth(amAppKey, code);
    }

}
