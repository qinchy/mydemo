package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDOExample;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;

/**
* PayNotifyRecordManager
*  on 2017/6/15.
*/
public class PayNotifyRecordManagerMock extends BaseManagerMock<PayNotifyRecordDTO, PayNotifyRecordDOExample> implements PayNotifyRecordManager {

	@Override
	public int add(PayNotifyRecordDTO payNotifyRecordDTO) {
		return 0;
	}

	@Override
	public int update(PayNotifyRecordDTO payNotifyRecordDTO) {
		return 0;
	}

	@Override
	public PayNotifyRecordDTO selectByOutTradeNoAndResultCode(String outTradeNo, String resultCode) {
		return null;
	}
}
