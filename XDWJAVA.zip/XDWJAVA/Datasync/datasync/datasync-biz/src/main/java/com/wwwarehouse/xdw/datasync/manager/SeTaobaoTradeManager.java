package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDOExample;

/**
* SeTaobaoTradeService
*  on 2017/6/14.
*/
public interface SeTaobaoTradeManager extends BaseService<SeTaobaoTradeDO, SeTaobaoTradeDOExample> {

}