package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.IExpressManager;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressUploadWeightInfo;
import com.wwwarehouse.xdw.datasync.model.LogisticsInformation;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaExpressCode;
import com.wwwarehouse.xdw.datasync.service.IExpressService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("expressService")
@com.alibaba.dubbo.config.annotation.Service
public class ExpressServiceImpl implements IExpressService {
    @Resource
    private IExpressManager expressManager;

    @Override
    public AbsResponse<LogisticsInformation> trackLogisticsInfo(String outSid, Long expressCode) throws Exception {
        AbsResponse<LogisticsInformation> absResponse = new AbsResponse<LogisticsInformation>();
        if (null == outSid || outSid.length() <= 0) {
            absResponse.setResult(2222, "快递单号为空");
            return absResponse;
        }

        if (null == BaExpressCode.getBaExpressCode(expressCode)) {
            absResponse.setResult(2223, "输入的快递公司为空");
            return absResponse;
        }
        try {
            LogisticsInformation information = expressManager.trackLogisticsInfo(outSid, expressCode);
            if (information == null) {
                absResponse.setResult(2224,
                        "快递单号在" + BaExpressCode.getBaExpressCode(expressCode).getExpName() + "中的运单信息不存在");
                return absResponse;
            }
            absResponse.setData(information);


        } catch (Exception e) {
            if (e instanceof IscsException) {
                IscsException exception = (IscsException) e;
                absResponse.setResult(exception.getErrCode(), exception.getErrMsg());
            }
        }

        return absResponse;
    }

    @Override
    public AbsResponse<ExpressOrderInfoDTO> generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
        AbsResponse<ExpressOrderInfoDTO> absResponse = new AbsResponse<ExpressOrderInfoDTO>();
        try {
            ExpressOrderInfoDTO information = expressManager.generateExpressInfo(expressOrderInfo);
            if (information == null) {
                absResponse.setResult(2221, "生成快递单失败");
                return absResponse;
            }
            absResponse.setData(information);

        } catch (Exception e) {
            if (e instanceof IscsException) {
                IscsException exception = (IscsException) e;
                absResponse.setResult(exception.getErrCode(), exception.getErrMsg());
            }
        }

        return absResponse;
    }

    @Override
    public <T extends ExpressOrderInfoDTO> AbsResponse<List<T>> generateExpressInfos(List<T> expressOrderInfoDTOs)
            throws Exception {
        AbsResponse<List<T>> absResponse = new AbsResponse<List<T>>();
        try {
            List<T> result = expressManager.generateExpressInfos(expressOrderInfoDTOs);
            absResponse.setData(result);
        } catch (Exception e) {
            if (e instanceof IscsException) {
                IscsException exception = (IscsException) e;
                absResponse.setResult(exception.getErrCode(), exception.getErrMsg());
            }
        }

        return absResponse;
    }

    @Override
    public AbsResponse<String> uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception {
        AbsResponse<String> absResponse = new AbsResponse<String>();
        try {
            if (weightInfos == null || weightInfos.size() <= 0) {
                absResponse.setResult(2225, "请检查传入的对象是否有误");
                return absResponse;
            }
            expressManager.uploadWeight(weightInfos);
            absResponse.setData("SUCCESS");
        } catch (Exception e) {
            if (e instanceof IscsException) {
                IscsException exception = (IscsException) e;
                absResponse.setResult(exception.getErrCode(), exception.getErrMsg());
            }
        }

        return absResponse;
    }

    @Override
    public AbsResponse<String> cancelExpressOrder(String orderId, String outSid, Long expressCode) throws Exception {
        AbsResponse<String> absResponse = new AbsResponse<String>();
        try {
            if (null == outSid || outSid.length() <= 0) {
                absResponse.setResult(2222, "快递单号为空");
                return absResponse;
            }

            if (null == BaExpressCode.getBaExpressCode(expressCode)) {
                absResponse.setResult(2223, "输入的快递公司为空");
                return absResponse;
            }
            if (null == orderId || orderId.length() <= 0) {
                absResponse.setResult(2226, "订单号为空");
                return absResponse;
            }
            expressManager.cancelExpressOrder(orderId, outSid, expressCode);
            absResponse.setData("SUCCESS");
        } catch (Exception e) {
            if (e instanceof IscsException) {
                IscsException exception = (IscsException) e;
                absResponse.setResult(exception.getErrCode(), exception.getErrMsg());
            }
        }

        return absResponse;
    }

}
