package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SaSmsMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsDO;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsExample;
import com.wwwarehouse.xdw.datasync.manager.SaSmsManager;
import com.wwwarehouse.xdw.datasync.model.SaSmsDTO;

import java.util.Date;
import java.util.List;

/**
* SaSmsService
*  on 2017/6/14.
*/
public class SaSmsManagerMock extends BaseServiceMock<SaSmsMapper, SaSmsDO, SaSmsExample> implements SaSmsManager {

    @Override
    public int updateSmsStatus(String smsUkids, Long smsStatus, Date actualSendTime, String returnText) {
        return 0;
    }

    @Override
    public String insert(Long serviceBuId, Long senderId, String smsType, String mobileNo, String content, Date planSendTime, String relatedType, Long relatedOrderUkid, Long platformId) throws Exception {
        return null;
    }


    @Override
    public List<SaSmsDTO> getNeedSendGroupList(Long smsAccountUkid) {
        return null;
    }

    @Override
    public List<SaSmsDTO> getNeedSendList(Long smsAccountUkid, Long buId, Long sendBuId, Long shopId, String sendContent) {
        return null;
    }

    @Override
    public String sendSms(String mobile, String smsContent, Long platformId) throws Exception {
        return null;
    }

}
