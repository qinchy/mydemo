package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyExample;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
* AmAppkeyService
*  on 2017/6/13.
*/
public interface AmAppKeyManager extends BaseService<AmAppkeyDO, AmAppkeyExample> {
    AmAppkeyDTO get(Long appUkid);

    /**
     * @param platformId
     * @param ownerBuId
     * @param appKey
     * @param appkeyType
     * @param status
     * @return
     */
    public List<AmAppkeyDTO> getsByType(Long platformId, Long ownerBuId, String appKey,
                                        String appkeyType, Long status);

    /**
     * 查询状态为1的数据
     *
     * @param platformId
     * @param appKey
     * @param appkeyType
     * @return
     */
    public AmAppkeyDTO getByAppkey(Long platformId, String appKey, String appkeyType);

    /**
     * 查询状态为1的数据
     *
     * @param platformId
     * @param ownerBuId
     * @param appType
     * @return
     */
    public AmAppkeyDTO getByType(Long platformId, Long ownerBuId, String appType);

    /**
     * 根据类型获取可用状态的appKeys
     *
     * @return
     */
    public List<AmAppkeyDTO> getsUsableKeys(String appType);
}