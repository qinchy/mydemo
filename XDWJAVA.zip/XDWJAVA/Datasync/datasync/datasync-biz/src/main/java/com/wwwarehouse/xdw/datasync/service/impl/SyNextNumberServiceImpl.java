package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.ukid.model.SyNextNumberDO;
import com.wwwarehouse.commons.ukid.service.SyNextNumberService;
import com.wwwarehouse.xdw.datasync.dao.mapper.SyNextNumberMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 流水号序列数的实现
 *
 * Created by zhigang.huang on 17/6/13.
 */
@Service("syNextNumberService")
public class SyNextNumberServiceImpl implements SyNextNumberService {

    @Resource
    SyNextNumberMapper syNextNumberMapper;

    public String getNextNumber(String numberType) {
        SyNextNumberDO nextNumberDO = new SyNextNumberDO();
        nextNumberDO.setNumberType(numberType);
        syNextNumberMapper.getNextNumber(nextNumberDO);
        return nextNumberDO.getReturnNo();
    }

    public Long getNextSeq() {
        return syNextNumberMapper.getNextSeq();
    }

    public String getAppSecret() {
        return syNextNumberMapper.getAppSecret();
    }
}
