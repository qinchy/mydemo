package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.spring.SpringContextUtil;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.manager.SeBaseTradeManager;
import com.wwwarehouse.xdw.datasync.manager.SeTradeDownManager;
import com.wwwarehouse.xdw.datasync.manager.SyParamManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeBaseTrade;
import com.wwwarehouse.xdw.datasync.model.SyParamDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/14 0014.
 */
@Service
public class SeTradeDownManagerImpl implements SeTradeDownManager {
    private static Logger _log = LoggerFactory.getLogger(SeTaobaoItemManagerImpl.class);
    @Resource
    SyParamManager syParamManager;

    @Override
    public AbsResponse<String> downTrades(AmAppSubscriptionDTO amAppSubscription, boolean isRedown) {
        AbsResponse<String> retBean = new AbsResponse<>();

        Long platformId = amAppSubscription.getPlatformId();
        String statusStr = syParamManager.getParamValue(platformId, SyParamDTO.S_DOWN_TRADE_STATUS);
        if (statusStr == null) {
            return retBean.setResult(108, "未定义需要下载的订单状态!");
        }

        String statuses[] = statusStr.split(";");
        for (String status : statuses) {
            downTrades(amAppSubscription, status, isRedown, false);
        }

        return retBean;
    }

    @Override
    public AbsResponse<String> downHistoryTrades(AmAppSubscriptionDTO amAppSubscription) {
        AbsResponse<String> retBean = new AbsResponse<>();

        Long platformId = amAppSubscription.getPlatformId();
        String statusStr = syParamManager.getParamValue(platformId, SyParamDTO.S_DOWN_TRADE_STATUS_HIS);
        if (statusStr == null) {
            return retBean.setResult(108, "未定义需要下载的历史订单状态!");
        }

        String statuses[] = statusStr.split(";");
        for (String status : statuses) {
            downTrades(amAppSubscription, status, false, true);
        }

        return retBean;
    }

    public AbsResponse<String> downTrades(AmAppSubscriptionDTO amAppSubscription, String status, boolean isRedown, boolean isHis){
        AbsResponse<String> retBean = new AbsResponse<>();

        Long shopId = amAppSubscription.getSubscriptionBuId();

        Date[] downDates = null;
        if(isHis) {
            downDates = syParamManager.getHisTradeDownDates(shopId, status, isRedown);
        } else {
            downDates = syParamManager.getTradeDownDates(shopId, status, isRedown);
        }
        if (downDates == null) {
            return retBean.setResult(108, "订单未抓取成功, 时间范围不正确!");
        }

        //如果下载历史订单，下载的开始时间大于当前时间，则要关闭下载历史订单
        if(isHis && System.currentTimeMillis() - downDates[1].getTime() < 1000 * 30 ){
            syParamManager.updateOrInsert(shopId, SyParamDTO.L_NEED_DOWN_TRADE_HIS, "0");
            return retBean;
        }

        DateUtil.DateIterator di = new DateUtil.DateIterator(downDates[0], downDates[1], Calendar.HOUR_OF_DAY, 1);
        Date startDate = di.nextTime();
        while (di.hasNext()) {
            Date endDate = di.nextTime();
            downTradesSmallTime(amAppSubscription, status, startDate, endDate, isHis);

            if(di.hasNext()){
                startDate = new Date(endDate.getTime());
            }
        }

        return retBean;
    }

    private void downTradesSmallTime(AmAppSubscriptionDTO amAppSubscription, String status, Date startDate, Date endDate, boolean isHis) {
        ITradeApi api = ApiUtil.getTradeApi(amAppSubscription);
        Long shopId = amAppSubscription.getSubscriptionBuId();
        Long platformId = amAppSubscription.getPlatformId();
        String serviceName = ApiUtil.getTradeService(platformId);

        SeBaseTradeManager<? extends SeBaseTrade<? extends SeBaseItem>, ? extends SeBaseItem> tradeService
                = (SeBaseTradeManager<? extends SeBaseTrade<? extends SeBaseItem>, ? extends SeBaseItem>)
                SpringContextUtil.getBean(serviceName);
        do {
            int num = 0;
            try {
                AbsResponse<List<?>> rsp = api.catchTradesPerPage(startDate, endDate, status, true);
                List<?> pTrades = rsp.getData();
                num = dumpTrades(tradeService, shopId, (List<SeBaseTrade<? extends SeBaseItem>>)pTrades);
            } catch (Exception e) {
                _log.error(StringUtils.toString(shopId), e);
            }
//			finally {
//                try {
//                    if (api != null && api.getAccessLogList() != null) {
//                        for (int i = 0; i < api.getAccessLogList().size(); i++) {
//                            api.getAccessLogList().get(i).setDoResult(String.valueOf(num));
//                        }
//                        mongoDao.dumpRecords(api.getAccessLogList());
//                    }
//                }catch (Exception e){
//                    logger.error("dump mongodb error", e);
//                }
//			}
        } while (null != api && api.hasNext());

        String paramName = null;
        if(isHis) {
            paramName = SyParamDTO.D_LAST_TRADE_HIS + status;
        } else {
            paramName = SyParamDTO.D_LAST_TRADE + status;
        }
        String paramValue = DateUtil.toDateTimeString(endDate);
        syParamManager.updateOrInsert(shopId, paramName, paramValue);
    }

    private int dumpTrades(SeBaseTradeManager tradeService, Long shopId,
                           List<? extends SeBaseTrade<? extends SeBaseItem>> pTrades) {
        int num = 0;
        Long userId = 999L;
        if(pTrades != null) for (SeBaseTrade<? extends SeBaseItem> t : pTrades) {
            try {
                AbsResponse<?> retBean = tradeService.saveTrade(shopId, t, userId);
            } catch (Exception e) {
                _log.error(t.getOrderId(), e);
            }
        }
        return num;
    }

}
