package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDOExample;

/**
* SeTaobaoItemService
*  on 2017/6/14.
*/
public class SeTaobaoItemManagerMock extends BaseServiceMock<SeTaobaoItemDOMapper, SeTaobaoItemDO, SeTaobaoItemDOExample> implements SeTaobaoItemManager {

}
