package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDO;
import com.wwwarehouse.xdw.datasync.manager.AmSmsSortManager;
import com.wwwarehouse.xdw.datasync.model.AmSmsSort;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDOExample;

import java.util.List;

/**
* AmSmsSortManager
*  on 2017/6/21.
*/
public class AmSmsSortManagerMock extends BaseManagerMock<AmSmsSort, AmSmsSortDOExample> implements AmSmsSortManager {

    @Override
    public AmSmsSortDO getAmSmsSortByAppUkids(List<Long> appUkids) {
        return null;
    }
}
