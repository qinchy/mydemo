package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDOExample;

/**
* AmAuthRecordService
*  on 2017/6/16.
*/
public interface AmAuthRecordManager extends BaseService<AmAuthRecordDO, AmAuthRecordDOExample> {

}