package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.xdw.datasync.dao.mapper.ImPlatformItemIllegalDOMapper;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemIllegalDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDOExample;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemIllegalManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;

/**
* ImPlatformItemIllegalManagerImpl
*  on 2017/6/16.
*/
@Service
@Transactional
public class ImPlatformItemIllegalManagerImpl extends BaseManagerImpl<ImPlatformItemIllegalDOMapper, ImPlatformItemIllegalDTO, ImPlatformItemIllegalDO, ImPlatformItemIllegalDOExample> implements ImPlatformItemIllegalManager {

    private static Logger _log = LoggerFactory.getLogger(ImPlatformItemIllegalManagerImpl.class);

    @Autowired
    ImPlatformItemIllegalDOMapper imPlatformItemIllegalDOMapper;

    @Override
    public ImPlatformItemIllegalDOMapper getMapper() {
        return imPlatformItemIllegalDOMapper;
    }

    @Override
    public int saveIllegal(Long lotUkid, ImPlatformItemIllegalDTO illPlatItem) throws Exception {

        ImPlatformItemIllegalDOExample imPlatformItemIllegalDOExample = new ImPlatformItemIllegalDOExample();
        imPlatformItemIllegalDOExample.createCriteria().andShopIdEqualTo(illPlatItem.getShopId())
                .andOwnerIdEqualTo(illPlatItem.getOwnerId()).andProductNumIdEqualTo(illPlatItem.getProductNumId())
                .andSkuNumIdEqualTo(illPlatItem.getSkuNumId());

        if(imPlatformItemIllegalDOMapper.countByExample(imPlatformItemIllegalDOExample) > 0){
            return 0;
        }

        illPlatItem.setLotUkid(lotUkid);
        if (illPlatItem.getPlatformItemUkid() == null) {
            illPlatItem.setPlatformItemUkid(UKID.getUKID());
        }
        ImPlatformItemIllegalDO imPlatformItemIllegalDO = new ImPlatformItemIllegalDO();
        BeanUtils.copyProperties(illPlatItem, imPlatformItemIllegalDO);

        return imPlatformItemIllegalDOMapper.insert(imPlatformItemIllegalDO);
    }
}