package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.dao.model.SyParamDO;
import com.wwwarehouse.xdw.datasync.manager.SeBaseRefundManager;
import com.wwwarehouse.xdw.datasync.manager.SyParamManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeBaseRefund;
import com.wwwarehouse.xdw.datasync.model.SyParamDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRefundApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jianjun.guan on 2017/6/15 0015.
 */
@Service
public abstract class SeBaseRefundManagerImpl<T extends SeBaseRefund<E>, E extends SeBaseItem>
        implements SeBaseRefundManager<T> {

    private static Logger _log = LoggerFactory.getLogger(SeBaseRefundManagerImpl.class);

    @Resource
    SyParamManager syParamManager;


    @Override
    public AbsResponse downRefund(AmAppSubscriptionDTO amAppSubscription, String refundId) throws Exception {
        Long shopId = amAppSubscription.getSubscriptionBuId();
        IRefundApi api = ApiUtil.getRefundApi(amAppSubscription);
        AbsResponse<T> rsp = api.getRefund(refundId);
        if (rsp.isSuccess()) {
            // Todo 日志记录成功
            return this.saveRefund(shopId, rsp.getData());
        } else {
            // Todo 日志记录错误
            return rsp;
        }
    }

    @Override
    public AbsResponse updateRefund(AmAppSubscriptionDTO amAppSubscription, String refundId) throws Exception {
        Long shopId = amAppSubscription.getSubscriptionBuId();
        IRefundApi api = ApiUtil.getRefundApi(amAppSubscription);
        AbsResponse rsp = api.getRefund(refundId);
        if (rsp.isSuccess()) {
            // Todo 日志记录成功
            return this.updateRefundStatus(shopId, rsp.getData());
        } else {
            // Todo 日志记录错误
            Map<String, Long> map = new HashMap<String, Long>();
            map.put("success", 0L);
            map.put("fail", 1L);
            rsp.setData(map);
            _log.error("同步平台退款单失败", refundId + rsp.getMsg());
            return rsp;
        }
    }

    /*
	 * 保存退款单的其中的判断
	 * 业务流程还不熟悉
	 * 暂时先放着
	 */
    @Override
    public AbsResponse saveRefund(Long shopId, T refund) throws Exception {
        AbsResponse<Long> retBean = checkeRefund(refund);

        //检查状态是否正常，是否有设置不用下载
        if (retBean.getCode() != 0) {
            return retBean;
        }
        refund.setShopId(shopId);

        return null;
    }

    public abstract AbsResponse checkeRefund(T pTrade) throws Exception;

    @Override
    public AbsResponse downRefunds(AmAppSubscriptionDTO amAppSubscription) throws Exception {
        AbsResponse retBean=new AbsResponse();
        Date[] downDates = syParamManager.getRefundDownDates(
                amAppSubscription.getSubscriptionBuId(), false);
        if (downDates == null) {
            return retBean.setResult(108, "退款单未抓取成功!");
        }
        //暂时写死
        downDates[0] = DateUtil.addHours(new Date(), -2);
        downDates[1] = new Date();
        Long platformId = amAppSubscription.getApp().getPlatformId();
        String statusStr = syParamManager.getParamValue(platformId, "Refund_status_down");

        if (statusStr == null) {
            return retBean.setResult(108, "未定义需要下载的订单状态!");
        }
        int num = 0;
        String statuses[] = statusStr.split(";");

        for (String status : statuses) {
            num += downRefundSmallTime(amAppSubscription, status, downDates[0], downDates[1]);
        }
        SyParamDTO pm = new SyParamDTO();
        pm.setRelatedId(amAppSubscription.getSubscriptionBuId());
        pm.setParamName("D_LAST_REFUND");
        pm.setParamValue(DateUtil.toDateTimeString(downDates[1]));
        syParamManager.updateOrInsert(pm);
        // Todo 监控。每次请求的保存的数量
        return retBean;
    }

    @Override
    public AbsResponse updateRefundStatus(Long shopId, Object pRefundList) throws Exception {
        return null;
    }


    private int downRefundSmallTime(AmAppSubscriptionDTO amAppSubscription, String status, Date startDate, Date endDate) {
        IRefundApi api = ApiUtil.getRefundApi(amAppSubscription);
        Long shopId = amAppSubscription.getSubscriptionBuId();
        AbsResponse retBean = null;
        int num = 0;
        do {
            try {
                AbsResponse rsp = api.fetchRefunds(startDate, endDate, status);
                if (rsp.isSuccess()) {
                    Map obj = (Map) rsp.getData();
                    List<T> trades = (List<T>) obj.get("refund");
                    for (T t : trades) {
                        try {
                            retBean = this.saveRefund(shopId, t);
                            if (retBean.isSuccess()) {
                                num++;
                            }
                        } catch (Exception e) {
                            //Todo 日志记录错误
                            _log.error(e.toString());
                        }
                    }
                } else {

                    //Todo 日志记录错误
                }
            } catch (Exception e) {
                _log.error(StringUtils.toString(amAppSubscription.getSubscriptionBuId()), e);
            }
        } while (api.hasNext());
        return num;
    }

}
