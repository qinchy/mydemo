package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.manager.AliPayManager;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.UnionPayManager;
import com.wwwarehouse.xdw.datasync.manager.WechatPayManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.PayPlatform;
import com.wwwarehouse.xdw.datasync.service.PayService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by chengwei on 2017/6/9 13:57.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class PayServiceImpl implements PayService {
    @Resource
    private AliPayManager aliPayManager;
    @Resource
    private WechatPayManager wechatManager;
    @Resource
    private UnionPayManager unionPayManager;
    @Resource
    private AmAppSubscriptionManager amAppSubscriptionManager;

    @Override
    public AbsResponse<Object> mobilePay(PayParamsDTO payParamsDTO) throws Exception{
        AbsResponse<Object> abs = new AbsResponse();
        Long platFormId = payParamsDTO.getPlatFormId();
        Long payServiceId = Constants.WCKJ.longValue();
        String payAppType = Constants.payAppType.trim();

        AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(
                platFormId, payServiceId, payAppType);
        if (appSuber == null) {
            abs.setResult(11111, "信息缺失");
            return abs;
        }
        if (PayPlatform.ALIPAY.equalsById(platFormId)) {
            abs = aliPayManager.aliPayValidate(appSuber, payParamsDTO);

        } else if (PayPlatform.WECHATPAY.equalsById(platFormId)) {
            abs = wechatManager.launchWechatPay(appSuber, payParamsDTO);
        } else if (PayPlatform.UNIONPAY.equalsById(platFormId)) {
            abs = unionPayManager.launchCommonPay(appSuber, payParamsDTO);
        }

        return abs;
    }

    @Override
    public String aliAnalyzeData(String request) throws Exception{
        return  aliPayManager.aliAnalyzeData(request);
    }

	@Transactional
	@Override
	public String UnionAnalyzeData(String request) throws Exception{
		return unionPayManager.unionAnalyzeData(request);
	}

    @Override
    public String wechatAnalyzeData(String request) throws Exception {
        return wechatManager.wechatAnalyzeData(request);
    }
}
