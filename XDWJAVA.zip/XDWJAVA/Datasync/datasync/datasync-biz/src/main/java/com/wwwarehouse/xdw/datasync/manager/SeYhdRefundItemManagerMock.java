package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdRefundItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDOExample;

/**
* SeYhdRefundItemService
*  on 2017/6/14.
*/
public class SeYhdRefundItemManagerMock extends BaseServiceMock<SeYhdRefundItemDOMapper, SeYhdRefundItemDO, SeYhdRefundItemDOExample> implements SeYhdRefundItemManager {

}
