package com.wwwarehouse.xdw.datasync.manager;


import com.wwwarehouse.xdw.datasync.dao.model.AmDownTimeDO;
import com.wwwarehouse.xdw.datasync.model.AmDownTimeDTO;

import java.util.Date;

public interface AmDownTimeManager {
	public AmDownTimeDTO getDownTime(Long shopId);

	public AmDownTimeDTO getHistoryDownTime(Long shopId);

	public AmDownTimeDTO addDowntime(Long relatedId, boolean isValid, Date startDownTime,
                                    Date endDownTime, Long opUserId) throws Exception;
	public AmDownTimeDTO addHistoryDowntime(Long relatedId, boolean isValid, Date startDownTime,
                                           Date endDownTime, Long opUserId) throws Exception;

	public int closeDowntime(Long relatedId, Long opUserId) throws Exception;

	public int closeHistoryDowntime(Long relatedId, Long opUserId) throws Exception;


}