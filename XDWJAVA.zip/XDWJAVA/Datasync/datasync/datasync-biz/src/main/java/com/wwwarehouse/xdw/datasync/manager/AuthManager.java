package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;

/**
 * Created by jianjun.guan on 2017/6/16 0016.
 */
public interface AuthManager {

    /**
     * 组装授权Url
     *
     * @param platformId
     * @param state
     * @return
     */
    public AbsResponse<String> getAuthUrl(Long platformId, String state);

    /**
     * 保存授权
     *
     * @param shopId
     * @param platformId
     * @param authRecord
     * @param userId
     * @return
     */
    public AbsResponse<AmAppSubscriptionDTO> saveAuth(Long shopId, Long platformId,
                                                      AmAuthRecordDTO authRecord, Long userId) throws Exception;

    /**
     * 刷新授权
     *
     * @param amAppSubscription
     * @param userId
     * @return
     */
    public AbsResponse<AmAppSubscriptionDTO> refreshAuth(AmAppSubscriptionDTO amAppSubscription,
                                                      Long userId) throws Exception;


    /**
     * 获取授权令牌
     * @param amAppKey
     * @param code
     * @return
     */
    public  AbsResponse<AmAuthRecordDTO> grantAuth(AmAppkeyDTO amAppKey, String code);
//    public AbsResponse<String> tradeDownPermit(Long shopId, Long platformId, String sellerNick, Long userId)throws Exception;

}
