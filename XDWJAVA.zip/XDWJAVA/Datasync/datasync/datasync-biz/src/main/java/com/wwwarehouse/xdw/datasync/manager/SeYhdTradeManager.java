package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDOExample;

/**
* SeYhdTradeService
*  on 2017/6/14.
*/
public interface SeYhdTradeManager extends BaseService<SeYhdTradeDO, SeYhdTradeDOExample> {

}