package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongItemMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemExample;
import com.wwwarehouse.xdw.datasync.model.SeJingdongItemDTO;

import java.util.List;

/**
* SeJingdongItemService
*  on 2017/6/13.
*/
public class SeJingdongItemManagerMock extends BaseServiceMock<SeJingdongItemMapper, SeJingdongItemDO, SeJingdongItemExample> implements SeJingdongItemManager {

    @Override
    public List<SeJingdongItemDTO> getsOrderByTradeUkid(Long tradeUkid) {
        return null;
    }

    @Override
    public SeJingdongItemDTO matchItem(List<SeJingdongItemDTO> oItemList, SeJingdongItemDTO pItem) throws Exception {
        return null;
    }

    @Override
    public int saveItem(SeJingdongItemDTO item) throws Exception {
        return 0;
    }

    @Override
    public int updateItem(SeJingdongItemDTO item) throws Exception {
        return 0;
    }

    @Override
    public int updateOriginItemStatus(SeJingdongItemDTO oItem) {
        return 0;
    }
}
