package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmSmsSortDOMapper;
import com.wwwarehouse.xdw.datasync.model.AmSmsSort;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDOExample;
import com.wwwarehouse.xdw.datasync.manager.AmSmsSortManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* AmSmsSortManagerImpl
*  on 2017/6/21.
*/
@Service
@Transactional
public class AmSmsSortManagerImpl extends BaseManagerImpl<AmSmsSortDOMapper, AmSmsSort, AmSmsSortDO, AmSmsSortDOExample> implements AmSmsSortManager {

    private static Logger _log = LoggerFactory.getLogger(AmSmsSortManagerImpl.class);

    @Autowired
    AmSmsSortDOMapper amSmsSortDOMapper;

    @Override
    public AmSmsSortDOMapper getMapper() {
        return amSmsSortDOMapper;
    }

    @Override
    public AmSmsSortDO getAmSmsSortByAppUkids(List<Long> appUkids) {
        return amSmsSortDOMapper.getAmSmsSortByAppUkids(appUkids);
    }
}