package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.xdw.datasync.dao.mapper.SyParamDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SyParamDO;
import com.wwwarehouse.xdw.datasync.manager.AmDownTimeManager;
import com.wwwarehouse.xdw.datasync.manager.SyParamManager;
import com.wwwarehouse.xdw.datasync.model.AmDownTimeDTO;
import com.wwwarehouse.xdw.datasync.model.SyParamDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;

/**
* SyParamService
*  on 2017/6/13.
*/
@Service
@Transactional
public class SyParamManagerImpl implements SyParamManager {

    @Resource
    private SyParamDOMapper paramMapper;
//    @Resource
//    private RedisHelper redisHelper;
    @Resource
    private AmDownTimeManager amDownTimeService;

    private static final int OVERLAP_MINUTE = 5;	//重叠时间，5分钟
    private static final int OVERLAP_DAY = 1;		//重叠时间，1小时
    private static final String REDIS_KEY = "SY_PARAM";

    @Override
    public int insert(SyParamDTO param) {
        SyParamDO syParamDO = new SyParamDO();
        BeanUtils.copyProperties(param, syParamDO);
        int i = this.paramMapper.insert(syParamDO);
        if (i > 0) {
//            redisHelper.hset(REDIS_KEY, param.getRelatedId() + param.getParamName(), param);
        }
        return i;
    }

    @Override
    public int update(SyParamDTO param) {
        SyParamDO syParamDO = new SyParamDO();
        BeanUtils.copyProperties(param, syParamDO);
        int i = this.paramMapper.updateByPrimaryKey(syParamDO);
        if (i > 0) {
//            redisHelper.hset(REDIS_KEY, param.getRelatedId() + param.getParamName(), param);
        }
        return i;
    }

    @Override
    public int delete(Long relatedId, String paramName) {
        int i = this.paramMapper.deleteByPrimaryKey(relatedId, paramName);
        if (i > 0) {
//            redisHelper.hdel(REDIS_KEY, relatedId + paramName);
        }
        return i;
    }

    @Override
    public SyParamDTO get(Long relatedId, String paramName) {
//        SyParamDTO param = redisHelper.hget(REDIS_KEY, relatedId + paramName, SyParam.class);
//        if (param == null) {
//            param = this.paramMapper.get(relatedId, paramName);
//            if(param != null){
//                redisHelper.hset(REDIS_KEY, relatedId + paramName, param);
//            }
//        }
//        return param;
        return null;
    }

//    @Override
//    public List<SyParamDTO> gets(PageParameter p) {
//        return this.paramMapper.gets(p);
//    }

    @Override
    public SyParamDTO getOrInsert(Long relatedId, String paramName) {
        SyParamDTO param = get(relatedId, paramName);
        if (param == null) {
            param = new SyParamDTO();
            param.setRelatedId(relatedId);
            param.setParamName(paramName);
            insert(param);
        }
        return param;
    }

    @Override
    public int updateOrInsert(SyParamDTO param) {
        int i = this.update(param);
        if (i == 0) {
            i = this.insert(param);
        }
        return i;
    }

    @Override
    public int updateOrInsert(Long relatedId, String paramName, String paramValue) {
        SyParamDTO pm = new SyParamDTO();
        pm.setRelatedId(relatedId);
        pm.setParamName(paramName);
        pm.setParamValue(paramValue);
        return this.updateOrInsert(pm);
    }

    @Override
    public String getParamValue(Long relatedId, String paramName) {
        SyParamDTO param = get(relatedId, paramName);
        return param == null ? null : param.getParamValue();
    }

    @Override
    public Date getParamDateValue(Long relatedId, String paramName) {
        String value = getParamValue(relatedId, paramName);
        return value == null ? null : DateUtil.parseDateTime(value);
    }

    /**
     * 按设置的下载时间与后期执行纪录计算当前应该下载的时间范围<br/>
     * 如果无下载记录，则开始时间为设置的下载时间开始时间，结束时间为设置的下载结束时间，但最晚时间不晚于当前时间
     * @param relatedId
     * @param paramName
     * @param isRedown
     * @return
     */
    public Date[] getDownDates(Long relatedId, String paramName, boolean isRedown) {
        AmDownTimeDTO shopDownTime = amDownTimeService.getDownTime(relatedId);
        if (shopDownTime == null) {
            return null;
        }

        //下载开始时间
        Date startDate = shopDownTime.getStartDownTime();
        Date lastDownTime = getParamDateValue(relatedId, paramName);
        if (lastDownTime == null) {
            lastDownTime = startDate;
        }
        if (isRedown) {
            lastDownTime = DateUtil.addDays(lastDownTime, -OVERLAP_DAY);// 往回重复时间
        } else {
            lastDownTime = DateUtil.addMinutes(lastDownTime, -OVERLAP_MINUTE);
        }
        if (startDate.getTime() < lastDownTime.getTime()) {
            startDate = lastDownTime;
        }

        Date nowTime = new Date();
        //下载结束时间
        Date endDate = shopDownTime.getEndDownTime();
        if (endDate == null || endDate.after(nowTime)) {
            endDate = nowTime;
        }
        return new Date[] { startDate, endDate };
    }

    public Date[] getTradeDownDates(Long shopId, boolean isReDown) {
        return getDownDates(shopId, SyParamDTO.D_LAST_TRADE, isReDown);
    }

    public Date[] getTradeDownDates(Long shopId, String status, boolean isReDown) {
        return getDownDates(shopId, SyParamDTO.D_LAST_TRADE + status, isReDown);
    }
    public Date[] getHisTradeDownDates(Long shopId, String status, boolean isReDown) {
        return getDownDates(shopId, SyParamDTO.D_LAST_TRADE_HIS + status, isReDown);
    }

    public Date[] getRefundDownDates(Long shopId, boolean isReDown) {
        return getDownDates(shopId, SyParamDTO.D_LAST_REFUND, isReDown);
    }
}