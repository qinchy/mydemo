package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;

/**
 * Created by jianjun.guan on 2017/6/15 0015.
 */
public interface SeBaseRefundManager<T> {
    /**
     * 下载保存单个退款单
     * @param amAppSubscription
     * @param refundId
     * @return
     * @throws Exception
     */
    AbsResponse downRefund(AmAppSubscriptionDTO amAppSubscription, String refundId) throws Exception;


    /**
     * 修改退款单状态
     * @param amAppSubscription
     * @param refundId
     * @return
     * @throws Exception
     */
    AbsResponse updateRefund(AmAppSubscriptionDTO amAppSubscription, String refundId) throws Exception;

    AbsResponse saveRefund(Long shopId, T refund) throws Exception;

    /**
     * 批量下载退款单
     *
     * @param AmAppSubscription
     * @return
     * @throws Exception
     */
    AbsResponse downRefunds(AmAppSubscriptionDTO AmAppSubscription) throws Exception;


    AbsResponse updateRefundStatus(Long shopId, Object pRefundList) throws Exception;

}
