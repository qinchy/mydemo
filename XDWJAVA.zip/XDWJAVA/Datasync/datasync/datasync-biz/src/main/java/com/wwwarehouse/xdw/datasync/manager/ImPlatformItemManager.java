package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemDOExample;

import java.util.List;

/**
* ImPlatformItemManager
*  on 2017/6/16.
*/
public interface ImPlatformItemManager extends BaseManager<ImPlatformItemDTO, ImPlatformItemDOExample> {

    public AbsResponse<String> savePlatformItems(List<ImPlatformItemDTO> platformItems, Long platformId, Long shopId, Long ownerId) throws Exception;
}