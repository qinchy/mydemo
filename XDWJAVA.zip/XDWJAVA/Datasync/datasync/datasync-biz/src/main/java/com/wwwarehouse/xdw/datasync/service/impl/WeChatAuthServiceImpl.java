package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.WeChatAuthManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.service.WeChatAuthService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by dan.han on 2017/6/13.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class WeChatAuthServiceImpl implements WeChatAuthService {
    @Resource
    private WeChatAuthManager weChatAuthManager;

    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode, AmAppkeyDTO amAppkey){
        return weChatAuthManager.grantAuth(authCode, amAppkey);
    }

}
