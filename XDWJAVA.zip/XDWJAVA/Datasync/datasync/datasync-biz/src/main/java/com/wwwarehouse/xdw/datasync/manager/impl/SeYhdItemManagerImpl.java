package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDOExample;
import com.wwwarehouse.xdw.datasync.manager.SeYhdItemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
* SeYhdItemService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeYhdItemManagerImpl extends BaseServiceImpl<SeYhdItemDOMapper, SeYhdItemDO, SeYhdItemDOExample> implements SeYhdItemManager {

    private static Logger _log = LoggerFactory.getLogger(SeYhdItemManagerImpl.class);

    @Autowired
    SeYhdItemDOMapper seYhdItemMapper;

    @Override
    public SeYhdItemDOMapper getMapper() {
        return seYhdItemMapper;
    }
}