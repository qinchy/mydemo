package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdTradeDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDOExample;

/**
* SeYhdTradeService
*  on 2017/6/14.
*/
public class SeYhdTradeManagerMock extends BaseServiceMock<SeYhdTradeDOMapper, SeYhdTradeDO, SeYhdTradeDOExample> implements SeYhdTradeManager {

}
