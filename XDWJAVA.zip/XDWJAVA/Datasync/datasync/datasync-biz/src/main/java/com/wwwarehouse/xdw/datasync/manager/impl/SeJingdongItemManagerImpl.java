package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongItemMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemExample;
import com.wwwarehouse.xdw.datasync.manager.SeJingdongItemManager;
import com.wwwarehouse.xdw.datasync.model.SeJingdongItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
* SeJingdongItemService
*  on 2017/6/13.
*/
@Service
@Transactional
public class SeJingdongItemManagerImpl extends BaseServiceImpl<SeJingdongItemMapper, SeJingdongItemDO, SeJingdongItemExample> implements SeJingdongItemManager {

    private static Logger _log = LoggerFactory.getLogger(SeJingdongItemManagerImpl.class);

    @Autowired
    SeJingdongItemMapper seJingdongItemMapper;

    @Override
    public SeJingdongItemMapper getMapper() {
        return seJingdongItemMapper;
    }

    @Override
    public List<SeJingdongItemDTO> getsOrderByTradeUkid(Long tradeUkid) {
//        return seJingdongItemMapper.getsByTradeUkid(tradeUkid);
        SeJingdongItemExample seJingdongItemExample = new SeJingdongItemExample();
        seJingdongItemExample.createCriteria().andTradeUkidEqualTo(tradeUkid);
        List<SeJingdongItemDO> seJingdongItemDOs = seJingdongItemMapper.selectByExample(seJingdongItemExample);
        List<SeJingdongItemDTO> seJingdongItemDTOs = new ArrayList<>();
        for (SeJingdongItemDO seJingdongItemDO : seJingdongItemDOs){
            seJingdongItemDTOs.add(converDTO(seJingdongItemDO));
        }
        return seJingdongItemDTOs;
    }

    @Override
    public SeJingdongItemDTO matchItem(List<SeJingdongItemDTO> oItemList, SeJingdongItemDTO pItem) throws Exception {
        for (SeJingdongItemDTO oItem : oItemList) {
            if (pItem.getSkuId().equals(oItem.getSkuId())) {
                oItem.setCouponPrice(pItem.getCouponPrice());
                //TODO 还要对其他字段赋值
                return oItem;
            }
        }
        return null;
    }

    @Override
    public int saveItem(SeJingdongItemDTO item) throws Exception {
        return seJingdongItemMapper.insert(converDO(item));
    }

    @Override
    public int updateItem(SeJingdongItemDTO item) throws Exception {
//        return seJingdongItemMapper.update(item);
        SeJingdongItemExample seJingdongItemExample = new SeJingdongItemExample();
        seJingdongItemExample.createCriteria().andTradeUkidEqualTo(item.getTradeUkid());
        return seJingdongItemMapper.updateByExample(converDO(item), seJingdongItemExample);
    }
    @Override
    public int updateOriginItemStatus(SeJingdongItemDTO oItem){
        SeJingdongItemExample seJingdongItemExample = new SeJingdongItemExample();
        seJingdongItemExample.createCriteria().andTradeUkidEqualTo(oItem.getTradeUkid());
        return seJingdongItemMapper.updateByExample(converDO(oItem), seJingdongItemExample);//seJingdongItemMapper.updateOriginStatus(oItem);
    }

    private SeJingdongItemDO converDO(SeJingdongItemDTO seJingdongItemDTO){
        SeJingdongItemDO seJingdongItemDO = new SeJingdongItemDO();
        BeanUtils.copyProperties(seJingdongItemDO, seJingdongItemDTO);
        return seJingdongItemDO;
    }

    private SeJingdongItemDTO converDTO(SeJingdongItemDO seJingdongItemDO){
        SeJingdongItemDTO seJingdongItemDTO = new SeJingdongItemDTO();
        BeanUtils.copyProperties(seJingdongItemDTO, seJingdongItemDO);
        return seJingdongItemDTO;
    }
}