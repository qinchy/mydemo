package com.wwwarehouse.xdw.datasync.manager.impl;

import com.alibaba.fastjson.JSONObject;
import com.wwwarehouse.commons.mq.MqProducer;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.dao.mapper.ItemMapper;
import com.wwwarehouse.xdw.datasync.dao.model.ItemDO;
import com.wwwarehouse.xdw.datasync.manager.ItemManager;
import com.wwwarehouse.xdw.datasync.model.Item;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by shisheng.wang on 17/6/6.
 */

public class ItemManagerImpl implements ItemManager {

    @Resource
    ItemMapper itemMapper;

    @Override
    public Item get(long itemId) {
        ItemDO itemDO = itemMapper.selectByPrimaryKey(itemId);
        Item item = new Item();
        BeanUtils.copyProperties(itemDO, item);
        Map<String, String> features = new HashMap();
        if (itemDO.getFeatures() != null) {
            JSONObject jsonObject = JSONObject.parseObject(itemDO.getFeatures());
            features.put("a", jsonObject.getString("a"));
        }
        item.setFeatures(features);
        return item;
    }

    @Transactional
    @Override
    public int add(Item item) {
        ItemDO itemDO = new ItemDO();
        BeanUtils.copyProperties(item, itemDO);
        itemDO.setFeatures(JSONObject.toJSONString(item.getFeatures()));

        //
        return itemMapper.insert(itemDO);
    }
}
