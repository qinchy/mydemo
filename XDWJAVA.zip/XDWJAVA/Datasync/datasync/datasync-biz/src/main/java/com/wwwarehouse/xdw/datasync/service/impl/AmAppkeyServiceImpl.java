package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.service.IAmAppkeyService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/19 0019.
 */
@Service
public class AmAppkeyServiceImpl implements IAmAppkeyService {

    @Resource
    AmAppKeyManager amAppKeyManager;

    @Override
    public List<AmAppkeyDTO> getsByType(Long platformId, Long ownerBuId, String appKey, String appkeyType, Long status) {
        return amAppKeyManager.getsByType(platformId,ownerBuId,appKey,appkeyType,status);
    }

    @Override
    public AmAppkeyDTO getByAppkey(Long platformId, String appKey, String appkeyType) {
        return amAppKeyManager.getByAppkey(platformId, appKey, appkeyType);
    }

    @Override
    public AmAppkeyDTO getByType(Long platformId, Long ownerBuId, String appType) {
        return amAppKeyManager.getByType(platformId, ownerBuId, appType);
    }

    @Override
    public List<AmAppkeyDTO> getsUsableKeys(String appType) {
        return amAppKeyManager.getsUsableKeys(appType);
    }
}
