package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdRefundItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDOExample;
import com.wwwarehouse.xdw.datasync.manager.SeYhdRefundItemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
* SeYhdRefundItemService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeYhdRefundItemManagerImpl extends BaseServiceImpl<SeYhdRefundItemDOMapper, SeYhdRefundItemDO, SeYhdRefundItemDOExample> implements SeYhdRefundItemManager {

    private static Logger _log = LoggerFactory.getLogger(SeYhdRefundItemManagerImpl.class);

    @Autowired
    SeYhdRefundItemDOMapper seYhdRefundItemMapper;

    @Override
    public SeYhdRefundItemDOMapper getMapper() {
        return seYhdRefundItemMapper;
    }
}