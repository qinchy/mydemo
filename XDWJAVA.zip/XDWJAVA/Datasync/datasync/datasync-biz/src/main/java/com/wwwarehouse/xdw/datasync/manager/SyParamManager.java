package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SyParamDOExample;
import com.wwwarehouse.xdw.datasync.model.SyParamDTO;

import java.util.Date;
import java.util.List;

/**
* SyParamService
*  on 2017/6/13.
*/
public interface SyParamManager {
    public int insert(SyParamDTO param);

    public int update(SyParamDTO param);

    public int delete(Long relatedId, String paramName);

    public SyParamDTO get(Long relatedId, String paramName);

//    public List<SyParamDTO> gets(PageParameter p);

    public SyParamDTO getOrInsert(Long relatedId, String paramName);

    public int updateOrInsert(SyParamDTO param);

    public int updateOrInsert(Long relatedId, String paramName, String paramValue);

    public String getParamValue(Long relatedId, String paramName);

    public Date getParamDateValue(Long shopId, String paramName);

    public Date[] getTradeDownDates(Long shopId, boolean isReDown);

    public Date[] getHisTradeDownDates(Long shopId, String status, boolean isReDown);
    public Date[] getTradeDownDates(Long shopId, String status, boolean isReDown);

    public Date[] getRefundDownDates(Long shopId, boolean isReDown);
}