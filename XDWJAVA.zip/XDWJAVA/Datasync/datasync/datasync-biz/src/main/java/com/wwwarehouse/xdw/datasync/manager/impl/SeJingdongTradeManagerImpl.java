package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongItemMapper;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongTradeMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeExample;
import com.wwwarehouse.xdw.datasync.model.SeJingdongItemDTO;
import com.wwwarehouse.xdw.datasync.model.SeJingdongTradeDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* SeJingdongTradeDOService
*  on 2017/6/13.
*/
@Service
@Transactional
public class SeJingdongTradeManagerImpl extends SeBaseTradeManagerImpl<SeJingdongTradeDTO, SeJingdongItemDTO> {

    private static Logger _log = LoggerFactory.getLogger(SeJingdongTradeManagerImpl.class);

    @Autowired
    SeJingdongTradeMapper seJingdongTradeMapper;
    @Autowired
    SeJingdongItemMapper seJingdongItemMapper;

    @Override
    public AbsResponse updateTrade(SeJingdongTradeDTO trade) throws Exception {
        return null;
    }

    @Override
    public SeJingdongTradeDTO getByTid(Long shopId, String tid) {
        SeJingdongTradeExample seJingdongTradeExample = new SeJingdongTradeExample();
        seJingdongTradeExample.createCriteria().andShopIdEqualTo(shopId).andOrderIdEqualTo(tid);
        return converDTO(seJingdongTradeMapper.selectByExample(seJingdongTradeExample).get(0));
        //SeJingdongTradeMapper.getByOrderId(shopId, tid);
    }

    @Override
    public int updatePlatformInfo(SeJingdongTradeDTO trade) throws Exception {
        SeJingdongTradeExample seJingdongTradeExample = new SeJingdongTradeExample();
        seJingdongTradeExample.createCriteria().andTradeUkidEqualTo(trade.getTradeUkid());
        return seJingdongTradeMapper.updateByExample(converDO(trade), seJingdongTradeExample); //SeJingdongTradeMapper.updatePlatformInfo(trade);
    }

    @Override
    public AbsResponse<SeJingdongTradeDTO> checkTrade(SeJingdongTradeDTO pTrade) throws Exception {
        AbsResponse<SeJingdongTradeDTO> checkResp = new AbsResponse<>();
        if (pTrade == null) {
            return checkResp.setResult(108, "订单未抓取成功!");
        }
        if (!needSend(pTrade.getPlatformOrderStatus())) {
            return checkResp.setResult(104, "不是待发货订单:" + pTrade.getPlatformOrderStatus());
        }
        return checkResp;
    }

    @Override
    public AbsResponse<SeJingdongTradeDTO> checkHisTrade(SeJingdongTradeDTO pTrade) throws Exception {
        AbsResponse<SeJingdongTradeDTO> checkResp = new AbsResponse<>();
        if (pTrade == null) {
            return checkResp.setResult(108, "订单未抓取成功!");
        }
        if (!isTradeFinish(pTrade.getPlatformOrderStatus())) {
            return checkResp.setResult(104, "不是待发货订单:" + pTrade.getPlatformOrderStatus());
        }
        return checkResp;
    }



    @Override
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId) {
        return null;//seJingdongItemMapper.getsItemByProduct(productNumId, skuNumId, shopId);
    }

    @Override
    public SeJingdongItemDTO matchItem(List<SeJingdongItemDTO> oItemList, SeJingdongItemDTO pItem) throws Exception {
        return null;
    }

    @Override
    public int saveItem(SeJingdongItemDTO item) throws Exception {
        SeJingdongItemDO seJingdongItemDO = new SeJingdongItemDO();
        BeanUtils.copyProperties(item, seJingdongItemDO);
        return seJingdongItemMapper.insert(seJingdongItemDO);
    }

    @Override
    public int updateItem(SeJingdongItemDTO item) throws Exception {
        SeJingdongItemDO seJingdongItemDO = new SeJingdongItemDO();
        BeanUtils.copyProperties(item, seJingdongItemDO);
        return seJingdongItemMapper.updateByPrimaryKey(seJingdongItemDO);
    }

    @Override
    public int saveTrdeDO(SeJingdongTradeDTO trade) throws Exception {
        SeJingdongTradeDO seJingdongTradeDO = new SeJingdongTradeDO();
        BeanUtils.copyProperties(trade, seJingdongTradeDO);
        return seJingdongTradeMapper.insert(seJingdongTradeDO);
    }

    @Override
    public int updateTrdeDO (SeJingdongTradeDTO trade) throws Exception {
        SeJingdongTradeDO seJingdongTradeDO = new SeJingdongTradeDO();
        BeanUtils.copyProperties(trade, seJingdongTradeDO);
        return seJingdongTradeMapper.updateByPrimaryKey(seJingdongTradeDO);
    }

//    @Override
//    public int updateOriginStatus(SeJingdongTradeDO oTrade) {
        //TODO
//        if(oTrade.getItemList() != null && !oTrade.getItemList().isEmpty()){
//            for(SeJingdongItemDO oItem : oTrade.getItemList()) {
//                SeJingdongItemManager.updateOriginItemStatus(oItem);
//            }
//        }

//        return 1;//SeJingdongTradeMapper.updateOriginStatus(oTrade);
//    }



    //    	WAIT_GOODS_RECEIVE_CONFIRM	等待确认收货
//    	RECEIPTS_CONFIRM	收款确认(LBP,SOPL)
//    	DISTRIBUTION_CENTER_RECEIVED	配送中心已收货(LBP,SOPL)
//    	WAIT_SELLER_STOCK_OUT	等待出库
//    	SEND_TO_DISTRIBUTION_CENER	发往配送中心(LBP,SOPL)
//    	FINISHED_L	完成
//    	WAIT_SELLER_DELIVERY	等待发货(SOP)
//    	TRADE_CANCELED	取消
//    	LOCKED	已锁定
    @Override
    public boolean isTradeClosed(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "Canceled":            	//已取消
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }

    //    WAIT_SELLER_STOCK_OUT 等待出库
//    SEND_TO_DISTRIBUTION_CENER 发往配送中心（只适用于LBP，SOPL商家）
//    DISTRIBUTION_CENTER_RECEIVED 配送中心已收货（只适用于LBP，SOPL商家）
//    WAIT_GOODS_RECEIVE_CONFIRM 等待确认收货
//    RECEIPTS_CONFIRM 收款确认（服务完成）（只适用于LBP，SOPL商家）
//    WAIT_SELLER_DELIVERY等待发货（只适用于海外购商家，等待境内发货 标签下的订单）
//    FINISHED_L 完成
//    TRADE_CANCELED 取消
//    LOCKED 已锁定
//    PAUSE 暂停（适用于LOC订单）
    @Override
    public boolean isTradeFinish(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "FINISHED_L":            	//完成
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }

    @Override
    public boolean needSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "WAIT_SELLER_STOCK_OUT":  		//等待出库
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }

    @Override
    public boolean canSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "WAIT_SELLER_STOCK_OUT":        //等待出库
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }

    @Override
    public boolean canConvert(String platformOrderStatus) {
        boolean canConvert;
        switch (platformOrderStatus) {
            case "WAIT_SELLER_STOCK_OUT":        //等待出库
            case "FINISHED_L":            	//完成
            {
                canConvert = true;
                break;
            }
            default:
                canConvert = false;
                break;
        }

        return canConvert;
    }

    private SeJingdongTradeDO converDO(SeJingdongTradeDTO seJingdongTradeDTO){
        SeJingdongTradeDO seJingdongTradeDO = new SeJingdongTradeDO();
        BeanUtils.copyProperties(seJingdongTradeDO, seJingdongTradeDTO);
        return seJingdongTradeDO;
    }

    private SeJingdongTradeDTO converDTO(SeJingdongTradeDO seJingdongTradeDO){
        SeJingdongTradeDTO seJingdongTradeDTO = new SeJingdongTradeDTO();
        BeanUtils.copyProperties(seJingdongTradeDTO, seJingdongTradeDO);
        return seJingdongTradeDTO;
    }
}