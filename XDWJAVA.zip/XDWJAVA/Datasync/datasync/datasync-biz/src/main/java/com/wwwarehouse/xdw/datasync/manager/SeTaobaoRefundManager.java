package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDOExample;

/**
* SeTaobaoRefundService
*  on 2017/6/14.
*/
public interface SeTaobaoRefundManager extends BaseService<SeTaobaoRefundDO, SeTaobaoRefundDOExample> {

}