package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;

/**
 * Created by chengwei on 2017/6/12 10:12.
 */
public interface UnionPayManager {

	/**
	 * 推送订单信息给银联
	 * @param appSuber
	 * @param payParamsDTO
	 * @return
	 */
	AbsResponse launchCommonPay(AmAppSubscriptionDTO appSuber, PayParamsDTO payParamsDTO) throws Exception;

	/**
	 * 银联异步验证
	 * @param request
	 * @return
	 * @throws Exception
	 */
	String unionAnalyzeData(String request) throws Exception;
}
