package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.dao.mapper.BaAreaDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDO;
import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDOExample;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.manager.BaCountryManager;
import com.wwwarehouse.xdw.datasync.model.BaArea;
import com.wwwarehouse.xdw.datasync.manager.BaAreaManager;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * BaAreaManagerImpl
 * on 2017/6/16.
 * <p>
 * 功能：国家地区相关功能实现类
 */
@Service
@Transactional
public class BaAreaManagerImpl extends BaseManagerImpl<BaAreaDOMapper, BaArea, BaAreaDO, BaAreaDOExample> implements BaAreaManager {

    //国家
    private final static long AREA_TYPE_COUNTRY= 0;
    //省
    private final static long AREA_TYPE_PROVINCE = 1;
    //市
    private final static long AREA_TYPE_CITY = 2;
    //区县
    private final static long AREA_TYPE_COUNTY = 3;
    //村镇
    private final static long AREA_TYPE_VILLAGES = 4;

    //所有地区信息集合存放redis的key
    private final static String REDIS_AREA_KEY = "base_area_all";

    private static Logger _log = LoggerFactory.getLogger(BaAreaManagerImpl.class);

    @Autowired
    BaAreaDOMapper baAreaDOMapper;

    @Resource
    private BaCountryManager baCountryManager;

    @Resource
    private RedisTemplate<String, List<BaAreaDTO>> redisTemplate;

    @Override
    public BaAreaDOMapper getMapper() {
        return baAreaDOMapper;
    }

    @Override
    public List<BaAreaDTO> listAllBaAreas() throws Exception {
        //先从redis中取
        List<BaAreaDTO> listAreaData = redisTemplate.opsForValue().get(REDIS_AREA_KEY);
        if (!CollectionUtils.isEmpty(listAreaData)){
            return listAreaData;
        }
        listAreaData = new ArrayList<>();
        //国家数据
        List<BaCountryDO> countryDoList = baCountryManager.listAllBaCountry();
        for (BaCountryDO country : countryDoList) {
            BaAreaDTO baAreaDTO = new BaAreaDTO();
            baAreaDTO.setAreaId(country.getCountryId());
            baAreaDTO.setAreaName(country.getCountryNameZh());
            baAreaDTO.setAreaNameEn(country.getCountryNameEn());
            baAreaDTO.setAreaType(0L);
            listAreaData.add(baAreaDTO);
        }
        //国内省市区数据
        List<BaAreaDO> listBaAreaDO = baAreaDOMapper.selectByExample(new BaAreaDOExample());
        for (BaAreaDO area:listBaAreaDO) {
            BaAreaDTO areaDTO = new BaAreaDTO();
            copyArea(area,areaDTO);
            listAreaData.add(areaDTO);
        }
        redisTemplate.opsForValue().set(REDIS_AREA_KEY,listAreaData);
        return listAreaData;
    }

    @Override
    public AbsResponse<BaAreaDTO> getBaArea(String areaId, String areaName) throws Exception {
        AbsResponse<BaAreaDTO> absResponse = new AbsResponse<>();
        if (StringUtils.isEmpty(areaId) && StringUtils.isEmpty(areaName)) {
            return absResponse.setResult(1, "areaId和areaName不能同时为空");
        }
        BaAreaDO baAreaDO = getBaAreaDO(areaId, areaName);
        if (baAreaDO == null) {
            return absResponse.setResult(2, "查询不到地区数据");
        }
        BaAreaDTO baAreaDTO = new BaAreaDTO();
        this.copyArea(baAreaDO, baAreaDTO);
        baAreaDTO.setNextLevelAreaList(getNextAreas(baAreaDO.getAreaId(), new BaAreaDOExample(), true));
        absResponse.setResult(0, null, null, baAreaDTO);
        return absResponse;
    }

    /**
     * 根据areaId或araeName查询baAreaDO对象
     * @param areaId
     * @param areaName
     * @return
     */
    private BaAreaDO getBaAreaDO(String areaId, String areaName) {
        BaAreaDOExample example = new BaAreaDOExample();
        if (StringUtils.isNotEmpty(areaId)) {
            example.createCriteria().andAreaIdEqualTo(areaId);
        }
        if (StringUtils.isNotEmpty(areaName)) {
            example.or().andAreaNameEqualTo(areaName);
        }
        List<BaAreaDO> areaDOList = baAreaDOMapper.selectByExample(example);
        return areaDOList.isEmpty() ? null : areaDOList.get(0);
    }

    /**
     * 获取国内所有地区
     *
     * @return
     */
    private List<BaAreaDTO> getAreas() {
        BaAreaDOExample example = new BaAreaDOExample();
        //查询所有省级数据（areaType为1）
        example.createCriteria().andAreaTypeEqualTo(AREA_TYPE_PROVINCE);
        List<BaAreaDO> provinceList = baAreaDOMapper.selectByExample(example);
        List<BaAreaDTO> areaList = new ArrayList<>();
        for (BaAreaDO province : provinceList) {
            BaAreaDTO baAreaDTO = new BaAreaDTO();
            this.copyArea(province, baAreaDTO);
            List<BaAreaDTO> list = getNextAreas(baAreaDTO.getAreaId(), example, false);
            baAreaDTO.setNextLevelAreaList(list);
            areaList.add(baAreaDTO);
        }
        return areaList;
    }

    /**
     * 传入一个区域id，返回区域下一级的所有地区
     *
     * @param areaId
     * @param example
     * @param onlyOnce 传false时递归查询areaId下的所有区域,传true时只查询下一级区域
     * @return
     */
    private List<BaAreaDTO> getNextAreas(String areaId, BaAreaDOExample example, boolean onlyOnce) {
        example.clear();
        example.createCriteria().andParentAreaIdEqualTo(areaId);
        List<BaAreaDO> baAreaDOList = baAreaDOMapper.selectByExample(example);
        if (baAreaDOList.isEmpty()) {
             return null;
        }
        List<BaAreaDTO> areaList = new ArrayList<>();
        for (BaAreaDO area : baAreaDOList) {
            BaAreaDTO baAreaDTO = new BaAreaDTO();
            this.copyArea(area, baAreaDTO);
            if (!onlyOnce) {
                //递归获取下一级地区数据
                baAreaDTO.setNextLevelAreaList(getNextAreas(baAreaDTO.getAreaId(), example, false));
            }
            areaList.add(baAreaDTO);
        }
        return areaList;
    }

    /**
     * 地区对象属性赋值【areaId、areaName、parentAreaId、areaType】
     *
     * @param oldArea
     * @param newArea
     */
    private void copyArea(BaAreaDO oldArea, BaAreaDTO newArea) {
        newArea.setAreaId(oldArea.getAreaId());
        newArea.setAreaName(oldArea.getAreaName());
        newArea.setParentAreaId(oldArea.getParentAreaId());
        newArea.setAreaType(oldArea.getAreaType());
    }

}