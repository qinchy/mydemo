package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAppSubscriptionMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionExample;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
* AmAppSubscriptionService
*  on 2017/6/13.
*/
public class AmAppSubscriptionManagerMock extends BaseServiceMock<AmAppSubscriptionMapper, AmAppSubscriptionDO, AmAppSubscriptionExample> implements AmAppSubscriptionManager {

    @Override
    public AmAppSubscriptionDTO get(Long subscriptionUkid) {
        return null;
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long suberBuId, String appType) {
        return null;
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long appOwnerId, Long suberBuId, String appType) {
        return null;
    }

    @Override
    public AmAppSubscriptionDTO packageAppSub(AmAppSubscriptionDTO subscription, AmAppkeyDTO app) {
        return null;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, Long suberBuId, Long status) {
        return null;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByBuid(Long suberBuId, Long status) {
        return null;
    }

    @Override
    public int insertSubscription(AmAppSubscriptionDTO subscription) {
        return 0;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsNeedRefresh() {
        return null;
    }

    @Override
    public int updateAuthBuId(AmAppSubscriptionDTO subscription) {
        return 0;
    }

    @Override
    public int updateSubscription(AmAppSubscriptionDTO subscription) {
        return 0;
    }

    @Override
    public int update(AmAppSubscriptionDTO subscription) {
        return 0;
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, int shardingCount, int shardingItem) {
        return null;
    }
}
