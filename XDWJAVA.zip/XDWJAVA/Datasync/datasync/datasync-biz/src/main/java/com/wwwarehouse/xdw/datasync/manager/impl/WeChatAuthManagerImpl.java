package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.WeChatAuthManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import org.springframework.stereotype.Service;

/**
 * Created by dan.han on 2017/6/13.
 */
@Service
public class WeChatAuthManagerImpl implements WeChatAuthManager {

    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(String authCode, AmAppkeyDTO amAppkey){
        IAuthApi api = ApiUtil.getAuthApi(amAppkey);
        return api.grantAuth(authCode);
    }
}
