package com.wwwarehouse.xdw.datasync.manager;


import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeBaseTrade;

import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/13 0013.
 */
public interface SeBaseTradeManager<T extends SeBaseTrade<E>, E extends SeBaseItem> {

    /**
     * 下载保存原始订单
     * (实现与downTrades基本类似，只是取时间不一样)
     *
     * @param AmAppSubscriptionDTO
     * @return
     * @throws Exception
     */
//    AbsResponse<?> reDownTrades(AmAppSubscriptionDTO AmAppSubscriptionDTO) throws Exception;

    /**
     * 下载保存原始订单
     *
     * @param AmAppSubscriptionDTO
     * @return
     * @throws Exception
     */
//    AbsResponse<?> downTrades(AmAppSubscriptionDTO AmAppSubscription) throws Exception;

    /**
     * 下载保存原始订单
     *
     * @param AmAppSubscriptionDTO
     * @param tid
     * @return
     * @throws Exception
     */
    public AbsResponse<?> downTrade(AmAppSubscriptionDTO AmAppSubscriptionDTO, String tid) throws Exception;



    /**
     * 发送订单出库信息
     *
     * @param AmAppSubscriptionDTO
     * @return
     * @throws Exception
     */
//    AbsResponse<?> shipNoticeTrades(AmAppSubscriptionDTO AmAppSubscription) throws Exception;


    /**
     * 发送订单出库信息
     *
     * @param AmAppSubscriptionDTO
     * @param tid
     * @return
     * @throws Exception
     */
//    AbsResponse<?> shipNoticeTrade(AmAppSubscriptionDTO AmAppSubscription, String tid) throws Exception;

    /**
     * 释放原始订单
     * @param AmAppSubscriptionDTO
     * @return
     * @throws Exception
     */
//    AbsResponse<?> releaseTrade(AmAppSubscriptionDTO AmAppSubscription) throws Exception;

    /**
     * 释放原始订单
     * @param AmAppSubscriptionDTO
     * @param tid
     * @return
     * @throws Exception
     */
//    AbsResponse<?> releaseTrades(AmAppSubscriptionDTO AmAppSubscription, String tid) throws Exception;


    /**
     * 保存原始订单
     *
     * @param t
     * @return
     */
    public AbsResponse<T> saveTrade(Long shopId, T t, Long userId) throws Exception;


    /**
     * 同步平台订单
     * @param shopId 店铺
     * @param pTrade 平台订单
     * @param oTrade 已经保存的原始订单
     * @param userId 操作人Id
     * @return
     * @throws Exception
     */
    public AbsResponse<T> updatePlatformTrade(Long shopId, T pTrade, T oTrade, Long userId) throws Exception;

    /**
     * 更新原始订单（原始订单已存在，需要分辨是否发生了变更）
     *
     * @param trade
     * @return
     */
    public AbsResponse<?> updateTrade(T trade) throws Exception;

    /**
     * 仅仅更新原始订单的平台信息
     *
     * @param trade
     * @return
     */
    public int updatePlatformInfo(T trade) throws Exception;

    /**
     * 根据TID获取原始订单
     *
     * @param shopId
     * @param tid
     * @return
     */
    public T getByTid(Long shopId, String tid);

    /**
     * 根据UKID获取原始订单
     *
     * @param ukid
     * @return
     */
    public T get(Long ukid);

    public List getsOrderByTradeUkid(Long tradeUkid);

    /**
     * 更新原始订单的网仓状态
     * @param t
     * @return
     */
    public int updateOriginStatus(T t);

    /**
     * 更新原始子订单的网仓状态
     * @param t
     * @return
     */
    public int updateOriginItemStatus(E t);

    public boolean isTradeClosed(String platformSradeStatus);

    /**
     * 判断平台状态是否为需要发货的状态
     * @param platformOrderStatus
     * @return
     */
    public boolean needSend(String platformOrderStatus);

    /**
     * 判断平台状态是否能否发货，已经付款
     * @param platformOrderStatus
     * @return
     */
    public boolean canSend(String platformOrderStatus);

    /**
     * 判断平台状态是否能否转三库
     * @param platformOrderStatus
     * @return
     */
    public boolean canConvert(String platformOrderStatus);

    /**
     * 判断网仓状态能否转换
     * @param originTradeStatus
     * @return
     */
    public boolean canConvert(Long originTradeStatus);

    /**
     * 判断交易状态是否是完成
     * @param platformSradeStatus
     * @return
     */
    public boolean isTradeFinish(String platformSradeStatus);

//    //从数据库获取需转契约的订单
//    public  List<T> getsNeedConvertTrade(PageParameter params);

    public void pushToConvertService(Long shopId, Long tradeUkid, Long userId) throws Exception;

    //根据productNumId,skuNumId,shopId获取tradeUkid
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId);

}
