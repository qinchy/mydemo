package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.exception.IscsException;
import com.wwwarehouse.xdw.datasync.manager.IExpressManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressOrderInfoDTO;
import com.wwwarehouse.xdw.datasync.model.ExpressUploadWeightInfo;
import com.wwwarehouse.xdw.datasync.model.LogisticsInformation;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShipApi;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("expressManager")
public class ExpressManagerImpl implements IExpressManager {

	@Override
	public LogisticsInformation trackLogisticsInfo(String outSid, Long expressCode) throws Exception {
		AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
		subscription.setPlatformId(expressCode);
		IShipApi shipApi = ApiUtil.getShipApi(subscription);
		if (shipApi == null) {
			throw new IscsException(2224, "选择了未知的快递公司");
		}
		return shipApi.trackLogisticsInfo(outSid);
	}

	@Override
	public ExpressOrderInfoDTO generateExpressInfo(ExpressOrderInfoDTO expressOrderInfo) throws Exception {
		AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
		subscription.setPlatformId(expressOrderInfo.getExpressCode());
		IShipApi shipApi = ApiUtil.getShipApi(subscription);
		if (shipApi == null) {
			throw new IscsException(2224, "选择了未知的快递公司");
		}
		return shipApi.generateExpressInfo(expressOrderInfo);
	}

	@Override
	public <T extends ExpressOrderInfoDTO> List<T> generateExpressInfos(List<T> expressOrderInfoDTOs) throws Exception {
		AmAppSubscriptionDTO subscriptionDTO = new AmAppSubscriptionDTO();
		if (expressOrderInfoDTOs.size() == 0) {
			return null;
		}
		// TODO 目前这里存在一个问题*******每个快递单都带有快递公司，
		// TODO 理论：按照同一个快递公司，各自快递公司都可以。
		// TODO 目前默认按同一种快递公司处理
		subscriptionDTO.setPlatformId(expressOrderInfoDTOs.get(0).getExpressCode());
		IShipApi shipApi = ApiUtil.getShipApi(subscriptionDTO);
		if (shipApi == null) {
			throw new IscsException(2224, "选择了未知的快递公司");
		}
		return shipApi.generateExpressInfos(expressOrderInfoDTOs);
	}

	@Override
	public void uploadWeight(List<ExpressUploadWeightInfo> weightInfos) throws Exception {
		AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
		subscription.setPlatformId(weightInfos.get(0).getExpressCode());
		IShipApi shipApi = ApiUtil.getShipApi(subscription);
		if (shipApi == null) {
			throw new IscsException(2224, "选择了未知的快递公司");
		}
		shipApi.uploadWeight(weightInfos);

	}

	@Override
	public void cancelExpressOrder(String orderId, String outSid, Long expressCode) throws Exception {
		AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
		subscription.setPlatformId(expressCode);
		IShipApi shipApi = ApiUtil.getShipApi(subscription);
		if (shipApi == null) {
			throw new IscsException(2224, "选择了未知的快递公司");
		}
		shipApi.cancelExpressOrder(orderId, outSid);

	}

}
