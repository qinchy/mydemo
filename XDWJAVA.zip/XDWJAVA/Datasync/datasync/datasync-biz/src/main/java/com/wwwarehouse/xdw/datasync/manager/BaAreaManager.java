package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDOExample;
import com.wwwarehouse.xdw.datasync.model.BaArea;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;

import java.util.List;

/**
* BaAreaManager
*  on 2017/6/16.
*/
public interface BaAreaManager extends BaseManager<BaArea, BaAreaDOExample> {

    /**
     * 获取地区库信息
     * @return
     * @throws Exception
     */
    List<BaAreaDTO> listAllBaAreas() throws Exception;

    /**
     *通过areaId或areaName获取地区及其下一级地区信息，二者不能同时为null
     * @param areaId 地区id
     * @param areaName 地区名称
     * @return
     * @throws Exception
     */
    AbsResponse<BaAreaDTO> getBaArea(String areaId, String areaName) throws Exception;
}