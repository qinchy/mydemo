package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAuthRecordDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDOExample;
import com.wwwarehouse.xdw.datasync.manager.AmAuthRecordManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
* AmAuthRecordService
*  on 2017/6/16.
*/
@Service
@Transactional
public class AmAuthRecordManagerImpl extends BaseServiceImpl<AmAuthRecordDOMapper, AmAuthRecordDO, AmAuthRecordDOExample> implements AmAuthRecordManager {

    private static Logger _log = LoggerFactory.getLogger(AmAuthRecordManagerImpl.class);

    @Autowired
    AmAuthRecordDOMapper amAuthRecordMapper;

    @Override
    public AmAuthRecordDOMapper getMapper() {
        return amAuthRecordMapper;
    }
}