package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAppkeyMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyExample;
import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
* AmAppkeyService
*  on 2017/6/13.
*/
public class AmAppkeyManagerMock extends BaseServiceMock<AmAppkeyMapper, AmAppkeyDO, AmAppkeyExample> implements AmAppKeyManager {

    @Override
    public AmAppkeyDTO get(Long appUkid) {
        return null;
    }

    @Override
    public List<AmAppkeyDTO> getsByType(Long platformId, Long ownerBuId, String appKey, String appkeyType, Long status) {
        return null;
    }

    @Override
    public AmAppkeyDTO getByAppkey(Long platformId, String appKey, String appkeyType) {
        return null;
    }

    @Override
    public AmAppkeyDTO getByType(Long platformId, Long ownerBuId, String appType) {
        return null;
    }

    @Override
    public List<AmAppkeyDTO> getsUsableKeys(String appType) {
        return null;
    }
}
