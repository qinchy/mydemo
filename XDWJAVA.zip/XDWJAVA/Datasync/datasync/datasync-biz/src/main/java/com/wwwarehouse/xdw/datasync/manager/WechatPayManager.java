package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xiuli.yang on 2017/6/12.
 */
public interface WechatPayManager {
    AbsResponse<Object> launchWechatPay(AmAppSubscriptionDTO appSuber, PayParamsDTO payParamsDTO) throws Exception;

    String wechatAnalyzeData(String request) throws Exception;
}
