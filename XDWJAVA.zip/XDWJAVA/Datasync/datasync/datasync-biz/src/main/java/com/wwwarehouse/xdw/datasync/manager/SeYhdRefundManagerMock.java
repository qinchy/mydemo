package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdRefundDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDOExample;

/**
* SeYhdRefundService
*  on 2017/6/14.
*/
public class SeYhdRefundManagerMock extends BaseServiceMock<SeYhdRefundDOMapper, SeYhdRefundDO, SeYhdRefundDOExample> implements SeYhdRefundManager {

}
