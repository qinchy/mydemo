package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.service.IAmSubscriptionService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/19 0019.
 */
@Service
public class AmSubscriptionServiceImpl implements IAmSubscriptionService{
    @Resource
    AmAppSubscriptionManager amAppSubscriptionManager;
    @Override
    public AmAppSubscriptionDTO get(Long subscriptionUkid) {
        return amAppSubscriptionManager.get(subscriptionUkid);
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long suberBuId, String appType) {
        return amAppSubscriptionManager.getSubscription(platformId, suberBuId, appType);
    }

    @Override
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long appOwnerId, Long suberBuId, String appType) {
        return amAppSubscriptionManager.getSubscription(platformId, appOwnerId, suberBuId, appType);
    }

    @Override
    public AmAppSubscriptionDTO packageAppSub(AmAppSubscriptionDTO subscription, AmAppkeyDTO app) {
        return amAppSubscriptionManager.packageAppSub(subscription,app);
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, Long suberBuId, Long status) {
        return amAppSubscriptionManager.getsByAppUkid(appUkid, suberBuId, status);
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByBuid(Long suberBuId, Long status) {
        return amAppSubscriptionManager.getsByBuid(suberBuId, status);
    }

    @Override
    public int insertSubscription(AmAppSubscriptionDTO subscription) {
        return amAppSubscriptionManager.insertSubscription(subscription);
    }

    @Override
    public List<AmAppSubscriptionDTO> getsNeedRefresh() {
        return amAppSubscriptionManager.getsNeedRefresh();
    }

    @Override
    public int updateAuthBuId(AmAppSubscriptionDTO subscription) {
        return amAppSubscriptionManager.updateAuthBuId(subscription);
    }

    @Override
    public int updateSubscription(AmAppSubscriptionDTO subscription) {
        return amAppSubscriptionManager.updateSubscription(subscription);
    }

    @Override
    public int update(AmAppSubscriptionDTO subscription) {
        return amAppSubscriptionManager.update(subscription);
    }

    @Override
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, int shardingCount, int shardingItem) {
        return amAppSubscriptionManager.getsByAppUkid(appUkid, shardingCount, shardingItem);
    }
}
