package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAuthRecordDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDOExample;

/**
* AmAuthRecordService
*  on 2017/6/16.
*/
public class AmAuthRecordManagerMock extends BaseServiceMock<AmAuthRecordDOMapper, AmAuthRecordDO, AmAuthRecordDOExample> implements AmAuthRecordManager {

}
