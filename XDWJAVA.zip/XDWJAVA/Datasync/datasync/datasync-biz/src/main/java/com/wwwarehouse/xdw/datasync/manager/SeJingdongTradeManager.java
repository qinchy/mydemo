package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeExample;
import com.wwwarehouse.xdw.datasync.model.SeJingdongTradeDTO;

import java.util.List;

/**
* SeJingdongTradeService
*  on 2017/6/13.
*/
public interface SeJingdongTradeManager extends BaseService<SeJingdongTradeDO, SeJingdongTradeExample> {
    boolean canConvert(String platformOrderStatus);
    boolean canSend(String platformOrderStatus);
    boolean needSend(String platformOrderStatus);
    boolean isTradeFinish(String platformSradeStatus);
    boolean isTradeClosed(String platformSradeStatus);
    int updateOriginStatus(SeJingdongTradeDO oTrade);
    List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId);
    AbsResponse<SeJingdongTradeDTO> checkHisTrade(SeJingdongTradeDTO pTrade) throws Exception;
    AbsResponse<SeJingdongTradeDTO> checkTrade(SeJingdongTradeDTO pTrade) throws Exception;
    AbsResponse updateTrade(SeJingdongTradeDTO trade) throws Exception ;
    SeJingdongTradeDO getByTid(Long shopId, String tid);
    int updatePlatformInfo(SeJingdongTradeDTO trade) throws Exception ;
}