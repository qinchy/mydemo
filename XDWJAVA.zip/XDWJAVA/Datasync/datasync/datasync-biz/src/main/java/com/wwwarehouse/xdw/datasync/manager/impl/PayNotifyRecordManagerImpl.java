package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.PayNotifyRecordDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDO;
import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDOExample;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* PayNotifyRecordManagerImpl
*  on 2017/6/15.
*/
@Service
@Transactional
public class PayNotifyRecordManagerImpl extends BaseManagerImpl<PayNotifyRecordDOMapper, PayNotifyRecordDTO, PayNotifyRecordDO, PayNotifyRecordDOExample> implements PayNotifyRecordManager {

    private static Logger _log = LoggerFactory.getLogger(PayNotifyRecordManagerImpl.class);

    @Autowired
    PayNotifyRecordDOMapper payNotifyRecordDOMapper;

    @Override
    public PayNotifyRecordDOMapper getMapper() {
        return payNotifyRecordDOMapper;
    }

    @Override
    public int add(PayNotifyRecordDTO payNotifyRecordDTO) {
        PayNotifyRecordDTO existDTO = selectByOutTradeNoAndResultCode(payNotifyRecordDTO.getOutTradeNo(), payNotifyRecordDTO.getResultCode());
        if (existDTO == null) {
            PayNotifyRecordDO payNotifyRecordDO = new PayNotifyRecordDO();
            BeanUtils.copyProperties(payNotifyRecordDTO, payNotifyRecordDO);
            return payNotifyRecordDOMapper.insert(payNotifyRecordDO);
        }

        return 0;
    }

    @Override
    public int update(PayNotifyRecordDTO payNotifyRecordDTO) {
        PayNotifyRecordDO payNotifyRecordDO = new PayNotifyRecordDO();
        BeanUtils.copyProperties(payNotifyRecordDTO, payNotifyRecordDO);
        return payNotifyRecordDOMapper.updateByPrimaryKey(payNotifyRecordDO);
    }

    @Override
    public PayNotifyRecordDTO selectByOutTradeNoAndResultCode(String outTradeNo, String resultCode) {
        PayNotifyRecordDTO payNotifyRecordDTO = null;
        PayNotifyRecordDOExample example = new PayNotifyRecordDOExample();
        example.createCriteria().andOutTradeNoEqualTo(outTradeNo).andResultCodeEqualTo(resultCode);

        List<PayNotifyRecordDO> DOList =  payNotifyRecordDOMapper.selectByExample(example);
        if (DOList != null && DOList.size() > 0) {
            payNotifyRecordDTO = new PayNotifyRecordDTO();
            BeanUtils.copyProperties(DOList.get(0), payNotifyRecordDTO);
        }
        return payNotifyRecordDTO;
    }
}