package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmSmsSortDOMapper;
import com.wwwarehouse.xdw.datasync.dao.mapper.SaSmsMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmSmsSortDO;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsDO;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsExample;
import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.SaSmsManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.SaSmsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ISmsApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * SaSmsService
 * on 2017/6/14.
 */
@Service
@Transactional
public class SaSmsManagerImpl extends BaseServiceImpl<SaSmsMapper, SaSmsDO, SaSmsExample> implements SaSmsManager {

    private static Logger _log = LoggerFactory.getLogger(SaSmsManagerImpl.class);

    @Autowired
    SaSmsMapper saSmsMapper;
    @Resource
    private AmAppKeyManager amAppKeyManager;
    @Resource
    private AmAppSubscriptionManager amAppSubscriptionManager;
    @Resource
    private AmSmsSortDOMapper amSmsSortDOMapper;

    @Override
    public SaSmsMapper getMapper() {
        return saSmsMapper;
    }


    public int updateSmsStatus(String smsUkids, Long smsStatus, Date actualSendTime, String returnText) {
        return saSmsMapper.updateSmsStatus(smsUkids, smsStatus, actualSendTime, returnText);
    }

    /**
     * 插入按任务发送的短信
     */
    public String insert(Long serviceBuId, Long senderId, String smsType,
                         String mobileNo, String content, Date planSendTime,
                         String relatedType, Long relatedOrderUkid, Long platformId) throws Exception {
        return insert(serviceBuId, senderId, smsType, mobileNo, content,
                planSendTime, 1, null, relatedType, relatedOrderUkid, platformId);
    }

    @Override
    public String sendSms(String mobile, String smsContent, Long platformId) throws Exception {
        return insert(Constants.WCKJ, Constants.WCKJ, "A",
                mobile, smsContent, new Date(), 2, null, null, null, platformId);
    }

    /**
     * required : smsBuId,sellerBuId,smsType,mobileNo,content,planSendTime
     * params:
     * sendActionType : 0:不需要发送，1，需要发送并按任务发发送，2：需要发送并马上发送，
     */
    private String insert(Long serviceBuId, Long senderId, String smsType,
                          String mobileNo, String content, Date planSendTime,
                          int sendActionType, Long smsTemplateUkid,
                          String relatedType, Long relatedOrderUkid, Long platformId) throws Exception {

        if (StringUtils.isEmpty(content)) {
            return "短信内容为空";
        }
        mobileNo = qxMobile(mobileNo);
        if (!StringUtils.isNumeric(mobileNo) || mobileNo.length() != 11
                || !mobileNo.startsWith("1")) {
            return "手机号码为空";
        }
        if (StringUtils.isEmpty(smsType)) {
            return "短信类型为空";
        }
        if (planSendTime == null) {
            planSendTime = new Date();
        }
        List<AmAppkeyDTO> smsAccounts = amAppKeyManager.getsByType(platformId, serviceBuId, null, "SMS", 1L);
        if (smsAccounts.isEmpty()) {
            return "未设置短信运营商";
        }
        AmAppkeyDTO amAppKey = null;
        //未指定短信平台时按策略的优先级发送
        if (platformId == null) {
            List<Long> appUkids = new ArrayList<>();
            for (AmAppkeyDTO amAppkeyDTO : smsAccounts) {
                appUkids.add(amAppkeyDTO.getAppUkid());
            }
            //查找优先级最高的
            AmSmsSortDO amSmsSortDO = amSmsSortDOMapper.getAmSmsSortByAppUkids(appUkids);
            if (amSmsSortDO == null) {
                amAppKey = smsAccounts.get(0);
            } else {
                for (AmAppkeyDTO amAppkeyDTO : smsAccounts) {
                    if (amAppkeyDTO.getAppUkid().equals(amSmsSortDO.getAppUkid())) {
                        amAppKey = amAppkeyDTO;
                        break;
                    }
                }
            }
        } else {
            amAppKey = smsAccounts.get(0);
        }
        SaSmsDO sms = new SaSmsDO();
        sms.setSmsUkid(UKID.getUKID());
        sms.setMobileNo(mobileNo);
        sms.setSendContent(content);
        sms.setPlanSendTime(planSendTime);
        sms.setSmsStatus(sendActionType >= 1 ? (short) 10 : (short) 100);
        sms.setSmsNum(getSmsNum(content));
        sms.setServiceBuId(serviceBuId);
        sms.setSendBuId(senderId);
        sms.setSmsType(smsType);
        sms.setPlatformId(amAppKey.getPlatformId());
        sms.setSmsAccountUkid(amAppKey.getAppUkid());
        sms.setCreateTime(new Date());
        sms.setCreateUserId(999L);
        sms.setSmsTemplateUkid(smsTemplateUkid);
        sms.setRelatedOrderUkid(relatedOrderUkid);
        sms.setRelatedType(relatedType);

        if (sendActionType == 2) {//实际发送短信
            executeSendSms(sms, amAppKey, senderId);
        }
        saSmsMapper.insert(sms);
        return sms.getSmsStatus() == 20L ? "OK" : sms.getReturnText();
    }

    private void executeSendSms(SaSmsDO sms, AmAppkeyDTO amAppkey, Long senderId) throws Exception {
        try {
            List<AmAppSubscriptionDTO> appSubers = amAppSubscriptionManager.getsByAppUkid(amAppkey.getAppUkid(), senderId, 1L);
            if (appSubers.isEmpty()) {
                sms.setReturnText("编号为" + senderId + "的客户未订购短信服务");
            } else {
                AmAppSubscriptionDTO appSuber = appSubers.get(0);
                appSuber.setApp(amAppkey);
                appSuber.setPlatformId(amAppkey.getPlatformId());

                ISmsApi api = ApiUtil.getSmsApi(appSuber);

                sms.setActualSendTime(new Date());
                AbsResponse<String> sendRet = api.sendSms(sms.getMobileNo(), sms.getSendContent());
                if (sendRet.isSuccess()) {
                    sms.setSmsStatus((short) 20);
                } else {
                    sms.setSmsStatus((short) 91);
                }

                String ret = sendRet.getData();
                if (null != ret) {
                    ret = StringUtils.stringCut(ret, 200, "...");
                    sms.setReturnText(ret);
                }
            }
        } catch (Exception e) {
            _log.error(sms.getMobileNo(), e);
            sms.setSmsStatus((short) 91);
            sms.setReturnText(StringUtils.stringCut(e.getMessage(), 200, "..."));
        }
    }

    public List<SaSmsDTO> getNeedSendGroupList(Long smsAccountUkid) {
        List<SaSmsDO> listSaSmsDO = saSmsMapper.getNeedSendGroupList(smsAccountUkid);
        List<SaSmsDTO> listsaSms = new ArrayList<>();
        BeanUtils.copyProperties(listSaSmsDO, listsaSms);
        return listsaSms;
    }

    public List<SaSmsDTO> getNeedSendList(Long smsAccountUkid, Long buId,
                                          Long sendBuId, Long shopId, String sendContent) {
        List<SaSmsDO> listSaSmsDO = saSmsMapper.getNeedSendList(smsAccountUkid, buId, sendBuId,
                shopId, sendContent);
        List<SaSmsDTO> listsaSms = new ArrayList<>();
        BeanUtils.copyProperties(listSaSmsDO, listsaSms);
        return listsaSms;
    }

    private String qxMobile(String mobileNo) {
        if (StringUtils.isEmpty(mobileNo)) {
            return null;
        }
        mobileNo = mobileNo.replace("-", "").replaceAll(
                "[ .,:：;/~、，（）()。话或\\-]+", "~").trim();
        String[] m = mobileNo.split("~");
        if (m.length == 0) return "手机号码为空";
        mobileNo = m[0];
        if (m.length > 1 && !StringUtils.isNumeric(m[0])) {
            mobileNo = m[1];
        }
        return mobileNo;
    }

    public static long getSmsNum(String content) {
        if (StringUtils.isEmpty(content)) return 0;
        return (content.length() + 70 - 1) / 70;
    }
}