package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdTradeDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdTradeDO;
import com.wwwarehouse.xdw.datasync.manager.SeYhdTradeManager;
import com.wwwarehouse.xdw.datasync.model.SeYhdItemDTO;
import com.wwwarehouse.xdw.datasync.model.SeYhdTradeDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
* SeYhdTradeService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeYhdTradeManagerImpl extends SeBaseTradeManagerImpl<SeYhdTradeDTO, SeYhdItemDTO> {

    private static Logger _log = LoggerFactory.getLogger(SeYhdTradeManagerImpl.class);

    @Resource
    SeYhdTradeDOMapper seYhdTradeMapper;
    @Resource
    SeYhdItemDOMapper seYhdItemMapper;
    @Override
    public SeYhdTradeDTO getByTid(Long shopId, String tid) {
        SeYhdTradeDO seYhdTradeDO = seYhdTradeMapper.getByOrderId(shopId, tid);
        SeYhdTradeDTO seYhdTradeDTO = new SeYhdTradeDTO();
        BeanUtils.copyProperties(seYhdTradeDO, seYhdTradeDTO);
        return seYhdTradeDTO;
    }
    @Override
    public int updatePlatformInfo(SeYhdTradeDTO oTrade) throws Exception {
        SeYhdTradeDO seYhdTradeDO = new SeYhdTradeDO();
        BeanUtils.copyProperties(oTrade, seYhdTradeDO);
        return seYhdTradeMapper.updatePlatformInfo(seYhdTradeDO);
    }

    @Override
    public AbsResponse checkTrade(SeYhdTradeDTO pTrade) throws Exception {
        AbsResponse retBean = new AbsResponse();
        if (pTrade == null) {
            return retBean.setResult(108, "订单未抓取成功!");
        }
        if (!needSend(pTrade.getPlatformOrderStatus())){
            return retBean.setResult(104, "不是待发货订单:" + pTrade.getPlatformOrderStatus());
        }
        return retBean;
    }

    @Override
    public AbsResponse checkHisTrade(SeYhdTradeDTO pTrade) throws Exception {
        AbsResponse retBean = new AbsResponse();
        if (pTrade == null) {
            return retBean.setResult(108, "订单未抓取成功!");
        }
        return retBean;
    }

    @Override
    public int saveItem(SeYhdItemDTO item) throws Exception {
        SeYhdItemDO seYhdTradeItemDO = new SeYhdItemDO();
        BeanUtils.copyProperties(item, seYhdTradeItemDO);
        return seYhdItemMapper.insert(seYhdTradeItemDO);
    }

    @Override
    public int updateItem(SeYhdItemDTO item) throws Exception {
        SeYhdItemDO seYhdTradeItemDO = new SeYhdItemDO();
        BeanUtils.copyProperties(item, seYhdTradeItemDO);
        return seYhdItemMapper.updateByPrimaryKey(seYhdTradeItemDO);
    }

    @Override
    public int saveTrdeDO(SeYhdTradeDTO trade) throws Exception {
        return 0;
    }

    @Override
    public int updateTrdeDO(SeYhdTradeDTO trade) throws Exception {
        return 0;
    }

//    @Override
//    public List<SeYhdTradeDTO> getsNeedConvertTrade(PageParameter params) {
//        return null;
//    }

    @Override
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId) {
        return null;
    }


    /**
     * 匹配已经保存的订单明细
     * @param oItemList
     * @param pItem
     * @return
     */
    @Override
    public SeYhdItemDTO matchItem(List<SeYhdItemDTO> oItemList, SeYhdItemDTO pItem) {
        for (SeYhdItemDTO oItem : oItemList) {
            if (pItem.getSubOrderId().equals(oItem.getSubOrderId())) {
                oItem.setDiscountAmount(pItem.getDiscountAmount());
                BeanUtils.copyProperties(pItem, oItem);
                return oItem;
            }
        }
        return null;
    }

    @Override
    public List<SeYhdItemDTO> getsOrderByTradeUkid(Long tradeUkid) {
        List<SeYhdItemDO> seYhdTradeItemDOList = seYhdItemMapper.getsByTradeUkid(tradeUkid);
        List<SeYhdItemDTO> seYhdTradeItemDTOList = new ArrayList<>();
        BeanUtils.copyProperties(seYhdTradeItemDOList, seYhdTradeItemDTOList);
        return seYhdTradeItemDTOList;
    }

    @Override
    public int updateOriginStatus(SeYhdTradeDTO oTrade) {
        if(oTrade.getItemList() != null && !oTrade.getItemList().isEmpty()){
            for(SeYhdItemDTO oItem : oTrade.getItemList()) {
                updateOriginItemStatus(oItem);
            }
        }
        SeYhdTradeDO seYhdTradeDO = new SeYhdTradeDO();
        BeanUtils.copyProperties(oTrade, seYhdTradeDO);
        return seYhdTradeMapper.updateOriginStatus(seYhdTradeDO);
    }

    public int updateOriginItemStatus(SeYhdItemDTO oItem){
        SeYhdItemDO seYhdItemDO = new SeYhdItemDO();
        BeanUtils.copyProperties(oItem, seYhdItemDO);
        return seYhdItemMapper.updateOriginStatus(seYhdItemDO);
    }

    //	ORDER_WAIT_PAY：已下单（货款未全收）
//	ORDER_PAYED：已下单（货款已收）
//	ORDER_TRUNED_TO_DO：可以发货（已送仓库）
//	ORDER_OUT_OF_WH：已出库（货在途）
//	ORDER_RECEIVED：货物用户已收到
//	ORDER_FINISH：订单完成
//	ORDER_CANCEL：订单取消
    @Override
    public boolean isTradeClosed(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "ORDER_CANCEL":            	//订单取消
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }

    @Override
    public boolean isTradeFinish(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "ORDER_FINISH":            	//订单完成
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }
    @Override
    public boolean needSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "ORDER_WAIT_PAY":  		//已下单（货款未全收）
            case "ORDER_PAYED":  			//已下单（货款已收）
            case "ORDER_TRUNED_TO_DO":  	//待发货
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }

    @Override
    public boolean canSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "ORDER_PAYED":  			//已下单（货款已收）
            case "ORDER_TRUNED_TO_DO":  	//待发货
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }
    @Override
    public boolean canConvert(String platformOrderStatus) {
        boolean canConvert;
        switch (platformOrderStatus) {
            case "ORDER_WAIT_PAY":  		//已下单（货款未全收）
            case "ORDER_PAYED":  			//已下单（货款已收）
            case "ORDER_TRUNED_TO_DO":  	//待发货
            case "ORDER_FINISH":            	//订单完成
            {
                canConvert = true;
                break;
            }
            default:
                canConvert = false;
                break;
        }

        return canConvert;
    }
}