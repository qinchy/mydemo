package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.manager.WechatPayManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.PayPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.pay.WechatApi;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by xiuli.yang on 2017/6/12.
 */
@Service
public class WechatPayManagerImpl implements WechatPayManager {
    @Resource
    private AmAppSubscriptionManager amAppSubscriptionManager;
    @Resource
    private PayNotifyRecordManager payNotifyRecordManager;

    @Override
    public AbsResponse<Object> launchWechatPay(AmAppSubscriptionDTO appSuber, PayParamsDTO payParamsDTO) throws Exception {
        AbsResponse<Object> abs = new AbsResponse<Object>();
        WechatApi payApi = new WechatApi(appSuber);
        boolean isP2C = payParamsDTO.isP2C();
        String tradeNo = payParamsDTO.getTradeNo();
        String title = payParamsDTO.getTitle();
        String clientIp = payParamsDTO.getClientIp();
        double amount = payParamsDTO.getAmount();
        if (isP2C) {//公对私
            abs = payApi.payToPersonal(tradeNo, title, clientIp, amount,
                    payParamsDTO.getOpenId(), payParamsDTO.getRegAppType());
        } else {
            abs = payApi.unifiedorder(tradeNo, title, clientIp, amount);
        }
        return abs;
    }

    @Override
    public String wechatAnalyzeData(String request) throws Exception {
        try {
            Map<String, String> orgMap = WechatApi.convertToMap(request);

            String attach = orgMap.get("attach");
            if (StringUtils.isEmpty(attach)) {//一定需要返回网仓的数据包
                return resultMsg("未返回网仓的合法数据包");
            }

            if (!"PAY".equals(attach) && !"IOSPAY".equals(attach)) {
                return resultMsg("未返回网仓的合法数据包");
            }

            String appType = attach;
            AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(PayPlatform.WECHATPAY.getId(),
                    Constants.WCKJ.longValue(), Constants.WCKJ.longValue(), appType);
            if (appSuber == null) {
                return resultMsg("未匹配正确的订购信息");
            }

            WechatApi wechatApi = new WechatApi(appSuber);
            if (!wechatApi.validate(orgMap)) {//验签失败
                return resultMsg("签名失败，请求不合法!");
            }
            String returnCode = orgMap.get("return_code"); // 返回状态码
            if ("SUCCESS".equals(returnCode)) {
                return insertPayNotifyRecord(request, orgMap);
            } else {
                return resultMsg("状态码错误");
            }
        } catch (Exception e) {
//            logger.error("微信异步通知", e);
            return resultMsg("发生异常");
        }
    }

    private String insertPayNotifyRecord(String request, Map<String, String> orgMap) {
        PayNotifyRecordDTO payNotifyRecordDTO = new PayNotifyRecordDTO();
        payNotifyRecordDTO.setPlatformId((short) PayPlatform.WECHATPAY.getId());
        payNotifyRecordDTO.setNotifyMsg(request);
        payNotifyRecordDTO.setAttach(orgMap.get("attach"));
        payNotifyRecordDTO.setPushStatus((short)0);
        String resultCode = orgMap.get("result_code"); // 业务交易结果
        payNotifyRecordDTO.setResultCode(resultCode);// 业务交易结果
        payNotifyRecordDTO.setOutTradeNo(orgMap.get("out_trade_no"));// 获取订单流水号
        payNotifyRecordDTO.setTimeEnd(DateUtil.parse(orgMap.get("time_end"), "yyyyMMddHHmmss"));//支付完成时间
        String sTotalFee = orgMap.get("total_fee");//订单总金额，单位为分
        payNotifyRecordDTO.setTotalFee(BigDecimal.valueOf(NumberUtils.toLong(sTotalFee)));
        payNotifyRecordDTO.setTransactionId(orgMap.get("transaction_id")); //微信支付订单号
        payNotifyRecordDTO.setPayRecordUkid(UKID.getUKID());
        payNotifyRecordManager.add(payNotifyRecordDTO);

        return resultMsg(resultCode);
    }

    private String resultMsg(String retMsg) {
        String template = "<xml><return_code><![CDATA[%s]]></return_code><return_msg><![CDATA[%s]]></return_msg></xml>";

        String returnCode = "OK".equals(retMsg) ? "SUCCESS" : "FAIL";

        return String.format(template, returnCode, retMsg);
    }
}
