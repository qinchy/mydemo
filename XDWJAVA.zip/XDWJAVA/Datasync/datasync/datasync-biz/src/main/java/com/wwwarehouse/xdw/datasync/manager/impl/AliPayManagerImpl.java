package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.CodecUtils;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.commons.utils.WebUtils;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.manager.AliPayManager;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.PayPlatform;
import com.wwwarehouse.xdw.datasync.outer.api.pay.AlipayApi;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by xiuli.yang on 2017/6/12.
 */

@Service
public class AliPayManagerImpl implements AliPayManager {

    @Resource
    private PayNotifyRecordManager payNotifyRecordManager;
    @Resource
    private AmAppSubscriptionManager amAppSubscriptionManager;
    

    @Override
    public AbsResponse<String> aliPayValidate( AmAppSubscriptionDTO appSuber,PayParamsDTO payParamsDTO) throws Exception {
        AbsResponse<String> abs = new AbsResponse<>();

        if(payParamsDTO == null){
            return abs.setResult(10010,"参数不可以为空");
        }

        if(StringUtils.isEmpty(payParamsDTO.getTradeNo())){
            return abs.setResult(10011,"订单号不可以为空");
        }

        AlipayApi api = new AlipayApi(appSuber);
        abs = api.buildPayUrl(payParamsDTO.getTradeNo(), payParamsDTO.getTitle(),
                payParamsDTO.getTitle(), payParamsDTO.getAmount());

        return abs;
    }

    @Override
    public String aliAnalyzeData(String request) throws Exception {
        String returnType = "failure";
        Map<String, String> valideParameters = WebUtils.getUrlParams(request);
        for (String key : valideParameters.keySet()) {
            String value = valideParameters.get(key);
            valideParameters.put(key, CodecUtils.urlDecode(value));
        }

        String outTradeNo = valideParameters.get("out_trade_no");
        String notifyId = valideParameters.get("notify_id");
        String tradeStatus = valideParameters.get("trade_status");
        String buyerEmail = valideParameters.get("buyer_email");
        String totalAmount = valideParameters.get("total_amount");
        // 判断接受的post通知中有无notify_id，如果有则是异步通知。
        if (StringUtils.isEmpty(notifyId) || StringUtils.isEmpty(outTradeNo)) {
            return returnType;
        }

        AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(PayPlatform.ALIPAY.getId(),
                Constants.WCKJ.longValue(), Constants.WCKJ.longValue(), "PAY");
        if (appSuber == null) {
            return returnType;
        }
        AlipayApi api = (AlipayApi)ApiUtil.getPayApi(appSuber);

        // 判断成功之后使用getResponse方法判断是否是支付宝发来的异步通知。
        boolean verifyRst = api.verify(valideParameters);
        if (!verifyRst) {
            return returnType;
        }
        dataHandel(tradeStatus,buyerEmail,totalAmount,outTradeNo);
        return "success";
    }

    public void dataHandel(String tradeStatus,String buyerEmail,String totalAmount,
                           String outTradeNo){
        PayNotifyRecordDTO payNotifyRecordDTO = new PayNotifyRecordDTO();
        payNotifyRecordDTO.setPayRecordUkid(UKID.getUKID());
        payNotifyRecordDTO.setBuyerId(buyerEmail);
        payNotifyRecordDTO.setTotalFee( BigDecimal.valueOf(Long.getLong(totalAmount)) );
        payNotifyRecordDTO.setPlatformId((short) PayPlatform.ALIPAY.getId());
        payNotifyRecordDTO.setOutTradeNo(outTradeNo);

        payNotifyRecordManager.add(payNotifyRecordDTO);
    }
}
