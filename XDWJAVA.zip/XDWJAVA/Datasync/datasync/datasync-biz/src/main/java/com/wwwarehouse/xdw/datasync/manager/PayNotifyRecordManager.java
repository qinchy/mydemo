package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.xdw.datasync.dao.model.PayNotifyRecordDOExample;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;

/**
* PayNotifyRecordManager
*  on 2017/6/15.
*/
public interface PayNotifyRecordManager extends BaseManager<PayNotifyRecordDTO, PayNotifyRecordDOExample> {
	int add(PayNotifyRecordDTO payNotifyRecordDTO);

	int update(PayNotifyRecordDTO payNotifyRecordDTO);

	PayNotifyRecordDTO selectByOutTradeNoAndResultCode(String outTradeNo, String resultCode );
}