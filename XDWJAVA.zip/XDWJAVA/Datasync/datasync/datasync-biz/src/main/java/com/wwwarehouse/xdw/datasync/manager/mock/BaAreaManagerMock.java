package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.model.BaAreaDOExample;
import com.wwwarehouse.xdw.datasync.manager.BaAreaManager;
import com.wwwarehouse.xdw.datasync.model.BaArea;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;

import java.util.List;

/**
* BaAreaManager
*  on 2017/6/16.
*/
public class BaAreaManagerMock extends BaseManagerMock<BaArea, BaAreaDOExample> implements BaAreaManager {

    @Override
    public List<BaAreaDTO> listAllBaAreas() throws Exception {
        return null;
    }

    @Override
    public AbsResponse<BaAreaDTO> getBaArea(String areaId, String areaName) throws Exception {
        return null;
    }


}
