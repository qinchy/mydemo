package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoRefundDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoRefundDOExample;
import com.wwwarehouse.xdw.datasync.manager.SeTaobaoRefundManager;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoRefundDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
* SeTaobaoRefundService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeTaobaoRefundManagerImpl extends SeBaseRefundManagerImpl<SeTaobaoRefundDTO, SeBaseItem> {

    private static Logger _log = LoggerFactory.getLogger(SeTaobaoRefundManagerImpl.class);

    @Autowired
    SeTaobaoRefundDOMapper seTaobaoRefundMapper;


    private static Long PROCESS_STATUS_SUCCESS = 80L;
    private static Long PROCESS_STATUS_CLOSE = 90L;


    @Override
    public AbsResponse checkeRefund(SeTaobaoRefundDTO pTrade) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    public AbsResponse<Map<String, Object>> updateRefundStatus(Long shopId,
                                                               Object pRefund) throws Exception {
        AbsResponse<Map<String, Object>> resp = new AbsResponse<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        SeTaobaoRefundDO pTaobaoRefund = (SeTaobaoRefundDO) pRefund;
        pTaobaoRefund.setShopId(shopId); //插入店铺ID
        Long success = 0L;
        Long fail = 0L;
        SeTaobaoRefundDO refund = seTaobaoRefundMapper.getRefund(pTaobaoRefund.getRefundId(),
                pTaobaoRefund.getSku());
        if(null == refund){
            pTaobaoRefund.setRefundUkid(UKID.getUKID());
            seTaobaoRefundMapper.insert(pTaobaoRefund);
            success++;
            map.put("success", success);
            map.put("fail", fail);
            map.put("seTaobaoRefund", pTaobaoRefund);
            resp.setData(map);
            return resp;
        }

        if (PROCESS_STATUS_SUCCESS.equals(String.valueOf(refund.getProcessStatus()))) {
            _log.error("同步退款单失败", refund.getRefundId() + "该单在网仓已退款成功");
            fail++;
        } else if (PROCESS_STATUS_CLOSE.equals(String.valueOf(refund.getProcessStatus()))) {
            _log.error("同步退款单失败", refund.getRefundId() + "该单在网仓已关闭");
            fail++;
        } else {
            refund.setModified(new Date());
            refund.setStatus(pTaobaoRefund.getStatus());
            refund.setGoodStatus(pTaobaoRefund.getGoodStatus());
            refund.setRefundFee(pTaobaoRefund.getRefundFee());
            refund.setReason(pTaobaoRefund.getReason());
            refund.setCompanyName(pTaobaoRefund.getCompanyName());
            refund.setSid(pTaobaoRefund.getSid());
            refund.setReasonDesc(pTaobaoRefund.getReasonDesc());

            if ("SUCCESS".equals(pTaobaoRefund.getStatus())) { // 当平台退款单状态为退款成功时
                refund.setProcessStatus(PROCESS_STATUS_SUCCESS);// 修改网仓退款单的状态为 退款成功
                int i = seTaobaoRefundMapper.updateProcessStatus(refund);
                if (i == 0) {
                    fail++;
                    _log.error("同步退款单失败", refund.getRefundId() + "修改退款单网仓状态为退款成功的时候 失败");
                } else {
                    success++;
                }
            } else if ("CLOSED".equals(pTaobaoRefund.getStatus())) {// 当平台退款单状态为已关闭时
                refund.setProcessStatus(PROCESS_STATUS_CLOSE);// 修改网仓退款单的状态为 已关闭
                int i = seTaobaoRefundMapper.updateProcessStatus(refund);
                if (i == 0) {
                    fail++;
                    _log.error("同步退款单失败", refund.getRefundId() + "修改退款单网仓状态为已关闭的时候 失败");
                } else {
                    success++;
                }
            } else {
                int i = seTaobaoRefundMapper.updatePlatfromStatus(refund);
                if (i == 0) {
                    fail++;
                    _log.error("同步退款单失败", refund.getRefundId() + "修改退款单平台状态  失败");
                } else {
                    success++;
                }
            }
        }
        map.put("success", success);
        map.put("fail", fail);
        map.put("seTaobaoRefund", refund);
        resp.setData(map);
        return resp;
    }


}