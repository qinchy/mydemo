package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmDownTimeMapper;
import com.wwwarehouse.xdw.datasync.manager.AmDownTimeManager;
import com.wwwarehouse.xdw.datasync.model.AmDownTimeDTO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;

@Service
public class AmDownTimeManagerImpl implements AmDownTimeManager {
//	@Resource
//	private RedisHelper redisHelper;
	@Resource
	private AmDownTimeMapper amDownTimeMapper;

	private String redisKey = "AmDownTime";

//	@Override
//	public IBasicDao<AmDownTimeDO> getDao() {
//		return amDownTimeMapper;
//	}

	@Override
	public AmDownTimeDTO getDownTime(Long shopId){
		return getDownTime(shopId, false);
	}

	@Override
	public AmDownTimeDTO getHistoryDownTime(Long shopId){
		return getDownTime(shopId, true);
	}

	public AmDownTimeDTO getDownTime(Long shopId, boolean isHistory){
		Long dbUkid = getDbUkid(shopId, isHistory);
//		AmDownTimeDTO shopDownTime = redisHelper.hget(redisKey, dbUkid.toString(), AmDownTime.class);
//		if (shopDownTime == null) {
//			shopDownTime = refreshRedis(dbUkid);
//		}
//		return shopDownTime;
		return null;
	}

	@Override
	public AmDownTimeDTO addDowntime(Long relatedId, boolean isValid, Date startDownTime,
                                  Date endDownTime, Long opUserId) throws Exception {
		return addDowntime(relatedId, isValid, false, startDownTime, endDownTime, opUserId);
	}

	@Override
	public AmDownTimeDTO addHistoryDowntime(Long relatedId, boolean isValid, Date startDownTime,
                                         Date endDownTime, Long opUserId) throws Exception {
		return addDowntime(relatedId, isValid, true, startDownTime, endDownTime, opUserId);
	}

	@Override
	public int closeDowntime(Long relatedId, Long opUserId) throws Exception {
		return closeDowntime(relatedId, false, opUserId);
	}

	@Override
	public int closeHistoryDowntime(Long relatedId, Long opUserId) throws Exception {
		return closeDowntime(relatedId, true, opUserId);
	}

	private AmDownTimeDTO addDowntime(Long relatedId, boolean isValid, boolean isHistory, Date startDownTime,
                                   Date endDownTime, Long opUserId) throws Exception {
		Long dbUkid = getDbUkid(relatedId, isHistory);

		HashMap<String, Object> params = new HashMap<>();
		params.put("related_id", dbUkid);
		params.put("is_valid", 1);
//		List<AmDownTimeDO> downTimes = amDownTimeMapper.getsByMap(params);
//		if(downTimes.size() > 0){
//			return null;
//		}

		AmDownTimeDTO amDownTime = new AmDownTimeDTO();
		amDownTime.setRelatedId(dbUkid);
		amDownTime.setIsValid(isValid ? 1 : 0);
		amDownTime.setOpenUserId(opUserId);
		amDownTime.setStartDownTime(startDownTime);
		amDownTime.setEndDownTime(endDownTime);
		amDownTime.setUkid(UKID.getUKID());
//		amDownTimeMapper.insert(amDownTime);

		return refreshRedis(dbUkid);
	}

	private int closeDowntime(Long relatedId, boolean isHistory, Long opUserId) throws Exception {
		Long dbUkid = getDbUkid(relatedId, isHistory);

		int i = amDownTimeMapper.updateInvalid(dbUkid, opUserId);
		if(i > 0) {
			refreshRedis(dbUkid);
		}

		return i;
	}

	private Long getDbUkid(Long relatedId, boolean isHistory) {
		long dbUkId = relatedId.longValue();
		if (isHistory) {
//			dbUkId = Converter.toLong(String.valueOf(dbUkId) + "01");
		}
		return dbUkId;
	}

	private AmDownTimeDTO refreshRedis(Long relatedId){
		HashMap<String, Object> params = new HashMap<>();
		params.put("related_id", relatedId);
		params.put("is_valid", 1L);
//		List<AmDownTimeDTO> downTimes = amDownTimeMapper.getsByMap(params);
		AmDownTimeDTO downTime = null;
//		if (downTimes.isEmpty()) {
//			redisHelper.hdel(redisKey, relatedId.toString());
//		} else {
//			downTime = downTimes.get(0);
//			redisHelper.hset(redisKey, relatedId.toString(), downTime);
//		}
		return downTime;
	}
}
