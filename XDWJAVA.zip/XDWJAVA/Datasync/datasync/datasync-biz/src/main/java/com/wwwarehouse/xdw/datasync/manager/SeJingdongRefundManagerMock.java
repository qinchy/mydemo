package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongRefundMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundExample;

/**
* SeJingdongRefundService
*  on 2017/6/13.
*/
public class SeJingdongRefundManagerMock extends BaseServiceMock<SeJingdongRefundMapper, SeJingdongRefundDO, SeJingdongRefundExample> implements SeJingdongRefundManager {

}
