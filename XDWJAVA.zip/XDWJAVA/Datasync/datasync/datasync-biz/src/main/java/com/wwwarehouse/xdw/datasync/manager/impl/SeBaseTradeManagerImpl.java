package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.StringUtils;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoTradeDOMapper;
import com.wwwarehouse.xdw.datasync.manager.SeBaseTradeManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemDTO;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeBaseTrade;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/13 0013.
 */
@Service
public abstract class SeBaseTradeManagerImpl <T extends SeBaseTrade<E>, E extends SeBaseItem>
         implements SeBaseTradeManager<T, E> {

    @Autowired
    SeTaobaoTradeDOMapper seTaobaoTradeMapper;

    @Override
    public AbsResponse<?> downTrade(AmAppSubscriptionDTO amAppSubscriptionDTO, String tid) throws Exception {
        AbsResponse<T> rsp = new AbsResponse<>();

        Long shopId = amAppSubscriptionDTO.getSubscriptionBuId();
//		try {
        ITradeApi api =  ApiUtil.getTradeApi(amAppSubscriptionDTO);
        if (api == null) {
            return rsp.setResult(404, "未实例化接口对象！" + amAppSubscriptionDTO.getSubscriptionBuId());
        }
        AbsResponse<?> cacheRsp = api.catchOneTrade(tid);
        if (cacheRsp.isSuccess()) {
            rsp = this.saveTrade(shopId, (T) cacheRsp.getData(), 999L);
        } else {
            rsp.setResult(cacheRsp);
        }
//		} finally {
//            try {
//                if (api != null && api.getAccessLogList() != null) {
//                    for (int i = 0; i < api.getAccessLogList().size(); i++) {
//                        api.getAccessLogList().get(i).setDoResult(rsp.getMsg());
//                    }
//                    mongoDao.dumpRecords(api.getAccessLogList());
//                }
//            }catch (Exception e){
//                logger.error(e.getMessage(), e);
//            }
//		}
        return rsp;
    }

    @Override
    public AbsResponse<T> saveTrade(Long shopId, T pTrade, Long userId) throws Exception {
        AbsResponse<T> retBean = new AbsResponse<>();

        pTrade.setShopId(shopId);
        Date now = new Date();
        long tradeStatus = 100L;
        int shopShipType = 1;//关联发货类型：3=关联不发货
        boolean isNew;
        boolean hasPresale = false;
        T oTrade = this.getByTid(shopId, pTrade.getOrderId());

        List<E> oItemList = new ArrayList<>();
        List<E> placeItemList = null;
        if (oTrade == null) {
            oTrade = pTrade;
            isNew = true;
        } else {
            isNew = false;
            if (oTrade.getOriginTradeStatus() == 200L) {
                return updatePlatformTrade(shopId, pTrade, oTrade, userId);
            } else if (oTrade.getOriginTradeStatus() >= 400) {
                return updatePlatformTrade(shopId, pTrade, oTrade, userId);
            }
            placeItemList = getsOrderByTradeUkid(oTrade.getTradeUkid());
        }

        if (pTrade.getItemList() == null || pTrade.getItemList().size() == 0) {
            tradeStatus = 130L;//未铺货
        } else {
            for (E pOrder : pTrade.getItemList()) {
                boolean needModify = true;
                E oOrder = null;
                if (!isNew) {
                    oOrder = matchItem(placeItemList, pOrder);
                }
                if (oOrder == null) {
                    oOrder = pOrder;
                } else if (oOrder.getProductCodeUkid() != null) {//已经匹配的不需要重复计算，返回原状态，可能逻辑仍要修改
                    needModify = false;
                }
                long orderStatus;
                if(needModify) {
                    orderStatus = getOrderStatus(oTrade, oOrder, isNew, hasPresale);

                    if(this.isTradeClosed(oOrder.getSubOrderStatus())) {
                        orderStatus = 400L;//交易关闭
                        oOrder.setOriginOrderStatus(orderStatus);
                    } else if(!this.needSend(oOrder.getSubOrderStatus())) {
                        orderStatus = 410L;//交易状态不非需发货状态
                        oOrder.setOriginOrderStatus(orderStatus);
                    }
                } else {
                    orderStatus = oOrder.getOriginOrderStatus();
                }
                tradeStatus = getTradeStatus(tradeStatus, orderStatus, shopShipType);
                oItemList.add(oOrder);
            }
        }

        if(this.isTradeClosed(oTrade.getPlatformOrderStatus())) {
            tradeStatus = 400L;//交易关闭
        } else if(!this.needSend(oTrade.getPlatformOrderStatus())) {
            tradeStatus = 410L;//交易状态不非需发货状态
        } else { //判断是否子订单全为关闭状态
            boolean all400 = true;
            if (pTrade.getItemList() == null || pTrade.getItemList().size() == 0) {
                all400 = true;
            } else {
                for (E oItem : oItemList) {
                    if (oItem.getOriginOrderStatus().longValue() < 400L) {
                        all400 = false;
                        break;
                    }
                }
            }
            if (all400) {
                tradeStatus = 400L;
            }
        }

        oTrade.setPlatformOrderStatus(pTrade.getPlatformOrderStatus());
        oTrade.setOriginTradeStatus(tradeStatus);
        if (isNew) {
            oTrade.setTradeUkid(UKID.getUKID());
            this.saveTrdeDO(oTrade);
        } else {
            this.updateTrdeDO(oTrade);
        }
        int idx = 0;
        for (E oItem : oItemList) {
            idx++;
            if (tradeStatus >= 400L) {//主订单为关闭状态，则子订单也为关闭状态
                oItem.setOriginOrderStatus(tradeStatus);
            }
            if (oItem.getItemUkid() == null) {
                if (isNew && idx == 1) {
                    oItem.setItemUkid(oTrade.getTradeUkid());// 如果是新增订单且是第一个订单行，则主键与订单主键一致，减少性能消耗，逻辑上不影响
                } else {
                    oItem.setItemUkid(UKID.getUKID());
                }
                oItem.setTradeUkid(oTrade.getTradeUkid());
                oItem.setDownTime(now);
                this.saveItem(oItem);
            } else {
                this.updateItem(oItem);
            }
        }

        retBean.setData(oTrade);

        //保存日志
        String remark =  pTrade.getPlatformOrderStatus() +";"+ oTrade.getOriginTradeStatus();
//        ruOperationLogMqService.addBusinessLog(oTrade.getTradeUkid(), "保存订单", "SE", userId, remark);

        if(oTrade.getOriginTradeStatus() == 100L){
            pushToConvertService(shopId, oTrade.getTradeUkid(), 999L);
        }
        return retBean;
    }

    @Override
    public AbsResponse<T> updatePlatformTrade(Long shopId, T pTrade, T oTrade, Long userId) throws Exception {
        return null;
    }

    @Override
    public AbsResponse<?> updateTrade(T trade) throws Exception {
        return null;
    }

    @Override
    public int updatePlatformInfo(T trade) throws Exception {
        return 0;
    }

    @Override
    public T getByTid(Long shopId, String tid) {
        return null;
    }

    @Override
    public T get(Long ukid) {
        return null;
    }

    @Override
    public List getsOrderByTradeUkid(Long tradeUkid) {
        return null;
    }

    @Override
    public int updateOriginStatus(T t) {
        return 0;
    }

    @Override
    public int updateOriginItemStatus(E t) {
        return 0;
    }

    @Override
    public boolean isTradeClosed(String platformSradeStatus) {
        return false;
    }

    @Override
    public boolean needSend(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean canSend(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean canConvert(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean canConvert(Long originTradeStatus) {
        return false;
    }

    @Override
    public boolean isTradeFinish(String platformSradeStatus) {
        return false;
    }

    @Override
    public void pushToConvertService(Long shopId, Long tradeUkid, Long userId) throws Exception {

    }


    @Override
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId) {
        return null;
    }



    /**
     * 判断订单明细状态
     *
     * @param oTrade
     * @param oOrder
     * @param isNew
     * @param hasPresale
     * @return
     * @throws Exception
     */
    public long getOrderStatus(T oTrade, E oOrder, boolean isNew, boolean hasPresale) throws Exception {
        if (oOrder.getProductCodeUkid() != null) {
            //已经匹配的不需要重复计算，返回原状态
            return oOrder.getOriginOrderStatus();
        }

        ImPlatformItemDTO platItem = new ImPlatformItemDTO();
        platItem.setShopId(oTrade.getShopId());
        platItem.setProductNumId(StringUtils.toString(oOrder.getProductNumId()));
        platItem.setSkuNumId(oOrder.getSkuNumId());
//        platItem = imPlatformItemService.getByProductNumId(platItem);
//
//        Date presaleDate = null;
//        if (hasPresale) {
//            presaleDate = PresaleUtil.getPresaleDate(oOrder.getProductName());
//        }
//        oOrder.setPresaleDate(presaleDate);
        boolean syncStock = true;
        if (platItem != null) {
            oOrder.setProductCodeUkid(platItem.getIdentifyUkid());
            oOrder.setProductCode(platItem.getIdentifyCode());
            oOrder.setShopProductUkid(platItem.getPlatformItemUkid());
//			if (oOrder.getPresaleDate() != null) {
//				shopProductCode.setIsPresale(Long.valueOf(1L));
//				shopProductCode.setPresaleDate(oOrder.getPresaleDate());
//			} else {
//				shopProductCode.setIsPresale(Long.valueOf(0L));
//				shopProductCode.setPresaleDate(null);
//			}
//			if ((shopProductCode.getSubStock() != null)
//					&& (shopProductCode.getSubStock().longValue() == 2L)
//					&& (("WAIT_BUYER_PAY".equals(oTrade.getStatus())) || ("TRADE_NO_CREATE_PAY"
//							.equals(oTrade.getStatus())))) {
//				syncStock = false;
//			}
//			if ((syncStock)
//					&& ((isNew) || ((oOrder.getOriginOrderStatus() != null) && (oOrder
//							.getOriginOrderStatus().longValue() == 130L)))) {
//				try {
//					this.shopInventoryService.updateInventoryAddQty(
//							shopProductCode.getProductCodeUkid(),
//							shopProductCode.getShopProductUkid(),
//							Long.valueOf(-oOrder.getNum().longValue()));
//				} catch (Exception e) {
//					log.error("同步库存出错" + oOrder.getShopProductCodeUkid(), e);
//				}
//			}
        }

        long orderStatus = getOrderStatus(platItem,
                oTrade.getTradeUkid(), oTrade.getOrderId(),
                oOrder.getQty(), syncStock);

        oOrder.setOriginOrderStatus(orderStatus);

        return orderStatus;
    }

    /**
     * 判断订单明细铺货状态
     *
     * @param spc       铺货
     * @param tradeUkid
     * @param tradeId
     * @param qty
     * @param syncStock
     * @return
     * @throws Exception
     */
    public long getOrderStatus(ImPlatformItemDTO spc, Long tradeUkid, String tradeId,
                               Long qty, boolean syncStock) throws Exception {
        long orderStatus = 100L;
//        if (spc == null) {
//            orderStatus = getTradeStatus(orderStatus, 130L, 0);
//        } else if (spc.getItemStatus().longValue() == 30L) {//无需发货
//            orderStatus = getTradeStatus(orderStatus, Long.valueOf(400L), 3);
//        } else if (spc.getItemStatus().longValue() != 90L) {//未关联
//            orderStatus = getTradeStatus(orderStatus, Long.valueOf(120L), 0);
//        } else if (!syncStock) {//不需要同步库存
//            orderStatus = getTradeStatus(orderStatus, 100L, 0);
//        } else {
            long retCode = 0L;
//			if ((spc.getIsPresale() != null)
//					&& (spc.getIsPresale().longValue() == 1L)
//					&& (spc.getPresaleDate().after(new Date()))) {
//				this.stPresaleInventoryService.lockPresaleInventory(
//						spc.getProductCodeUkid(), spc.getPresaleDate(), qty,
//						tradeUkid, tradeId, "S", true, Long.valueOf(999L));
//			} else {
//				this.stReserveInventoryService.lockReserveInventory(
//						spc.getShopId(), spc.getProductCodeUkid(), qty,
//						tradeUkid, tradeId, "S", true, Long.valueOf(999L));
//
//				retCode = this.inventoryService.lockInventory(
//						spc.getProductCodeUkid(), qty, tradeUkid, tradeId, "S",
//						true, Long.valueOf(999L));
//			}
//            if (retCode != 0L) {//库存不足
//                orderStatus = getTradeStatus(orderStatus, 110L, 0);
//            }
//        }
        return orderStatus;
    }
    /**
     * 计算订单状态
     *
     * @param oTradeStatus 原订单状态
     * @param status       新订单状态
     * @param shopShipType 关联发货类型
     * @return
     */
    public long getTradeStatus(long oTradeStatus, long status, int shopShipType) {
        if (status == 400L && shopShipType == 3) {//如果关联不发货，则整个订单不需要发货
            status = 400L;
        } else if (status == 400L) {//
            status = oTradeStatus;
        }
        return Math.max(oTradeStatus, status);
    }


    public abstract E matchItem(List<E> oItemList, E pItem) throws Exception;

    public abstract int saveItem(E item) throws Exception;

    public abstract int updateItem(E item) throws Exception;

    public abstract int saveTrdeDO(T trade) throws Exception;

    public abstract int updateTrdeDO(T trade) throws Exception;

    /**
     * 判断平台订单的的下载设置，能否下载订单
     * 一些对某些字段的更改也可以放在这里。对对象直接操作。
     *
     * @param pTrade
     * @return
     * @throws Exception
     */
    public abstract AbsResponse<T> checkTrade(T pTrade) throws Exception;

    /**
     * 检查历史订单状态
     * @param pTrade
     * @return
     * @throws Exception
     */
    public abstract AbsResponse<T> checkHisTrade(T pTrade) throws Exception;
}
