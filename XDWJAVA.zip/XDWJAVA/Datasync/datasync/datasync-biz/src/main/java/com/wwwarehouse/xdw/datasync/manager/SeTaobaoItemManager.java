package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDOExample;

/**
* SeTaobaoItemService
*  on 2017/6/14.
*/
public interface SeTaobaoItemManager extends BaseService<SeTaobaoItemDO, SeTaobaoItemDOExample> {

}