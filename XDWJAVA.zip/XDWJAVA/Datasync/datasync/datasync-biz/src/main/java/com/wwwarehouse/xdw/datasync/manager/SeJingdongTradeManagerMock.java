package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongTradeMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongTradeExample;
import com.wwwarehouse.xdw.datasync.model.SeJingdongTradeDTO;

import java.util.List;

/**
* SeJingdongTradeService
*  on 2017/6/13.
*/
public class SeJingdongTradeManagerMock extends BaseServiceMock<SeJingdongTradeMapper, SeJingdongTradeDO, SeJingdongTradeExample> implements SeJingdongTradeManager {

    @Override
    public boolean canConvert(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean canSend(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean needSend(String platformOrderStatus) {
        return false;
    }

    @Override
    public boolean isTradeFinish(String platformSradeStatus) {
        return false;
    }

    @Override
    public boolean isTradeClosed(String platformSradeStatus) {
        return false;
    }

    @Override
    public int updateOriginStatus(SeJingdongTradeDO oTrade) {
        return 0;
    }

    @Override
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId) {
        return null;
    }

    @Override
    public AbsResponse<SeJingdongTradeDTO> checkHisTrade(SeJingdongTradeDTO pTrade) throws Exception {
        return null;
    }

    @Override
    public AbsResponse<SeJingdongTradeDTO> checkTrade(SeJingdongTradeDTO pTrade) throws Exception {
        return null;
    }

    @Override
    public AbsResponse updateTrade(SeJingdongTradeDTO trade) throws Exception {
        return null;
    }

    @Override
    public SeJingdongTradeDO getByTid(Long shopId, String tid) {
        return null;
    }

    @Override
    public int updatePlatformInfo(SeJingdongTradeDTO trade) throws Exception {
        return 0;
    }
}
