package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.model.BaCountry;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDOExample;

import java.util.List;

/**
* BaCountryManager
*  on 2017/6/16.
*/
public interface BaCountryManager extends BaseManager<BaCountry, BaCountryDOExample> {

    /**
     * 获取所有国家
     * @return
     */
    List<BaCountryDO> listAllBaCountry();
}