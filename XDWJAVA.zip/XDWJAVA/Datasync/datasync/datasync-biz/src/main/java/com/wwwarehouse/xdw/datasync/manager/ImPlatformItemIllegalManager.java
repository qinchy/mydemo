package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemIllegalDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDOExample;

/**
* ImPlatformItemIllegalManager
*  on 2017/6/16.
*/
public interface ImPlatformItemIllegalManager extends BaseManager<ImPlatformItemIllegalDTO, ImPlatformItemIllegalDOExample> {

    public int saveIllegal(Long lotUkid, ImPlatformItemIllegalDTO imPlatformItem) throws Exception;
}