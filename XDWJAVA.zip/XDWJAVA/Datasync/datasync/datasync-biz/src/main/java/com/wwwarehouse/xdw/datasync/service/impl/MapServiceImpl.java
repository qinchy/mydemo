package com.wwwarehouse.xdw.datasync.service.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.IbsMapManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.MapPlatform;
import com.wwwarehouse.xdw.datasync.service.MapService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

/**
 * Created by huahui.wu on 2017/6/15.
 */
@Service("mapService")
@com.alibaba.dubbo.config.annotation.Service
public class MapServiceImpl implements MapService {
	@Resource
	private IbsMapManager ibsMapManager;
	@Resource
	private AmAppSubscriptionManager amAppSubscriptionManager;

	@Override
	public AbsResponse<Object> geoCodeGeo(String address, String city, String location, Long mapCode) throws Exception{
		AbsResponse<Object> absResponse = new AbsResponse<Object>();
		Long payServiceId = Constants.WCKJ.longValue();
		String mapAppType = "";

		AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(
				mapCode, payServiceId, mapAppType);
		if (MapPlatform.IBSMAP.equalsById(mapCode)) {
			absResponse = ibsMapManager.geoCodeGeo(address, city, location, appSuber);
		}

		return absResponse;
	}

	@Override
	public AbsResponse<Object> direction(String origin, String destination, String strategy, String mode, Long mapCode, String region) throws Exception{
		AbsResponse<Object> absResponse = new AbsResponse<Object>();

		Long payServiceId = Constants.WCKJ.longValue();
		String mapAppType = "";

		AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(
				mapCode, payServiceId, mapAppType);

		if (MapPlatform.IBSMAP.equalsById(mapCode)) {
			absResponse = ibsMapManager.direction(origin, destination, strategy, mode, appSuber);
		}
		return absResponse;
	}

	@Override
	public AbsResponse<Object> getLocation(String city, String keywords, Long mapCode) throws Exception{
		Long payServiceId = Constants.WCKJ.longValue();
		String mapAppType = "";

		AmAppSubscriptionDTO appSuber = amAppSubscriptionManager.getSubscription(
				mapCode, payServiceId, mapAppType);

		Map<String, Double> map = ibsMapManager.getLocation(city, keywords, appSuber);
		return null;
	}
}
