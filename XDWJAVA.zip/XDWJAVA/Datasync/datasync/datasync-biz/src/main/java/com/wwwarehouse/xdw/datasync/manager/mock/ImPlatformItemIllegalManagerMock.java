package com.wwwarehouse.xdw.datasync.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.xdw.datasync.manager.ImPlatformItemIllegalManager;
import com.wwwarehouse.xdw.datasync.model.ImPlatformItemIllegalDTO;
import com.wwwarehouse.xdw.datasync.dao.model.ImPlatformItemIllegalDOExample;

/**
* ImPlatformItemIllegalManager
*  on 2017/6/16.
*/
public class ImPlatformItemIllegalManagerMock extends BaseManagerMock<ImPlatformItemIllegalDTO, ImPlatformItemIllegalDOExample> implements ImPlatformItemIllegalManager {

    @Override
    public int saveIllegal(Long lotUkid, ImPlatformItemIllegalDTO imPlatformItem) throws Exception {
        return 0;
    }
}
