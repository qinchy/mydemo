package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsDO;
import com.wwwarehouse.xdw.datasync.dao.model.SaSmsExample;
import com.wwwarehouse.xdw.datasync.model.SaSmsDTO;
import sun.util.resources.cldr.ga.LocaleNames_ga;

import java.util.Date;
import java.util.List;

/**
* SaSmsService
*  on 2017/6/14.
*/
public interface SaSmsManager extends BaseService<SaSmsDO, SaSmsExample> {
    public int updateSmsStatus(String smsUkids, Long smsStatus, Date actualSendTime, String returnText);

    /**
     * 插入按任务发送的短信
     */
    public String insert(Long serviceBuId, Long senderId, String smsType, String mobileNo, String content,
                         Date planSendTime, String relatedType, Long relatedOrderUkid,Long platformId) throws Exception;

    public List<SaSmsDTO> getNeedSendGroupList(Long smsAccountUkid);

    public List<SaSmsDTO> getNeedSendList(Long smsAccountUkid, Long buId, Long sendBuId, Long shopId, String sendContent);

    public String sendSms(String mobile, String smsContent,Long platformId) throws Exception;
}