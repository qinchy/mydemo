package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoItemDOMapper;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoTradeDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoItemDTO;
import com.wwwarehouse.xdw.datasync.model.SeTaobaoTradeDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
* SeTaobaoTradeService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeTaobaoTradeManagerImpl extends SeBaseTradeManagerImpl<SeTaobaoTradeDTO, SeTaobaoItemDTO>  {

    private static Logger _log = LoggerFactory.getLogger(SeTaobaoTradeManagerImpl.class);

    @Autowired
    SeTaobaoTradeDOMapper seTaobaoTradeMapper;

    @Resource
    SeTaobaoItemDOMapper seTaobaoItemMapper;



    @Override
    public SeTaobaoTradeDTO getByTid(Long shopId, String tid) {
        SeTaobaoTradeDO seTaobaoTradeDO = seTaobaoTradeMapper.getByOrderId(shopId, tid);
        if(seTaobaoTradeDO == null){
            return null;
        }
        SeTaobaoTradeDTO seTaobaoTradeDTO = new SeTaobaoTradeDTO();
        BeanUtils.copyProperties(seTaobaoTradeDO, seTaobaoTradeDTO);
        return seTaobaoTradeDTO;
    }
    @Override
    public int updatePlatformInfo(SeTaobaoTradeDTO oTrade) {
        SeTaobaoTradeDO seTaobaoTradeDO = new SeTaobaoTradeDO();
        BeanUtils.copyProperties(oTrade, seTaobaoTradeDO);
        return seTaobaoTradeMapper.updateByPrimaryKey(seTaobaoTradeDO);
    }

    @Override
    public int updateOriginStatus(SeTaobaoTradeDTO oTrade) {

        if(oTrade.getItemList() != null && !oTrade.getItemList().isEmpty()){
            for(SeTaobaoItemDTO oItem : oTrade.getItemList()) {
                updateOriginItemStatus(oItem);
            }
        }
        SeTaobaoTradeDO seTaobaoTradeDO = new SeTaobaoTradeDO();
        BeanUtils.copyProperties(oTrade, seTaobaoTradeDO);
        return seTaobaoTradeMapper.updateOriginStatus(seTaobaoTradeDO);
    }

    @Override
    public int updateOriginItemStatus(SeTaobaoItemDTO oItem){
        SeTaobaoItemDO seTaobaoItemDO = new SeTaobaoItemDO();
        BeanUtils.copyProperties(oItem, seTaobaoItemDO);
        return seTaobaoItemMapper.updateOriginStatus(seTaobaoItemDO);
    }

    @Override
    public List getsOrderByTradeUkid(Long tradeUkid) {
        List<SeTaobaoItemDO> seTaobaoItemDOs = seTaobaoItemMapper.getsByTradeUkid(tradeUkid);
        List<SeTaobaoItemDTO> SeTaobaoItemDTOs = new ArrayList<>();
        BeanUtils.copyProperties(seTaobaoItemDOs, SeTaobaoItemDTOs);
        return SeTaobaoItemDTOs;
    }

    @Override
    public SeTaobaoItemDTO matchItem(List<SeTaobaoItemDTO> oItemList, SeTaobaoItemDTO pItem) throws Exception {
        for (SeTaobaoItemDTO oItem : oItemList) {
            if (pItem.getSubOrderId().equals(oItem.getSubOrderId())) {
                pItem.setTradeUkid(oItem.getTradeUkid());
                pItem.setItemUkid(oItem.getItemUkid());
                pItem.setOriginOrderStatus(oItem.getOriginOrderStatus());
                pItem.setShopProductUkid(oItem.getShopProductUkid());
                pItem.setProductCodeUkid(oItem.getProductCodeUkid());
                //TODO 还要对其他字段赋值
                return pItem;
            }
        }
        return null;
    }

    @Override
    public int saveItem(SeTaobaoItemDTO item) throws Exception {
        SeTaobaoItemDO seTaobaoItemDO = new SeTaobaoItemDO();
        BeanUtils.copyProperties(item, seTaobaoItemDO);
        return seTaobaoItemMapper.insert(seTaobaoItemDO);
    }

    @Override
    public int updateItem(SeTaobaoItemDTO item) throws Exception {
        SeTaobaoItemDO seTaobaoItemDO = new SeTaobaoItemDO();
        BeanUtils.copyProperties(item, seTaobaoItemDO);
        return seTaobaoItemMapper.updateByPrimaryKey(seTaobaoItemDO);
    }

    @Override
    public int saveTrdeDO(SeTaobaoTradeDTO trade) throws Exception {
        SeTaobaoTradeDO seTaobaoTradeDO = new SeTaobaoTradeDO();
        BeanUtils.copyProperties(trade, seTaobaoTradeDO);
        return seTaobaoTradeMapper.insert(seTaobaoTradeDO);
    }

    @Override
    public int updateTrdeDO (SeTaobaoTradeDTO trade) throws Exception {
        SeTaobaoTradeDO seTaobaoTradeDO = new SeTaobaoTradeDO();
        BeanUtils.copyProperties(trade, seTaobaoTradeDO);
        return seTaobaoTradeMapper.updateByPrimaryKey(seTaobaoTradeDO);
    }


//    @Override
//    public List<SeTaobaoTradeDTO> getsNeedConvertTrade(PageParameter params) {
//        return seTaobaoTradeMapper.getsNeedConvertTrade(params);
//    }

    @Override
    public List<Long> getsItemByProduct(String productNumId, String skuNumId, Long shopId) {
        return seTaobaoItemMapper.getsItemByProduct(productNumId, skuNumId, shopId);
    }

    @Override
    public AbsResponse<SeTaobaoTradeDTO> checkTrade(SeTaobaoTradeDTO pTrade) throws Exception {
        AbsResponse<SeTaobaoTradeDTO> retBean = new AbsResponse<>();
        if (pTrade == null) {
            return retBean.setResult(108, "订单未抓取成功!");
        }
        if (!needSend(pTrade.getPlatformOrderStatus())) {
            return retBean.setResult(104, "不是待发货订单:" + pTrade.getPlatformOrderStatus());
        }
        return retBean;
    }

    @Override
    public AbsResponse<SeTaobaoTradeDTO> checkHisTrade(SeTaobaoTradeDTO pTrade) throws Exception {
        AbsResponse<SeTaobaoTradeDTO> retBean = new AbsResponse<>();
        if (pTrade == null) {
            return retBean.setResult(108, "订单未抓取成功!");
        }
        if (!isTradeFinish(pTrade.getPlatformOrderStatus())) {
            return retBean.setResult(104, "不是已完成订单:" + pTrade.getPlatformOrderStatus());
        }
        return retBean;
    }

    @Override
    public AbsResponse updateTrade(SeTaobaoTradeDTO trade) throws Exception {
        AbsResponse<Long> retBean = new AbsResponse<>();
        if (trade == null) {
            return retBean.setResult(108, "订单不能为空");
        }

        List<SeTaobaoItemDTO> items = trade.getItemList();
        if(!items.isEmpty()) {
            for(SeTaobaoItemDTO item : items) {
                updateItem(item);
            }
        }
        SeTaobaoTradeDO seTaobaoTradeDO = new SeTaobaoTradeDO();
        BeanUtils.copyProperties(trade, seTaobaoTradeDO);
        seTaobaoTradeMapper.updateByPrimaryKey(seTaobaoTradeDO);
        return retBean;
    }

    /**
     TRADE_NO_CREATE_PAY(没有创建支付宝交易)
     WAIT_BUYER_PAY(等待买家付款)
     SELLER_CONSIGNED_PART(卖家部分发货)
     WAIT_SELLER_SEND_GOODS(等待卖家发货,即:买家已付款)
     WAIT_BUYER_CONFIRM_GOODS(等待买家确认收货,即:卖家已发货)
     TRADE_BUYER_SIGNED(买家已签收,货到付款专用)
     TRADE_FINISHED(交易成功)
     TRADE_CLOSED(付款以后用户退款成功，交易自动关闭)
     TRADE_CLOSED_BY_TAOBAO(付款以前，卖家或买家主动关闭交易)
     PAY_PENDING(国际信用卡支付付款确认中)
     WAIT_PRE_AUTH_CONFIRM(0元购合约中)
     */
    @Override
    public boolean isTradeClosed(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "TRADE_CLOSED_BY_TAOBAO":    	//(付款以前，卖家或买家主动关闭交易)
            case "TRADE_CLOSED":            	//(付款以后用户退款成功，交易自动关闭)
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }
    @Override
    public boolean isTradeFinish(String platformSradeStatus) {
        boolean isTradeClosed;
        switch (platformSradeStatus) {
            case "TRADE_FINISHED":            	//交易成功
            {
                isTradeClosed = true;
                break;
            }
            default:
                isTradeClosed = false;
                break;
        }

        return isTradeClosed;
    }

    @Override
    public boolean needSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "WAIT_BUYER_PAY":  		//等待买家付款
            case "TRADE_NO_CREATE_PAY":  	//等待买家付款
            case "PAY_PENDING":  			//国际信用卡支付付款确认中
            case "WAIT_SELLER_SEND_GOODS":  //等待卖家发货
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }

    @Override
    public boolean canSend(String platformOrderStatus) {
        boolean needSend;
        switch (platformOrderStatus) {
            case "WAIT_SELLER_SEND_GOODS":  //等待卖家发货
            {
                needSend = true;
                break;
            }
            default:
                needSend = false;
                break;
        }

        return needSend;
    }

    /**
     *交易状态status
     WAIT_BUYER_PAY：等待买家付款
     WAIT_SELLER_SEND_GOODS：等待卖家发货
     SELLER_CONSIGNED_PART：卖家部分发货
     WAIT_BUYER_CONFIRM_GOODS：等待买家确认收货
     TRADE_BUYER_SIGNED：买家已签收（货到付款专用）
     TRADE_FINISHED：交易成功
     TRADE_CLOSED：交易关闭
     TRADE_CLOSED_BY_TAOBAO：交易被淘宝关闭
     TRADE_NO_CREATE_PAY：没有创建外部交易（支付宝交易）
     WAIT_PRE_AUTH_CONFIRM：余额宝0元购合约中
     PAY_PENDING：外卡支付付款确认中
     ALL_WAIT_PAY：所有买家未付款的交易（包含：WAIT_BUYER_PAY、TRADE_NO_CREATE_PAY）
     ALL_CLOSED：所有关闭的交易（包含：TRADE_CLOSED、TRADE_CLOSED_BY_TAOBAO）
     */
    public boolean canConvert(String platformOrderStatus){
        switch (platformOrderStatus){
            case "WAIT_BUYER_PAY":
            case "SELLER_CONSIGNED_PART":
            case "TRADE_FINISHED":
            case "WAIT_SELLER_SEND_GOODS": return true;
        }
        return false;
    }
}