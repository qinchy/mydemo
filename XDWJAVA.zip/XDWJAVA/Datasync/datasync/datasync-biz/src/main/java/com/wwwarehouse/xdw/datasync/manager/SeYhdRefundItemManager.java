package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundItemDOExample;

/**
* SeYhdRefundItemService
*  on 2017/6/14.
*/
public interface SeYhdRefundItemManager extends BaseService<SeYhdRefundItemDO, SeYhdRefundItemDOExample> {

}