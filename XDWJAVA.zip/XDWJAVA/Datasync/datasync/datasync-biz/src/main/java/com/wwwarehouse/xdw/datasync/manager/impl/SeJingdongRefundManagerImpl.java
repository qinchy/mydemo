package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeJingdongRefundMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeJingdongRefundExample;
import com.wwwarehouse.xdw.datasync.manager.SeJingdongRefundManager;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeJingdongRefundDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
* SeJingdongRefundService
*  on 2017/6/13.
*/
@Service
@Transactional
public class SeJingdongRefundManagerImpl extends SeBaseRefundManagerImpl<SeJingdongRefundDTO, SeBaseItem> {

    private static Logger _log = LoggerFactory.getLogger(SeJingdongRefundManagerImpl.class);

    @Autowired
    SeJingdongRefundMapper seJingdongRefundMapper;

    @Override
    public AbsResponse checkeRefund(SeJingdongRefundDTO pTrade) throws Exception {
        return null;
    }
}