package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseService;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppSubscriptionExample;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;

import java.util.List;

/**
* AmAppSubscriptionService
*  on 2017/6/13.
*/
public interface AmAppSubscriptionManager extends BaseService<AmAppSubscriptionDO, AmAppSubscriptionExample> {
    public AmAppSubscriptionDTO get(Long subscriptionUkid);
    public AmAppSubscriptionDTO getSubscription(Long platformId, Long suberBuId, String appType);

    public AmAppSubscriptionDTO getSubscription(Long platformId, Long appOwnerId, Long suberBuId,
                                                String appType);

    /**
     * 封闭订购对象：设置amAppkey与platformId
     * setApp();
     * setPlatformId();
     *
     *
     * @param subscription
     * @param app
     * @return
     */
    public AmAppSubscriptionDTO packageAppSub(AmAppSubscriptionDTO subscription, AmAppkeyDTO app);

    /**
     * 根据appUkid获取list
     *
     * @param appUkid
     * @return
     */
    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, Long suberBuId, Long status);

    public List<AmAppSubscriptionDTO> getsByBuid(Long suberBuId, Long status);

    public int insertSubscription(AmAppSubscriptionDTO subscription);

    public List<AmAppSubscriptionDTO> getsNeedRefresh();

    public int updateAuthBuId(AmAppSubscriptionDTO subscription);

    public int updateSubscription(AmAppSubscriptionDTO subscription);

    public int update(AmAppSubscriptionDTO subscription);

    public List<AmAppSubscriptionDTO> getsByAppUkid(Long appUkid, int shardingCount, int shardingItem);
}