package com.wwwarehouse.xdw.datasync.manager.mock;

import com.alibaba.fastjson.JSON;
import com.wwwarehouse.xdw.datasync.manager.ItemManager;
import com.wwwarehouse.xdw.datasync.model.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created by shisheng.wang on 17/6/6.
 */
@Service
public class ItemManagerMock implements ItemManager {

    @Override
    public Item get(long itemId) {
//        Item item = new Item();
//        item.setItemId(itemId);
//        item.setItemName("item" + itemId);
//        //mqProducer.send(Constants.TOPIC_DATASYNC_RESULT, String.valueOf(item.hashCode()), item);
//
//        itemRedisTemplate.opsForValue().set("item:"+itemId, item);
//        itemRedisTemplate.expire("item:"+itemId, 10, TimeUnit.MINUTES);
//
//        Item item1 = itemRedisTemplate.opsForValue().get("item:"+itemId);
//        System.out.println(item1);
//
//        redisSet();
//
//        return item;
        return null;
    }

    private void redisSet(){
//        redisTemplate.opsForValue().set("a","avalue");
//        redisTemplate.expire("a", 10, TimeUnit.MINUTES);
//        String s = redisTemplate.opsForValue().get("a");
//        System.out.println("a =" + s);
//
//        redisTemplate.opsForSet().add("b", "b1", "b2", "b3");
//        redisTemplate.opsForSet().pop("b");
//        Set set = redisTemplate.opsForSet().members("b");
//        System.out.println("set =" + set);
//
//        Item item = new Item();
//        item.setItemId(1L);
//        item.setItemName("111");
//        redisTemplate.opsForValue().set("1", JSON.toJSONString(item));
//        Item item1 = JSON.parseObject(redisTemplate.opsForValue().get("1"), Item.class);
//
//        System.out.println("item =" + item1);
//        redisTemplate.delete("a");
//        redisTemplate.delete("b");
//        redisTemplate.delete("1");
    }

    @Override
    public int add(Item item) {
        return 1;
    }
}
