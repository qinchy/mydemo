package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeYhdRefundDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeYhdRefundDO;
import com.wwwarehouse.xdw.datasync.model.SeYhdRefundDTO;
import com.wwwarehouse.xdw.datasync.model.SeYhdRefundItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
* SeYhdRefundService
*  on 2017/6/14.
*/
@Service
@Transactional
public class SeYhdRefundManagerImpl extends SeBaseRefundManagerImpl<SeYhdRefundDTO, SeYhdRefundItemDTO> {

    private static Logger log = LoggerFactory.getLogger(SeYhdRefundManagerImpl.class);

    @Autowired
    SeYhdRefundDOMapper seYhdRefundMapper;

    private static Long PROCESS_STATUS_SUCCESS = 80L;
    private static Long PROCESS_STATUS_CLOSE = 90L;

    @Override
    public AbsResponse checkeRefund(SeYhdRefundDTO pTrade) throws Exception {
        return null;
    }

    public AbsResponse<Map<String, Long>> updateRefundStatus(Long shopId, Object pRefund) throws Exception {
        AbsResponse<Map<String, Long>> resp = new AbsResponse<Map<String, Long>>();
        SeYhdRefundDTO pYhdRefund=(SeYhdRefundDTO) pRefund;
        SeYhdRefundDO pYhdRefundDO = new SeYhdRefundDO();
        BeanUtils.copyProperties(pYhdRefund, pYhdRefundDO);

        Map<String, Long> map = new HashMap<String, Long>();
        Long success = 0L;
        Long fail = 0L;
        SeYhdRefundDO refundDO = seYhdRefundMapper.getRefund(pYhdRefund.getRefundId());
        SeYhdRefundDTO refund = new SeYhdRefundDTO();

        BeanUtils.copyProperties(refundDO, refund);
        if (refund.getProcessStatus() == 80L) {
            log.error("同步退款单失败", refund.getRefundId() + "该单在网仓已退款成功");
            fail++;
        } else if (refund.getProcessStatus() == 90L) {
            log.error("同步退款单失败", refund.getRefundId() + "该单在网仓已关闭");
            fail++;
        } else {
            refund.setModifyTime(new Date());
            refund.setRefundStatus(pYhdRefund.getRefundStatus());
            refund.setProductAmount(pYhdRefund.getProductAmount());
            refund.setReasonMsg(pYhdRefund.getReasonMsg());
            refund.setExpressName(pYhdRefund.getExpressName());
            refund.setExpressNbr(pYhdRefund.getExpressNbr());
            refund.setMerchantMark(pYhdRefund.getMerchantMark());

            if ("27".equals(pYhdRefund.getRefundStatus())) { // 当平台退款单状态为退款成功时
                refund.setProcessStatus(80L);// 修改网仓退款单的状态为 退款成功
                int i = seYhdRefundMapper.updateProcessStatus(refundDO);
                if (i == 0) {
                    fail++;
                    log.error("同步退款单失败", refund.getRefundId() + "修改退款单网仓状态为退款成功的时候 失败");
                } else {
                    success++;
                }
            } else if ("40".equals(pYhdRefund.getRefundStatus())) {// 当平台退款单状态为已关闭时
                refund.setProcessStatus(90L);// 修改网仓退款单的状态为 已关闭
                int i = seYhdRefundMapper.updateProcessStatus(refundDO);
                if (i == 0) {
                    fail++;
                    log.error("同步退款单失败", refund.getRefundId() + "修改退款单网仓状态为已关闭的时候 失败");
                } else {
                    success++;
                }
            } else {
                int i = seYhdRefundMapper.updateRefundStatus(pYhdRefundDO);
                if (i == 0) {
                    fail++;
                    log.error("同步退款单失败", refund.getRefundId() + "修改退款单平台状态  失败");
                } else {
                    success++;
                }
            }
        }
        map.put("success", success);
        map.put("fail", fail);
        resp.setData(map);
        return resp;
    }
    
    
}