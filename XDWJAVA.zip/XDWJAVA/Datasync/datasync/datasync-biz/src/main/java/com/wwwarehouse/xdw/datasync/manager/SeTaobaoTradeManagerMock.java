package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.mybatis.BaseServiceMock;
import com.wwwarehouse.xdw.datasync.dao.mapper.SeTaobaoTradeDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDO;
import com.wwwarehouse.xdw.datasync.dao.model.SeTaobaoTradeDOExample;

/**
* SeTaobaoTradeService
*  on 2017/6/14.
*/
public class SeTaobaoTradeManagerMock extends BaseServiceMock<SeTaobaoTradeDOMapper, SeTaobaoTradeDO, SeTaobaoTradeDOExample> implements SeTaobaoTradeManager {

}
