package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;

/**
 * Created by jianjun.guan on 2017/6/14 0014.
 */
public interface SeTradeDownManager {
    public AbsResponse<String> downTrades(AmAppSubscriptionDTO amAppSubscription, boolean isRedown);

    public AbsResponse<String> downHistoryTrades(AmAppSubscriptionDTO amAppSubscription);
}
