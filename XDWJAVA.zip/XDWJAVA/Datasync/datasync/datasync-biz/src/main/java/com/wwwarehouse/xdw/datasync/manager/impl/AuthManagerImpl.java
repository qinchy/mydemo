package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.constant.Constants;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAuthRecordDOMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAuthRecordDO;
import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.manager.AmAppSubscriptionManager;
import com.wwwarehouse.xdw.datasync.manager.AuthManager;
import com.wwwarehouse.xdw.datasync.manager.SyParamManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Created by jianjun.guan on 2017/6/16 0016.
 */
@Service
public class AuthManagerImpl implements AuthManager {

    @Resource
    AmAppKeyManager amAppKeyManager;
    @Resource
    AmAppSubscriptionManager amAppSubscriptionManager;
    @Resource
    AmAuthRecordDOMapper amAuthRecordDOMapper;
    @Resource
    SyParamManager syParamManager;


    @Override
    public AbsResponse<String> getAuthUrl(Long platformId, String state) {
        AbsResponse<String> ret = new AbsResponse<>();
        BaPlatform baPlatform = BaPlatform.getPlatform(platformId);
        if(baPlatform == null){
            return ret.setResult(60500111, "不合法的平台！");
        }

        AmAppkeyDTO amAppKey = amAppKeyManager.getByType(platformId, Constants.WCKJ.longValue(), "EC");

        if(amAppKey == null){
            return ret.setResult(60500111, "不支持授权！！");
        }

        IAuthApi api = ApiUtil.getAuthApi(amAppKey);
        if(api == null){
            return ret.setResult(60500111, "不支持授权！！");
        }

        return api.buildAuthUrl(state);
    }

    @Override
    public AbsResponse<AmAppSubscriptionDTO> saveAuth(Long shopId, Long platformId, AmAuthRecordDTO authRecord, Long userId) throws Exception {
        AbsResponse<AmAppSubscriptionDTO> ret = new AbsResponse<>();

        authRecord.setAuthRecordUkid(UKID.getUKID());
        authRecord.setRelatedId(shopId);
        authRecord.setCreateUserId(userId);
        authRecord.setIsLastAuth(1L);
        AmAuthRecordDO amAuthRecordDO = new AmAuthRecordDO();
        BeanUtils.copyProperties(authRecord, amAuthRecordDO);

        amAuthRecordDOMapper.insert(amAuthRecordDO);

        List<AmAppSubscriptionDTO> list = amAppSubscriptionManager.getsByAppUkid(authRecord.getAppUkid(), shopId, 1L);
        AmAppSubscriptionDTO subscription = convertSubscription(authRecord);
        subscription.setLastAuthTime(new Date());//该值不保存数据，由sql中的sysdate保存
        if(list.size() > 0){
            subscription.setSubscriptionUkid(list.get(0).getSubscriptionUkid());
            subscription.setSubscriptionBuId(shopId);
            amAppSubscriptionManager.updateSubscription(subscription);
        }else{
            subscription.setSubscriptionUkid(UKID.getUKID());
            subscription.setSubscriptionBuId(shopId);
            subscription.setStatus(0L);
            amAppSubscriptionManager.insertSubscription(subscription);
        }

        ret.setData(subscription);
        return ret;
    }

    @Override
    public AbsResponse<AmAppSubscriptionDTO> refreshAuth(AmAppSubscriptionDTO amAppSubscription, Long userId) throws Exception {
        AbsResponse<AmAppSubscriptionDTO> refreshResult = new AbsResponse<>();
//		try{
        Long shopId = amAppSubscription.getSubscriptionBuId();
        Long platformId = amAppSubscription.getApp().getPlatformId();
        IAuthApi api = ApiUtil.getAuthApi(amAppSubscription.getApp());

        AbsResponse<AmAuthRecordDTO> res = api.refreshAuth(amAppSubscription.getRefreshToken());
        if (res.getCode() != 0) {
            return refreshResult.setResult(res.getCode(), res.getMsg());
        }

        AmAuthRecordDTO authRecord = res.getData();
        authRecord.setAppUkid(amAppSubscription.getAppUkid());
        return saveAuth(shopId, platformId, authRecord, userId);
//		} finally {
//			if (api != null){
//				mongoDao.dumpRecords(api.getAccessLogList());
//			}
//		}
    }

    @Override
    public AbsResponse<AmAuthRecordDTO> grantAuth(AmAppkeyDTO amAppKey, String code) {
        AbsResponse<AmAuthRecordDTO> abs = new AbsResponse<>();
        IAuthApi api = ApiUtil.getAuthApi(amAppKey);
        if (api == null) {
            return abs.setResult(905001,"该平台授权信息不完整");
        }
        return api.grantAuth(code);
    }

//    @Override
//    public AbsResponse<String> tradeDownPermit(Long shopId, Long platformId, String sellerNick, Long userId) throws Exception {
//        AbsResponse<String> abs = new AbsResponse<>();
//
//        HashMap<String, Object> paramMap = new HashMap<>();
//        paramMap.put("subscription_bu_id", shopId);
//        paramMap.put("status", 1L);
//        paramMap.put("platform_user_nick", sellerNick);
//        List<AmAppSubscriptionDTO> appSubList = amAppSubscriptionManager.getsByMap(paramMap);
//        if(appSubList == null || appSubList.size() < 1){
//            return abs.setResult(503, "没有找到授权信息");
//        }
//
//        StringBuilder opResult = new StringBuilder();
//
//        //增加开关，设置需要下载订单
//        syParamManager.updateOrInsert(shopId, SyParam.L_NEED_DOWN_TRADE, "1");
//        syParamManager.updateOrInsert(shopId, SyParam.L_NEED_DOWN_TRADE_HIS, "1");
//        opResult.append("开通下载订单成功;");
//
//        syParamManager.updateOrInsert(shopId, SyParam.L_NEED_DOWN_PRODUCT, "1");
//        String hisTimeRange = String.valueOf(getHisProductTImeRange());
//        syParamManager.updateOrInsert(shopId, SyParam.L_PRODUCT_TIME_RANGE, hisTimeRange);
//        opResult.append("开通下载商品成功，历史" + hisTimeRange + "天内;");
//
//        if (BaPlatform.TAOBAO.equalsById(platformId) || BaPlatform.TMALL.equalsById(platformId)) {
//            AmAppSubscriptionDTO appSubscription = appSubList.get(0);
//            AmAppkeyDTO amAppKey = amAppKeyManager.get(appSubscription.getAppUkid());
//            appSubscription.setApp(amAppKey);
//            TaobaoApi api = new TaobaoApi(appSubscription);
//
//            //开通消息推送
//            AbsResponse<String> tmcPermitAbs = api.tmcUserPermit(null);
//            if(!tmcPermitAbs.isSuccess()){
//                opResult.append("开通淘宝消息推送失败：").append(tmcPermitAbs.getMsg()).append(";");
//                abs.setResult(tmcPermitAbs);
//            } else {
//                opResult.append("开通淘宝消息推送成功;");
//
//                HashMap<String, Object> paramMap1 = new HashMap<>();
//                paramMap1.put("app_ukid", amAppKey.getAppUkid());
//                paramMap1.put("platform_user_nick", sellerNick);
//                List<AmPlatformMsgGroup> msgGroupList = amPlatformMsgGroupService.getMsgGroups(amAppKey.getAppUkid());
//                if (msgGroupList.isEmpty()) {
//                    opResult.append("未设置分组，使用默认分组:default;");
//                    abs.setResult(3, "未设置分组，使用默认分组:default");
//                } else {
//                    //添加至分组
//                    String groupName = msgGroupList.get(0).getGroupName();
//                    AbsResponse<String> addT = api.addTmcGroup(groupName, sellerNick, null);
//                    if (!addT.isSuccess()) {
//                        opResult.append("设置分组失败：").append(addT.getMsg());
//                        abs.setResult(addT);
//                    } else {
//                        opResult.append("设置分组：").append(groupName);
//                    }
//                }
//            }
//        }
//
//        ruOperationLogMqService.addBusinessLog(shopId,
//                "BA", "开通订单下载", userId, opResult.toString());
//
//        return abs;
//    }

    private AmAppSubscriptionDTO convertSubscription(AmAuthRecordDTO authRecord){
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
        subscription.setAppUkid(authRecord.getAppUkid());

        subscription.setAccessToken(authRecord.getAccessToken());
        subscription.setRefreshToken(authRecord.getRefreshToken());
        subscription.setPlatformUserId(authRecord.getPlatformUserId());
        subscription.setPlatformUserNick(authRecord.getPlatformUserNick());
        subscription.setExpiresIn(authRecord.getExpiresIn());
        subscription.setReExpiresIn(authRecord.getReExpiresIn());
        subscription.setR1ExpiresIn(authRecord.getR1ExpiresIn());
        subscription.setR2ExpiresIn(authRecord.getR2ExpiresIn());
        subscription.setW1ExpiresIn(authRecord.getW1ExpiresIn());
        subscription.setW2ExpiresIn(authRecord.getW2ExpiresIn());

        return subscription;
    }
}
