package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseServiceImpl;
import com.wwwarehouse.xdw.datasync.dao.mapper.AmAppkeyMapper;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyDO;
import com.wwwarehouse.xdw.datasync.dao.model.AmAppkeyExample;
import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * AmAppkeyService
 * on 2017/6/13.
 */
@Service
@Transactional
public class AmAppKeyManagerImpl extends BaseServiceImpl<AmAppkeyMapper, AmAppkeyDO, AmAppkeyExample> implements AmAppKeyManager {

    private static Logger _log = LoggerFactory.getLogger(AmAppKeyManagerImpl.class);

    @Autowired
    AmAppkeyMapper amAppkeyMapper;

    @Override
    public AmAppkeyMapper getMapper() {
        return amAppkeyMapper;
    }

    @Override
    public AmAppkeyDTO getByAppkey(Long platformId, String appKey, String appType) {
        String redisKey = "AmAppkey";
        String recordKey = platformId + "_" + appKey + "_" + appType;
        //AmAppkey amAppkey = redisHelper.hget(redisKey, recordKey, AmAppkey.class);
        AmAppkeyDTO amAppkey = null;
        if (amAppkey == null) {
            List<AmAppkeyDTO> list = getsByType(platformId, null, appKey, appType, 1L);
            if (!list.isEmpty()) {
                amAppkey = list.get(0);
                //redisHelper.hset(redisKey, recordKey, amAppkey);
            }
        }
        return amAppkey;
    }

    @Override
    public AmAppkeyDTO getByType(Long platformId, Long ownerBuId, String appType) {
        List<AmAppkeyDTO> list = getsByType(platformId, ownerBuId, null, appType, 1L);
        return list.size() > 0 ? list.get(0) : null;
    }

    @Override
    public AmAppkeyDTO get(Long appUkid) {
        AmAppkeyDO amAppkeyDO = amAppkeyMapper.selectByPrimaryKey(appUkid);
        AmAppkeyDTO amAppkey = new AmAppkeyDTO();
        BeanUtils.copyProperties(amAppkeyDO, amAppkey);
        return amAppkey;
    }

    @Override
    public List<AmAppkeyDTO> getsByType(Long platformId, Long ownerBuId, String appKey,
                                        String appkeyType, Long status) {
        AmAppkeyExample example = new AmAppkeyExample();
        AmAppkeyExample.Criteria criteria = example.createCriteria();
        if (platformId != null) {
            criteria.andPlatformIdEqualTo(platformId);
        }
        if (appKey != null) {
            criteria.andAppKeyEqualTo(appKey);
        }
        if (status != null) {
            criteria.andStatusEqualTo(status);
        }
        if (ownerBuId != null) {
            criteria.andOwnerBuIdEqualTo(ownerBuId);
        }
        if (appkeyType != null) {
            criteria.andAppTypeEqualTo(appkeyType);
        }
        List<AmAppkeyDO> amAppkeyDOList = amAppkeyMapper.selectByExample(example);
        List<AmAppkeyDTO> amAppkeyList = new ArrayList<>();
        for (AmAppkeyDO amAppkeyDO : amAppkeyDOList) {
            AmAppkeyDTO amAppkeyDTO = new AmAppkeyDTO();
            BeanUtils.copyProperties(amAppkeyDO, amAppkeyDTO);
            amAppkeyList.add(amAppkeyDTO);
        }
        return amAppkeyList;
    }

    @Override
    public List<AmAppkeyDTO> getsUsableKeys(String appType) {
        return getsByType(null, null, null, appType, 1L);
    }
}