package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.PayNotifyRecordManager;
import com.wwwarehouse.xdw.datasync.manager.UnionPayManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.PayNotifyRecordDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import com.wwwarehouse.xdw.datasync.outer.api.util.unionpaySdk.SDKConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chengwei on 2017/6/12 15:01.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring-config-test.xml"})
public class UnionPayManagerImplTest {
	@Resource
	private UnionPayManager unionPayManager;
	@Resource
	private PayNotifyRecordManager payNotifyRecordManager;

	@Test
	public void launchCommonPay() throws Exception {
		AmAppSubscriptionDTO amAppSubscriptionDTO = new AmAppSubscriptionDTO();
		amAppSubscriptionDTO.setPlatformId(1330L);
		amAppSubscriptionDTO.setPlatformUserId("310420147890001");
		PayParamsDTO payParamsDTO = new PayParamsDTO();
		payParamsDTO.setTradeNo("10001010");
		payParamsDTO.setAmount(1.01);
		AbsResponse<Object> abs = unionPayManager.launchCommonPay(amAppSubscriptionDTO, payParamsDTO);
		System.out.println(abs.getData());
		Map map = JsonUtils.toObject(abs.getData().toString(), HashMap.class);
		System.out.println("------ tn ----" + map.get("tn"));
	}

	@Test
	public void unionAnalyzeData() throws Exception {
		SDKConfig.getConfig().loadPropertiesFromSrc();
		String str = "accNo=CetQZAbgWEiFiBJOacpZzvFzNOyVe9JUuDKBfGhBmcrfAItB4Y9OgTIA0tL8pM9OgT5cBWHX47T1zZuzbx7KOmhrtKu2XEYQyhfcOu65Ez94vbkaxkTOwzEptYQ7741wHOyaQnNQbcAjFlYeEMEdSQx6y1wqv+VbWl1k4qEJiCc=&accessType=0&bizType=000201&certId=68759585097&currencyCode=156&encoding=UTF-8&merId=777290058138017&orderId=51753100000059004&queryId=201610191140221986738&respCode=00&respMsg=Success!&settleAmt=2&settleCurrencyCode=156&settleDate=1019&signMethod=01&traceNo=198673&traceTime=1019114022&txnAmt=2&txnSubType=01&txnTime=20161019114022&txnType=01&version=5.0.0";
		String result = unionPayManager.unionAnalyzeData(str);
		Assert.assertNotNull(result);
		System.out.println("------ result ----:" + result);
	}

	@Test
	public void add(){
		PayNotifyRecordDTO dto = new PayNotifyRecordDTO();
		dto.setPayRecordUkid(UKID.getUKID());
		dto.setOutTradeNo("1234");
		dto.setResultCode("00");
		payNotifyRecordManager.add(dto);
	}

}