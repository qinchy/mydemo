package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.xdw.datasync.manager.SaSmsManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by yinsheng.wang on 2017/6/14.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring-config-test.xml"})
public class SaSmsManagerImplTest {
    @Resource
    private SaSmsManager saSmsManager;

    @Test
    public void sendSms() throws Exception {
       /* String mobile = "18658854915";
        //浩丝模板格式：【网仓科技】验证码:852852
        //云片格式：【网仓科技】您的验证码是:888888
        String smsContent = "【网仓科技】验证码:852852，仅用于注册，请勿告知他人。工作人员不会向您索取。";
        String smsResult  = saSmsManager.sendSms(mobile, smsContent,null);
        System.out.println(smsResult);*/
    }
}
