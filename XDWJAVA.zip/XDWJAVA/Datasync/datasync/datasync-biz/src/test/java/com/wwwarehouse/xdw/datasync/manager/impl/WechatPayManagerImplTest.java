package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.WechatPayManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.PayParamsDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by xiuli.yang on 2017/6/14.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-config-test.xml"})
public class WechatPayManagerImplTest {
    @Resource
    private WechatPayManager wechatPayManager;

    @Test
    public void testLaunchWechatPay() throws Exception {
        AmAppSubscriptionDTO amAppSubscriptionDTO = new AmAppSubscriptionDTO();
        amAppSubscriptionDTO.setPlatformId(1320L);
        amAppSubscriptionDTO.setPlatformUserId("1401609202");

        AmAppkeyDTO amAppkey = new AmAppkeyDTO();
        amAppkey.setAppKey("wxb716f229c6313a0e"); //appId
        amAppkey.setAppSecret("Zjwckj20161021Wckj20161021201621"); //key
        amAppkey.setCharset("UTF-8");
        amAppkey.setAppType("PAY");

        amAppSubscriptionDTO.setApp(amAppkey);

        PayParamsDTO payParamsDTO = new PayParamsDTO();
        payParamsDTO.setTradeNo("201706140001");
        payParamsDTO.setAmount(1.01);
        payParamsDTO.setIsP2C(false);
        payParamsDTO.setClientIp("192.168.200.123");
        payParamsDTO.setTitle("app");

//        payParamsDTO.setIsP2C(true);
        payParamsDTO.setRegAppType("QY");
        payParamsDTO.setOpenId("o08F4w2Diie88ZOmabcbZIf-VEnk");

        AbsResponse<Object> abs = wechatPayManager.launchWechatPay(amAppSubscriptionDTO, payParamsDTO);
        System.out.println(abs.getData());
    }
}
