package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.BaseTest;
import com.wwwarehouse.xdw.datasync.manager.BaAreaManager;
import com.wwwarehouse.xdw.datasync.model.BaAreaDTO;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by jingchun.zhang on 2017/6/16.
 */
public class BaAreaManagerImplTest extends BaseTest{

    @Resource
    private BaAreaManager baAreaManager;

    @Test
    public void listAllBaAreasTest() throws Exception {
        List<BaAreaDTO> list = baAreaManager.listAllBaAreas();
        System.out.println(list);
    }

    @Test
    public void getBaAreaObjectTest() throws Exception {
        AbsResponse<BaAreaDTO> list = baAreaManager.getBaArea("110100",null);
        System.out.println(list);
    }

}
