package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.WeChatAuthManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.AmAuthRecordDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by dan.han on 2017/6/13.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class WeChatAuthManagerImplTest {
    @Resource
    private WeChatAuthManager weChatAuthManager;


    @Test
    public void grantAuth() throws Exception {
        AmAppkeyDTO amAppkey = new AmAppkeyDTO();
        amAppkey.setAppKey("wxfbf6e942942b21cc");
        amAppkey.setAppSecret("3cb8f76cd8d2f040aa2e7e07df983d4b");
        amAppkey.setPlatformId(27L);
        AbsResponse<AmAuthRecordDTO> authResult = weChatAuthManager.grantAuth("13464567fsdf", amAppkey);
    }

}
