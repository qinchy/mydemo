package com.wwwarehouse.xdw.datasync.api;

import com.wwwarehouse.commons.json.JsonUtils;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.TaobaoApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IShopApi;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by jianjun.guan on 2017/6/9 0009.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class TaobaoShopApiTest {
    private IShopApi api;

    @Before
    public void init(){
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
        subscription.setPlatformUserNick("浙江网仓科技有限公司");
        subscription.setAccessToken("62011078dcd4e52ZZeachjcbe5e0a42b64bdaead031f7f8802713339");
        subscription.setRefreshToken("620210741c9c131ZZba1eg4a85b4d28da1617fdc0f28b26802713339");
        subscription.setPlatformId(10L);
        subscription.setPlatformUserId("802713339");
        subscription.setSubscriptionBuId(1490975173L);

        AmAppkeyDTO appkey = new AmAppkeyDTO();
        appkey.setApiUrl("http://gw.api.taobao.com/router/rest");
        appkey.setAppKey("21353585");
        appkey.setAppName("淘宝");
        appkey.setAppSecret("6b2969a6423b35c06be59c07ea3c1e0e");
        appkey.setAppType("EC");
        appkey.setDataFormat("JSON");
        appkey.setCharset("UTF-8");
        appkey.setSignMethod("MD5");
        appkey.setDataEncrypt(0L);
        appkey.setAuthType("OAUTH2");
        subscription.setApp(appkey);
        api = new TaobaoApi(subscription);
    }

    /**
     *  获取店铺信息
     */
    @Test
    public void getShopTest(){
        try {
            AbsResponse abs = api.getShop("浙江网仓科技有限公司");
            System.out.println(abs.getCode());
            System.out.println(abs.getMsg());
            System.out.println(JsonUtils.toJson(abs.getData()));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
