package com.wwwarehouse.xdw.datasync.api;

import com.wwwarehouse.commons.spring.SpringContextUtil;
import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.manager.SeBaseTradeManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.model.SeBaseItem;
import com.wwwarehouse.xdw.datasync.model.SeBaseTrade;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;

/**
 * Created by jianjun.guan on 2017/6/9 0009.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class TaobaoTradeApiTest {
    private ITradeApi api;
    private AmAppSubscriptionDTO subscription;
    private SeBaseTradeManager<? extends SeBaseTrade<? extends SeBaseItem>, ? extends SeBaseItem> seBaseTradeManager;

    @Before
    public void init(){
        subscription = new AmAppSubscriptionDTO();
        subscription.setPlatformUserNick("浙江网仓科技有限公司");
        subscription.setAccessToken("62011078dcd4e52ZZeachjcbe5e0a42b64bdaead031f7f8802713339");
        subscription.setRefreshToken("620210741c9c131ZZba1eg4a85b4d28da1617fdc0f28b26802713339");
        subscription.setPlatformId(10L);
        subscription.setPlatformUserId("802713339");
        subscription.setSubscriptionBuId(1490975173L);

        AmAppkeyDTO appkey = new AmAppkeyDTO();
        appkey.setApiUrl("http://gw.api.taobao.com/router/rest");
        appkey.setAppKey("21353585");
        appkey.setAppName("淘宝");
        appkey.setAppSecret("6b2969a6423b35c06be59c07ea3c1e0e");
        appkey.setAppType("EC");
        appkey.setDataFormat("JSON");
        appkey.setCharset("UTF-8");
        appkey.setSignMethod("MD5");
        appkey.setDataEncrypt(0L);
        appkey.setAuthType("OAUTH2");
        subscription.setApp(appkey);
        api = ApiUtil.getTradeApi(subscription);
        String serviceName = ApiUtil.getTradeService(10L);
        seBaseTradeManager = (SeBaseTradeManager<? extends SeBaseTrade<? extends SeBaseItem>, ? extends SeBaseItem>)
                SpringContextUtil.getBean(serviceName);
    }

    /**
     * 查询订单
     */
    @Test
    public void catchOneTradeTest(){
        AbsResponse abs = api.catchOneTrade("4145454545");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     * 每次查询一页数据 查询订单
     */
    @Test
    public void catchTradesTest(){
        AbsResponse abs = api.catchTrades(new Date(),new Date(),"ALL_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     * 增量每次查询一页数据 查询订单
     */
    @Test
    public void catchTradesPerPageTest(){
        AbsResponse abs = api.catchTradesPerPage(new Date(),new Date(),"ALL_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     * 抓取平台订单数量
     */
    @Test
    public void catchTradesIncPerPageTest(){
        AbsResponse abs = api.catchTradesIncPerPage(new Date(),new Date(),"ALL_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     * 查询订单
     */
    @Test
    public void catchTradeCountTest(){
        int count = api.catchTradeCount(new Date(),new Date(),"ALL_WAIT_PAY");
        System.out.println(count);
    }

    /**
     *  线上发货通知
     */
    @Test
    public void shipNoticeTest(){
        AbsResponse abs = api.shipNotice("441545","54545549874","sfas","444444454",44.5D,false,"45454454");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     *  为已授权的用户开通消息服务
     */
    @Test
    public void tmcUserPermitTest(){
        AbsResponse abs = api.tmcUserPermit("dev1");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     *  取消用户的消息服务
     */
    @Test
    public void tmcUserCancelTest(){
        AbsResponse abs = api.tmcUserCancel("浙江网仓科技有限公司", "WCKJ");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     *  下载并保存订单
     */
    @Test
    public void downTradeTest(){
        AbsResponse abs = null;
        try {
            abs = seBaseTradeManager.downTrade(subscription,"6183870081629160");
            System.out.println(abs.getCode());
            System.out.println(abs.getMsg());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
