package com.wwwarehouse.xdw.datasync.api.yhd;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.TaobaoApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRefundApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;

/**
 * Created by jianjun.guan on 2017/6/9 0009.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class YhdRefundApiTest {
    private IRefundApi api;

    @Before
    public void init(){
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
//        subscription.setPlatformUserNick("杭州界内电子商务有限公司");
        subscription.setAccessToken("84d44a57a0a276390303aa3d764640e3");//bae42230dc62b6718300ed1efc9456cd   84d44a57a0a276390303aa3d764640e3
//        subscription.setRefreshToken("620210741c9c131ZZba1eg4a85b4d28da1617fdc0f28b26802713339");

        AmAppkeyDTO appkey = new AmAppkeyDTO();
        appkey.setApiUrl("http://openapi.yhd.com/app/api/rest/router");
        appkey.setAppKey("10210014122900002799  ");
        appkey.setAppName("一号店");
        appkey.setAppSecret("69866822497fa496c92e9ab45816edc0");
        appkey.setAppType("EC");
        appkey.setDataFormat("JSON");
        appkey.setCharset("UTF-8");
        appkey.setSignMethod("MD5");
        appkey.setDataEncrypt(0L);
        appkey.setAuthType("OAUTH2");
        subscription.setAppUkid(1L);
        subscription.setSubscriptionBuId(10L);
        subscription.setPlatformId(BaPlatform.YHD.getId());
        subscription.setApp(appkey);
        api = ApiUtil.getRefundApi(subscription);
    }

    /**
     *  按单号查询退款单
     */
    @Test
    public void getRefundTest(){
        AbsResponse abs = api.getRefund("12565545");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

       /**
     * 查询退款单
     */
    @Test
    public void fetchRefundsTest(){

        AbsResponse abs = api.fetchRefunds(new Date(), new Date(), "WAIT_SELLER_AGREE");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     * 查询退款单
     */
    @Test
    public void updateRefundStatusTest(){

    }

}
