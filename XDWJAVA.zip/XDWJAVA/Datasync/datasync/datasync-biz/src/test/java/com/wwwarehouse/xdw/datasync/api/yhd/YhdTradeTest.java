package com.wwwarehouse.xdw.datasync.api.yhd;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;

/**
 * Created by shisheng.wang on 17/6/7.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class YhdTradeTest extends AbstractTransactionalJUnit4SpringContextTests {

    private String sessionKey = null;
    private String appKey = "10210014122900002799";
    private String appSecret = "69866822497fa496c92e9ab45816edc0";
    private AmAppSubscriptionDTO subscription;
    private ITradeApi api;

    /**
     * ke:10210014122900002799
     secret:69866822497fa496c92e9ab45816edc0
     session_key:84d44a57a0a276390303aa3d764640e3
     */
    @Before
    public void init(){
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
//        subscription.setPlatformUserNick("杭州界内电子商务有限公司");
        subscription.setAccessToken("84d44a57a0a276390303aa3d764640e3");//bae42230dc62b6718300ed1efc9456cd   84d44a57a0a276390303aa3d764640e3
//        subscription.setRefreshToken("620210741c9c131ZZba1eg4a85b4d28da1617fdc0f28b26802713339");

        AmAppkeyDTO appkey = new AmAppkeyDTO();
        appkey.setApiUrl("http://openapi.yhd.com/app/api/rest/router");
        appkey.setAppKey("10210014122900002799  ");
        appkey.setAppName("一号店");
        appkey.setAppSecret("69866822497fa496c92e9ab45816edc0");
        appkey.setAppType("EC");
        appkey.setDataFormat("JSON");
        appkey.setCharset("UTF-8");
        appkey.setSignMethod("MD5");
        appkey.setDataEncrypt(0L);
        appkey.setAuthType("OAUTH2");
        subscription.setAppUkid(1L);
        subscription.setSubscriptionBuId(10L);
        subscription.setPlatformId(BaPlatform.YHD.getId());
        subscription.setApp(appkey);
        api = ApiUtil.getTradeApi(subscription);
    }

    /**
     * 查询订单
     */
    @Test
    public void catchOneTradeTest(){
        AbsResponse abs = api.catchOneTrade("13167346127176");//13167346127176   4145454545
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     * 每次查询一页数据 查询订单
     */
    @Test
    public void catchTradesTest(){
        Date startDate = DateUtil.parseDay("2017-6-10");
        Date endDate = DateUtil.parseDay("2017-6-12");

        AbsResponse abs =api.catchTrades(startDate, endDate,"ORDER_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     * 增量每次查询一页数据 查询订单
     */
    @Test
    public void catchTradesPerPageTest(){
        AbsResponse abs = api.catchTradesPerPage(new Date(),new Date(),"ALL_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     * 抓取平台订单数量
     */
    @Test
    public void catchTradesIncPerPageTest(){
        AbsResponse abs = api.catchTradesIncPerPage(new Date(),new Date(),"ALL_WAIT_PAY",false);
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }
    /**
     * 查询订单
     */
    @Test
    public void catchTradeCountTest(){
        int count = api.catchTradeCount(new Date(),new Date(),"ALL_WAIT_PAY");
        System.out.println(count);
    }

    /**
     *  线上发货通知
     */
    @Test
    public void shipNoticeTest(){
        AbsResponse abs = api.shipNotice("441545","54545549874","sfas","444444454",44.5D,false,"45454454");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     *  为已授权的用户开通消息服务
     */
    @Test
    public void tmcUserPermitTest(){
        AbsResponse abs = api.tmcUserPermit("dev1");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

    /**
     *  为已授权的用户开通消息服务
     */
    @Test
    public void tmcUserCancelTest(){
        AbsResponse abs = api.tmcUserCancel("浙江网仓科技有限公司", "WCKJ");
        System.out.println(abs.getCode());
        System.out.println(abs.getMsg());
    }

//    /**
//     *  查询退货单号
//     */
//    @Test
//    public void orderCancelTest(){
//        AbsResponse abs = api.getRefund("15616156146516");
//        System.out.println(abs.getCode());
//        System.out.println(abs.getMsg());
//    }

}