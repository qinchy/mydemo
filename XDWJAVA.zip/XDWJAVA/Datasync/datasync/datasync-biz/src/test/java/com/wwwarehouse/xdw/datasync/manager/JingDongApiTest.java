
package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.commons.utils.AbsResponse;
import com.wwwarehouse.commons.utils.DateUtil;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import com.wwwarehouse.xdw.datasync.outer.api.ebusiness.JingdongApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ApiUtil;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IAuthApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.IRefundApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.ITradeApi;
import com.wwwarehouse.xdw.datasync.outer.api.interfaces.enums.BaPlatform;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.Date;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class JingDongApiTest extends AbstractTransactionalJUnit4SpringContextTests {

    ITradeApi tradeApi = null;
    IAuthApi authApi = null;
    IRefundApi refundApi = null;

    @Before
    public void getApi(){
        AmAppkeyDTO app = new AmAppkeyDTO();
        app.setApiUrl("https://api.jd.com/routerjson");
        app.setAppKey("F5FA8C15F2EAE053A65C9541641A43DC");
        app.setAppSecret("b06568639e2046778fb9cbfacbbb1184");
        app.setAppUkid(1L);
        app.setPlatformId(BaPlatform.JINGDONG.getId());
        AmAppSubscriptionDTO subscription = new AmAppSubscriptionDTO();
        subscription.setAppUkid(1L);
        subscription.setAccessToken("f83c68d6-99c3-4c6e-8684-7a2404f12b90");
        subscription.setApp(app);
        subscription.setPlatformId(BaPlatform.JINGDONG.getId());
        subscription.setSubscriptionBuId(1L);

        this.tradeApi = ApiUtil.getTradeApi(subscription);
        this.authApi = ApiUtil.getAuthApi(app);
        this.refundApi = ApiUtil.getRefundApi(subscription);
    }

    @Test
    public void grantAuth(){
        AbsResponse abs = authApi.grantAuth(""); //authCode
        System.out.print(abs.getData());
    }

    @Test
    public void refreshAuth(){
        AbsResponse abs = authApi.refreshAuth(""); //refreshToken
        System.out.print(abs.getData());
    }

    @Test
    public void getRefund(){
        AbsResponse abs = refundApi.getRefund("684038263");//退款单号
        System.out.print(abs.getData());
    }

    @Test
    public void catchOneTrade(){
        AbsResponse abs = tradeApi.catchOneTrade("684038263");//单号
        System.out.print(abs.getData());
    }

    @Test
    public void catchTradesPerPage(){
        Date endTime = new Date();
        Date startTime = DateUtil.addHours(endTime, -2);
        AbsResponse abs = tradeApi.catchTradesPerPage(startTime, endTime, "WAIT_SELLER_STOCK_OUT", true);
        System.out.print(abs.getData());
    }

    @Test
    public void catchTradesIncPerPage(){
        Date endTime = new Date();
        Date startTime = DateUtil.addHours(endTime, -2);
        AbsResponse abs = tradeApi.catchTradesIncPerPage(startTime, endTime, "WAIT_SELLER_STOCK_OUT", true);
        System.out.print(abs.getData());
    }
}