package com.wwwarehouse.xdw.datasync.service;

import com.wwwarehouse.commons.ukid.DOCN;
import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.commons.ukid.service.SyNextNumberService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by shisheng.wang on 17/6/7.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class SyNextNumberServiceTest {
    @Resource
    private SyNextNumberService syNextNumberService;

    @Test
    public void getUKID() {
        Long ukid = UKID.getUKID();
        Assert.assertNotNull(ukid);
        System.out.println("===ukid = " + ukid);
    }

    @Test
    public void buId() {
        Long buId = DOCN.getBuId();
        Assert.assertNotNull(buId);
        System.out.println("===buId = " + buId);
    }

    @Test
    public void getNextNumber() {
        String nextNumber = syNextNumberService.getNextNumber("XU0");
        Assert.assertNotNull(nextNumber);
        System.out.println("===nextNumber = " + nextNumber);
    }
}