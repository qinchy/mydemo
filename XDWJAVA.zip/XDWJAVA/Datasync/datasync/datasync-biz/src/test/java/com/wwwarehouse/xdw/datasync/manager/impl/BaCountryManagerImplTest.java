package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.xdw.datasync.BaseTest;
import com.wwwarehouse.xdw.datasync.dao.model.BaCountryDO;
import com.wwwarehouse.xdw.datasync.manager.BaCountryManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by jingchun.zhang on 2017/6/16.
 */
public class BaCountryManagerImplTest extends BaseTest{
    @Resource
    private BaCountryManager baCountryManager;

    @Test
    public void listAllBaCountryTest(){
        List<BaCountryDO> list = baCountryManager.listAllBaCountry();
        System.out.println(list);
    }
}
