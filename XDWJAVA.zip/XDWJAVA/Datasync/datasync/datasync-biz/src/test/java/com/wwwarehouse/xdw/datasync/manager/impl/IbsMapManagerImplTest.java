package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.xdw.datasync.manager.IbsMapManager;
import com.wwwarehouse.xdw.datasync.model.AmAppSubscriptionDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by huahui.wu on 2017/6/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring-config-test.xml"})
public class IbsMapManagerImplTest {

	@Resource
	private IbsMapManager ibsMapManager;

	@Test
	public void geoCodeGeo() throws Exception {
		AmAppSubscriptionDTO appSuber = new AmAppSubscriptionDTO();
		appSuber.setPlatformId(0L);
//		System.out.println(ibsMapManager.geoCodeGeo("安庆市", "杨湾镇",null, appSuber));
		System.out.println(ibsMapManager.geoCodeGeo(null, null,"120.382613,30.317101", appSuber));
	}

	@Test
	public void direction() throws Exception {
		AmAppSubscriptionDTO appSuber = new AmAppSubscriptionDTO();
		appSuber.setPlatformId(0L);
		System.out.println(ibsMapManager.direction("116.481028,39.989643", "120.382613,30.317101","0", "driving", appSuber));
	}

	@Test
	public void getLocation() throws Exception {
		AmAppSubscriptionDTO appSuber = new AmAppSubscriptionDTO();
		appSuber.setPlatformId(0L);
		System.out.println(ibsMapManager.getLocation("", "", appSuber));
	}

}