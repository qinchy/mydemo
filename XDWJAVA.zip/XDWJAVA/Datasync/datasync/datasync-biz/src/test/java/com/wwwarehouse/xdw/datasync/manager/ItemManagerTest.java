package com.wwwarehouse.xdw.datasync.manager;

import com.wwwarehouse.xdw.datasync.model.Item;
import com.wwwarehouse.xdw.datasync.service.ItemService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by shisheng.wang on 17/6/7.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class ItemManagerTest extends AbstractTransactionalJUnit4SpringContextTests {
    @Resource
    private ItemManager itemManager;

    @Test
    public void getTest(){
        Item item = itemManager.get(51885300000006948L);
        System.out.println(item);
    }
}