package com.wwwarehouse.xdw.datasync.manager.impl;

import com.wwwarehouse.xdw.datasync.manager.AmAppKeyManager;
import com.wwwarehouse.xdw.datasync.model.AmAppkeyDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by yinsheng.wang on 2017/6/14.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring-config-test.xml"})
public class AmAppKeyManagerImplTest {
    @Resource
    private AmAppKeyManager amAppKeyManager;

    @Test
    public void getsByType() {
        List<AmAppkeyDTO> amAppkeyDTOList = amAppKeyManager.getsByType(null, null, null, null, 1L);
        System.out.println(amAppkeyDTOList);
    }
}
