package com.wwwarehouse.xdw.contractcenter.web.controller;

import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import com.wwwarehouse.xdw.contractcenter.service.PbPlatformHisLogService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by chaoyong.qin on 2017/6/22.
 */
@RequestMapping("/pbPlatformHisLog")
@Controller
public class PbPlatformHisLogController {
    @Resource
    PbPlatformHisLogService service;

    @RequestMapping("/create")
    @ResponseBody
    public int create() {
        PbPlatformHisLog pbPlatformHisLog = new PbPlatformHisLog();

        pbPlatformHisLog.setPbShopRuleUkid(1L);
        pbPlatformHisLog.setOwnerUkid(2L);
        pbPlatformHisLog.setShopUkid(3L);
        pbPlatformHisLog.setPlatformUkid(4L);
        pbPlatformHisLog.setResourceUkid(5L);
        pbPlatformHisLog.setItemUkid(6L);
        pbPlatformHisLog.setOriginQty(7L);
        pbPlatformHisLog.setResourceQty(8L);

        return service.insertSelective(pbPlatformHisLog);
    }

    @RequestMapping("/selectByExample")
    @ResponseBody
    public List<PbPlatformHisLog> selectByExample() {
        Long pbShopRuleUkid = 1L;
        Long ownerUkid = 2L;
        Long shopUkid = 3L;
        Long platformUkid = 4L;
        Long resourceUkid = 5L;
        Long itemUkid = 6L;
        Long originQty = 7L;
        Long resourceQty = 8L;
        return service.selectByExample(pbShopRuleUkid, ownerUkid, shopUkid,
                platformUkid, resourceUkid, itemUkid,
                originQty, resourceQty);
    }
}
