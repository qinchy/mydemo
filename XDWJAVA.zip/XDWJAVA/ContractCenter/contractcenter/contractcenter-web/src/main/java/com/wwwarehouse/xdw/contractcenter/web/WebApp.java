package com.wwwarehouse.xdw.contractcenter.web;

/**
 * Created by shisheng.wang on 17/6/13.
 */
public class WebApp {
}
