package com.wwwarehouse.xdw.contractcenter.manager.mock;

import com.wwwarehouse.xdw.contractcenter.dao.mapper.ItemMapper;
import com.wwwarehouse.xdw.contractcenter.manager.ItemManager;
import com.wwwarehouse.xdw.contractcenter.model.Item;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * Created by shisheng.wang on 17/6/6.
 */
@Service
public class ItemManagerMock implements ItemManager {

    @Resource
    ItemMapper itemMapper;

    @Override
    public Item get(long itemId) {
        Item item = new Item();
        item.setItemId(itemId);
        item.setItemName("item" + itemId);
        return item;
    }

    @Transactional
    @Override
    public int add(Item item) {
        return 1;
    }
}
