package com.wwwarehouse.xdw.contractcenter.manager;

import com.wwwarehouse.xdw.contractcenter.model.Item;

/**
 * 业务具体实现.
 * 可能调用其他Manager
 * Created by shisheng.wang on 17/6/6.
 */
public interface ItemManager {
    Item get(long itemId);
    int add(Item item);
}
