package com.wwwarehouse.xdw.contractcenter.service.impl;

import com.wwwarehouse.xdw.contractcenter.manager.ItemManager;
import com.wwwarehouse.xdw.contractcenter.model.Item;
import com.wwwarehouse.xdw.contractcenter.service.ItemService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * rpc接口实现
 * 调用manager,一般比较简洁
 * Created by shisheng.wang on 17/6/6.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class ItemServiceImpl implements ItemService {

    @Resource
    ItemManager itemManager;

    @Override
    public Item get(long itemId) {
        return itemManager.get(itemId);
    }

    @Transactional
    @Override
    public int add(Item item) {
        return itemManager.add(item);
    }
}
