package com.wwwarehouse.xdw.contractcenter.manager;

import com.wwwarehouse.commons.mybatis.BaseManager;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDO;
import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDOExample;

import java.util.List;

/**
 * PbPlatformHisLogManager
 * on 2017/6/21.
 */
public interface PbPlatformHisLogManager extends BaseManager<PbPlatformHisLog, PbPlatformHisLogDOExample> {

    /**
     * 新增记录
     *
     * @param pbPlatformHisLog
     * @return
     */
    int insertSelective(PbPlatformHisLog pbPlatformHisLog);

    /**
     * 按主键查询
     *
     * @param pbPlatformHisLogUkid
     * @return
     */
    PbPlatformHisLog selectByPrimaryKey(Long pbPlatformHisLogUkid);

    /**
     * 按条件查询
     *
     * @param pbShopRuleUkid
     * @param ownerUkid
     * @param shopUkid
     * @param platformUkid
     * @param resourceUkid
     * @param itemUkid
     * @param originQty
     * @param resourceQty
     * @return
     */
    List<PbPlatformHisLog> selectByExample(Long pbShopRuleUkid, Long ownerUkid, Long shopUkid,
                                           Long platformUkid, Long resourceUkid, Long itemUkid,
                                           Long originQty, Long resourceQty);

}