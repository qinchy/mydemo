package com.wwwarehouse.xdw.contractcenter.service.impl;

import com.wwwarehouse.commons.ukid.UKID;
import com.wwwarehouse.xdw.contractcenter.manager.PbPlatformHisLogManager;
import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import com.wwwarehouse.xdw.contractcenter.service.PbPlatformHisLogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by chaoyong.qin on 2017/6/21.
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class PbPlatformHisLogServiceImpl implements PbPlatformHisLogService {

    @Resource
    PbPlatformHisLogManager pbPlatformHisLogManager;

    @Override
    public int insertSelective(PbPlatformHisLog pbPlatformHisLog) {
        pbPlatformHisLog.setPbPlatformHisLogUkid(UKID.getUKID());
        return pbPlatformHisLogManager.insertSelective(pbPlatformHisLog);
    }

    @Override
    public PbPlatformHisLog selectByPrimaryKey(Long pbPlatformHisLogUkid) {
        return pbPlatformHisLogManager.selectByPrimaryKey(pbPlatformHisLogUkid);
    }

    @Override
    public List<PbPlatformHisLog> selectByExample(Long pbShopRuleUkid, Long ownerUkid, Long shopUkid,
                                                  Long platformUkid, Long resourceUkid, Long itemUkid,
                                                  Long originQty, Long resourceQty) {
        return pbPlatformHisLogManager.selectByExample(pbShopRuleUkid, ownerUkid, shopUkid,
                platformUkid, resourceUkid, itemUkid, originQty, resourceQty);
    }
}
