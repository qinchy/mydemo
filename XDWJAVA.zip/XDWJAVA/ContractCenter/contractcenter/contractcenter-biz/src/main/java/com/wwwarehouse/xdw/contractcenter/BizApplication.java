package com.wwwarehouse.xdw.contractcenter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 服务启动类
 * Created by shisheng.wang on 17/6/6.
 */
public class BizApplication {
    private static Logger logger = LoggerFactory.getLogger(BizApplication.class);

    public static void main(String[] args) throws InterruptedException {
        logger.info(">>>>> xdw-contractcenter-biz 正在启动 <<<<<");
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:spring-config.xml");
        logger.info(">>>>> xdw-contractcenter-biz 启动完成 <<<<<");

        Thread.sleep(Long.MAX_VALUE);
    }
}
