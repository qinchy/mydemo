package com.wwwarehouse.xdw.contractcenter.manager.impl;

import com.wwwarehouse.commons.mybatis.BaseManagerImpl;
import com.wwwarehouse.xdw.contractcenter.dao.mapper.PbPlatformHisLogDOMapper;
import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDO;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDOExample;
import com.wwwarehouse.xdw.contractcenter.manager.PbPlatformHisLogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
* PbPlatformHisLogManagerImpl
*  on 2017/6/21.
*/
@Service
@Transactional
public class PbPlatformHisLogManagerImpl extends BaseManagerImpl<PbPlatformHisLogDOMapper, PbPlatformHisLog, PbPlatformHisLogDO, PbPlatformHisLogDOExample> implements PbPlatformHisLogManager {

    private static Logger _log = LoggerFactory.getLogger(PbPlatformHisLogManagerImpl.class);

    @Resource
    PbPlatformHisLogDOMapper pbPlatformHisLogDOMapper;

    @Override
    public PbPlatformHisLogDOMapper getMapper() {
        return pbPlatformHisLogDOMapper;
    }

    @Override
    public int insertSelective(PbPlatformHisLog pbPlatformHisLog) {
        PbPlatformHisLogDO pbPlatformHisLogDO = convertDO(pbPlatformHisLog);
        return pbPlatformHisLogDOMapper.insertSelective(pbPlatformHisLogDO);
    }

    @Override
    public PbPlatformHisLog selectByPrimaryKey(Long pbPlatformHisLogUkid) {
        PbPlatformHisLogDO pbPlatformHisLogDO = pbPlatformHisLogDOMapper.selectByPrimaryKey(pbPlatformHisLogUkid);
        return convertDTO(pbPlatformHisLogDO);
    }

    @Override
    public List<PbPlatformHisLog> selectByExample(Long pbShopRuleUkid, Long ownerUkid, Long shopUkid,
                                                  Long platformUkid, Long resourceUkid, Long itemUkid,
                                                  Long originQty, Long resourceQty) {
        PbPlatformHisLogDOExample pbPlatformHisLogDOExample = new PbPlatformHisLogDOExample();
        PbPlatformHisLogDOExample.Criteria criteria = pbPlatformHisLogDOExample.createCriteria();
        if (pbShopRuleUkid != null){
            criteria.andPbShopRuleUkidEqualTo(pbShopRuleUkid);
        }

        if (ownerUkid != null){
            criteria.andOwnerUkidEqualTo(ownerUkid);
        }

        if (shopUkid != null){
            criteria.andShopUkidEqualTo(shopUkid);
        }

        if (platformUkid != null){
            criteria.andPlatformUkidEqualTo(platformUkid);
        }

        if (resourceUkid != null){
            criteria.andResourceUkidEqualTo(resourceUkid);
        }

        if (itemUkid != null){
            criteria.andItemUkidEqualTo(itemUkid);
        }

        if (originQty != null){
            criteria.andOriginQtyEqualTo(originQty);
        }

        if (resourceQty != null){
            criteria.andResourceQtyEqualTo(resourceQty);
        }

        List<PbPlatformHisLogDO> pbPlatformHisLogDOs = pbPlatformHisLogDOMapper.selectByExample(pbPlatformHisLogDOExample);
        return convertDTOList(pbPlatformHisLogDOs);
    }
}