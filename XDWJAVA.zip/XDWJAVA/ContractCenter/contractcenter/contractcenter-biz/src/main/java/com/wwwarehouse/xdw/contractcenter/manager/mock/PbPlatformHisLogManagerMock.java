package com.wwwarehouse.xdw.contractcenter.manager.mock;

import com.wwwarehouse.commons.mybatis.BaseManagerMock;
import com.wwwarehouse.xdw.contractcenter.dao.mapper.PbPlatformHisLogDOMapper;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDO;
import com.wwwarehouse.xdw.contractcenter.manager.PbPlatformHisLogManager;
import com.wwwarehouse.xdw.contractcenter.manager.impl.PbPlatformHisLogManagerImpl;
import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDOExample;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
* PbPlatformHisLogManager
*  on 2017/6/22.
*/
public class PbPlatformHisLogManagerMock extends BaseManagerMock<PbPlatformHisLog, PbPlatformHisLogDOExample> implements PbPlatformHisLogManager {

    private static Logger _log = LoggerFactory.getLogger(PbPlatformHisLogManagerImpl.class);

    @Override
    public int insertSelective(PbPlatformHisLog pbPlatformHisLog) {
        return -1;
    }

    @Override
    public PbPlatformHisLog selectByPrimaryKey(Long pbPlatformHisLogUkid) {
        return null;
    }

    @Override
    public List<PbPlatformHisLog> selectByExample(Long pbShopRuleUkid, Long ownerUkid, Long shopUkid,
                                                  Long platformUkid, Long resourceUkid, Long itemUkid,
                                                  Long originQty, Long resourceQty) {
        return new ArrayList<PbPlatformHisLog>();
    }
}
