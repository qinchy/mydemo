package com.wwwarehouse.xdw.contractcenter.service;

import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Created by chaoyong.qin on 2017/6/22.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class PbPlatformHisLogServiceTest {
    @Resource
    PbPlatformHisLogService service;

    @Test
    public void create(){
        PbPlatformHisLog pbPlatformHisLog = new PbPlatformHisLog();
        pbPlatformHisLog.setPbShopRuleUkid(1L);
        pbPlatformHisLog.setOwnerUkid(2L);
        pbPlatformHisLog.setShopUkid(3L);
        pbPlatformHisLog.setPlatformUkid(4L);
        pbPlatformHisLog.setResourceUkid(5L);
        pbPlatformHisLog.setItemUkid(6L);
        pbPlatformHisLog.setOriginQty(7L);
        pbPlatformHisLog.setResourceQty(8L);
        pbPlatformHisLog.setCreateTime(new Date());

        int result = service.insertSelective(pbPlatformHisLog);
        System.out.println(result);
    }

    @Test
    public void selectByPrimaryKey(){
        PbPlatformHisLog pbPlatformHisLog = service.selectByPrimaryKey(52000800000003000L);
        System.out.println(pbPlatformHisLog);
    }

    @Test
    public void selectByExample() {
        Long pbShopRuleUkid = 1L, ownerUkid = 2L, shopUkid = 3L,
                platformUkid = 4L, resourceUkid = 5L, itemUkid = 6L,
                originQty = 7L, resourceQty = 8L;
        List<PbPlatformHisLog> pbPlatformHisLogs = service.selectByExample(pbShopRuleUkid, ownerUkid, shopUkid, platformUkid, resourceUkid, itemUkid, originQty, resourceQty);
        for (PbPlatformHisLog pbPlatformHisLog : pbPlatformHisLogs) {
            System.out.println(pbPlatformHisLog);
        }
    }
}
