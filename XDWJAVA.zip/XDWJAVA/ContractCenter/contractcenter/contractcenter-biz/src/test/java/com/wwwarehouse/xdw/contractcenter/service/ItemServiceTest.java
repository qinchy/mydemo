package com.wwwarehouse.xdw.contractcenter.service;

import com.wwwarehouse.xdw.contractcenter.model.Item;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by shisheng.wang on 17/6/7.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config-test.xml")
public class ItemServiceTest extends AbstractTransactionalJUnit4SpringContextTests {
    @Resource
    private ItemService itemService;

    @Test
    public void getTest(){
        Item item = itemService.get(51885300000006948L);
        System.out.println(item);
    }
}