package com.wwwarehouse.xdw.contractcenter.service;

import com.wwwarehouse.xdw.contractcenter.model.PbPlatformHisLog;

import java.util.List;

/**
 * Created by chaoyong.qin on 2017/6/21.
 */
public interface PbPlatformHisLogService {
    /**
     * 新增记录
     * @param pbPlatformHisLogDO
     * @return
     */
    int insertSelective(PbPlatformHisLog pbPlatformHisLogDO);

    /**
     * 按主键查询
     * @param pbPlatformHisLogUkid
     * @return
     */
    PbPlatformHisLog selectByPrimaryKey(Long pbPlatformHisLogUkid);

    /**
     * 按组合条件查询
     * @param pbShopRuleUkid
     * @param ownerUkid
     * @param shopUkid
     * @param platformUkid
     * @param resourceUkid
     * @param itemUkid
     * @param originQty
     * @param resourceQty
     * @return
     */
    List<PbPlatformHisLog> selectByExample(Long pbShopRuleUkid, Long ownerUkid, Long shopUkid,
                                           Long platformUkid, Long resourceUkid, Long itemUkid,
                                           Long originQty, Long resourceQty);
}
