package com.wwwarehouse.xdw.contractcenter.constant;

/**
 * 定义项目中使用的常量
 * Created by shisheng.wang on 17/6/8.
 */
public class Constants {

}
