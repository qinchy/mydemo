package com.wwwarehouse.xdw.contractcenter.model;

import java.io.Serializable;
import java.util.Date;

public class PbPlatformHisLog implements Serializable {
    private Long pbPlatformHisLogUkid;

    private Long pbShopRuleUkid;

    private Long ownerUkid;

    private Long shopUkid;

    private Long platformUkid;

    private Long resourceUkid;

    private Long itemUkid;

    private Long originQty;

    private Long resourceQty;

    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getPbPlatformHisLogUkid() {
        return pbPlatformHisLogUkid;
    }

    public void setPbPlatformHisLogUkid(Long pbPlatformHisLogUkid) {
        this.pbPlatformHisLogUkid = pbPlatformHisLogUkid;
    }

    public Long getPbShopRuleUkid() {
        return pbShopRuleUkid;
    }

    public void setPbShopRuleUkid(Long pbShopRuleUkid) {
        this.pbShopRuleUkid = pbShopRuleUkid;
    }

    public Long getOwnerUkid() {
        return ownerUkid;
    }

    public void setOwnerUkid(Long ownerUkid) {
        this.ownerUkid = ownerUkid;
    }

    public Long getShopUkid() {
        return shopUkid;
    }

    public void setShopUkid(Long shopUkid) {
        this.shopUkid = shopUkid;
    }

    public Long getPlatformUkid() {
        return platformUkid;
    }

    public void setPlatformUkid(Long platformUkid) {
        this.platformUkid = platformUkid;
    }

    public Long getResourceUkid() {
        return resourceUkid;
    }

    public void setResourceUkid(Long resourceUkid) {
        this.resourceUkid = resourceUkid;
    }

    public Long getItemUkid() {
        return itemUkid;
    }

    public void setItemUkid(Long itemUkid) {
        this.itemUkid = itemUkid;
    }

    public Long getOriginQty() {
        return originQty;
    }

    public void setOriginQty(Long originQty) {
        this.originQty = originQty;
    }

    public Long getResourceQty() {
        return resourceQty;
    }

    public void setResourceQty(Long resourceQty) {
        this.resourceQty = resourceQty;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", pbPlatformHisLogUkid=").append(pbPlatformHisLogUkid);
        sb.append(", pbShopRuleUkid=").append(pbShopRuleUkid);
        sb.append(", ownerUkid=").append(ownerUkid);
        sb.append(", shopUkid=").append(shopUkid);
        sb.append(", platformUkid=").append(platformUkid);
        sb.append(", resourceUkid=").append(resourceUkid);
        sb.append(", itemUkid=").append(itemUkid);
        sb.append(", originQty=").append(originQty);
        sb.append(", resourceQty=").append(resourceQty);
        sb.append(", createTime=").append(createTime);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        PbPlatformHisLog other = (PbPlatformHisLog) that;
        return (this.getPbPlatformHisLogUkid() == null ? other.getPbPlatformHisLogUkid() == null : this.getPbPlatformHisLogUkid().equals(other.getPbPlatformHisLogUkid()))
            && (this.getPbShopRuleUkid() == null ? other.getPbShopRuleUkid() == null : this.getPbShopRuleUkid().equals(other.getPbShopRuleUkid()))
            && (this.getOwnerUkid() == null ? other.getOwnerUkid() == null : this.getOwnerUkid().equals(other.getOwnerUkid()))
            && (this.getShopUkid() == null ? other.getShopUkid() == null : this.getShopUkid().equals(other.getShopUkid()))
            && (this.getPlatformUkid() == null ? other.getPlatformUkid() == null : this.getPlatformUkid().equals(other.getPlatformUkid()))
            && (this.getResourceUkid() == null ? other.getResourceUkid() == null : this.getResourceUkid().equals(other.getResourceUkid()))
            && (this.getItemUkid() == null ? other.getItemUkid() == null : this.getItemUkid().equals(other.getItemUkid()))
            && (this.getOriginQty() == null ? other.getOriginQty() == null : this.getOriginQty().equals(other.getOriginQty()))
            && (this.getResourceQty() == null ? other.getResourceQty() == null : this.getResourceQty().equals(other.getResourceQty()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getPbPlatformHisLogUkid() == null) ? 0 : getPbPlatformHisLogUkid().hashCode());
        result = prime * result + ((getPbShopRuleUkid() == null) ? 0 : getPbShopRuleUkid().hashCode());
        result = prime * result + ((getOwnerUkid() == null) ? 0 : getOwnerUkid().hashCode());
        result = prime * result + ((getShopUkid() == null) ? 0 : getShopUkid().hashCode());
        result = prime * result + ((getPlatformUkid() == null) ? 0 : getPlatformUkid().hashCode());
        result = prime * result + ((getResourceUkid() == null) ? 0 : getResourceUkid().hashCode());
        result = prime * result + ((getItemUkid() == null) ? 0 : getItemUkid().hashCode());
        result = prime * result + ((getOriginQty() == null) ? 0 : getOriginQty().hashCode());
        result = prime * result + ((getResourceQty() == null) ? 0 : getResourceQty().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        return result;
    }
}