package com.wwwarehouse.xdw.contractcenter.exception;

import com.wwwarehouse.commons.exception.ServiceException;
import com.wwwarehouse.xdw.contractcenter.constant.ContractResultConstant;

/**
 * Created by shisheng.wang on 17/6/16.
 * biz 异常.
 */
public class ContractCenterException extends ServiceException {
    public ContractCenterException(ContractResultConstant result) {
        this(result.getCode(), result.getMessage());
    }

    public ContractCenterException(ContractResultConstant result, Throwable cause) {
        this(result.getCode(), result.getMessage(), cause);
    }

    public ContractCenterException(ContractResultConstant result, Object... params) {
        this(result.getCode(), String.format(result.getMessage(), params));
    }

    public ContractCenterException(ContractResultConstant result, Throwable cause, Object... params) {
        this(result.getCode(), String.format(result.getMessage(), params), cause);
    }

    public ContractCenterException(int code, String message) {
        super(code, message);
    }

    public ContractCenterException(int code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
