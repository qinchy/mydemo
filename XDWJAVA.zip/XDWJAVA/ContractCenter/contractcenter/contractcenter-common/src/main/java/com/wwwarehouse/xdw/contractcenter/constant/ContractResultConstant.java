package com.wwwarehouse.xdw.contractcenter.constant;

/**
 * Created by shisheng.wang on 17/6/16.
 */
public enum ContractResultConstant {

    FAILED(0, "failed"),
    SUCCESS(1, "success"),

    // 其他错误
    UNKNOW_ERROR(70001, "unknow error!");
    //AN_ERROR(70002, "some erorr, info{0}"); // {0}表示ServiceException构造方法带参数

    public int code;

    public String message;

    ContractResultConstant(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
