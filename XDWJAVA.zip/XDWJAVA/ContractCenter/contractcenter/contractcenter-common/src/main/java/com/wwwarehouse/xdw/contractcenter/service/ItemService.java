package com.wwwarehouse.xdw.contractcenter.service;

import com.wwwarehouse.xdw.contractcenter.model.Item;

/**
 * Created by shisheng.wang on 17/6/13.
 */
public interface ItemService {
    Item get(long itemId);
    int add(Item item);
}
