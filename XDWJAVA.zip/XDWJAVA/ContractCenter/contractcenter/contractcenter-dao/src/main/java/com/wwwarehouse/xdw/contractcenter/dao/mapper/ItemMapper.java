package com.wwwarehouse.xdw.contractcenter.dao.mapper;

import com.wwwarehouse.xdw.contractcenter.dao.model.ItemDO;

/**
 * Created by shisheng.wang on 17/6/13.
 */
public interface ItemMapper {
    ItemDO selectByPrimaryKey(long itemId);
    int insert(ItemDO itemDO);
}
