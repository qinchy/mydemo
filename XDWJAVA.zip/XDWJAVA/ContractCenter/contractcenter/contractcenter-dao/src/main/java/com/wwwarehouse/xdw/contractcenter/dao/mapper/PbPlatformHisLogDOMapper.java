package com.wwwarehouse.xdw.contractcenter.dao.mapper;

import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDO;
import com.wwwarehouse.xdw.contractcenter.dao.model.PbPlatformHisLogDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PbPlatformHisLogDOMapper {
    long countByExample(PbPlatformHisLogDOExample example);

    int deleteByExample(PbPlatformHisLogDOExample example);

    int deleteByPrimaryKey(Long pbPlatformHisLogUkid);

    int insert(PbPlatformHisLogDO record);

    int insertSelective(PbPlatformHisLogDO record);

    List<PbPlatformHisLogDO> selectByExample(PbPlatformHisLogDOExample example);

    PbPlatformHisLogDO selectByPrimaryKey(Long pbPlatformHisLogUkid);

    int updateByExampleSelective(@Param("record") PbPlatformHisLogDO record, @Param("example") PbPlatformHisLogDOExample example);

    int updateByExample(@Param("record") PbPlatformHisLogDO record, @Param("example") PbPlatformHisLogDOExample example);

    int updateByPrimaryKeySelective(PbPlatformHisLogDO record);

    int updateByPrimaryKey(PbPlatformHisLogDO record);
}